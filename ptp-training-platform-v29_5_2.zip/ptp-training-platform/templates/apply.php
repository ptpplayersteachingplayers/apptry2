<?php
/**
 * Template: Apply as Trainer v29.5.1
 * Logo + Mobile Optimized
 */
defined('ABSPATH') || exit;

$error = '';
$success = false;

if (isset($_POST['ptp_apply']) && wp_verify_nonce($_POST['ptp_apply_nonce'], 'ptp_apply')) {
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $playing_level = sanitize_text_field($_POST['playing_level']);
    $college = sanitize_text_field($_POST['college']);
    $city = sanitize_text_field($_POST['city']);
    $state = sanitize_text_field($_POST['state']);
    $bio = sanitize_textarea_field($_POST['bio']);
    
    if (empty($name) || empty($email) || empty($phone) || empty($playing_level)) {
        $error = 'Please fill in all required fields.';
    } elseif (!is_email($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        global $wpdb;
        
        // Check if application with this email already exists
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_applications WHERE email = %s",
            $email
        ));
        
        // Also check if already a trainer
        $is_trainer = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE email = %s",
            $email
        ));
        
        if ($exists) {
            $error = 'An application with this email already exists. We\'ll be in touch soon!';
        } elseif ($is_trainer) {
            $error = 'You\'re already registered as a trainer. Please log in to your account.';
        } else {
            // Build location string
            $location = trim($city . ', ' . $state);
            
            // Insert into applications table
            $result = $wpdb->insert(
                $wpdb->prefix . 'ptp_applications',
                array(
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone,
                    'playing_level' => $playing_level,
                    'college' => $college,
                    'location' => $location,
                    'bio' => $bio,
                    'hourly_rate' => 70,
                    'status' => 'pending',
                    'created_at' => current_time('mysql')
                ),
                array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%s', '%s')
            );
            
            if ($result) {
                $success = true;
                $app_id = $wpdb->insert_id;
                
                // Send notification email to admin
                $admin_email = get_option('admin_email');
                $subject = 'New Trainer Application - ' . $name;
                $message = "New trainer application received:\n\n";
                $message .= "Name: $name\n";
                $message .= "Email: $email\n";
                $message .= "Phone: $phone\n";
                $message .= "Level: $playing_level\n";
                $message .= "College: $college\n";
                $message .= "Location: $location\n\n";
                $message .= "Bio:\n$bio\n\n";
                $message .= "Review in admin dashboard:\n";
                $message .= admin_url('admin.php?page=ptp-applications');
                
                wp_mail($admin_email, $subject, $message);
                
                // Send confirmation email to applicant
                if (class_exists('PTP_Email')) {
                    PTP_Email::send_application_received($email, $name);
                }
            } else {
                $error = 'Something went wrong. Please try again. Error: ' . $wpdb->last_error;
            }
        }
    }
}

$logo_url = PTP_Images::logo();
$hero_bg = PTP_Images::get('BG7A1642');

get_header();
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
*{box-sizing:border-box;margin:0;padding:0}
.ptp-apply{font-family:'Inter',-apple-system,sans-serif;-webkit-font-smoothing:antialiased}
.ptp-apply input:focus,.ptp-apply select:focus,.ptp-apply textarea:focus{border-color:#FCB900!important;outline:none}
@media(max-width:768px){
    .ptp-apply-hero h1{font-size:32px!important}
    .ptp-apply-grid{grid-template-columns:1fr!important}
    .ptp-apply-form{padding:24px 20px!important;margin:0 16px!important;border-radius:20px!important}
    .ptp-apply-benefits{padding:40px 16px!important}
    .ptp-apply-form-wrap{padding:40px 0!important}
    .ptp-form-row{grid-template-columns:1fr!important}
}
</style>

<div class="ptp-apply">
    <!-- Hero with Background Image -->
    <div style="background:linear-gradient(135deg,rgba(14,15,17,0.85),rgba(14,15,17,0.75)),url('<?php echo esc_url($hero_bg); ?>') center/cover;padding:60px 24px 80px;text-align:center">
        <div style="max-width:700px;margin:0 auto">
            <!-- Logo -->
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Soccer" style="height:50px;width:auto;margin-bottom:32px">
            
            <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(252,185,0,0.15);color:#FCB900;padding:10px 20px;border-radius:50px;font-size:14px;font-weight:600;margin-bottom:20px">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                Join Our Team
            </div>
            <h1 class="ptp-apply-hero" style="font-size:48px;font-weight:900;color:#fff;margin:0 0 16px;line-height:1.1">Become a <span style="color:#FCB900">PTP Trainer</span></h1>
            <p style="font-size:18px;color:rgba(255,255,255,0.8);margin:0;line-height:1.6">Share your skills, earn money on your schedule, and inspire the next generation of soccer players.</p>
        </div>
    </div>

    <?php if ($success): ?>
    <!-- Success State -->
    <div style="padding:80px 24px;background:#F9FAFB">
        <div style="max-width:500px;margin:0 auto;text-align:center">
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Soccer" style="height:40px;width:auto;margin-bottom:24px">
            <div style="width:80px;height:80px;background:#ECFDF5;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 24px">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <h2 style="font-size:28px;font-weight:800;color:#111;margin:0 0 12px">Application Submitted!</h2>
            <p style="font-size:16px;color:#6B7280;margin:0 0 32px;line-height:1.6">Thanks for applying to become a PTP trainer. We'll review your application and get back to you within 24-48 hours.</p>
            <a href="<?php echo esc_url(home_url('/')); ?>" style="display:inline-flex;align-items:center;gap:8px;padding:16px 32px;background:#FCB900;color:#0E0F11;border-radius:12px;font-size:16px;font-weight:700;text-decoration:none">Back to Home</a>
        </div>
    </div>
    <?php else: ?>
    
    <!-- Benefits -->
    <div class="ptp-apply-benefits" style="padding:60px 24px;background:#fff">
        <div style="max-width:1000px;margin:0 auto">
            <div class="ptp-apply-grid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:32px">
                <div style="text-align:center;padding:24px">
                    <div style="width:64px;height:64px;background:#FEF3C7;border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6"/></svg>
                    </div>
                    <h3 style="font-size:18px;font-weight:700;color:#111;margin:0 0 8px">Earn $50-100/hr</h3>
                    <p style="font-size:14px;color:#6B7280;margin:0;line-height:1.6">Set your own rates and earn what you're worth. Top trainers make $1,000+ per week.</p>
                </div>
                <div style="text-align:center;padding:24px">
                    <div style="width:64px;height:64px;background:#DBEAFE;border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/></svg>
                    </div>
                    <h3 style="font-size:18px;font-weight:700;color:#111;margin:0 0 8px">Flexible Schedule</h3>
                    <p style="font-size:14px;color:#6B7280;margin:0;line-height:1.6">Train when you want, where you want. You're in complete control of your availability.</p>
                </div>
                <div style="text-align:center;padding:24px">
                    <div style="width:64px;height:64px;background:#FCE7F3;border-radius:16px;display:flex;align-items:center;justify-content:center;margin:0 auto 16px">
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#EC4899" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                    </div>
                    <h3 style="font-size:18px;font-weight:700;color:#111;margin:0 0 8px">Make an Impact</h3>
                    <p style="font-size:14px;color:#6B7280;margin:0;line-height:1.6">Mentor young players and share the knowledge that helped you succeed.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Application Form -->
    <div class="ptp-apply-form-wrap" style="padding:60px 24px;background:#F9FAFB">
        <div style="max-width:600px;margin:0 auto">
            <div class="ptp-apply-form" style="background:#fff;border-radius:24px;padding:40px;box-shadow:0 10px 40px rgba(0,0,0,0.08)">
                <h2 style="font-size:24px;font-weight:800;color:#111;margin:0 0 8px;text-align:center">Apply Now</h2>
                <p style="font-size:15px;color:#6B7280;margin:0 0 32px;text-align:center">Tell us about your soccer background</p>
                
                <?php if ($error): ?>
                <div style="padding:14px 16px;background:#FEF2F2;border:1px solid #FECACA;border-radius:12px;margin-bottom:20px;display:flex;align-items:center;gap:10px">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                    <span style="font-size:14px;color:#DC2626"><?php echo esc_html($error); ?></span>
                </div>
                <?php endif; ?>
                
                <form method="post" action="">
                    <?php wp_nonce_field('ptp_apply', 'ptp_apply_nonce'); ?>
                    <input type="hidden" name="ptp_apply" value="1">
                    
                    <div style="margin-bottom:16px">
                        <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">Full Name *</label>
                        <input type="text" name="name" required style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px" placeholder="Your name">
                    </div>
                    
                    <div class="ptp-form-row" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
                        <div>
                            <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">Email *</label>
                            <input type="email" name="email" required style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px" placeholder="you@email.com">
                        </div>
                        <div>
                            <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">Phone *</label>
                            <input type="tel" name="phone" required style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px" placeholder="(555) 123-4567">
                        </div>
                    </div>
                    
                    <div style="margin-bottom:16px">
                        <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">Playing Level *</label>
                        <select name="playing_level" required style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px;background:#fff;cursor:pointer">
                            <option value="">Select your highest level</option>
                            <option value="pro">Professional (MLS, USL, etc.)</option>
                            <option value="college_d1">NCAA Division 1</option>
                            <option value="college_d2">NCAA Division 2</option>
                            <option value="college_d3">NCAA Division 3</option>
                            <option value="semi_pro">Semi-Professional</option>
                            <option value="academy">MLS Academy</option>
                        </select>
                    </div>
                    
                    <div style="margin-bottom:16px">
                        <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">College/Team</label>
                        <input type="text" name="college" style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px" placeholder="e.g., Villanova University">
                    </div>
                    
                    <div class="ptp-form-row" style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px">
                        <div>
                            <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">City *</label>
                            <input type="text" name="city" required style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px" placeholder="Philadelphia">
                        </div>
                        <div>
                            <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">State *</label>
                            <select name="state" required style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px;background:#fff">
                                <option value="">Select</option>
                                <option value="PA">Pennsylvania</option>
                                <option value="NJ">New Jersey</option>
                                <option value="DE">Delaware</option>
                                <option value="MD">Maryland</option>
                                <option value="NY">New York</option>
                            </select>
                        </div>
                    </div>
                    
                    <div style="margin-bottom:24px">
                        <label style="display:block;font-size:14px;font-weight:600;color:#374151;margin-bottom:8px">Tell us about yourself</label>
                        <textarea name="bio" rows="4" style="width:100%;padding:14px 16px;border:2px solid #E5E7EB;border-radius:12px;font-family:inherit;font-size:16px;resize:vertical" placeholder="Your soccer background, achievements, and why you want to coach..."></textarea>
                    </div>
                    
                    <button type="submit" style="width:100%;padding:18px;background:#FCB900;color:#0E0F11;border:none;border-radius:12px;font-family:inherit;font-size:17px;font-weight:700;cursor:pointer">
                        Submit Application
                    </button>
                    
                    <p style="font-size:13px;color:#9CA3AF;text-align:center;margin:16px 0 0">
                        By applying, you agree to our background check policy
                    </p>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
