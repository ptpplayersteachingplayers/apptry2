# PTP Training Platform v24.9.6

Complete 1-on-1 soccer training marketplace connecting parents with elite NCAA and professional trainers.

## Features

### Core Platform
- **Trainer Marketplace** - Browse and search verified trainers by location, specialty, rating
- **Booking System** - 3-step booking wizard with calendar, time slots, and payment
- **Dual Confirmation** - Both parent and trainer must confirm session completion
- **Messaging** - In-app messaging between parents and trainers
- **Reviews & Ratings** - 5-star rating system with text reviews
- **Player Profiles** - Manage multiple children with skill levels and goals

### Integrations

#### 💳 Stripe Payments
- Payment Intent API for secure card processing
- Stripe Connect for automatic trainer payouts
- Webhook handling for payment events
- Refund processing for cancellations
- Test and Live mode support

#### 📱 Twilio SMS
- Booking confirmation notifications
- Session reminders (24 hours before)
- Cancellation alerts
- New message notifications
- Completion confirmation requests

#### 📧 Email System
- HTML email templates with branding
- Booking confirmations
- Session reminders
- Review requests
- Welcome emails
- Application status updates
- Payout notifications

#### 🔍 SEO
- Dynamic meta tags per page
- Open Graph for Facebook/LinkedIn
- Twitter Cards
- Schema.org structured data (Person, Service, FAQ)
- Breadcrumb markup
- Trainer sitemap generation

#### 📱 Social Media
- Social share buttons (Facebook, Twitter, LinkedIn, WhatsApp, Email)
- Instagram feed integration
- Facebook pixel tracking
- Social proof widgets

#### 📍 Geocoding
- Google Maps API integration
- ZIP code to coordinates conversion
- Distance-based trainer search
- Location autocomplete

## Installation

1. Upload `ptp-training-platform` folder to `/wp-content/plugins/`
2. Activate the plugin through WordPress admin
3. Configure settings under **PTP Training → Settings**

## Configuration

### Stripe Setup
1. Go to PTP Training → Settings → Payments
2. Enter your Stripe API keys (test or live)
3. Add webhook endpoint to Stripe Dashboard
4. Enable Stripe Connect for automatic payouts

### Twilio SMS Setup
1. Go to PTP Training → Settings → SMS
2. Enter Account SID, Auth Token, and From Number
3. Test with your phone number

### Social Media Setup
1. Go to PTP Training → Settings → Social
2. Add your social media URLs
3. Configure Facebook Pixel ID (optional)

## Pages Created

| URL | Shortcode | Description |
|-----|-----------|-------------|
| /find-trainers/ | [ptp_trainers_grid] | Search and browse trainers |
| /trainer-profile/ | [ptp_trainer_profile] | Individual trainer page |
| /book-session/ | [ptp_booking_form] | Booking wizard |
| /booking-confirmation/ | [ptp_booking_confirmation] | Success page |
| /my-training/ | [ptp_my_training] | Parent dashboard |
| /trainer-dashboard/ | [ptp_trainer_dashboard] | Trainer dashboard |
| /messages/ | [ptp_messaging] | Messaging interface |
| /account/ | [ptp_account] | Account settings |
| /login/ | [ptp_login] | Login page |
| /register/ | [ptp_register] | Parent registration |
| /become-a-trainer/ | [ptp_trainer_application] | Trainer application |

## Database Tables (17 total)

- `ptp_trainers` - Trainer profiles
- `ptp_parents` - Parent profiles
- `ptp_players` - Children profiles
- `ptp_bookings` - Session bookings
- `ptp_availability` - Weekly schedules
- `ptp_availability_exceptions` - Date overrides
- `ptp_messages` - Chat messages
- `ptp_conversations` - Message threads
- `ptp_reviews` - Ratings and reviews
- `ptp_notifications` - In-app notifications
- `ptp_payouts` - Payout records
- `ptp_payout_items` - Payout line items
- `ptp_applications` - Trainer applications
- `ptp_activity_log` - Activity tracking
- `ptp_sms_log` - SMS history
- `ptp_social_posts` - Social feed cache
- `ptp_geocode_cache` - Location cache

## Scheduled Tasks (Cron)

- **Hourly**: Session reminders, review requests, completion confirmations
- **Daily**: Payout processing
- **Weekly**: Data cleanup (90+ day old notifications, logs)

## API Endpoints

### REST API
- `POST /wp-json/ptp/v1/stripe-webhook` - Stripe webhook handler

### AJAX Actions
- `ptp_search_trainers` - Search/filter trainers
- `ptp_get_availability` - Get trainer availability
- `ptp_create_booking` - Create new booking
- `ptp_confirm_booking` - Confirm session completion
- `ptp_cancel_booking` - Cancel booking
- `ptp_send_message` - Send message
- `ptp_get_messages` - Load messages
- `ptp_add_player` - Add child profile
- `ptp_submit_review` - Submit review
- `ptp_update_availability` - Update trainer schedule
- `ptp_submit_application` - Trainer application

## File Structure

```
ptp-training-platform/
├── ptp-training-platform.php    # Main plugin file
├── README.md                    # This file
├── admin/
│   └── class-ptp-admin.php      # Admin interface
├── assets/
│   ├── css/
│   │   ├── admin.css            # Admin styles
│   │   └── frontend.css         # Frontend styles (27KB)
│   └── js/
│       ├── admin.js             # Admin scripts
│       └── frontend.js          # Frontend scripts (23KB)
├── includes/
│   ├── class-ptp-ajax.php       # AJAX handlers
│   ├── class-ptp-availability.php
│   ├── class-ptp-booking.php
│   ├── class-ptp-cron.php       # Scheduled tasks
│   ├── class-ptp-database.php   # Database schema
│   ├── class-ptp-email.php      # Email system
│   ├── class-ptp-geocoding.php  # Location services
│   ├── class-ptp-messaging.php
│   ├── class-ptp-notifications.php
│   ├── class-ptp-parent.php
│   ├── class-ptp-payments.php
│   ├── class-ptp-player.php
│   ├── class-ptp-reviews.php
│   ├── class-ptp-seo.php        # SEO & meta tags
│   ├── class-ptp-settings.php   # Settings page
│   ├── class-ptp-shortcodes.php
│   ├── class-ptp-sms.php        # Twilio integration
│   ├── class-ptp-social.php     # Social media
│   ├── class-ptp-stripe.php     # Payment processing
│   ├── class-ptp-templates.php
│   ├── class-ptp-trainer.php
│   └── class-ptp-user.php
└── templates/
    ├── account.php
    ├── booking-confirmation.php
    ├── booking-form.php
    ├── login.php
    ├── messaging.php
    ├── my-training.php
    ├── register.php
    ├── trainer-application.php
    ├── trainer-dashboard.php
    ├── trainer-profile.php
    └── trainers-grid.php
```

## Requirements

- WordPress 6.0+
- PHP 7.4+
- MySQL 5.7+
- SSL certificate (for payments)

## Support

For support, contact PTP Soccer at https://ptpsummercamps.com

## Changelog

### v24.9.6
- **Security**: Fixed XSS vulnerability in message rendering - now uses safe DOM manipulation
- **Performance**: Improved message polling with visibility-based pause/resume
- **Performance**: Added cleanup for polling intervals to prevent memory leaks
- **UX**: Enhanced trainer filtering with actual AJAX calls and URL state management
- **UX**: Improved auth form error handling with inline error display
- **UX**: Added success messages before redirects for better user feedback
- **Accessibility**: Added focus-visible states for keyboard navigation
- **Accessibility**: Added ARIA busy attributes to async operations
- **Accessibility**: Enhanced form focus states with improved visibility
- **Code**: Updated JavaScript to v19 with comprehensive error handling
- **Code**: Updated CSS to v23.4.0 with accessibility improvements

### v24.9.5
- Admin calendar scheduling improvements
- Training plan packages
- Tax reporting features

### v12.0.0
- Complete platform rebuild
- Added Stripe Connect for payouts
- Added Twilio SMS integration
- Added comprehensive email system
- Added SEO with Schema.org markup
- Added social media integration
- Added geocoding for location search
- New TeachMeTo-inspired UI design
- Mobile-first responsive design
