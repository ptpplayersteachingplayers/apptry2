<?php
/**
 * Template: Trainer Application - Simplified Single Step v24.1
 * Minimal barrier to entry - just the essentials
 */
defined('ABSPATH') || exit;

$playing_levels = array(
    'pro' => 'Professional (MLS, USL, NWSL, etc.)',
    'college_d1' => 'NCAA Division 1',
    'college_d2' => 'NCAA Division 2',
    'college_d3' => 'NCAA Division 3',
    'academy' => 'MLS/NWSL Academy',
    'semi_pro' => 'Semi-Professional',
    'high_level_club' => 'High-Level Club (ECNL, GA, MLS Next)',
);
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
* { box-sizing: border-box; }
html, body { overflow-x: hidden !important; max-width: 100vw; }

.ptp-apply {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    min-height: 100vh;
    background: #FFFFFF;
    color: #111827;
    overflow-x: hidden;
}

.ptp-apply-header {
    padding: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    max-width: 500px;
    margin: 0 auto;
}

.ptp-apply-logo { height: 32px; }

.ptp-apply-login {
    color: #6B7280;
    font-size: 13px;
    text-decoration: none;
}

.ptp-apply-login:hover { color: #111827; }

.ptp-apply-main {
    max-width: 500px;
    margin: 0 auto;
    padding: 20px 16px 60px;
}

.ptp-apply-hero {
    text-align: center;
    margin-bottom: 32px;
}

.ptp-apply-badge {
    display: inline-block;
    background: rgba(252,185,0,0.15);
    color: #B45309;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    margin-bottom: 16px;
}

.ptp-apply-title {
    font-size: 32px;
    font-weight: 800;
    color: #111827;
    margin: 0 0 12px;
    line-height: 1.15;
}

.ptp-apply-subtitle {
    font-size: 15px;
    color: #6B7280;
    margin: 0;
    line-height: 1.5;
}

.ptp-apply-card {
    background: #F9FAFB;
    border: 1px solid #E5E7EB;
    border-radius: 20px;
    padding: 28px 24px;
    margin-bottom: 20px;
}

.ptp-form-row {
    display: grid;
    grid-template-columns: 1fr;
    gap: 12px;
}

@media (min-width: 480px) {
    .ptp-form-row { grid-template-columns: 1fr 1fr; }
}

.ptp-form-group { margin-bottom: 18px; }
.ptp-form-group:last-child { margin-bottom: 0; }

.ptp-form-label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #374151;
    margin-bottom: 6px;
}

.ptp-form-input, .ptp-form-select {
    width: 100%;
    padding: 14px 16px;
    border: 1.5px solid #E5E7EB;
    border-radius: 12px;
    font-size: 16px;
    font-family: inherit;
    transition: all 0.2s;
    background: #fff;
}

.ptp-form-input:focus, .ptp-form-select:focus {
    outline: none;
    border-color: #FCB900;
    box-shadow: 0 0 0 3px rgba(252,185,0,0.15);
}

.ptp-form-input::placeholder { color: #9CA3AF; }
.ptp-form-input.error { border-color: #EF4444; }

.ptp-password-wrap { position: relative; }

.ptp-password-toggle {
    position: absolute;
    right: 14px;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    cursor: pointer;
    color: #9CA3AF;
    padding: 4px;
}

.ptp-password-toggle:hover { color: #6B7280; }

.ptp-submit-btn {
    width: 100%;
    padding: 16px 24px;
    background: #FCB900;
    color: #0F172A;
    border: none;
    border-radius: 12px;
    font-size: 16px;
    font-weight: 700;
    cursor: pointer;
    transition: all 0.2s;
    margin-top: 8px;
}

.ptp-submit-btn:hover { background: #E5A800; }
.ptp-submit-btn:disabled { opacity: 0.6; cursor: not-allowed; }

.ptp-terms {
    display: flex;
    gap: 10px;
    align-items: flex-start;
    margin-top: 20px;
    padding-top: 20px;
    border-top: 1px solid #E5E7EB;
}

.ptp-terms input {
    width: 18px;
    height: 18px;
    margin-top: 2px;
    accent-color: #FCB900;
    flex-shrink: 0;
}

.ptp-terms-text {
    font-size: 13px;
    color: #6B7280;
    line-height: 1.5;
}

.ptp-terms-text a { color: #B45309; text-decoration: none; }

.ptp-benefits {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}

.ptp-benefit {
    display: flex;
    align-items: center;
    gap: 12px;
    color: #374151;
    font-size: 14px;
}

.ptp-benefit-icon {
    width: 36px;
    height: 36px;
    background: rgba(252,185,0,0.15);
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.ptp-benefit-icon svg { width: 18px; height: 18px; color: #B45309; }

.ptp-error {
    background: #FEF2F2;
    border: 1px solid #FECACA;
    color: #DC2626;
    padding: 12px 16px;
    border-radius: 10px;
    font-size: 14px;
    margin-bottom: 16px;
    display: none;
}

.ptp-error.show { display: block; }

.ptp-success-card { text-align: center; padding: 40px 24px; }

.ptp-success-icon {
    width: 72px;
    height: 72px;
    background: #D1FAE5;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 20px;
}

.ptp-success-icon svg { width: 36px; height: 36px; color: #10B981; }

.ptp-success-title {
    font-size: 22px;
    font-weight: 800;
    color: #111827;
    margin: 0 0 10px;
}

.ptp-success-text {
    font-size: 15px;
    color: #6B7280;
    margin: 0 0 24px;
    line-height: 1.6;
}

.ptp-success-btn {
    display: inline-block;
    background: #0F172A;
    color: #fff;
    padding: 14px 28px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 15px;
    text-decoration: none;
}

.ptp-footer-note {
    text-align: center;
    color: #9CA3AF;
    font-size: 12px;
    margin-top: 24px;
}

/* Mobile Optimizations */
@media (max-width: 600px) {
    .ptp-apply {
        padding: 16px;
    }
    
    .ptp-apply-header {
        flex-direction: column;
        gap: 12px;
        align-items: flex-start;
    }
    
    .ptp-apply-title {
        font-size: 26px;
    }
    
    .ptp-apply-subtitle {
        font-size: 14px;
    }
    
    .ptp-apply-card {
        padding: 20px 16px;
        border-radius: 16px;
    }
    
    .ptp-form-input,
    .ptp-form-select,
    .ptp-form-textarea {
        padding: 16px;
        font-size: 16px;
        min-height: 52px;
    }
    
    .ptp-submit-btn {
        padding: 18px 24px;
        font-size: 16px;
        min-height: 56px;
    }
    
    .ptp-benefits {
        grid-template-columns: 1fr;
        gap: 12px;
    }
    
    .ptp-benefit {
        padding: 14px;
    }
}

@media (max-width: 400px) {
    .ptp-apply-title {
        font-size: 22px;
    }
}
</style>

<div class="ptp-apply">
    <div class="ptp-apply-header">
        <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png" alt="PTP" class="ptp-apply-logo">
        <a href="<?php echo home_url('/login/'); ?>" class="ptp-apply-login">Already applied? Log in</a>
    </div>
    
    <div class="ptp-apply-main">
        <div class="ptp-apply-hero">
            <div class="ptp-apply-badge" style="background: linear-gradient(135deg, #7C3AED 0%, #5B21B6 100%); color: #fff;">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="#FCD34D"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                For Current &amp; Former College/Pro Players
            </div>
            <h1 class="ptp-apply-title">Join the Team</h1>
            <p class="ptp-apply-subtitle">Train the next generation. Earn $50-$100+/hr doing what you love. We welcome all current and former collegiate and professional players.</p>
            <div class="ptp-apply-stats" style="display:flex;gap:24px;justify-content:center;margin-top:16px;">
                <div style="text-align:center;">
                    <div style="font-size:24px;font-weight:800;color:#111;">250+</div>
                    <div style="font-size:12px;color:#6B7280;">Families Helped</div>
                </div>
                <div style="text-align:center;">
                    <div style="font-size:24px;font-weight:800;color:#111;">5.0★</div>
                    <div style="font-size:12px;color:#6B7280;">Average Rating</div>
                </div>
                <div style="text-align:center;">
                    <div style="font-size:24px;font-weight:800;color:#111;">$75</div>
                    <div style="font-size:12px;color:#6B7280;">Avg Hourly Rate</div>
                </div>
            </div>
        </div>
        
        <div class="ptp-apply-card" id="apply-card">
            <form id="apply-form">
                <div class="ptp-error" id="error-msg"></div>
                
                <div class="ptp-form-row">
                    <div class="ptp-form-group">
                        <label class="ptp-form-label">First Name</label>
                        <input type="text" name="first_name" class="ptp-form-input" required placeholder="John">
                    </div>
                    <div class="ptp-form-group">
                        <label class="ptp-form-label">Last Name</label>
                        <input type="text" name="last_name" class="ptp-form-input" required placeholder="Smith">
                    </div>
                </div>
                
                <div class="ptp-form-group">
                    <label class="ptp-form-label">Email</label>
                    <input type="email" name="email" class="ptp-form-input" required placeholder="john@example.com">
                </div>
                
                <div class="ptp-form-group">
                    <label class="ptp-form-label">Password</label>
                    <div class="ptp-password-wrap">
                        <input type="password" name="password" class="ptp-form-input" id="password" required minlength="8" placeholder="Min 8 characters">
                        <button type="button" class="ptp-password-toggle" onclick="togglePassword()">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                </div>
                
                <div class="ptp-form-row">
                    <div class="ptp-form-group">
                        <label class="ptp-form-label">City</label>
                        <input type="text" name="city" class="ptp-form-input" required placeholder="Philadelphia">
                    </div>
                    <div class="ptp-form-group">
                        <label class="ptp-form-label">State</label>
                        <select name="state" class="ptp-form-select" required>
                            <option value="">Select</option>
                            <option value="PA">Pennsylvania</option>
                            <option value="NJ">New Jersey</option>
                            <option value="DE">Delaware</option>
                            <option value="MD">Maryland</option>
                            <option value="NY">New York</option>
                            <option value="CT">Connecticut</option>
                            <option value="MA">Massachusetts</option>
                            <option value="VA">Virginia</option>
                            <option value="DC">Washington DC</option>
                            <option value="CA">California</option>
                            <option value="TX">Texas</option>
                            <option value="FL">Florida</option>
                            <option value="IL">Illinois</option>
                            <option value="OH">Ohio</option>
                            <option value="GA">Georgia</option>
                            <option value="NC">North Carolina</option>
                            <option value="other">Other</option>
                        </select>
                    </div>
                </div>
                
                <div class="ptp-form-group">
                    <label class="ptp-form-label">Playing Level</label>
                    <select name="playing_level" class="ptp-form-select" required>
                        <option value="">Select your level</option>
                        <?php foreach ($playing_levels as $key => $label): ?>
                            <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="ptp-terms">
                    <input type="checkbox" name="terms" id="terms" required>
                    <label for="terms" class="ptp-terms-text">I agree to the <a href="#">Terms</a> and <a href="#">Privacy Policy</a></label>
                </div>
                
                <button type="submit" class="ptp-submit-btn" id="submit-btn">Apply Now</button>
            </form>
        </div>
        
        <div class="ptp-apply-card ptp-success-card" id="success-card" style="display: none;">
            <div class="ptp-success-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <h2 class="ptp-success-title">Application Received!</h2>
            <p class="ptp-success-text">We'll review your application and get back to you within 24-48 hours. Check your email for next steps.</p>
            <a href="<?php echo home_url('/'); ?>" class="ptp-success-btn">Back to Home</a>
        </div>
        
        <div class="ptp-benefits">
            <div class="ptp-benefit">
                <div class="ptp-benefit-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
                <span>$50-$100+/hour</span>
            </div>
            <div class="ptp-benefit">
                <div class="ptp-benefit-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
                <span>Full insurance</span>
            </div>
            <div class="ptp-benefit">
                <div class="ptp-benefit-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></div>
                <span>We find clients</span>
            </div>
            <div class="ptp-benefit">
                <div class="ptp-benefit-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg></div>
                <span>Elite brand</span>
            </div>
        </div>
        
        <div style="background:#F0FDF4;border:1px solid #BBF7D0;border-radius:12px;padding:16px;margin-top:16px;">
            <div style="font-weight:700;color:#166534;font-size:14px;margin-bottom:8px;">Why train with PTP?</div>
            <p style="color:#15803D;font-size:13px;margin:0;line-height:1.6;">We're not like other platforms that accept anyone. PTP trainers are current and former college and professional players who know what it takes to compete at the highest levels.</p>
        </div>
        
        <p class="ptp-footer-note">Questions? Email us at luke@ptpsummercamps.com</p>
    </div>
</div>

<script>
function togglePassword() {
    const input = document.getElementById('password');
    input.type = input.type === 'password' ? 'text' : 'password';
}

document.getElementById('apply-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const form = this;
    const btn = document.getElementById('submit-btn');
    const errorEl = document.getElementById('error-msg');
    
    errorEl.classList.remove('show');
    form.querySelectorAll('.ptp-form-input').forEach(el => el.classList.remove('error'));
    
    const password = form.password.value;
    if (password.length < 8) {
        errorEl.textContent = 'Password must be at least 8 characters';
        errorEl.classList.add('show');
        form.password.classList.add('error');
        return;
    }
    
    btn.disabled = true;
    btn.textContent = 'Submitting...';
    
    const formData = new FormData(form);
    formData.append('action', 'ptp_submit_application');
    formData.append('nonce', '<?php echo wp_create_nonce('ptp_nonce'); ?>');
    formData.append('password_confirm', password); // Add password confirm to match backend
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            document.getElementById('apply-card').style.display = 'none';
            document.getElementById('success-card').style.display = 'block';
            window.scrollTo(0, 0);
        } else {
            errorEl.textContent = data.data?.message || 'Something went wrong. Please try again.';
            errorEl.classList.add('show');
            btn.disabled = false;
            btn.textContent = 'Apply Now';
        }
    })
    .catch(err => {
        errorEl.textContent = 'Connection error. Please try again.';
        errorEl.classList.add('show');
        btn.disabled = false;
        btn.textContent = 'Apply Now';
    });
});
</script>
