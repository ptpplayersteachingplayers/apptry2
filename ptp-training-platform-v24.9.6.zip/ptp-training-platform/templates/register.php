<?php
/**
 * Template: Register - Modern Split-Screen Design
 * v24.9.4 - Clean, professional auth page
 */
defined('ABSPATH') || exit;

$logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
$img = 'https://ptpsummercamps.com/wp-content/uploads/2025/09/august-18-soccer-camp-goal-celebration.jpg-scaled.jpg';
$error = '';

if (isset($_POST['ptp_register']) && wp_verify_nonce($_POST['ptp_register_nonce'], 'ptp_register')) {
    $email = sanitize_email($_POST['email']);
    $password = $_POST['password'];
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $phone = sanitize_text_field($_POST['phone']);
    
    if (empty($email) || empty($password) || empty($first_name) || empty($last_name)) {
        $error = 'Please fill in all required fields.';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif (email_exists($email)) {
        $error = 'An account with this email already exists. <a href="' . home_url('/login/') . '" style="color:#991B1B;font-weight:600;">Sign in instead</a>';
    } else {
        $user_id = wp_create_user($email, $password, $email);
        
        if (is_wp_error($user_id)) {
            $error = $user_id->get_error_message();
        } else {
            wp_update_user(array(
                'ID' => $user_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'display_name' => $first_name . ' ' . $last_name
            ));
            
            update_user_meta($user_id, 'phone', $phone);
            
            $user = new WP_User($user_id);
            $user->set_role('ptp_parent');
            
            if (class_exists('PTP_Parent')) {
                PTP_Parent::create($user_id, array(
                    'display_name' => $first_name . ' ' . $last_name,
                    'phone' => $phone
                ));
            }
            
            if (class_exists('PTP_Email') && method_exists('PTP_Email', 'send_welcome_parent')) {
                PTP_Email::send_welcome_parent($user_id);
            }
            
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);
            
            wp_redirect(home_url('/my-training/'));
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account | PTP Training</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { overflow-x: hidden; max-width: 100vw; }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            min-height: 100vh;
            display: flex;
            background: #fff;
        }
        
        .auth-layout {
            display: flex;
            width: 100%;
            min-height: 100vh;
        }
        
        .auth-form-side {
            width: 100%;
            display: flex;
            flex-direction: column;
            padding: 24px;
            overflow-y: auto;
        }
        
        @media (min-width: 1024px) {
            .auth-form-side {
                width: 50%;
                max-width: 600px;
                padding: 40px 60px;
            }
        }
        
        .auth-image-side {
            display: none;
            flex: 1;
            background: url('<?php echo esc_url($img); ?>') center/cover no-repeat;
            position: relative;
        }
        
        .auth-image-side::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(14, 15, 17, 0.7) 0%, rgba(14, 15, 17, 0.4) 100%);
        }
        
        @media (min-width: 1024px) {
            .auth-image-side { display: block; }
        }
        
        .auth-image-content {
            position: absolute;
            bottom: 60px;
            left: 60px;
            right: 60px;
            color: #fff;
            z-index: 2;
        }
        
        .auth-image-title {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 12px;
            line-height: 1.2;
        }
        
        .auth-image-text {
            font-size: 16px;
            opacity: 0.9;
            line-height: 1.6;
        }
        
        .auth-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 40px;
        }
        
        .auth-logo img {
            height: 40px;
            width: auto;
        }
        
        .auth-header-link {
            font-size: 14px;
            color: #6B7280;
        }
        
        .auth-header-link a {
            color: #FCB900;
            font-weight: 600;
            text-decoration: none;
        }
        
        .auth-header-link a:hover {
            text-decoration: underline;
        }
        
        .auth-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-width: 400px;
            margin: 0 auto;
            width: 100%;
        }
        
        .auth-title {
            font-size: 28px;
            font-weight: 800;
            color: #111;
            margin-bottom: 8px;
        }
        
        .auth-subtitle {
            font-size: 15px;
            color: #6B7280;
            margin-bottom: 28px;
        }
        
        .auth-error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        
        .form-group {
            margin-bottom: 18px;
        }
        
        .form-row-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        
        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }
        
        .form-input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #E5E7EB;
            border-radius: 10px;
            font-size: 16px;
            font-family: inherit;
            transition: all 0.2s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #FCB900;
            box-shadow: 0 0 0 3px rgba(252, 185, 0, 0.15);
        }
        
        .form-hint {
            font-size: 12px;
            color: #9CA3AF;
            margin-top: 6px;
        }
        
        .btn-submit {
            width: 100%;
            padding: 16px;
            background: #FCB900;
            color: #0E0F11;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 8px;
        }
        
        .btn-submit:hover {
            background: #E5A800;
            transform: translateY(-1px);
        }
        
        .auth-terms {
            font-size: 13px;
            color: #9CA3AF;
            text-align: center;
            margin-top: 20px;
            line-height: 1.5;
        }
        
        .auth-terms a {
            color: #6B7280;
        }
        
        .auth-divider {
            display: flex;
            align-items: center;
            margin: 24px 0;
            color: #9CA3AF;
            font-size: 13px;
        }
        
        .auth-divider::before,
        .auth-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #E5E7EB;
        }
        
        .auth-divider span {
            padding: 0 16px;
        }
        
        .trainer-cta {
            text-align: center;
            padding: 20px;
            background: #F9FAFB;
            border-radius: 12px;
            border: 1px solid #E5E7EB;
        }
        
        .trainer-cta p {
            font-size: 14px;
            color: #6B7280;
            margin-bottom: 10px;
        }
        
        .trainer-cta a {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #0E0F11;
            font-weight: 600;
            text-decoration: none;
        }
        
        .trainer-cta a:hover {
            color: #FCB900;
        }
        
        .auth-footer {
            text-align: center;
            padding-top: 24px;
            margin-top: auto;
        }
        
        .auth-footer p {
            font-size: 13px;
            color: #9CA3AF;
        }
        
        .auth-footer a {
            color: #6B7280;
            text-decoration: none;
        }
        
        .auth-footer a:hover {
            color: #FCB900;
        }
        
        /* Mobile Optimizations */
        @media (max-width: 600px) {
            .auth-form-side {
                padding: 20px 16px;
            }
            
            .auth-header {
                margin-bottom: 24px;
                flex-direction: column;
                gap: 16px;
                align-items: flex-start;
            }
            
            .auth-header-link {
                font-size: 13px;
            }
            
            .auth-logo img {
                height: 36px;
            }
            
            .auth-title {
                font-size: 26px;
            }
            
            .auth-subtitle {
                font-size: 14px;
            }
            
            .form-input {
                padding: 16px;
                font-size: 16px;
                min-height: 52px;
            }
            
            .btn-submit {
                padding: 18px;
                font-size: 16px;
                min-height: 56px;
            }
            
            .name-row {
                flex-direction: column;
            }
            
            .social-btn {
                padding: 16px;
                min-height: 52px;
            }
            
            .auth-footer {
                padding-top: 24px;
            }
        }
        
        @media (max-width: 380px) {
            .auth-title {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-layout">
        <div class="auth-form-side">
            <div class="auth-header">
                <a href="<?php echo home_url(); ?>" class="auth-logo">
                    <img src="<?php echo esc_url($logo); ?>" alt="PTP">
                </a>
                <div class="auth-header-link">
                    Already have an account? <a href="<?php echo home_url('/login/'); ?>">Sign in</a>
                </div>
            </div>
            
            <div class="auth-content">
                <h1 class="auth-title">Create your account</h1>
                <p class="auth-subtitle">Book private soccer training for your player</p>
                
                <?php if ($error): ?>
                <div class="auth-error"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form method="post">
                    <?php wp_nonce_field('ptp_register', 'ptp_register_nonce'); ?>
                    
                    <div class="form-row-2">
                        <div class="form-group">
                            <label class="form-label">First name *</label>
                            <input type="text" name="first_name" class="form-input" placeholder="John" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last name *</label>
                            <input type="text" name="last_name" class="form-input" placeholder="Smith" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Email address *</label>
                        <input type="email" name="email" class="form-input" placeholder="you@example.com" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Phone number</label>
                        <input type="tel" name="phone" class="form-input" placeholder="(555) 555-5555">
                        <p class="form-hint">For session reminders and trainer communication</p>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" class="form-input" placeholder="••••••••" required minlength="8">
                        <p class="form-hint">At least 8 characters</p>
                    </div>
                    
                    <button type="submit" name="ptp_register" value="1" class="btn-submit">Create Account</button>
                    
                    <p class="auth-terms">
                        By creating an account, you agree to our 
                        <a href="<?php echo home_url('/terms/'); ?>">Terms of Service</a> and 
                        <a href="<?php echo home_url('/privacy/'); ?>">Privacy Policy</a>
                    </p>
                </form>
                
                <div class="auth-divider"><span>or</span></div>
                
                <div class="trainer-cta">
                    <p>Are you a coach or trainer?</p>
                    <a href="<?php echo home_url('/apply/'); ?>">
                        Apply to become a trainer
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>
                </div>
            </div>
            
            <div class="auth-footer">
                <p>Need help? <a href="mailto:luke@ptpsummercamps.com">Contact support</a> • <a href="tel:+14845724770">(484) 572-4770</a></p>
            </div>
        </div>
        
        <div class="auth-image-side">
            <div class="auth-image-content">
                <h2 class="auth-image-title">Real players. Real training.</h2>
                <p class="auth-image-text">Join hundreds of families who have elevated their player's game with personalized 1-on-1 coaching from current college and professional athletes.</p>
            </div>
        </div>
    </div>
</body>
</html>
