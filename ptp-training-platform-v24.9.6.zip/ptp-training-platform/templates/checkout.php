<?php
/**
 * Template: Checkout - Secure Payment Processing
 * PTP v25.0 - Robust Stripe integration for individuals
 */
defined('ABSPATH') || exit;

// Get booking data
$booking_id = isset($_GET['booking']) ? intval($_GET['booking']) : 0;
$trainer_slug = isset($_GET['trainer']) ? sanitize_text_field($_GET['trainer']) : '';

global $wpdb;

$booking = null;
$trainer = null;

if ($booking_id) {
    $booking = $wpdb->get_row($wpdb->prepare("
        SELECT b.*, t.display_name as trainer_name, t.photo_url as trainer_photo, 
               t.hourly_rate, t.stripe_account_id, t.stripe_charges_enabled,
               p.name as player_name
        FROM {$wpdb->prefix}ptp_bookings b
        JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
        LEFT JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
        WHERE b.id = %d
    ", $booking_id));
    
    if ($booking) {
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
            $booking->trainer_id
        ));
    }
} elseif ($trainer_slug) {
    $trainer = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE slug = %s",
        $trainer_slug
    ));
}

if (!$trainer && !$booking) {
    wp_redirect(home_url('/find-trainers/'));
    exit;
}

// Calculate amounts
$rate = $booking ? $booking->total_amount : ($trainer->hourly_rate ?: 80);
$platform_fee = round($rate * 0.20, 2);
$trainer_earnings = $rate - $platform_fee;

// Get Stripe publishable key
$stripe_key = PTP_Stripe::get_publishable_key();
$stripe_enabled = PTP_Stripe::is_enabled();

// Check if trainer can receive direct payments
$direct_to_trainer = $trainer && !empty($trainer->stripe_account_id) && $trainer->stripe_charges_enabled;

$trainer_photo = $trainer->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($trainer->display_name) . '&size=120&background=FCB900&color=0A0A0A&bold=true';

wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
?>

<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - PTP Training</title>
    <?php wp_head(); ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { overflow-x: hidden !important; max-width: 100vw; }
        
        :root {
            --ptp-yellow: #FCB900;
            --ptp-black: #0E0F11;
            --ptp-green: #10B981;
            --ptp-gray-50: #F9FAFB;
            --ptp-gray-100: #F3F4F6;
            --ptp-gray-200: #E5E7EB;
            --ptp-gray-500: #6B7280;
            --ptp-gray-700: #374151;
            --ptp-gray-900: #111827;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--ptp-gray-100);
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }
        
        .checkout-page {
            max-width: 480px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
        }
        
        .checkout-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
        }
        
        .checkout-back {
            width: 40px;
            height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff;
            border-radius: 10px;
            color: var(--ptp-gray-700);
            text-decoration: none;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        
        .checkout-title {
            font-size: 22px;
            font-weight: 800;
            color: var(--ptp-gray-900);
        }
        
        .checkout-card {
            background: #fff;
            border-radius: 20px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.08);
            overflow: hidden;
            margin-bottom: 20px;
        }
        
        .checkout-card-header {
            padding: 20px;
            border-bottom: 1px solid var(--ptp-gray-100);
        }
        
        .checkout-card-title {
            font-size: 14px;
            font-weight: 700;
            color: var(--ptp-gray-900);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .checkout-card-body {
            padding: 20px;
        }
        
        /* Trainer Info */
        .trainer-info {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        
        .trainer-photo {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--ptp-yellow);
        }
        
        .trainer-details h3 {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 4px;
        }
        
        .trainer-details p {
            font-size: 14px;
            color: var(--ptp-gray-500);
        }
        
        /* Session Details */
        .session-row {
            display: flex;
            justify-content: space-between;
            padding: 14px 0;
            border-bottom: 1px solid var(--ptp-gray-100);
            font-size: 15px;
        }
        
        .session-row:last-child {
            border-bottom: none;
        }
        
        .session-row .label {
            color: var(--ptp-gray-500);
        }
        
        .session-row .value {
            font-weight: 600;
            color: var(--ptp-gray-900);
        }
        
        .session-total {
            background: var(--ptp-gray-50);
            margin: 20px -20px -20px;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .session-total .label {
            font-size: 16px;
            font-weight: 600;
        }
        
        .session-total .value {
            font-size: 28px;
            font-weight: 800;
            color: var(--ptp-gray-900);
        }
        
        /* Payment Form */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: var(--ptp-gray-700);
            margin-bottom: 8px;
        }
        
        .form-input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid var(--ptp-gray-200);
            border-radius: 12px;
            font-size: 16px;
            font-family: inherit;
            transition: all 0.2s;
            background: var(--ptp-gray-50);
        }
        
        .form-input:focus {
            outline: none;
            border-color: var(--ptp-yellow);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(252,185,0,0.1);
        }
        
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        
        /* Stripe Elements */
        .stripe-element {
            padding: 16px;
            border: 2px solid var(--ptp-gray-200);
            border-radius: 12px;
            background: var(--ptp-gray-50);
            transition: all 0.2s;
        }
        
        .stripe-element.StripeElement--focus {
            border-color: var(--ptp-yellow);
            background: #fff;
            box-shadow: 0 0 0 4px rgba(252,185,0,0.1);
        }
        
        .stripe-element.StripeElement--invalid {
            border-color: #EF4444;
        }
        
        /* Submit Button */
        .pay-btn {
            width: 100%;
            padding: 18px;
            background: var(--ptp-yellow);
            color: var(--ptp-black);
            border: none;
            border-radius: 14px;
            font-size: 17px;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .pay-btn:hover {
            background: #E5A800;
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(252,185,0,0.3);
        }
        
        .pay-btn:disabled {
            background: var(--ptp-gray-200);
            color: var(--ptp-gray-500);
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .pay-btn.loading {
            pointer-events: none;
        }
        
        .pay-btn .spinner {
            width: 20px;
            height: 20px;
            border: 3px solid rgba(0,0,0,0.2);
            border-top-color: var(--ptp-black);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        /* Error Message */
        .error-msg {
            background: #FEE2E2;
            color: #991B1B;
            padding: 14px 16px;
            border-radius: 10px;
            font-size: 14px;
            margin-bottom: 20px;
            display: none;
        }
        
        .error-msg.show {
            display: block;
        }
        
        /* Success State */
        .success-state {
            display: none;
            text-align: center;
            padding: 40px 20px;
        }
        
        .success-state.show {
            display: block;
        }
        
        .success-icon {
            width: 80px;
            height: 80px;
            background: #D1FAE5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        
        .success-icon svg {
            width: 40px;
            height: 40px;
            color: var(--ptp-green);
        }
        
        .success-title {
            font-size: 24px;
            font-weight: 800;
            margin-bottom: 8px;
        }
        
        .success-text {
            color: var(--ptp-gray-500);
            margin-bottom: 24px;
        }
        
        .success-btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--ptp-black);
            color: #fff;
            padding: 14px 28px;
            border-radius: 12px;
            text-decoration: none;
            font-weight: 700;
        }
        
        /* Security Badge */
        .security-badge {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 16px;
            color: var(--ptp-gray-500);
            font-size: 13px;
        }
        
        .security-badge svg {
            width: 16px;
            height: 16px;
        }
        
        /* Trust Badges */
        .trust-badges {
            display: flex;
            justify-content: center;
            gap: 20px;
            padding: 20px;
            border-top: 1px solid var(--ptp-gray-100);
        }
        
        .trust-badge {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            color: var(--ptp-gray-500);
        }
        
        .trust-badge svg {
            width: 14px;
            height: 14px;
            color: var(--ptp-green);
        }
        
        /* Mobile Optimizations */
        @media (max-width: 600px) {
            .checkout-page {
                padding: 16px 12px;
            }
            
            .checkout-header {
                margin-bottom: 20px;
            }
            
            .checkout-title {
                font-size: 18px;
            }
            
            .checkout-card {
                border-radius: 16px;
                margin-bottom: 16px;
            }
            
            .checkout-card-header,
            .checkout-card-body {
                padding: 16px;
            }
            
            .checkout-grid {
                grid-template-columns: 1fr;
            }
            
            .trainer-info img {
                width: 50px;
                height: 50px;
            }
            
            .trainer-name {
                font-size: 16px;
            }
            
            .session-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 4px;
            }
            
            .form-input {
                padding: 16px;
                font-size: 16px;
                min-height: 52px;
            }
            
            .pay-btn {
                padding: 18px;
                font-size: 16px;
                min-height: 56px;
            }
            
            .trust-badges {
                flex-wrap: wrap;
                gap: 12px;
            }
            
            .trust-badge {
                font-size: 11px;
            }
            
            .total-row {
                font-size: 18px;
            }
        }
        
        @media (max-width: 400px) {
            .checkout-title {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

<div class="checkout-page">
    
    <!-- Header -->
    <div class="checkout-header">
        <a href="javascript:history.back()" class="checkout-back">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="15 18 9 12 15 6"/>
            </svg>
        </a>
        <h1 class="checkout-title">Secure Checkout</h1>
    </div>
    
    <!-- Payment Form -->
    <form id="payment-form">
        
        <!-- Trainer Card -->
        <div class="checkout-card">
            <div class="checkout-card-body">
                <div class="trainer-info">
                    <img src="<?php echo esc_url($trainer_photo); ?>" alt="" class="trainer-photo">
                    <div class="trainer-details">
                        <h3><?php echo esc_html($trainer->display_name); ?></h3>
                        <p>Private Training Session</p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Session Details -->
        <div class="checkout-card">
            <div class="checkout-card-header">
                <h2 class="checkout-card-title">Session Details</h2>
            </div>
            <div class="checkout-card-body">
                <?php if ($booking): ?>
                <div class="session-row">
                    <span class="label">Player</span>
                    <span class="value"><?php echo esc_html($booking->player_name ?: 'TBD'); ?></span>
                </div>
                <div class="session-row">
                    <span class="label">Date</span>
                    <span class="value"><?php echo date('l, M j, Y', strtotime($booking->session_date)); ?></span>
                </div>
                <div class="session-row">
                    <span class="label">Time</span>
                    <span class="value"><?php echo date('g:i A', strtotime($booking->start_time)); ?></span>
                </div>
                <?php if ($booking->location): ?>
                <div class="session-row">
                    <span class="label">Location</span>
                    <span class="value"><?php echo esc_html($booking->location); ?></span>
                </div>
                <?php endif; ?>
                <?php else: ?>
                <div class="session-row">
                    <span class="label">Duration</span>
                    <span class="value">1 Hour</span>
                </div>
                <div class="session-row">
                    <span class="label">Type</span>
                    <span class="value">1-on-1 Training</span>
                </div>
                <?php endif; ?>
                
                <div class="session-total">
                    <span class="label">Total</span>
                    <span class="value">$<?php echo number_format($rate, 2); ?></span>
                </div>
            </div>
        </div>
        
        <!-- Payment Card -->
        <div class="checkout-card">
            <div class="checkout-card-header">
                <h2 class="checkout-card-title">Payment Method</h2>
            </div>
            <div class="checkout-card-body">
                
                <div class="error-msg" id="error-msg"></div>
                
                <?php if (!is_user_logged_in()): ?>
                <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" class="form-input" id="email" placeholder="your@email.com" required>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label">First Name</label>
                        <input type="text" class="form-input" id="first_name" placeholder="First" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Last Name</label>
                        <input type="text" class="form-input" id="last_name" placeholder="Last" required>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input type="tel" class="form-input" id="phone" placeholder="(555) 123-4567">
                </div>
                <?php endif; ?>
                
                <div class="form-group">
                    <label class="form-label">Card Information</label>
                    <div class="stripe-element" id="card-element"></div>
                </div>
                
                <button type="submit" class="pay-btn" id="pay-btn">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                        <line x1="1" y1="10" x2="23" y2="10"/>
                    </svg>
                    Pay $<?php echo number_format($rate, 2); ?>
                </button>
                
            </div>
            
            <div class="trust-badges">
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                    </svg>
                    Secure Payment
                </div>
                <div class="trust-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 11-5.93-9.14"/>
                        <polyline points="22 4 12 14.01 9 11.01"/>
                    </svg>
                    Money-Back Guarantee
                </div>
            </div>
        </div>
        
        <div class="security-badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                <path d="M7 11V7a5 5 0 0110 0v4"/>
            </svg>
            Payments secured by Stripe. We never store your card details.
        </div>
        
    </form>
    
    <!-- Success State -->
    <div class="success-state" id="success-state">
        <div class="checkout-card">
            <div class="checkout-card-body" style="padding: 40px 20px;">
                <div class="success-icon">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3">
                        <polyline points="20 6 9 17 4 12"/>
                    </svg>
                </div>
                <h2 class="success-title">Booking Confirmed!</h2>
                <p class="success-text">Your session with <?php echo esc_html($trainer->display_name); ?> is all set. We've sent a confirmation to your email.</p>
                <a href="<?php echo esc_url(home_url('/my-training/')); ?>" class="success-btn">
                    View My Sessions
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="9 18 15 12 9 6"/>
                    </svg>
                </a>
            </div>
        </div>
    </div>
    
</div>

<script>
(function() {
    <?php if (!$stripe_enabled): ?>
    document.getElementById('error-msg').textContent = 'Payment system is being configured. Please try again later or contact support.';
    document.getElementById('error-msg').classList.add('show');
    document.getElementById('pay-btn').disabled = true;
    return;
    <?php endif; ?>
    
    // Initialize Stripe
    const stripe = Stripe('<?php echo esc_js($stripe_key); ?>');
    const elements = stripe.elements({
        fonts: [{ cssSrc: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap' }]
    });
    
    // Create card element
    const cardElement = elements.create('card', {
        style: {
            base: {
                fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
                fontSize: '16px',
                color: '#111827',
                '::placeholder': { color: '#9CA3AF' }
            },
            invalid: {
                color: '#EF4444',
                iconColor: '#EF4444'
            }
        },
        hidePostalCode: false
    });
    
    cardElement.mount('#card-element');
    
    // Handle form submission
    const form = document.getElementById('payment-form');
    const submitBtn = document.getElementById('pay-btn');
    const errorMsg = document.getElementById('error-msg');
    
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Disable button
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<div class="spinner"></div> Processing...';
        errorMsg.classList.remove('show');
        
        try {
            // Create payment intent
            const intentResponse = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'ptp_process_booking_payment',
                    nonce: '<?php echo wp_create_nonce('ptp_nonce'); ?>',
                    booking_id: '<?php echo $booking_id; ?>',
                    trainer_id: '<?php echo $trainer->id; ?>',
                    amount: '<?php echo $rate; ?>'
                })
            });
            
            const intentData = await intentResponse.json();
            
            if (!intentData.success) {
                throw new Error(intentData.data?.message || 'Unable to process payment');
            }
            
            // Confirm payment with Stripe
            const { error, paymentIntent } = await stripe.confirmCardPayment(intentData.data.client_secret, {
                payment_method: {
                    card: cardElement,
                    billing_details: {
                        name: document.getElementById('first_name') 
                            ? (document.getElementById('first_name').value + ' ' + document.getElementById('last_name').value).trim()
                            : '<?php echo esc_js(is_user_logged_in() ? wp_get_current_user()->display_name : ''); ?>',
                        email: document.getElementById('email')?.value || '<?php echo esc_js(is_user_logged_in() ? wp_get_current_user()->user_email : ''); ?>'
                    }
                }
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            if (paymentIntent.status === 'succeeded') {
                // Confirm with backend
                const confirmResponse = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({
                        action: 'ptp_complete_payment',
                        nonce: '<?php echo wp_create_nonce('ptp_nonce'); ?>',
                        payment_intent_id: paymentIntent.id,
                        booking_id: '<?php echo $booking_id; ?>'
                    })
                });
                
                const confirmData = await confirmResponse.json();
                
                // Show success
                form.style.display = 'none';
                document.getElementById('success-state').classList.add('show');
                
                // Redirect after delay
                if (confirmData.data?.redirect) {
                    setTimeout(() => {
                        window.location.href = confirmData.data.redirect;
                    }, 3000);
                }
            } else {
                throw new Error('Payment was not completed. Please try again.');
            }
            
        } catch (err) {
            errorMsg.textContent = err.message;
            errorMsg.classList.add('show');
            submitBtn.disabled = false;
            submitBtn.innerHTML = `
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                    <line x1="1" y1="10" x2="23" y2="10"/>
                </svg>
                Pay $<?php echo number_format($rate, 2); ?>
            `;
        }
    });
    
    // Handle card element changes
    cardElement.on('change', function(event) {
        if (event.error) {
            errorMsg.textContent = event.error.message;
            errorMsg.classList.add('show');
        } else {
            errorMsg.classList.remove('show');
        }
    });
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
