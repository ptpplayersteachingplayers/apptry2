<?php
/**
 * Template: Booking Confirmation - PTP Style v23.4
 */
defined('ABSPATH') || exit;
?>

<style>
html, body { overflow-x: hidden !important; max-width: 100vw; }
.ptp-confirm-wrap { min-height: 100vh; background: linear-gradient(135deg, #0E0F11 0%, #1a1a1a 100%); display: flex; align-items: center; justify-content: center; padding: 40px 20px; overflow-x: hidden; }
.ptp-confirm-card { background: #fff; border-radius: 24px; max-width: 520px; width: 100%; overflow: hidden; box-shadow: 0 25px 80px rgba(0,0,0,0.4); }
.ptp-confirm-header { background: linear-gradient(135deg, #22C55E 0%, #16A34A 100%); padding: 40px; text-align: center; position: relative; overflow: hidden; }
.ptp-confirm-header::before { content: ''; position: absolute; top: -50%; left: -50%; width: 200%; height: 200%; background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, transparent 60%); }
.ptp-confirm-icon { width: 80px; height: 80px; background: #fff; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; font-size: 40px; box-shadow: 0 8px 24px rgba(0,0,0,0.15); position: relative; animation: bounceIn 0.6s ease; }
@keyframes bounceIn { 0% { transform: scale(0); } 50% { transform: scale(1.1); } 100% { transform: scale(1); } }
.ptp-confirm-title { font-family: 'Oswald', sans-serif; font-size: 32px; font-weight: 700; color: #fff; margin: 0 0 8px; position: relative; }
.ptp-confirm-subtitle { font-size: 16px; color: rgba(255,255,255,0.9); margin: 0; position: relative; }
.ptp-confirm-body { padding: 32px; }
.ptp-confirm-booking-num { background: #F3F4F6; border-radius: 12px; padding: 16px; text-align: center; margin-bottom: 24px; }
.ptp-confirm-booking-label { font-size: 12px; font-weight: 600; color: #6B7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px; }
.ptp-confirm-booking-value { font-family: 'Oswald', sans-serif; font-size: 24px; font-weight: 700; color: #111827; letter-spacing: 2px; }
.ptp-confirm-details { border: 2px solid #F3F4F6; border-radius: 16px; overflow: hidden; }
.ptp-confirm-row { display: flex; padding: 16px 20px; border-bottom: 1px solid #F3F4F6; }
.ptp-confirm-row:last-child { border-bottom: none; }
.ptp-confirm-row:nth-child(even) { background: #FAFAFA; }
.ptp-confirm-label { width: 100px; font-size: 13px; font-weight: 600; color: #6B7280; flex-shrink: 0; }
.ptp-confirm-value { flex: 1; font-size: 15px; font-weight: 600; color: #111827; }
.ptp-confirm-total { background: #0E0F11 !important; }
.ptp-confirm-total .ptp-confirm-label { color: rgba(255,255,255,0.7); }
.ptp-confirm-total .ptp-confirm-value { color: #FCB900; font-family: 'Oswald', sans-serif; font-size: 20px; }
.ptp-confirm-actions { display: flex; gap: 12px; margin-top: 28px; }
.ptp-confirm-btn { flex: 1; padding: 16px; border-radius: 12px; font-weight: 700; font-size: 15px; text-decoration: none; text-align: center; transition: all 0.2s; }
.ptp-confirm-btn-primary { background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%); color: #0E0F11; }
.ptp-confirm-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(252,185,0,0.3); }
.ptp-confirm-btn-outline { background: transparent; border: 2px solid #E5E7EB; color: #374151; }
.ptp-confirm-btn-outline:hover { background: #F9FAFB; border-color: #D1D5DB; }
.ptp-confirm-footer { padding: 24px 32px; background: #F9FAFB; border-top: 1px solid #F3F4F6; text-align: center; }
.ptp-confirm-footer p { font-size: 13px; color: #6B7280; margin: 0; }
.ptp-confirm-footer a { color: #FCB900; text-decoration: none; font-weight: 600; }
</style>

<div class="ptp-confirm-wrap">
    <div class="ptp-confirm-card">
        <div class="ptp-confirm-header">
            <div class="ptp-confirm-icon">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#22C55E" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
            </div>
            <h1 class="ptp-confirm-title">You're Booked!</h1>
            <p class="ptp-confirm-subtitle">Your training session has been confirmed</p>
        </div>
        
        <div class="ptp-confirm-body">
            <div class="ptp-confirm-booking-num">
                <div class="ptp-confirm-booking-label">Booking Number</div>
                <div class="ptp-confirm-booking-value"><?php echo esc_html($booking->booking_number); ?></div>
            </div>
            
            <div class="ptp-confirm-details">
                <div class="ptp-confirm-row">
                    <span class="ptp-confirm-label">Trainer</span>
                    <span class="ptp-confirm-value"><?php echo esc_html($booking->trainer_name); ?></span>
                </div>
                <div class="ptp-confirm-row">
                    <span class="ptp-confirm-label">Player</span>
                    <span class="ptp-confirm-value"><?php echo esc_html($booking->player_name); ?></span>
                </div>
                <div class="ptp-confirm-row">
                    <span class="ptp-confirm-label">Date</span>
                    <span class="ptp-confirm-value"><?php echo date('l, F j, Y', strtotime($booking->session_date)); ?></span>
                </div>
                <div class="ptp-confirm-row">
                    <span class="ptp-confirm-label">Time</span>
                    <span class="ptp-confirm-value"><?php echo date('g:i A', strtotime($booking->start_time)); ?> - <?php echo date('g:i A', strtotime($booking->end_time)); ?></span>
                </div>
                <?php if (!empty($booking->location)): ?>
                <div class="ptp-confirm-row">
                    <span class="ptp-confirm-label">Location</span>
                    <span class="ptp-confirm-value"><?php echo esc_html($booking->location); ?></span>
                </div>
                <?php endif; ?>
                <div class="ptp-confirm-row ptp-confirm-total">
                    <span class="ptp-confirm-label">Total Paid</span>
                    <span class="ptp-confirm-value">$<?php echo number_format($booking->total_amount, 2); ?></span>
                </div>
            </div>
            
            <div class="ptp-confirm-actions">
                <a href="<?php echo home_url('/messages/?trainer=' . $booking->trainer_id); ?>" class="ptp-confirm-btn ptp-confirm-btn-primary">Message Trainer</a>
                <a href="<?php echo home_url('/my-training/'); ?>" class="ptp-confirm-btn ptp-confirm-btn-outline">My Sessions</a>
            </div>
        </div>
        
        <!-- Camps Cross-Sell -->
        <div style="padding: 24px 32px; background: linear-gradient(135deg, #0E0F11 0%, #1a1a1a 100%); border-top: 1px solid #E5E7EB;">
            <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
                <div style="flex: 1; min-width: 200px;">
                    <div style="display: inline-block; background: #FCB900; color: #0E0F11; padding: 4px 10px; border-radius: 4px; font-size: 11px; font-weight: 700; margin-bottom: 8px;">SUMMER 2026</div>
                    <h3 style="font-size: 18px; font-weight: 700; color: #fff; margin: 0 0 4px;">Want More Training?</h3>
                    <p style="font-size: 14px; color: rgba(255,255,255,0.7); margin: 0;">Check out our week-long summer camps with the same elite coaches!</p>
                </div>
                <a href="<?php echo home_url('/ptp-shop-page/'); ?>" style="background: #FCB900; color: #0E0F11; padding: 12px 24px; border-radius: 10px; font-weight: 700; font-size: 14px; text-decoration: none; white-space: nowrap;">View Summer Camps</a>
            </div>
        </div>
        
        <div class="ptp-confirm-footer">
            <p>Confirmation email sent to your inbox. <a href="<?php echo home_url('/account/'); ?>">Manage notifications</a></p>
        </div>
    </div>
</div>
