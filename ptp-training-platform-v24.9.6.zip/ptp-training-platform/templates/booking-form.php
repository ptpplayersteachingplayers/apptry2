<?php
/**
 * Template: Booking Form v24.4.7
 * Robust booking with packages, player selection, and location handling
 */
defined('ABSPATH') || exit;

$slug = isset($_GET['trainer']) ? sanitize_text_field($_GET['trainer']) : '';
$trainer = $slug ? PTP_Trainer::get_by_slug($slug) : null;

if (!$trainer) {
    echo '<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:40px;background:#F3F4F6;">
        <div style="background:#fff;border-radius:16px;padding:40px;text-align:center;max-width:400px;">
            <h2 style="margin:0 0 12px;">Select a Trainer</h2>
            <p style="color:#6B7280;margin:0 0 24px;">Please choose a trainer before booking.</p>
            <a href="' . esc_url(home_url('/find-trainers/')) . '" style="display:inline-block;background:#FCB900;color:#000;padding:14px 28px;border-radius:10px;font-weight:700;text-decoration:none;">Find Trainers</a>
        </div>
    </div>';
    return;
}

$is_logged_in = is_user_logged_in();
$user_id = $is_logged_in ? get_current_user_id() : 0;
$parent = null;
$players = array();

if ($is_logged_in) {
    // Try to get existing parent
    $parent = PTP_Parent::get_by_user_id($user_id);
    
    // Auto-create if needed
    if (!$parent) {
        $user = wp_get_current_user();
        $parent_id = PTP_Parent::create($user_id, array(
            'display_name' => $user->display_name ?: $user->user_login
        ));
        if (!is_wp_error($parent_id)) {
            $parent = PTP_Parent::get($parent_id);
        }
    }
    
    // Get players
    if ($parent) {
        $players = PTP_Player::get_by_parent($parent->id);
        if (!is_array($players)) $players = array();
    }
}

$photo = $trainer->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($trainer->display_name) . '&size=200&background=FCB900&color=0A0A0A';
$rate = (int)($trainer->hourly_rate ?: 70);
$stripe_key = get_option('ptp_stripe_test_mode') ? get_option('ptp_stripe_test_publishable') : get_option('ptp_stripe_live_publishable');

// Get trainer locations
$trainer_locations = array();
if (!empty($trainer->training_locations)) {
    $trainer_locations = is_array($trainer->training_locations) ? $trainer->training_locations : json_decode($trainer->training_locations, true);
    if (!is_array($trainer_locations)) $trainer_locations = array();
}

// Packages - matching the UI with 4 tiers
$packages = array(
    array('sessions' => 1, 'price' => $rate, 'save' => 0, 'name' => 'Single Session', 'per' => $rate),
    array('sessions' => 4, 'price' => round($rate * 4 * 0.95), 'save' => 5, 'name' => '4 Sessions', 'per' => round($rate * 0.95)),
    array('sessions' => 8, 'price' => round($rate * 8 * 0.90), 'save' => 10, 'name' => '8 Sessions', 'per' => round($rate * 0.90)),
    array('sessions' => 12, 'price' => round($rate * 12 * 0.85), 'save' => 15, 'name' => '12 Sessions', 'per' => round($rate * 0.85)),
);

$preselect_pkg = isset($_GET['package']) ? (int)$_GET['package'] : 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Book with <?php echo esc_attr($trainer->display_name); ?> | PTP</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
html, body { overflow-x: hidden !important; max-width: 100vw; }
body { font-family: 'Inter', sans-serif; background: #F3F4F6; min-height: 100vh; }

.container { max-width: 900px; margin: 0 auto; padding: 24px 16px 100px; }
h1 { font-size: 24px; text-align: center; margin-bottom: 8px; }
.back { display: block; text-align: center; color: #6B7280; text-decoration: none; margin-bottom: 24px; }
.back:hover { color: #FCB900; }

.grid { display: grid; gap: 24px; }
@media (min-width: 768px) { .grid { grid-template-columns: 1fr 320px; } }

.card { background: #fff; border-radius: 16px; padding: 24px; }
.card h2 { font-size: 18px; margin-bottom: 20px; }

/* Trainer Summary */
.trainer { display: flex; gap: 12px; align-items: center; padding-bottom: 16px; border-bottom: 1px solid #E5E7EB; margin-bottom: 16px; }
.trainer img { width: 60px; height: 60px; border-radius: 12px; object-fit: cover; }
.trainer h3 { font-size: 16px; margin-bottom: 2px; }
.trainer p { font-size: 13px; color: #6B7280; }
.row { display: flex; justify-content: space-between; padding: 8px 0; font-size: 14px; }
.row.total { font-weight: 700; font-size: 16px; border-top: 1px solid #E5E7EB; margin-top: 8px; padding-top: 12px; }

/* Form */
.form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
@media (max-width: 500px) { .form-row { grid-template-columns: 1fr; } }
.field { margin-bottom: 16px; }
.field label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 6px; }
.field input, .field select, .field textarea { width: 100%; padding: 12px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px; font-family: inherit; }
.field input:focus, .field select:focus, .field textarea:focus { outline: none; border-color: #FCB900; }

/* Section Label */
.section-label { font-size: 14px; font-weight: 600; margin-bottom: 12px; color: #374151; }

/* Players */
.players { display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 12px; margin-bottom: 20px; }
.player { padding: 20px 12px; text-align: center; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; transition: all 0.15s ease; }
.player:hover { border-color: #FCB900; background: #FFFDF5; }
.player.selected { border-color: #FCB900; background: #FFFBEB; }
.player-icon { font-size: 28px; margin-bottom: 8px; }
.player-name { font-weight: 600; font-size: 14px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.player-age { font-size: 12px; color: #6B7280; margin-top: 2px; }
.player.add { border-style: dashed; color: #9CA3AF; }
.player.add:hover { color: #FCB900; border-color: #FCB900; background: #FFFDF5; }

/* Packages */
.packages { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin-bottom: 20px; }
@media (max-width: 500px) { .packages { grid-template-columns: 1fr; } }
.pkg { padding: 16px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; position: relative; transition: all 0.15s ease; }
.pkg:hover { border-color: #FCB900; }
.pkg.selected { border-color: #FCB900; background: #FFFBEB; }
.pkg .save-badge { position: absolute; top: -8px; right: 12px; background: #10B981; color: #fff; padding: 2px 8px; border-radius: 4px; font-size: 10px; font-weight: 700; }
.pkg-name { font-weight: 600; font-size: 15px; }
.pkg-price { font-size: 20px; font-weight: 700; margin-top: 4px; }
.pkg-per { font-size: 12px; color: #6B7280; }

/* Location */
.location-section { margin-bottom: 20px; }
.location-options { display: flex; flex-direction: column; gap: 8px; margin-bottom: 12px; }
.location-opt { display: flex; align-items: center; gap: 10px; padding: 12px; border: 2px solid #E5E7EB; border-radius: 10px; cursor: pointer; transition: all 0.15s ease; }
.location-opt:hover { border-color: #FCB900; }
.location-opt.selected { border-color: #FCB900; background: #FFFBEB; }
.location-opt input[type="radio"] { display: none; }
.location-radio { width: 20px; height: 20px; border: 2px solid #D1D5DB; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.location-opt.selected .location-radio { border-color: #FCB900; }
.location-opt.selected .location-radio::after { content: ''; width: 10px; height: 10px; background: #FCB900; border-radius: 50%; }
.location-text { font-size: 14px; }
.location-note { font-size: 12px; color: #9CA3AF; margin-top: 8px; }

/* Calendar */
.cal-head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
.cal-head span { font-weight: 600; }
.cal-head button { width: 32px; height: 32px; border-radius: 50%; border: 1px solid #E5E7EB; background: #fff; cursor: pointer; font-size: 16px; }
.cal-head button:hover { background: #F9FAFB; }
.cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; text-align: center; }
.cal-day-name { font-size: 11px; color: #9CA3AF; padding: 8px 0; }
.cal-day { aspect-ratio: 1; display: flex; align-items: center; justify-content: center; border-radius: 8px; font-size: 13px; cursor: pointer; transition: all 0.1s ease; }
.cal-day:hover:not(.past):not(.empty) { background: #FFFBEB; }
.cal-day.selected { background: #FCB900; font-weight: 700; }
.cal-day.past { color: #D1D5DB; cursor: default; }
.cal-day.today { border: 2px solid #FCB900; }

/* Slots */
.slots { margin-top: 16px; padding-top: 16px; border-top: 1px solid #E5E7EB; display: none; }
.slots.show { display: block; }
.slots-title { font-size: 14px; color: #6B7280; margin-bottom: 12px; }
.slots-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
@media (max-width: 400px) { .slots-grid { grid-template-columns: repeat(2, 1fr); } }
.slot { padding: 12px 10px; text-align: center; border: 2px solid #E5E7EB; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.1s ease; -webkit-tap-highlight-color: transparent; }
.slot:hover { border-color: #FCB900; background: #FFFBEB; }
.slot.selected { background: #FCB900; border-color: #FCB900; }
.slots-empty { text-align: center; padding: 20px; color: #9CA3AF; }

/* Buttons */
.btn { padding: 14px 24px; border-radius: 10px; font-weight: 700; font-size: 15px; cursor: pointer; border: none; transition: all 0.15s ease; -webkit-tap-highlight-color: transparent; }
.btn-primary { background: #FCB900; color: #000; }
.btn-primary:hover { background: #E5A800; }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-ghost { background: transparent; color: #6B7280; border: 2px solid #E5E7EB; }
.btn-ghost:hover { border-color: #D1D5DB; }
.btn-row { display: flex; justify-content: space-between; margin-top: 24px; gap: 12px; }

/* Mobile Optimizations */
@media (max-width: 768px) {
    .container { padding: 16px 12px 120px; }
    h1 { font-size: 20px; }
    .card { padding: 20px 16px; border-radius: 14px; }
    .card h2 { font-size: 16px; margin-bottom: 16px; }
    .trainer img { width: 50px; height: 50px; }
    .trainer h3 { font-size: 15px; }
    .trainer p { font-size: 12px; }
    .player { padding: 16px 10px; }
    .player-icon { font-size: 24px; margin-bottom: 6px; }
    .player-name { font-size: 13px; }
    .pkg { padding: 14px; }
    .pkg-name { font-size: 14px; }
    .pkg-price { font-size: 18px; }
    .field input, .field select, .field textarea { padding: 14px 12px; font-size: 16px; }
    .btn { padding: 16px 20px; font-size: 16px; width: 100%; }
    .btn-row { flex-direction: column-reverse; }
    .btn-ghost { width: 100%; text-align: center; }
}

@media (max-width: 400px) {
    .players { grid-template-columns: 1fr 1fr; gap: 8px; }
    .player { padding: 14px 8px; }
    .cal-day { font-size: 12px; }
    .cal-day-name { font-size: 10px; padding: 6px 0; }
}

/* Card Element */
#card-element { padding: 14px; border: 2px solid #E5E7EB; border-radius: 10px; background: #fff; }
#card-errors { color: #DC2626; font-size: 13px; margin-top: 8px; }

/* Modal - Fixed positioning and z-index */
.modal { 
    display: none; 
    position: fixed; 
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5); 
    z-index: 999999; 
    align-items: center; 
    justify-content: center; 
    padding: 20px;
}
.modal.show { display: flex !important; visibility: visible !important; opacity: 1 !important; }
.modal-box { 
    background: #fff; 
    border-radius: 16px; 
    width: 100%; 
    max-width: 420px; 
    max-height: 90vh;
    overflow-y: auto;
    box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);
    z-index: 1000000;
    position: relative;
}
.modal-head { display: flex; justify-content: space-between; align-items: center; padding: 20px; border-bottom: 1px solid #E5E7EB; }
.modal-head h3 { font-size: 18px; }
.modal-close { width: 32px; height: 32px; border-radius: 50%; border: none; background: #F3F4F6; cursor: pointer; font-size: 18px; display: flex; align-items: center; justify-content: center; }
.modal-close:hover { background: #E5E7EB; }
.modal-body { padding: 20px; }
.modal-foot { padding: 16px 20px; border-top: 1px solid #E5E7EB; }

/* Step visibility */
.step { display: none; }
.step.active { display: block; }

/* Loading spinner */
.spinner { display: inline-block; width: 16px; height: 16px; border: 2px solid #E5E7EB; border-top-color: #000; border-radius: 50%; animation: spin 0.8s linear infinite; margin-right: 8px; vertical-align: middle; }
@keyframes spin { to { transform: rotate(360deg); } }

/* Notes textarea */
.field textarea { min-height: 80px; resize: vertical; }
</style>
</head>
<body>

<div class="container">
    <h1>Book Your Session</h1>
    <a href="<?php echo esc_url(home_url('/trainer/' . $trainer->slug . '/')); ?>" class="back">← Back to profile</a>
    
    <div class="grid">
        <div>
            <?php if (!$is_logged_in): ?>
            <!-- Step 0: Guest Info -->
            <div class="card step active" id="step-0">
                <h2>Your Information</h2>
                <p style="color:#6B7280;margin:-12px 0 20px;font-size:14px;">Have an account? <a href="<?php echo esc_url(wp_login_url($_SERVER['REQUEST_URI'])); ?>" style="color:#FCB900;font-weight:600;">Log in</a></p>
                <div class="form-row">
                    <div class="field"><label>First Name *</label><input type="text" id="g-fname" autocomplete="given-name"></div>
                    <div class="field"><label>Last Name *</label><input type="text" id="g-lname" autocomplete="family-name"></div>
                </div>
                <div class="field"><label>Email *</label><input type="email" id="g-email" autocomplete="email"></div>
                <div class="field"><label>Phone *</label><input type="tel" id="g-phone" autocomplete="tel"></div>
                <div class="btn-row"><div></div><button class="btn btn-primary" onclick="next(0)">Continue</button></div>
            </div>
            <?php endif; ?>
            
            <!-- Step 1: Player Selection -->
            <div class="card step <?php echo $is_logged_in ? 'active' : ''; ?>" id="step-1">
                <h2>Who's Training?</h2>
                <?php if (!$is_logged_in): ?>
                <!-- Guest: Enter player info directly -->
                <div class="form-row">
                    <div class="field"><label>Player First Name *</label><input type="text" id="p-fname"></div>
                    <div class="field"><label>Player Last Name *</label><input type="text" id="p-lname"></div>
                </div>
                <div class="form-row">
                    <div class="field"><label>Age *</label><input type="number" id="p-age" min="4" max="18" placeholder="e.g. 10"></div>
                    <div class="field"><label>Skill Level</label>
                        <select id="p-skill">
                            <option value="beginner">Beginner</option>
                            <option value="intermediate">Intermediate</option>
                            <option value="advanced">Advanced</option>
                            <option value="elite">Elite</option>
                        </select>
                    </div>
                </div>
                <div class="btn-row">
                    <button class="btn btn-ghost" onclick="prev(1)">← Back</button>
                    <button class="btn btn-primary" onclick="next(1)">Continue</button>
                </div>
                <?php else: ?>
                <!-- Logged in: Select or add player -->
                <div class="section-label">Select Player</div>
                <div class="players" id="players-grid">
                    <?php foreach ($players as $p): ?>
                    <div class="player" data-id="<?php echo esc_attr($p->id); ?>" data-name="<?php echo esc_attr($p->name); ?>">
                        <div class="player-icon">⚽</div>
                        <div class="player-name"><?php echo esc_html($p->name); ?></div>
                        <div class="player-age"><?php echo $p->age ? 'Age ' . esc_html($p->age) : ''; ?></div>
                    </div>
                    <?php endforeach; ?>
                    <button type="button" class="player add" onclick="document.getElementById('ptp-add-player-modal').style.display='flex';" style="cursor:pointer;background:none;font-family:inherit;">
                        <div class="player-icon">+</div>
                        <div class="player-name">Add Player</div>
                    </button>
                </div>
                <div class="btn-row"><div></div><button class="btn btn-primary" id="btn-step1" disabled onclick="next(1)">Continue</button></div>
                
                <!-- ADD PLAYER MODAL - INLINE -->
                <div id="ptp-add-player-modal" onclick="if(event.target===this)this.style.display='none';" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;background:rgba(0,0,0,0.7);z-index:2147483647;justify-content:center;align-items:center;">
                    <div onclick="event.stopPropagation();" style="background:#fff;border-radius:16px;width:90%;max-width:400px;margin:20px;box-shadow:0 25px 50px rgba(0,0,0,0.3);">
                        <div style="display:flex;justify-content:space-between;align-items:center;padding:20px;border-bottom:1px solid #eee;">
                            <span style="font-size:18px;font-weight:700;">Add New Player</span>
                            <button type="button" onclick="document.getElementById('ptp-add-player-modal').style.display='none';" style="width:36px;height:36px;border-radius:50%;border:none;background:#f3f4f6;cursor:pointer;font-size:24px;line-height:1;">&times;</button>
                        </div>
                        <div style="padding:20px;">
                            <div style="margin-bottom:16px;">
                                <label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px;">First Name *</label>
                                <input type="text" id="ptp-add-fname" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;">
                            </div>
                            <div style="margin-bottom:16px;">
                                <label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px;">Last Name *</label>
                                <input type="text" id="ptp-add-lname" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;">
                            </div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:16px;">
                                <div>
                                    <label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px;">Age *</label>
                                    <input type="number" id="ptp-add-age" min="4" max="18" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;">
                                </div>
                                <div>
                                    <label style="display:block;font-size:14px;font-weight:500;margin-bottom:6px;">Skill</label>
                                    <select id="ptp-add-skill" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;background:#fff;">
                                        <option value="beginner">Beginner</option>
                                        <option value="intermediate">Intermediate</option>
                                        <option value="advanced">Advanced</option>
                                    </select>
                                </div>
                            </div>
                            <div id="ptp-add-error" style="display:none;padding:12px;background:#fee2e2;color:#dc2626;border-radius:8px;font-size:14px;margin-bottom:16px;"></div>
                            <button type="button" onclick="ptpAddPlayer();" style="width:100%;padding:16px;background:#FCB900;color:#000;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;">Add Player</button>
                        </div>
                    </div>
                </div>
                <script>
                function ptpAddPlayer() {
                    var fname = document.getElementById('ptp-add-fname').value.trim();
                    var lname = document.getElementById('ptp-add-lname').value.trim();
                    var age = parseInt(document.getElementById('ptp-add-age').value) || 0;
                    var skill = document.getElementById('ptp-add-skill').value;
                    var errDiv = document.getElementById('ptp-add-error');
                    
                    if (!fname || !lname) {
                        errDiv.textContent = 'Please enter first and last name';
                        errDiv.style.display = 'block';
                        return;
                    }
                    if (age < 4 || age > 18) {
                        errDiv.textContent = 'Please enter age (4-18)';
                        errDiv.style.display = 'block';
                        return;
                    }
                    
                    errDiv.style.display = 'none';
                    event.target.disabled = true;
                    event.target.textContent = 'Adding...';
                    
                    var fd = new FormData();
                    fd.append('action', 'ptp_add_player');
                    fd.append('nonce', '<?php echo wp_create_nonce("ptp_nonce"); ?>');
                    fd.append('name', fname + ' ' + lname);
                    fd.append('age', age);
                    fd.append('skill_level', skill);
                    
                    fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
                        method: 'POST',
                        body: fd,
                        credentials: 'same-origin'
                    })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        event.target.disabled = false;
                        event.target.textContent = 'Add Player';
                        
                        if (data.success && data.data && data.data.player) {
                            var p = data.data.player;
                            var grid = document.getElementById('players-grid');
                            var addBtn = grid.querySelector('.player.add');
                            
                            var card = document.createElement('div');
                            card.className = 'player';
                            card.setAttribute('data-id', p.id);
                            card.setAttribute('data-name', p.name);
                            card.innerHTML = '<div class="player-icon">⚽</div><div class="player-name">' + p.name + '</div><div class="player-age">Age ' + p.age + '</div>';
                            grid.insertBefore(card, addBtn);
                            
                            card.onclick = function() {
                                grid.querySelectorAll('.player').forEach(function(x) { x.classList.remove('selected'); });
                                card.classList.add('selected');
                                if (window.ptpSelectPlayer) window.ptpSelectPlayer(p.id, p.name);
                                document.getElementById('btn-step1').disabled = false;
                            };
                            card.click();
                            
                            document.getElementById('ptp-add-player-modal').style.display = 'none';
                            document.getElementById('ptp-add-fname').value = '';
                            document.getElementById('ptp-add-lname').value = '';
                            document.getElementById('ptp-add-age').value = '';
                        } else {
                            errDiv.textContent = (data.data && data.data.message) || 'Error adding player';
                            errDiv.style.display = 'block';
                        }
                    })
                    .catch(function(e) {
                        event.target.disabled = false;
                        event.target.textContent = 'Add Player';
                        errDiv.textContent = 'Network error. Try again.';
                        errDiv.style.display = 'block';
                    });
                }
                </script>
                <?php endif; ?>
            </div>
            
            <!-- Step 2: Package, Location & Schedule -->
            <div class="card step" id="step-2">
                <h2>Choose Package & Time</h2>
                
                <!-- Packages -->
                <div class="section-label">Select Package</div>
                <div class="packages">
                    <?php foreach ($packages as $i => $pkg): ?>
                    <div class="pkg <?php echo ($pkg['sessions'] == $preselect_pkg || ($i === 0 && $preselect_pkg === 1)) ? 'selected' : ''; ?>" data-sessions="<?php echo $pkg['sessions']; ?>" data-price="<?php echo $pkg['price']; ?>" data-name="<?php echo esc_attr($pkg['name']); ?>">
                        <?php if ($pkg['save']): ?><span class="save-badge">Save <?php echo $pkg['save']; ?>%</span><?php endif; ?>
                        <div class="pkg-name"><?php echo esc_html($pkg['name']); ?></div>
                        <div class="pkg-price">$<?php echo $pkg['price']; ?></div>
                        <div class="pkg-per">$<?php echo $pkg['per']; ?>/ea</div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Training Location -->
                <div class="location-section">
                    <div class="section-label">Training Location</div>
                    <?php if (!empty($trainer_locations)): ?>
                    <div class="location-options" id="location-options">
                        <?php foreach ($trainer_locations as $idx => $loc): ?>
                        <label class="location-opt <?php echo $idx === 0 ? 'selected' : ''; ?>">
                            <input type="radio" name="location" value="<?php echo esc_attr($loc); ?>" <?php echo $idx === 0 ? 'checked' : ''; ?>>
                            <span class="location-radio"></span>
                            <span class="location-text"><?php echo esc_html($loc); ?></span>
                        </label>
                        <?php endforeach; ?>
                        <label class="location-opt">
                            <input type="radio" name="location" value="custom">
                            <span class="location-radio"></span>
                            <span class="location-text">Suggest a different location</span>
                        </label>
                    </div>
                    <div class="field" id="custom-location-field" style="display:none;margin-bottom:0;">
                        <input type="text" id="custom-location" placeholder="Enter address, park, or field name">
                    </div>
                    <?php else: ?>
                    <p class="location-note" style="margin-bottom:12px;">This trainer hasn't set up training locations yet.</p>
                    <div class="field" style="margin-bottom:0;">
                        <input type="text" id="custom-location" placeholder="Suggest a location (park, field, address)">
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Calendar -->
                <div class="section-label" style="margin-top:20px;">Select Date & Time</div>
                <div class="cal-head">
                    <span id="cal-month"></span>
                    <div><button type="button" onclick="calPrev()">‹</button> <button type="button" onclick="calNext()">›</button></div>
                </div>
                <div class="cal-grid">
                    <div class="cal-day-name">S</div><div class="cal-day-name">M</div><div class="cal-day-name">T</div><div class="cal-day-name">W</div><div class="cal-day-name">T</div><div class="cal-day-name">F</div><div class="cal-day-name">S</div>
                </div>
                <div id="cal-days"></div>
                
                <div class="slots" id="slots">
                    <div class="slots-title" id="slots-title"></div>
                    <div class="slots-grid" id="slots-grid"></div>
                </div>
                
                <!-- Notes -->
                <div class="field" style="margin-top:20px;">
                    <label>Notes for <?php echo esc_html($trainer->display_name); ?> (optional)</label>
                    <textarea id="booking-notes" placeholder="Any specific skills to work on, injuries to be aware of, etc."></textarea>
                </div>
                
                <div class="btn-row">
                    <button class="btn btn-ghost" onclick="prev(2)">← Back</button>
                    <button class="btn btn-primary" id="btn-step2" disabled onclick="next(2)">Continue</button>
                </div>
            </div>
            
            <!-- Step 3: Payment -->
            <div class="card step" id="step-3">
                <h2>Payment</h2>
                <?php if (!$is_logged_in): ?>
                <div style="display:flex;gap:12px;padding:16px;background:#F9FAFB;border-radius:10px;margin-bottom:20px;">
                    <input type="checkbox" id="create-acct" style="width:20px;height:20px;flex-shrink:0;">
                    <label for="create-acct"><strong>Create account</strong><br><span style="font-size:13px;color:#6B7280;">Book faster next time & manage sessions</span></label>
                </div>
                <div id="pw-fields" style="display:none;">
                    <div class="form-row">
                        <div class="field"><label>Password</label><input type="password" id="acct-pw" autocomplete="new-password"></div>
                        <div class="field"><label>Confirm</label><input type="password" id="acct-pw2" autocomplete="new-password"></div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="field"><label>Card Details</label><div id="card-element"></div><div id="card-errors"></div></div>
                <div class="btn-row">
                    <button class="btn btn-ghost" onclick="prev(3)">← Back</button>
                    <button class="btn btn-primary" id="btn-pay" onclick="pay()">Pay $<?php echo $rate; ?></button>
                </div>
            </div>
            
            <!-- Success -->
            <div class="card step" id="step-done" style="text-align:center;padding:48px;">
                <div style="font-size:64px;margin-bottom:16px;">🎉</div>
                <h2 style="margin-bottom:8px;">Booking Confirmed!</h2>
                <p style="color:#6B7280;margin-bottom:24px;">Check your email for details.</p>
                <a href="<?php echo esc_url(home_url('/my-training/')); ?>" class="btn btn-primary" style="text-decoration:none;display:inline-block;">View My Sessions</a>
            </div>
        </div>
        
        <!-- Summary -->
        <div>
            <div class="card" style="position:sticky;top:24px;">
                <div class="trainer">
                    <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>">
                    <div><h3><?php echo esc_html($trainer->display_name); ?></h3><p><?php echo esc_html($trainer->headline ?: $trainer->college ?: 'Trainer'); ?></p></div>
                </div>
                <div class="row"><span>Package</span><span id="sum-pkg">Single Session</span></div>
                <div class="row" id="sum-player-row" style="display:none;"><span>Player</span><span id="sum-player"></span></div>
                <div class="row" id="sum-date-row" style="display:none;"><span>Date</span><span id="sum-date"></span></div>
                <div class="row" id="sum-time-row" style="display:none;"><span>Time</span><span id="sum-time"></span></div>
                <div class="row"><span>Duration</span><span>1 hour</span></div>
                <div class="row total"><span>Total</span><span id="sum-total">$<?php echo $rate; ?></span></div>
            </div>
        </div>
    </div>
</div>

<script src="https://js.stripe.com/v3/"></script>
<script>
(function() {
    'use strict';
    
    // Config
    const logged = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
    const trainerId = <?php echo (int)$trainer->id; ?>;
    const baseRate = <?php echo $rate; ?>;
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    const nonce = '<?php echo wp_create_nonce('ptp_nonce'); ?>';
    const hasTrainerLocations = <?php echo !empty($trainer_locations) ? 'true' : 'false'; ?>;
    
    // State
    let step = logged ? 1 : 0;
    let player = null;
    let playerName = '';
    let date = null;
    let time = null;
    let location = '';
    let pkg = { sessions: 1, price: baseRate, name: 'Single Session' };
    let month = new Date();
    
    // Guest/player data
    let guest = {};
    let playerInfo = {};
    
    // Stripe
    const stripeKey = '<?php echo esc_js($stripe_key); ?>';
    let stripe, elements, card, cardMounted = false;
    
    if (stripeKey) {
        stripe = Stripe(stripeKey);
        elements = stripe.elements();
        card = elements.create('card', { 
            style: { 
                base: { fontSize: '16px', fontFamily: 'Inter, sans-serif' } 
            } 
        });
    }
    
    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        initPlayerSelection();
        initPackages();
        initLocationSelection();
        initAccountCheckbox();
        show(step);
    });
    
    // Show step
    window.show = function(s) {
        document.querySelectorAll('.step').forEach(el => el.classList.remove('active'));
        const stepEl = document.getElementById('step-' + s);
        if (stepEl) stepEl.classList.add('active');
        
        if (s === 2) { 
            renderCal(); 
        }
        if (s === 3 && !cardMounted && card) { 
            card.mount('#card-element'); 
            cardMounted = true;
            card.on('change', function(event) {
                const displayError = document.getElementById('card-errors');
                displayError.textContent = event.error ? event.error.message : '';
            });
        }
        step = s;
    };
    
    // Navigation
    window.next = function(from) {
        if (from === 0) {
            guest.fname = document.getElementById('g-fname').value.trim();
            guest.lname = document.getElementById('g-lname').value.trim();
            guest.email = document.getElementById('g-email').value.trim();
            guest.phone = document.getElementById('g-phone').value.trim();
            
            if (!guest.fname || !guest.lname || !guest.email || !guest.phone) { 
                alert('Please fill in all fields'); 
                return; 
            }
            if (!isValidEmail(guest.email)) {
                alert('Please enter a valid email address');
                return;
            }
            show(1);
        } else if (from === 1) {
            if (!logged) {
                playerInfo.fname = document.getElementById('p-fname').value.trim();
                playerInfo.lname = document.getElementById('p-lname').value.trim();
                playerInfo.age = document.getElementById('p-age').value;
                playerInfo.skill = document.getElementById('p-skill').value;
                if (!playerInfo.fname || !playerInfo.lname || !playerInfo.age) { 
                    alert('Please fill in player information'); 
                    return; 
                }
                playerName = playerInfo.fname + ' ' + playerInfo.lname;
            } else if (!player) { 
                alert('Please select a player'); 
                return; 
            }
            updateSum();
            show(2);
        } else if (from === 2) {
            if (!date || !time) { 
                alert('Please select a date and time'); 
                return; 
            }
            // Get location
            location = getSelectedLocation();
            show(3);
        }
    };
    
    window.prev = function(from) {
        if (from === 1) show(logged ? 1 : 0);
        else if (from === 2) show(1);
        else if (from === 3) show(2);
    };
    
    // Player Selection
    function initPlayerSelection() {
        if (!logged) return;
        
        // Add click handler to existing players
        document.querySelectorAll('#players-grid .player:not(.add)').forEach(el => {
            el.addEventListener('click', function() {
                document.querySelectorAll('#players-grid .player').forEach(p => p.classList.remove('selected'));
                this.classList.add('selected');
                player = this.dataset.id;
                playerName = this.dataset.name || '';
                document.getElementById('btn-step1').disabled = false;
                updateSum();
            });
        });
    }
    
    // Player selection hook for modal integration
    window.ptpSelectPlayer = function(id, name) {
        player = id;
        playerName = name;
        updateSum();
    };
    
    // Packages
    function initPackages() {
        document.querySelectorAll('.pkg').forEach(el => {
            el.addEventListener('click', function() {
                document.querySelectorAll('.pkg').forEach(p => p.classList.remove('selected'));
                this.classList.add('selected');
                pkg = { 
                    sessions: +this.dataset.sessions, 
                    price: +this.dataset.price, 
                    name: this.dataset.name || this.querySelector('.pkg-name').textContent 
                };
                updateSum();
            });
        });
        
        // Initialize with first selected package
        const selected = document.querySelector('.pkg.selected');
        if (selected) {
            pkg = {
                sessions: +selected.dataset.sessions,
                price: +selected.dataset.price,
                name: selected.dataset.name || selected.querySelector('.pkg-name').textContent
            };
        }
    }
    
    // Location Selection
    function initLocationSelection() {
        if (!hasTrainerLocations) return;
        
        document.querySelectorAll('.location-opt').forEach(opt => {
            opt.addEventListener('click', function() {
                document.querySelectorAll('.location-opt').forEach(o => o.classList.remove('selected'));
                this.classList.add('selected');
                
                const radio = this.querySelector('input[type="radio"]');
                radio.checked = true;
                
                const customField = document.getElementById('custom-location-field');
                if (customField) {
                    customField.style.display = radio.value === 'custom' ? 'block' : 'none';
                }
            });
        });
    }
    
    function getSelectedLocation() {
        if (!hasTrainerLocations) {
            const customInput = document.getElementById('custom-location');
            return customInput ? customInput.value.trim() : '';
        }
        
        const selected = document.querySelector('input[name="location"]:checked');
        if (!selected) return '';
        
        if (selected.value === 'custom') {
            const customInput = document.getElementById('custom-location');
            return customInput ? customInput.value.trim() : '';
        }
        
        return selected.value;
    }
    
    // Account checkbox
    function initAccountCheckbox() {
        const checkbox = document.getElementById('create-acct');
        const pwFields = document.getElementById('pw-fields');
        if (checkbox && pwFields) {
            checkbox.addEventListener('change', function() {
                pwFields.style.display = this.checked ? 'block' : 'none';
            });
        }
    }
    
    // Calendar
    window.renderCal = function() {
        const y = month.getFullYear(), m = month.getMonth();
        const first = new Date(y, m, 1), last = new Date(y, m + 1, 0);
        const today = new Date(); today.setHours(0,0,0,0);
        
        document.getElementById('cal-month').textContent = first.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        
        let html = '<div class="cal-grid">';
        for (let i = 0; i < first.getDay(); i++) html += '<div class="cal-day empty"></div>';
        for (let d = 1; d <= last.getDate(); d++) {
            const dt = new Date(y, m, d);
            const str = dt.toISOString().split('T')[0];
            const past = dt < today;
            const isToday = dt.getTime() === today.getTime();
            const sel = date === str;
            html += '<div class="cal-day' + (past ? ' past' : '') + (isToday ? ' today' : '') + (sel ? ' selected' : '') + '" data-date="' + str + '">' + d + '</div>';
        }
        html += '</div>';
        document.getElementById('cal-days').innerHTML = html;
        
        document.querySelectorAll('.cal-day:not(.past):not(.empty)').forEach(el => {
            el.addEventListener('click', function() {
                document.querySelectorAll('.cal-day').forEach(d => d.classList.remove('selected'));
                this.classList.add('selected');
                date = this.dataset.date;
                time = null;
                document.getElementById('btn-step2').disabled = true;
                loadSlots(date);
                updateSum();
            });
        });
    };
    
    window.calPrev = function() { 
        month.setMonth(month.getMonth() - 1); 
        renderCal(); 
    };
    
    window.calNext = function() { 
        month.setMonth(month.getMonth() + 1); 
        renderCal(); 
    };
    
    async function loadSlots(d, retryCount = 0) {
        const box = document.getElementById('slots');
        const grid = document.getElementById('slots-grid');
        const titleEl = document.getElementById('slots-title');
        
        if (!box || !grid) {
            console.error('Slots container not found');
            return;
        }
        
        box.classList.add('show');
        
        // Format and display date
        try {
            const dateObj = new Date(d + 'T12:00:00');
            if (titleEl) {
                titleEl.textContent = dateObj.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
            }
        } catch (e) {
            if (titleEl) titleEl.textContent = d;
        }
        
        grid.innerHTML = '<div class="slots-empty"><span class="spinner"></span> Loading available times...</div>';
        
        try {
            // Validate date format
            if (!/^\d{4}-\d{2}-\d{2}$/.test(d)) {
                throw new Error('Invalid date format');
            }
            
            const fd = new FormData();
            fd.append('action', 'ptp_get_available_slots');
            fd.append('nonce', nonce);
            fd.append('trainer_id', trainerId);
            fd.append('date', d);
            
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout
            
            const res = await fetch(ajaxUrl, { 
                method: 'POST', 
                body: fd,
                signal: controller.signal
            });
            
            clearTimeout(timeoutId);
            
            if (!res.ok) {
                throw new Error('Server error: ' + res.status);
            }
            
            const data = await res.json();
            
            // Handle various response formats
            let slots = [];
            if (data.success && data.data && Array.isArray(data.data.slots)) {
                slots = data.data.slots;
            } else if (data.data && data.data.message) {
                // Server returned a message instead of slots
                console.log('Server message:', data.data.message);
            }
            
            // If no slots configured, show default time slots
            if (slots.length === 0) {
                const defaultTimes = ['09:00','10:00','11:00','12:00','14:00','15:00','16:00','17:00','18:00','19:00'];
                grid.innerHTML = defaultTimes.map(t => {
                    return '<div class="slot" data-time="' + t + '">' + fmtTime(t) + '</div>';
                }).join('');
                
                // Add click handlers for default slots
                document.querySelectorAll('.slot').forEach(el => {
                    el.addEventListener('click', function() {
                        document.querySelectorAll('.slot').forEach(s => s.classList.remove('selected'));
                        this.classList.add('selected');
                        time = this.dataset.time;
                        const btn = document.getElementById('btn-step2');
                        if (btn) btn.disabled = false;
                        updateSum();
                    });
                });
                return;
            }
            
            // Render slots with validation
            grid.innerHTML = slots.map(s => {
                const timeVal = s.start || s.time || '';
                const displayTime = s.display || fmtTime(timeVal);
                if (!timeVal) return '';
                return '<div class="slot" data-time="' + escapeHtml(timeVal) + '">' + escapeHtml(displayTime) + '</div>';
            }).filter(Boolean).join('');
            
            // Add click handlers
            document.querySelectorAll('.slot').forEach(el => {
                el.addEventListener('click', function() {
                    document.querySelectorAll('.slot').forEach(s => s.classList.remove('selected'));
                    this.classList.add('selected');
                    time = this.dataset.time;
                    const btn = document.getElementById('btn-step2');
                    if (btn) btn.disabled = false;
                    updateSum();
                });
            });
            
        } catch (e) {
            console.error('Load slots error:', e);
            
            // Retry once on network errors
            if (retryCount < 1 && (e.name === 'AbortError' || e.message.includes('network'))) {
                console.log('Retrying slots load...');
                setTimeout(() => loadSlots(d, retryCount + 1), 1000);
                return;
            }
            
            grid.innerHTML = '<div class="slots-empty">Unable to load times.<br><button type="button" onclick="loadSlots(\'' + d + '\')" style="margin-top:10px;padding:8px 16px;background:#FCB900;border:none;border-radius:6px;font-weight:600;cursor:pointer;">Try Again</button></div>';
        }
    }
    
    function fmtTime(t) {
        if (!t || typeof t !== 'string') return '';
        const parts = t.split(':');
        if (parts.length < 2) return t;
        const h = parseInt(parts[0], 10);
        const m = parts[1];
        if (isNaN(h)) return t;
        return (h % 12 || 12) + ':' + m + ' ' + (h >= 12 ? 'PM' : 'AM');
    }
    
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function updateSum() {
        document.getElementById('sum-pkg').textContent = pkg.name;
        document.getElementById('sum-total').textContent = '$' + pkg.price;
        
        const payBtn = document.getElementById('btn-pay');
        if (payBtn) payBtn.textContent = 'Pay $' + pkg.price;
        
        // Player
        const playerRow = document.getElementById('sum-player-row');
        const playerEl = document.getElementById('sum-player');
        if (playerRow && playerEl && playerName) {
            playerRow.style.display = 'flex';
            playerEl.textContent = playerName;
        }
        
        // Date
        if (date) {
            document.getElementById('sum-date-row').style.display = 'flex';
            document.getElementById('sum-date').textContent = new Date(date + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
        }
        
        // Time
        if (time) {
            document.getElementById('sum-time-row').style.display = 'flex';
            document.getElementById('sum-time').textContent = fmtTime(time);
        }
    }
    
    // Payment
    window.pay = async function() {
        const btn = document.getElementById('btn-pay');
        btn.disabled = true; 
        btn.innerHTML = '<span class="spinner"></span>Processing...';
        
        try {
            // Build booking data
            const fd = new FormData();
            fd.append('action', 'ptp_create_booking');
            fd.append('nonce', nonce);
            fd.append('trainer_id', trainerId);
            fd.append('date', date);
            fd.append('time', time);
            fd.append('package_sessions', pkg.sessions);
            fd.append('package_price', pkg.price);
            fd.append('location', location);
            fd.append('notes', document.getElementById('booking-notes')?.value || '');
            
            if (logged) {
                fd.append('player_id', player);
            } else {
                fd.append('is_guest', '1');
                fd.append('guest_email', guest.email);
                fd.append('guest_first_name', guest.fname);
                fd.append('guest_last_name', guest.lname);
                fd.append('guest_phone', guest.phone);
                fd.append('player_first_name', playerInfo.fname);
                fd.append('player_last_name', playerInfo.lname);
                fd.append('player_age', playerInfo.age);
                fd.append('player_skill', playerInfo.skill);
                
                if (document.getElementById('create-acct')?.checked) {
                    const pw = document.getElementById('acct-pw').value;
                    const pw2 = document.getElementById('acct-pw2').value;
                    if (pw.length < 8) throw new Error('Password must be at least 8 characters');
                    if (pw !== pw2) throw new Error('Passwords do not match');
                    fd.append('create_account', '1');
                    fd.append('password', pw);
                }
            }
            
            const res = await fetch(ajaxUrl, { method: 'POST', body: fd });
            const data = await res.json();
            if (!data.success) throw new Error(data.data?.message || 'Booking failed');
            
            const bookingId = data.data.booking_id;
            
            // Create payment intent
            const fd2 = new FormData();
            fd2.append('action', 'ptp_create_payment_intent');
            fd2.append('nonce', nonce);
            fd2.append('booking_id', bookingId);
            fd2.append('amount', pkg.price);
            
            const res2 = await fetch(ajaxUrl, { method: 'POST', body: fd2 });
            const data2 = await res2.json();
            if (!data2.success) throw new Error(data2.data?.message || 'Payment setup failed');
            
            // Confirm payment
            const { error, paymentIntent } = await stripe.confirmCardPayment(data2.data.client_secret || data2.data.clientSecret, {
                payment_method: { card: card }
            });
            if (error) throw new Error(error.message);
            
            // Confirm booking
            const fd3 = new FormData();
            fd3.append('action', 'ptp_confirm_booking_payment');
            fd3.append('nonce', nonce);
            fd3.append('booking_id', bookingId);
            fd3.append('payment_intent_id', paymentIntent.id);
            await fetch(ajaxUrl, { method: 'POST', body: fd3 });
            
            show('done');
        } catch (e) {
            alert(e.message);
            btn.disabled = false; 
            btn.textContent = 'Pay $' + pkg.price;
        }
    };
    
    // Helpers
    function isValidEmail(email) {
        return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }
})();
</script>

</body>
</html>
