<?php
/**
 * Template: Trainer Profile v24.4.3
 * Interactive calendar with inline booking
 */
defined('ABSPATH') || exit;

// Get trainer
$slug = get_query_var('trainer_slug');
if (empty($slug)) $slug = isset($_GET['trainer']) ? sanitize_text_field($_GET['trainer']) : '';
if (empty($slug)) {
    $path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    if (preg_match('#trainer/([^/]+)/?$#', $path, $m)) $slug = sanitize_text_field($m[1]);
}
$trainer = $slug ? PTP_Trainer::get_by_slug($slug) : null;

if (!$trainer || $trainer->status !== 'active') {
    echo '<div style="min-height:100vh;display:flex;align-items:center;justify-content:center;padding:40px;background:#F3F4F6;">
        <div style="background:#fff;border-radius:16px;padding:40px;text-align:center;max-width:400px;">
            <h2 style="margin:0 0 12px;">Trainer Not Found</h2>
            <p style="color:#6B7280;margin:0 0 24px;">This trainer isn\'t available.</p>
            <a href="' . esc_url(home_url('/find-trainers/')) . '" style="display:inline-block;background:#FCB900;color:#000;padding:14px 28px;border-radius:10px;font-weight:700;text-decoration:none;">Find Trainers</a>
        </div>
    </div>';
    return;
}

$photo = $trainer->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($trainer->display_name) . '&size=400&background=FCB900&color=0A0A0A';
$rate = (int)($trainer->hourly_rate ?: 80);
$location = $trainer->city && $trainer->state ? $trainer->city . ', ' . $trainer->state : ($trainer->location ?: 'Philadelphia Area');
$rating = $trainer->average_rating ? number_format((float)$trainer->average_rating, 1) : '5.0';
$reviews = class_exists('PTP_Reviews') ? PTP_Reviews::get_trainer_reviews($trainer->id) : array();
$review_count = is_array($reviews) ? count($reviews) : 0;
$specialties = !empty($trainer->specialties) ? (is_array(json_decode($trainer->specialties, true)) ? json_decode($trainer->specialties, true) : explode(',', $trainer->specialties)) : array();
$bio = $trainer->bio ?: ($trainer->college ? "Trained at {$trainer->college}." : "Elite soccer trainer.");

// Credential badge
$level_labels = array(
    'pro' => 'Professional Player',
    'college_d1' => 'NCAA Division 1',
    'college_d2' => 'NCAA Division 2', 
    'college_d3' => 'NCAA Division 3',
    'academy' => 'MLS/NWSL Academy',
    'semi_pro' => 'Semi-Professional',
    'high_level_club' => 'Elite Club'
);
$level_colors = array(
    'pro' => '#7C3AED',
    'college_d1' => '#2563EB',
    'college_d2' => '#3B82F6',
    'college_d3' => '#60A5FA',
    'academy' => '#059669',
    'semi_pro' => '#D97706',
    'high_level_club' => '#6B7280'
);
$playing_level = $trainer->playing_level ?? '';
$level_label = isset($level_labels[$playing_level]) ? $level_labels[$playing_level] : '';
$level_color = isset($level_colors[$playing_level]) ? $level_colors[$playing_level] : '#6B7280';

// Get parent and players if logged in
$is_logged_in = is_user_logged_in();
$user_id = $is_logged_in ? get_current_user_id() : 0;
$parent = null;
$players = array();

if ($is_logged_in && class_exists('PTP_Parent')) {
    $parent = PTP_Parent::get_by_user_id($user_id);
    if ($parent && class_exists('PTP_Player')) {
        $players = PTP_Player::get_by_parent($parent->id);
    }
}

// Get trainer's training locations
$training_locations = array();
if (!empty($trainer->training_locations)) {
    $decoded = json_decode($trainer->training_locations, true);
    if (is_array($decoded)) {
        $training_locations = $decoded;
    } else {
        // Handle comma-separated string
        $training_locations = array_filter(array_map('trim', explode(',', $trainer->training_locations)));
    }
}

// Package pricing
$packages = array(
    1 => array('sessions' => 1, 'price' => $rate, 'label' => 'Single Session'),
    4 => array('sessions' => 4, 'price' => round($rate * 4 * 0.95), 'label' => '4 Sessions', 'save' => 5),
    8 => array('sessions' => 8, 'price' => round($rate * 8 * 0.90), 'label' => '8 Sessions', 'save' => 10),
    12 => array('sessions' => 12, 'price' => round($rate * 12 * 0.85), 'label' => '12 Sessions', 'save' => 15),
);

// SEO
$title = $trainer->display_name . ' - Soccer Training in ' . $location . ' | PTP';
$desc = $trainer->display_name . ' offers private 1-on-1 soccer training in ' . $location . '. Starting at $' . $rate . '/session.';
$google_maps_api_key = get_option('ptp_google_maps_api_key', '');

// Stripe key for payments
$stripe_key = get_option('ptp_stripe_test_mode') ? get_option('ptp_stripe_test_publishable') : get_option('ptp_stripe_live_publishable');

// Get parent phone if logged in
$parent_phone = '';
if ($parent && !empty($parent->phone)) {
    $parent_phone = $parent->phone;
} elseif ($is_logged_in) {
    $parent_phone = get_user_meta($user_id, 'phone', true) ?: get_user_meta($user_id, 'billing_phone', true) ?: '';
}
?>

<style>
/* Reset */
html, body { overflow-x: hidden !important; max-width: 100vw; }
.ptp-profile { font-family: 'Inter', -apple-system, sans-serif; background: #F3F4F6; min-height: 100vh; margin: 0 -9999px; padding: 0 9999px; overflow-x: hidden; }
.ptp-profile * { box-sizing: border-box; }

.ptp-profile-container { max-width: 1100px; margin: 0 auto; padding: 24px 16px 120px; }

/* Header */
.ptp-back { display: inline-flex; align-items: center; gap: 6px; color: #6B7280; text-decoration: none; font-size: 14px; margin-bottom: 20px; }
.ptp-back:hover { color: #FCB900; }

/* Grid */
.ptp-grid { display: grid; gap: 24px; }
@media (min-width: 900px) { .ptp-grid { grid-template-columns: 400px 1fr; } }

/* Photo */
.ptp-photo-card { background: #fff; border-radius: 20px; overflow: hidden; }
.ptp-photo-card img { width: 100%; aspect-ratio: 4/5; object-fit: cover; object-position: top; display: block; }
@media (min-width: 900px) { .ptp-photo-card { position: sticky; top: 24px; } }

/* Info Column */
.ptp-info { display: flex; flex-direction: column; gap: 20px; }

/* Cards */
.ptp-card { background: #fff; border-radius: 20px; padding: 24px; }

/* Credential Badge */
.ptp-credential-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    color: #fff;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-radius: 8px;
    margin-bottom: 16px;
}

.ptp-credential-badge svg {
    color: #FCD34D;
}

/* Profile Header */
.ptp-name { font-size: 32px; font-weight: 800; margin: 0 0 6px; color: #111; }
.ptp-headline { color: #6B7280; font-size: 16px; margin: 0 0 12px; }

.ptp-affiliation {
    display: flex;
    flex-wrap: wrap;
    gap: 16px;
    margin-bottom: 16px;
    padding-bottom: 16px;
    border-bottom: 1px solid #E5E7EB;
}

.ptp-affiliation span {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    font-weight: 600;
    color: #374151;
}

.ptp-affiliation svg {
    color: #9CA3AF;
}

.ptp-rating { display: flex; align-items: center; gap: 8px; margin-bottom: 16px; }
.ptp-stars { color: #FCB900; font-size: 18px; }
.ptp-rating-num { font-weight: 700; font-size: 16px; }
.ptp-rating-count { color: #6B7280; font-size: 14px; }

.ptp-meta { display: flex; flex-wrap: wrap; gap: 16px; padding: 16px 0; border-top: 1px solid #E5E7EB; }
.ptp-meta-item { display: flex; align-items: center; gap: 6px; font-size: 14px; color: #4B5563; }
.ptp-meta-item svg { width: 16px; height: 16px; color: #9CA3AF; }

.ptp-price-row { display: flex; justify-content: space-between; align-items: center; margin-top: 16px; padding-top: 16px; border-top: 1px solid #E5E7EB; }
.ptp-price { font-size: 28px; font-weight: 800; color: #111; }
.ptp-price span { font-size: 16px; font-weight: 400; color: #6B7280; }

/* Section Title */
.ptp-section-title { display: flex; align-items: center; gap: 10px; font-size: 18px; font-weight: 700; margin-bottom: 16px; color: #111; }
.ptp-section-title svg { width: 20px; height: 20px; color: #FCB900; }

/* Calendar */
.ptp-cal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px; }
.ptp-cal-month { font-size: 16px; font-weight: 600; }
.ptp-cal-nav { display: flex; gap: 8px; }
.ptp-cal-nav button { width: 36px; height: 36px; border: 2px solid #E5E7EB; border-radius: 10px; background: #fff; cursor: pointer; font-size: 18px; color: #4B5563; }
.ptp-cal-nav button:hover { border-color: #FCB900; }

.ptp-cal-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; }
.ptp-cal-day-name { text-align: center; font-size: 12px; font-weight: 600; color: #9CA3AF; padding: 8px 0; }
.ptp-cal-day { aspect-ratio: 1; display: flex; align-items: center; justify-content: center; border-radius: 10px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all 0.2s; }
.ptp-cal-day.empty { cursor: default; }
.ptp-cal-day.past { color: #D1D5DB; cursor: default; }
.ptp-cal-day.avail { background: #D1FAE5; color: #065F46; }
.ptp-cal-day.avail:hover { background: #A7F3D0; }
.ptp-cal-day.today { border: 2px solid #FCB900; }
.ptp-cal-day.selected { background: #FCB900 !important; color: #000 !important; }

/* Time Slots */
.ptp-slots { margin-top: 20px; padding-top: 20px; border-top: 1px solid #E5E7EB; display: none; }
.ptp-slots.show { display: block; }
.ptp-slots-title { font-weight: 600; margin-bottom: 12px; color: #111; }
.ptp-slots-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
@media (max-width: 500px) { .ptp-slots-grid { grid-template-columns: repeat(2, 1fr); } }

/* Booking Steps */
.ptp-booking-step {
    padding: 20px 0;
    border-bottom: 1px solid #E5E7EB;
}
.ptp-booking-step:last-of-type {
    border-bottom: none;
}

.ptp-step-label {
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 15px;
    font-weight: 600;
    color: #111;
    margin-bottom: 16px;
}

.ptp-step-num {
    width: 28px;
    height: 28px;
    background: #FCB900;
    color: #000;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    font-weight: 700;
}

/* Location Cards */
.ptp-location-cards {
    display: flex;
    flex-direction: column;
    gap: 12px;
}

.ptp-location-card {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 16px;
    border: 2px solid #E5E7EB;
    border-radius: 14px;
    cursor: pointer;
    transition: all 0.2s;
    background: #fff;
}

.ptp-location-card:hover {
    border-color: #FCB900;
    background: #FFFBEB;
}

.ptp-location-card.selected {
    border-color: #FCB900;
    background: #FFFBEB;
}

.ptp-location-card-icon {
    width: 48px;
    height: 48px;
    background: #F3F4F6;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.ptp-location-card.selected .ptp-location-card-icon {
    background: #FCB900;
}

.ptp-location-card-icon svg {
    color: #6B7280;
}

.ptp-location-card.selected .ptp-location-card-icon svg {
    color: #000;
}

.ptp-location-card-info {
    flex: 1;
}

.ptp-location-card-name {
    font-weight: 600;
    font-size: 15px;
    color: #111;
    margin-bottom: 2px;
}

.ptp-location-card-dist {
    font-size: 13px;
    color: #6B7280;
}

.ptp-location-map-link {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-size: 12px;
    color: #0284C7;
    text-decoration: none;
    padding: 4px 8px;
    background: #E0F2FE;
    border-radius: 6px;
    margin-top: 4px;
    transition: all 0.2s;
}

.ptp-location-map-link:hover {
    background: #BAE6FD;
    color: #0369A1;
}

.ptp-location-card-check {
    width: 24px;
    height: 24px;
    border: 2px solid #E5E7EB;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: all 0.2s;
}

.ptp-location-card.selected .ptp-location-card-check {
    opacity: 1;
    background: #10B981;
    border-color: #10B981;
}

.ptp-location-card-check svg {
    color: #fff;
}

.ptp-no-locations-msg {
    text-align: center;
    padding: 30px 20px;
    background: #F9FAFB;
    border-radius: 12px;
}

.ptp-no-locations-msg p {
    color: #6B7280;
    margin: 12px 0;
}

/* DateTime Grid */
.ptp-datetime-grid {
    display: grid;
    gap: 20px;
}

@media (min-width: 600px) {
    .ptp-datetime-grid {
        grid-template-columns: 1fr 1fr;
    }
}

.ptp-cal-section {
    background: #F9FAFB;
    border-radius: 12px;
    padding: 16px;
}

.ptp-time-section {
    background: #F9FAFB;
    border-radius: 12px;
    padding: 16px;
    display: block;
}

/* Booking Summary */
.ptp-booking-summary {
    background: #F9FAFB;
    border-radius: 12px;
    padding: 16px;
    margin: 20px 0;
}

.ptp-summary-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    font-size: 14px;
    color: #6B7280;
}

.ptp-summary-row span:last-child {
    font-weight: 600;
    color: #111;
}

.ptp-summary-total {
    border-top: 1px solid #E5E7EB;
    margin-top: 8px;
    padding-top: 12px;
    font-size: 16px;
}

.ptp-summary-total span:last-child {
    font-size: 18px;
    color: #059669;
}
.ptp-slot { padding: 12px; border: 2px solid #E5E7EB; border-radius: 10px; text-align: center; font-size: 14px; font-weight: 500; cursor: pointer; transition: all 0.2s; }
.ptp-slot:hover { border-color: #FCB900; background: #FFFBEB; }
.ptp-slot.selected { background: #FCB900; border-color: #FCB900; }
.ptp-slots-empty { text-align: center; padding: 20px; color: #6B7280; }

/* Booking Form */
.ptp-booking-form { margin-top: 20px; padding-top: 20px; border-top: 1px solid #E5E7EB; display: none; }
.ptp-booking-form.show { display: block; }
.ptp-booking-summary { background: #F9FAFB; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
.ptp-booking-summary-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 14px; }
.ptp-booking-summary-row:last-child { margin-bottom: 0; padding-top: 8px; border-top: 1px solid #E5E7EB; font-weight: 700; }

.ptp-form-group { margin-bottom: 16px; }
.ptp-form-label { display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 6px; }
.ptp-form-input, .ptp-form-select { width: 100%; padding: 12px 14px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px; }
.ptp-form-input:focus, .ptp-form-select:focus { outline: none; border-color: #FCB900; }

.ptp-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
@media (max-width: 500px) { .ptp-form-row { grid-template-columns: 1fr; } }

/* Package Selection */
.ptp-packages { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 20px; }
@media (max-width: 500px) { .ptp-packages { grid-template-columns: 1fr; } }
.ptp-package { padding: 14px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; transition: all 0.2s; position: relative; }
.ptp-package:hover { border-color: #FCB900; }
.ptp-package.selected { border-color: #FCB900; background: #FFFBEB; }
.ptp-package-name { font-weight: 600; margin-bottom: 4px; }
.ptp-package-price { font-size: 18px; font-weight: 700; }
.ptp-package-price span { font-size: 13px; font-weight: 400; color: #6B7280; }
.ptp-package-save { position: absolute; top: -8px; right: 10px; background: #10B981; color: #fff; font-size: 10px; font-weight: 700; padding: 3px 8px; border-radius: 10px; }

/* Player Selection */
.ptp-players { display: flex; flex-direction: column; gap: 8px; margin-bottom: 16px; }
.ptp-player { display: flex; align-items: center; gap: 12px; padding: 12px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; transition: all 0.2s; }
.ptp-player:hover { border-color: #FCB900; }
.ptp-player.selected { border-color: #FCB900; background: #FFFBEB; }
.ptp-player-avatar { width: 40px; height: 40px; border-radius: 50%; background: #FCB900; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #000; }
.ptp-player-info { flex: 1; }
.ptp-player-name { font-weight: 600; }
.ptp-player-meta { font-size: 12px; color: #6B7280; }
.ptp-add-player { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 14px; border: 2px dashed #D1D5DB; border-radius: 12px; color: #6B7280; cursor: pointer; font-weight: 500; }
.ptp-add-player:hover { border-color: #FCB900; color: #FCB900; }

/* Location Selection */
.ptp-locations { display: flex; flex-direction: column; gap: 8px; }
.ptp-location { display: flex; align-items: center; gap: 10px; padding: 14px 16px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; transition: all 0.2s; }
.ptp-location:hover { border-color: #FCB900; background: #FFFBEB; }
.ptp-location.selected { border-color: #FCB900; background: #FFFBEB; }
.ptp-location svg { color: #9CA3AF; flex-shrink: 0; }
.ptp-location.selected svg { color: #FCB900; }
.ptp-location span { font-weight: 500; }

/* Submit Button */
.ptp-submit { width: 100%; padding: 16px; background: #FCB900; color: #000; border: none; border-radius: 12px; font-size: 16px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
.ptp-submit:hover { background: #E5A800; transform: translateY(-1px); }
.ptp-submit:disabled { background: #E5E7EB; color: #9CA3AF; cursor: not-allowed; transform: none; }

/* Login CTA */
.ptp-login-cta { background: linear-gradient(135deg, #111 0%, #333 100%); border-radius: 16px; padding: 24px; text-align: center; }
.ptp-login-cta h3 { color: #fff; margin: 0 0 8px; }
.ptp-login-cta p { color: rgba(255,255,255,0.7); font-size: 14px; margin: 0 0 16px; }
.ptp-login-btn { display: inline-block; background: #FCB900; color: #000; padding: 12px 24px; border-radius: 10px; font-weight: 700; text-decoration: none; }

/* Specialties */
.ptp-specs { display: flex; flex-wrap: wrap; gap: 8px; }
.ptp-spec { background: #F3F4F6; padding: 8px 14px; border-radius: 20px; font-size: 13px; font-weight: 500; }

/* Bio */
.ptp-bio { color: #4B5563; line-height: 1.7; }

/* Fixed Mobile Bar */
.ptp-fixed-bar { display: none; position: fixed; bottom: 0; left: 0; right: 0; background: #fff; padding: 12px 16px; box-shadow: 0 -4px 20px rgba(0,0,0,0.1); z-index: 1000; }
.ptp-fixed-inner { display: flex; justify-content: space-between; align-items: center; max-width: 600px; margin: 0 auto; }
.ptp-fixed-price { font-size: 20px; font-weight: 800; }
.ptp-fixed-price span { font-size: 14px; font-weight: 400; color: #6B7280; }
.ptp-fixed-btn { background: #FCB900; color: #000; padding: 14px 24px; border-radius: 12px; font-weight: 700; text-decoration: none; border: none; cursor: pointer; }
@media (max-width: 899px) { .ptp-fixed-bar { display: block; } }

/* Add Player Modal */
.ptp-modal-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 2000; align-items: center; justify-content: center; padding: 20px; }
.ptp-modal-overlay.show { display: flex; }
.ptp-modal { background: #fff; border-radius: 20px; padding: 24px; max-width: 400px; width: 100%; max-height: 90vh; overflow-y: auto; }
.ptp-modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.ptp-modal-title { font-size: 20px; font-weight: 700; }
.ptp-modal-close { width: 32px; height: 32px; border: none; background: #F3F4F6; border-radius: 8px; cursor: pointer; font-size: 18px; }

/* Message Form */
.ptp-message-form textarea.ptp-form-input { min-height: 80px; resize: vertical; }
.ptp-msg-btn { display: inline-flex; align-items: center; gap: 8px; justify-content: center; }
.ptp-msg-btn svg { flex-shrink: 0; }

/* Share Buttons */
.ptp-share-buttons { display: flex; flex-wrap: wrap; gap: 10px; }
.ptp-share-btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 10px; background: #fff; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.ptp-share-btn:hover { border-color: #FCB900; background: #FFFBEB; }
.ptp-share-btn.sms { color: #10B981; }
.ptp-share-btn.sms:hover { border-color: #10B981; background: #ECFDF5; }
.ptp-share-btn.email { color: #3B82F6; }
.ptp-share-btn.email:hover { border-color: #3B82F6; background: #EFF6FF; }
.ptp-share-btn.facebook { color: #1877F2; }
.ptp-share-btn.facebook:hover { border-color: #1877F2; background: #EFF6FF; }
.ptp-share-btn.copy { color: #6B7280; }
.ptp-share-btn.copy:hover { border-color: #6B7280; background: #F9FAFB; }

/* Mobile Optimizations */
@media (max-width: 899px) {
    .ptp-profile-container { padding: 16px 12px 100px; }
    .ptp-card { padding: 20px 16px; border-radius: 16px; }
    .ptp-name { font-size: 26px; }
    .ptp-price { font-size: 24px; }
    .ptp-section-title { font-size: 16px; }
    .ptp-grid { gap: 16px; }
}

@media (max-width: 600px) {
    .ptp-profile-container { padding: 12px 12px 100px; }
    
    /* Photo card */
    .ptp-photo-card { border-radius: 16px; }
    .ptp-photo-card img { height: 280px; }
    
    /* Info card */
    .ptp-card { padding: 16px 14px; margin-bottom: 12px; }
    .ptp-name { font-size: 22px; line-height: 1.2; }
    .ptp-tagline { font-size: 14px; }
    .ptp-price { font-size: 22px; }
    .ptp-section-title { font-size: 15px; margin-bottom: 12px; }
    
    /* Stats row */
    .ptp-stats-row { flex-wrap: wrap; gap: 12px; }
    .ptp-stat { min-width: calc(50% - 6px); }
    
    /* Back link */
    .ptp-back { font-size: 13px; padding: 10px 0; margin-bottom: 12px; }
    
    /* Credential badge */
    .ptp-credential-badge { font-size: 11px; padding: 6px 10px; }
    
    /* Bio text */
    .ptp-bio { font-size: 14px; line-height: 1.6; }
    
    /* Specialty tags */
    .ptp-specialty { font-size: 12px; padding: 6px 12px; }
    
    /* Fixed bottom button */
    .ptp-fixed-btn {
        padding: 16px 24px;
        font-size: 16px;
        border-radius: 14px;
    }
}

@media (max-width: 500px) {
    .ptp-share-buttons { gap: 8px; }
    .ptp-share-btn { flex: 1 1 calc(50% - 4px); justify-content: center; padding: 12px 10px; font-size: 13px; min-height: 48px; }
    .ptp-form-row { grid-template-columns: 1fr; gap: 12px; }
    .ptp-packages { grid-template-columns: 1fr; }
    .ptp-package { padding: 16px; min-height: 48px; }
    .ptp-cal-grid { gap: 2px; }
    .ptp-cal-day { font-size: 12px; min-height: 40px; min-width: 40px; }
    .ptp-slots-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
    .ptp-slot { padding: 12px 10px; font-size: 14px; min-height: 48px; }
    .ptp-submit { padding: 18px; font-size: 16px; min-height: 56px; }
    .ptp-booking-summary { padding: 14px; }
    .ptp-booking-summary-row { font-size: 13px; }
    
    /* Calendar navigation */
    .ptp-cal-nav button { min-width: 44px; min-height: 44px; }
    
    /* Form inputs */
    .ptp-form-group input,
    .ptp-form-group select,
    .ptp-form-group textarea {
        font-size: 16px; /* Prevents iOS zoom */
        min-height: 48px;
        padding: 14px;
    }
}

@media (max-width: 380px) {
    .ptp-name { font-size: 20px; }
    .ptp-price { font-size: 20px; }
    .ptp-photo-card img { height: 240px; }
    .ptp-slot { padding: 10px 8px; font-size: 13px; }
}
</style>

<div class="ptp-profile">
    <div class="ptp-profile-container">
        <a href="<?php echo esc_url(home_url('/find-trainers/')); ?>" class="ptp-back">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            Find Trainers
        </a>
        
        <div class="ptp-grid">
            <!-- Photo -->
            <div class="ptp-photo-card">
                <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>">
            </div>
            
            <!-- Info -->
            <div class="ptp-info">
                <!-- Profile Card -->
                <div class="ptp-card">
                    <?php if ($level_label): ?>
                    <div class="ptp-credential-badge" style="background: <?php echo esc_attr($level_color); ?>;">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                        <?php echo esc_html($level_label); ?>
                    </div>
                    <?php endif; ?>
                    
                    <h1 class="ptp-name"><?php echo esc_html($trainer->display_name); ?></h1>
                    <p class="ptp-headline"><?php echo esc_html($trainer->headline ?: ($trainer->college ?: 'Elite Soccer Trainer')); ?></p>
                    
                    <?php if ($trainer->team || $trainer->college): ?>
                    <div class="ptp-affiliation">
                        <?php if ($trainer->team): ?>
                        <span class="ptp-team">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                            <?php echo esc_html($trainer->team); ?>
                        </span>
                        <?php endif; ?>
                        <?php if ($trainer->college): ?>
                        <span class="ptp-college">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                            <?php echo esc_html($trainer->college); ?>
                        </span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="ptp-rating">
                        <span class="ptp-stars"><?php echo str_repeat('★', max(1, (int)round((float)$rating))); ?></span>
                        <span class="ptp-rating-num"><?php echo $rating; ?></span>
                        <span class="ptp-rating-count">(<?php echo $review_count; ?> reviews)</span>
                    </div>
                    
                    <div class="ptp-meta">
                        <div class="ptp-meta-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            <?php echo esc_html($location); ?>
                        </div>
                        <?php if ($trainer->travel_radius): ?>
                        <div class="ptp-meta-item">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                            Travels <?php echo esc_html($trainer->travel_radius); ?> mi
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ptp-price-row">
                        <div class="ptp-price">$<?php echo $rate; ?> <span>/session</span></div>
                    </div>
                </div>
                
                <!-- Booking Calendar -->
                <div class="ptp-card" id="booking-section">
                    <h2 class="ptp-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        Book a Session
                    </h2>
                    
                    <?php if ($is_logged_in): ?>
                    
                    <!-- Step 1: Select Location -->
                    <div class="ptp-booking-step" id="step-location">
                        <div class="ptp-step-label">
                            <span class="ptp-step-num">1</span>
                            Select Training Location
                        </div>
                        
                        <?php if (!empty($training_locations)): ?>
                        <div class="ptp-location-cards" id="locations-list">
                            <?php foreach ($training_locations as $idx => $loc): 
                                $maps_url = 'https://www.google.com/maps/search/' . urlencode($loc);
                            ?>
                            <div class="ptp-location-card" data-location="<?php echo esc_attr($loc); ?>" data-index="<?php echo $idx; ?>">
                                <div class="ptp-location-card-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                </div>
                                <div class="ptp-location-card-info">
                                    <div class="ptp-location-card-name"><?php echo esc_html($loc); ?></div>
                                    <a href="<?php echo esc_url($maps_url); ?>" target="_blank" class="ptp-location-map-link" onclick="event.stopPropagation();">
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                                        Open in Google Maps
                                    </a>
                                </div>
                                <div class="ptp-location-card-check">
                                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else: ?>
                        <div class="ptp-no-locations-msg">
                            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="1.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            <p>This trainer hasn't set up training locations yet.</p>
                            <input type="text" class="ptp-form-input" id="location-input" placeholder="Suggest a location (park, field, address)">
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Step 2: Select Date & Time -->
                    <div class="ptp-booking-step" id="step-datetime">
                        <div class="ptp-step-label">
                            <span class="ptp-step-num">2</span>
                            Select Date & Time
                        </div>
                        
                        <div class="ptp-datetime-grid">
                            <!-- Calendar -->
                            <div class="ptp-cal-section">
                                <div class="ptp-cal-header">
                                    <span class="ptp-cal-month" id="cal-month"></span>
                                    <div class="ptp-cal-nav">
                                        <button onclick="calPrev()">‹</button>
                                        <button onclick="calNext()">›</button>
                                    </div>
                                </div>
                                <div class="ptp-cal-grid">
                                    <div class="ptp-cal-day-name">S</div>
                                    <div class="ptp-cal-day-name">M</div>
                                    <div class="ptp-cal-day-name">T</div>
                                    <div class="ptp-cal-day-name">W</div>
                                    <div class="ptp-cal-day-name">T</div>
                                    <div class="ptp-cal-day-name">F</div>
                                    <div class="ptp-cal-day-name">S</div>
                                </div>
                                <div id="cal-days"></div>
                            </div>
                            
                            <!-- Time Slots -->
                            <div class="ptp-time-section" id="slots">
                                <div class="ptp-slots-title" id="slots-title">Select a date first</div>
                                <div class="ptp-slots-grid" id="slots-grid"></div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Step 3: Player & Details -->
                    <div class="ptp-booking-step" id="step-details">
                        <div class="ptp-step-label">
                            <span class="ptp-step-num">3</span>
                            Player & Details
                        </div>
                        
                        <!-- Player Selection -->
                        <div class="ptp-form-group">
                            <label class="ptp-form-label">Select Player</label>
                            <div class="ptp-players">
                                <?php if (!empty($players)): ?>
                                    <?php foreach ($players as $p): ?>
                                    <div class="ptp-player" data-player="<?php echo $p->id; ?>">
                                        <div class="ptp-player-avatar"><?php echo strtoupper(substr($p->name, 0, 1)); ?></div>
                                        <div class="ptp-player-info">
                                            <div class="ptp-player-name"><?php echo esc_html($p->name); ?></div>
                                            <div class="ptp-player-meta">Age <?php echo esc_html($p->age); ?> • <?php echo ucfirst($p->skill_level ?: 'Beginner'); ?></div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                <div class="ptp-add-player" onclick="document.getElementById('add-player-modal').style.display='flex';">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                    Add New Player
                                </div>
                            </div>
                        </div>
                        
                        <!-- Notes -->
                        <div class="ptp-form-group">
                            <label class="ptp-form-label">Notes (optional)</label>
                            <textarea class="ptp-form-input" id="notes-input" rows="2" placeholder="Skills to work on, injuries, etc."></textarea>
                        </div>
                    </div>
                    
                    <!-- Booking Summary -->
                    <div class="ptp-booking-summary" id="booking-summary">
                        <div class="ptp-summary-row">
                            <span>Location</span>
                            <span id="summary-location">-</span>
                        </div>
                        <div class="ptp-summary-row">
                            <span>Date</span>
                            <span id="summary-date">-</span>
                        </div>
                        <div class="ptp-summary-row">
                            <span>Time</span>
                            <span id="summary-time">-</span>
                        </div>
                        <div class="ptp-summary-row ptp-summary-total">
                            <span>Total</span>
                            <span>$<?php echo $rate; ?></span>
                        </div>
                    </div>
                    
                    <!-- Submit -->
                    <button class="ptp-submit" id="submit-btn" disabled onclick="submitBooking()">Select date & time to continue</button>
                    
                    <!-- Quick Message Link -->
                    <div style="text-align: center; margin-top: 12px;">
                        <a href="#contact-section" onclick="document.getElementById('contact-section').scrollIntoView({behavior:'smooth'}); return false;" style="color: #6B7280; font-size: 13px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px;">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                            Or send a message first
                        </a>
                    </div>
                    
                    <?php else: ?>
                        <!-- Guest Booking CTA -->
                        <div class="ptp-login-cta" style="text-align:center; padding: 30px 0;">
                            <h3 style="margin:0 0 8px;">Ready to book?</h3>
                            <p style="color:#6B7280;margin:0 0 16px;">No account needed - book as a guest!</p>
                            <a href="<?php echo esc_url(home_url('/book/?trainer=' . $trainer->slug)); ?>" class="ptp-submit" style="display:inline-block;text-decoration:none;">Book Session - $<?php echo $rate; ?>/hr</a>
                            <p style="color:#9CA3AF;font-size:12px;margin:16px 0 0;">Have an account? <a href="<?php echo esc_url(home_url('/login/?redirect=' . urlencode($_SERVER['REQUEST_URI']))); ?>" style="color:#FCB900;">Log in</a></p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Old Booking Form (hidden, for legacy support) -->
                <div class="ptp-booking-form" id="booking-form" style="display:none;"></div>
                
                <!-- Video Introduction -->
                <?php if (!empty($trainer->intro_video_url)): ?>
                <div class="ptp-card">
                    <h2 class="ptp-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>
                        Meet <?php echo esc_html(explode(' ', $trainer->display_name)[0]); ?>
                    </h2>
                    <div style="position:relative;padding-bottom:56.25%;height:0;overflow:hidden;border-radius:12px;background:#000;">
                        <iframe src="<?php echo esc_url(ptp_get_video_embed_url($trainer->intro_video_url)); ?>" style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;" allowfullscreen></iframe>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Trust & Safety Badges -->
                <div class="ptp-card" style="background: linear-gradient(135deg, #F0FDF4 0%, #ECFDF5 100%); border-color: #BBF7D0;">
                    <h2 class="ptp-section-title" style="color: #166534;">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        Trust & Safety
                    </h2>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px;">
                        <?php if ($trainer->is_verified || $trainer->background_verified): ?>
                        <div style="display: flex; align-items: center; gap: 10px; padding: 12px; background: #fff; border-radius: 10px;">
                            <div style="width: 36px; height: 36px; background: #D1FAE5; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            </div>
                            <div>
                                <div style="font-weight: 600; font-size: 13px; color: #111;">Background Checked</div>
                                <div style="font-size: 11px; color: #6B7280;">Verified clean</div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($trainer->safesport_verified): ?>
                        <div style="display: flex; align-items: center; gap: 10px; padding: 12px; background: #fff; border-radius: 10px;">
                            <div style="width: 36px; height: 36px; background: #D1FAE5; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                            </div>
                            <div>
                                <div style="font-weight: 600; font-size: 13px; color: #111;">SafeSport Certified</div>
                                <div style="font-size: 11px; color: #6B7280;">Youth protection trained</div>
                            </div>
                        </div>
                        <?php endif; ?>
                        
                        <div style="display: flex; align-items: center; gap: 10px; padding: 12px; background: #fff; border-radius: 10px;">
                            <div style="width: 36px; height: 36px; background: #D1FAE5; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                            </div>
                            <div>
                                <div style="font-weight: 600; font-size: 13px; color: #111;">Fully Insured</div>
                                <div style="font-size: 11px; color: #6B7280;">Liability coverage</div>
                            </div>
                        </div>
                        
                        <div style="display: flex; align-items: center; gap: 10px; padding: 12px; background: #fff; border-radius: 10px;">
                            <div style="width: 36px; height: 36px; background: #D1FAE5; border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2.5"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>
                            </div>
                            <div>
                                <div style="font-weight: 600; font-size: 13px; color: #111;">CPR/First Aid</div>
                                <div style="font-size: 11px; color: #6B7280;">Emergency ready</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- About -->
                <div class="ptp-card">
                    <h2 class="ptp-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        About
                    </h2>
                    <p class="ptp-bio"><?php echo nl2br(esc_html($bio)); ?></p>
                </div>
                
                <!-- Specialties -->
                <?php if (!empty($specialties)): ?>
                <div class="ptp-card">
                    <h2 class="ptp-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/></svg>
                        Specialties
                    </h2>
                    <div class="ptp-specs">
                        <?php foreach ($specialties as $s): ?>
                        <span class="ptp-spec"><?php echo esc_html(ucfirst(trim($s))); ?></span>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Contact & Share Card -->
                <div class="ptp-card" id="contact-section">
                    <h2 class="ptp-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                        Contact <?php echo esc_html(explode(' ', $trainer->display_name)[0]); ?>
                    </h2>
                    
                    <!-- Quick Message Form -->
                    <div class="ptp-message-form" id="message-form">
                        <?php if (!$is_logged_in): ?>
                        <div class="ptp-form-row">
                            <div class="ptp-form-group">
                                <label class="ptp-form-label">Your Name *</label>
                                <input type="text" class="ptp-form-input" id="msg-name" placeholder="Full name">
                            </div>
                            <div class="ptp-form-group">
                                <label class="ptp-form-label">Email *</label>
                                <input type="email" class="ptp-form-input" id="msg-email" placeholder="your@email.com">
                            </div>
                        </div>
                        <div class="ptp-form-group">
                            <label class="ptp-form-label">Phone <span style="color: #9CA3AF;">(optional)</span></label>
                            <input type="tel" class="ptp-form-input" id="msg-phone" placeholder="(555) 123-4567">
                        </div>
                        <?php endif; ?>
                        <div class="ptp-form-group">
                            <label class="ptp-form-label">Message *</label>
                            <textarea class="ptp-form-input" id="msg-content" rows="3" placeholder="Hi <?php echo esc_attr(explode(' ', $trainer->display_name)[0]); ?>, I'm interested in training for my son/daughter..."></textarea>
                        </div>
                        <button type="button" class="ptp-submit ptp-msg-btn" onclick="sendMessage()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                            Send Message
                        </button>
                    </div>
                    <div id="message-success" style="display: none; text-align: center; padding: 20px;">
                        <div style="font-size: 48px; margin-bottom: 12px;">✉️</div>
                        <h3 style="margin: 0 0 8px;">Message Sent!</h3>
                        <p style="color: #6B7280; margin: 0; font-size: 14px;"><?php echo esc_html($trainer->display_name); ?> will get back to you soon.</p>
                    </div>
                    
                    <!-- Schedule Coordinator Link -->
                    <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #E5E7EB; text-align: center;">
                        <p style="font-size: 13px; color: #6B7280; margin: 0 0 8px;">Need help scheduling?</p>
                        <a href="mailto:luke@ptpsummercamps.com?subject=Training%20Inquiry%20-%20<?php echo urlencode($trainer->display_name); ?>" style="color: #FCB900; font-weight: 600; font-size: 14px; text-decoration: none;">
                            📧 Contact Schedule Coordinator
                        </a>
                        <span style="color: #D1D5DB; margin: 0 8px;">|</span>
                        <a href="tel:+14845724770" style="color: #FCB900; font-weight: 600; font-size: 14px; text-decoration: none;">
                            📞 (484) 572-4770
                        </a>
                    </div>
                </div>
                
                <!-- Share Profile Card -->
                <div class="ptp-card">
                    <h2 class="ptp-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
                        Share This Trainer
                    </h2>
                    <p style="color: #6B7280; font-size: 14px; margin-bottom: 16px;">Know someone who could use <?php echo esc_html(explode(' ', $trainer->display_name)[0]); ?>'s training?</p>
                    <div class="ptp-share-buttons">
                        <button type="button" class="ptp-share-btn sms" onclick="shareTrainer('sms')">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                            Text
                        </button>
                        <button type="button" class="ptp-share-btn email" onclick="shareTrainer('email')">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
                            Email
                        </button>
                        <button type="button" class="ptp-share-btn facebook" onclick="shareTrainer('facebook')">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                            Facebook
                        </button>
                        <button type="button" class="ptp-share-btn copy" onclick="shareTrainer('copy')">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
                            Copy Link
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Fixed Mobile Bar -->
<div class="ptp-fixed-bar">
    <div class="ptp-fixed-inner">
        <div class="ptp-fixed-price">$<?php echo $rate; ?> <span>/session</span></div>
        <button class="ptp-fixed-btn" onclick="scrollToBooking()">Book Now</button>
    </div>
</div>

<!-- Add Player Modal -->
<div id="add-player-modal" onclick="if(event.target===this)this.style.display='none';" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:999999;align-items:center;justify-content:center;padding:20px;overflow-y:auto;">
    <div onclick="event.stopPropagation();" style="background:#fff;border-radius:16px;width:100%;max-width:440px;box-shadow:0 25px 50px rgba(0,0,0,0.25);margin:auto;">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:20px;border-bottom:1px solid #eee;">
            <h3 style="margin:0;font-size:18px;font-weight:700;">Add Player</h3>
            <button type="button" onclick="document.getElementById('add-player-modal').style.display='none';" style="width:36px;height:36px;border-radius:50%;border:none;background:#f3f4f6;cursor:pointer;font-size:24px;line-height:1;">&times;</button>
        </div>
        <div style="padding:20px;">
            <div id="add-player-error" style="display:none;padding:12px;background:#FEE2E2;color:#DC2626;border-radius:8px;margin-bottom:16px;font-size:14px;"></div>
            
            <!-- Basic Info -->
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Player Name *</label>
                <input type="text" id="new-player-name" placeholder="First and last name" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px;">
                <div>
                    <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Age *</label>
                    <input type="number" id="new-player-age" min="4" max="18" placeholder="4-18" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;">
                </div>
                <div>
                    <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Skill Level</label>
                    <select id="new-player-skill" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;background:#fff;">
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                        <option value="elite">Elite</option>
                    </select>
                </div>
            </div>
            
            <!-- Position -->
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Preferred Position</label>
                <select id="new-player-position" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;background:#fff;">
                    <option value="">Not sure / Multiple</option>
                    <option value="goalkeeper">Goalkeeper</option>
                    <option value="defender">Defender</option>
                    <option value="midfielder">Midfielder</option>
                    <option value="forward">Forward/Striker</option>
                </select>
            </div>
            
            <!-- Goals -->
            <div style="margin-bottom:20px;">
                <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Training Goals</label>
                <textarea id="new-player-goals" rows="3" placeholder="What skills do they want to improve? (ball control, shooting, dribbling, etc.)" style="width:100%;padding:12px;border:2px solid #ddd;border-radius:8px;font-size:14px;box-sizing:border-box;resize:vertical;font-family:inherit;"></textarea>
            </div>
            
            <button type="button" id="add-player-btn" onclick="addPlayerToProfile();" style="width:100%;padding:16px;background:#FCB900;color:#000;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">
                Add Player
            </button>
        </div>
    </div>
</div>

<!-- Payment Modal -->
<div id="payment-modal" onclick="if(event.target===this)this.style.display='none';" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.6);z-index:999999;align-items:center;justify-content:center;padding:20px;overflow-y:auto;">
    <div onclick="event.stopPropagation();" style="background:#fff;border-radius:16px;width:100%;max-width:480px;box-shadow:0 25px 50px rgba(0,0,0,0.25);margin:auto;">
        <div style="display:flex;justify-content:space-between;align-items:center;padding:20px;border-bottom:1px solid #eee;">
            <h3 style="margin:0;font-size:18px;font-weight:700;">Complete Your Booking</h3>
            <button type="button" onclick="document.getElementById('payment-modal').style.display='none';" style="width:36px;height:36px;border-radius:50%;border:none;background:#f3f4f6;cursor:pointer;font-size:24px;line-height:1;">&times;</button>
        </div>
        <div style="padding:20px;">
            <!-- Order Summary -->
            <div style="background:#F9FAFB;border-radius:12px;padding:16px;margin-bottom:20px;">
                <div style="font-size:12px;font-weight:600;color:#6B7280;text-transform:uppercase;margin-bottom:12px;">Order Summary</div>
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px;">
                    <span style="color:#6B7280;">Trainer</span>
                    <span id="pay-summary-trainer" style="font-weight:600;"></span>
                </div>
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px;">
                    <span style="color:#6B7280;">Date</span>
                    <span id="pay-summary-date" style="font-weight:600;"></span>
                </div>
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px;">
                    <span style="color:#6B7280;">Time</span>
                    <span id="pay-summary-time" style="font-weight:600;"></span>
                </div>
                <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px;">
                    <span style="color:#6B7280;">Package</span>
                    <span id="pay-summary-package" style="font-weight:600;"></span>
                </div>
                <div style="border-top:1px solid #E5E7EB;margin-top:12px;padding-top:12px;display:flex;justify-content:space-between;font-size:18px;font-weight:700;">
                    <span>Total</span>
                    <span id="pay-summary-total" style="color:#059669;"></span>
                </div>
            </div>
            
            <!-- Error Display -->
            <div id="pay-error" style="display:none;padding:12px;background:#FEE2E2;color:#DC2626;border-radius:8px;margin-bottom:16px;font-size:14px;"></div>
            
            <!-- Phone Number -->
            <div style="margin-bottom:16px;">
                <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Phone Number *</label>
                <input type="tel" id="pay-phone" value="<?php echo esc_attr($parent_phone); ?>" placeholder="(555) 555-5555" style="width:100%;padding:14px;border:2px solid #ddd;border-radius:8px;font-size:16px;box-sizing:border-box;">
                <p style="font-size:12px;color:#6B7280;margin:6px 0 0;">For session reminders and trainer communication</p>
            </div>
            
            <!-- Card Element -->
            <div id="card-section" style="margin-bottom:20px;<?php echo empty($stripe_key) ? 'display:none;' : ''; ?>">
                <label style="display:block;font-size:14px;font-weight:600;margin-bottom:6px;">Card Details *</label>
                <div id="card-element" style="padding:14px;border:2px solid #ddd;border-radius:8px;background:#fff;"></div>
                <div id="card-errors" style="color:#DC2626;font-size:13px;margin-top:6px;"></div>
            </div>
            
            <?php if (empty($stripe_key)): ?>
            <div style="background:#FEF3C7;border:1px solid #F59E0B;border-radius:8px;padding:12px;margin-bottom:20px;font-size:14px;color:#92400E;">
                <strong>Pay at Session</strong> - Payment will be collected by your trainer at the session.
            </div>
            <?php endif; ?>
            
            <!-- Pay Button -->
            <button type="button" id="pay-btn" onclick="processPayment();" style="width:100%;padding:16px;background:#FCB900;color:#000;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">
                <?php if (empty($stripe_key)): ?>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                Confirm Booking
                <?php else: ?>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                Pay Now
                <?php endif; ?>
            </button>
            
            <?php if (!empty($stripe_key)): ?>
            <p style="font-size:12px;color:#6B7280;text-align:center;margin:16px 0 0;">
                <svg style="vertical-align:middle;margin-right:4px;" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                Secure payment powered by Stripe
            </p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Stripe.js -->
<script src="https://js.stripe.com/v3/"></script>

<script>
function addPlayerToProfile() {
    var name = document.getElementById('new-player-name').value.trim();
    var age = document.getElementById('new-player-age').value;
    var skill = document.getElementById('new-player-skill').value;
    var position = document.getElementById('new-player-position').value;
    var goals = document.getElementById('new-player-goals').value.trim();
    var errorDiv = document.getElementById('add-player-error');
    var btn = document.getElementById('add-player-btn');
    
    // Reset error
    errorDiv.style.display = 'none';
    
    // Validate
    if (!name || name.length < 2) {
        errorDiv.textContent = 'Please enter player name (first and last)';
        errorDiv.style.display = 'block';
        return;
    }
    
    var ageNum = parseInt(age);
    if (!age || ageNum < 4 || ageNum > 18) {
        errorDiv.textContent = 'Please enter age between 4 and 18';
        errorDiv.style.display = 'block';
        return;
    }
    
    // Loading state
    btn.disabled = true;
    btn.innerHTML = '<span style="display:inline-block;width:16px;height:16px;border:2px solid #000;border-top-color:transparent;border-radius:50%;animation:spin 0.8s linear infinite;"></span> Adding...';
    
    var fd = new FormData();
    fd.append('action', 'ptp_add_player');
    fd.append('nonce', '<?php echo wp_create_nonce("ptp_nonce"); ?>');
    fd.append('name', name);
    fd.append('age', ageNum);
    fd.append('skill_level', skill);
    fd.append('position', position);
    fd.append('goals', goals);
    
    fetch('<?php echo admin_url("admin-ajax.php"); ?>', {
        method: 'POST',
        body: fd,
        credentials: 'same-origin'
    })
    .then(function(r) { return r.json(); })
    .then(function(data) {
        btn.disabled = false;
        btn.innerHTML = 'Add Player';
        
        if (data.success && data.data && data.data.player) {
            var player = data.data.player;
            var container = document.querySelector('.ptp-players');
            
            if (container) {
                var addBtn = container.querySelector('.ptp-add-player');
                
                // Create player card
                var playerDiv = document.createElement('div');
                playerDiv.className = 'ptp-player selected';
                playerDiv.setAttribute('data-player', player.id);
                playerDiv.innerHTML = '<div class="ptp-player-avatar">' + name.charAt(0).toUpperCase() + '</div><div class="ptp-player-info"><div class="ptp-player-name">' + player.name + '</div><div class="ptp-player-meta">Age ' + player.age + ' • ' + skill.charAt(0).toUpperCase() + skill.slice(1) + '</div></div>';
                
                // Deselect others
                container.querySelectorAll('.ptp-player').forEach(function(p) { p.classList.remove('selected'); });
                
                // Insert before add button
                if (addBtn) {
                    container.insertBefore(playerDiv, addBtn);
                } else {
                    container.appendChild(playerDiv);
                }
                
                // Add click handler
                playerDiv.onclick = function() {
                    container.querySelectorAll('.ptp-player').forEach(function(p) { p.classList.remove('selected'); });
                    this.classList.add('selected');
                    if (typeof selectedPlayer !== 'undefined') selectedPlayer = parseInt(this.dataset.player);
                    if (typeof updateForm === 'function') updateForm();
                };
                
                // Update global state
                if (typeof selectedPlayer !== 'undefined') selectedPlayer = player.id;
                if (typeof updateForm === 'function') updateForm();
            }
            
            // Close modal and reset form
            document.getElementById('add-player-modal').style.display = 'none';
            document.getElementById('new-player-name').value = '';
            document.getElementById('new-player-age').value = '';
            document.getElementById('new-player-skill').value = 'beginner';
            document.getElementById('new-player-position').value = '';
            document.getElementById('new-player-goals').value = '';
            errorDiv.style.display = 'none';
            
        } else {
            errorDiv.textContent = (data.data && data.data.message) ? data.data.message : 'Error adding player. Please try again.';
            errorDiv.style.display = 'block';
        }
    })
    .catch(function(e) {
        btn.disabled = false;
        btn.innerHTML = 'Add Player';
        errorDiv.textContent = 'Network error. Please check your connection and try again.';
        errorDiv.style.display = 'block';
        console.error('Add player error:', e);
    });
}
</script>
<style>
@keyframes spin { to { transform: rotate(360deg); } }
</style>

<script>
const trainerId = <?php echo (int)$trainer->id; ?>;
const trainerSlug = '<?php echo esc_js($trainer->slug); ?>';
const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
const nonce = '<?php echo wp_create_nonce('ptp_nonce'); ?>';
const isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
const baseRate = <?php echo $rate; ?>;
const hasTrainerLocations = <?php echo !empty($training_locations) ? 'true' : 'false'; ?>;

// Package definitions for payment modal
const packages = {
    1: { sessions: 1, price: <?php echo $rate; ?>, label: 'Single Session' },
    4: { sessions: 4, price: <?php echo round($rate * 4 * 0.95); ?>, label: '4 Sessions' },
    8: { sessions: 8, price: <?php echo round($rate * 8 * 0.90); ?>, label: '8 Sessions' },
    12: { sessions: 12, price: <?php echo round($rate * 12 * 0.85); ?>, label: '12 Sessions' }
};

let month = new Date();
let selectedDate = null;
let selectedTime = null;
let selectedPackage = 1;
let selectedPlayer = <?php echo !empty($players) ? (int)$players[0]->id : 'null'; ?>;
let selectedLocation = null;

// Initialize location cards
document.querySelectorAll('.ptp-location-card').forEach(card => {
    card.addEventListener('click', function() {
        document.querySelectorAll('.ptp-location-card').forEach(c => c.classList.remove('selected'));
        this.classList.add('selected');
        selectedLocation = this.dataset.location;
        updateSummary();
    });
    // Auto-select first location
    if (card.dataset.index === '0') {
        card.classList.add('selected');
        selectedLocation = card.dataset.location;
    }
});

// Initialize player cards
document.querySelectorAll('.ptp-player').forEach(player => {
    player.addEventListener('click', function() {
        document.querySelectorAll('.ptp-player').forEach(p => p.classList.remove('selected'));
        this.classList.add('selected');
        selectedPlayer = parseInt(this.dataset.player);
        updateSummary();
    });
});

// Auto-select first player if exists
if (selectedPlayer) {
    const firstPlayer = document.querySelector('.ptp-player[data-player="' + selectedPlayer + '"]');
    if (firstPlayer) firstPlayer.classList.add('selected');
}

function renderCal() {
    const y = month.getFullYear(), m = month.getMonth();
    const first = new Date(y, m, 1), last = new Date(y, m + 1, 0);
    const today = new Date(); today.setHours(0,0,0,0);
    
    document.getElementById('cal-month').textContent = first.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    let html = '<div class="ptp-cal-grid">';
    for (let i = 0; i < first.getDay(); i++) html += '<div class="ptp-cal-day empty"></div>';
    for (let d = 1; d <= last.getDate(); d++) {
        const dt = new Date(y, m, d);
        const str = dt.toISOString().split('T')[0];
        const past = dt < today;
        const isToday = dt.getTime() === today.getTime();
        const sel = selectedDate === str;
        html += '<div class="ptp-cal-day' + (past ? ' past' : ' avail') + (isToday ? ' today' : '') + (sel ? ' selected' : '') + '" data-date="' + str + '">' + d + '</div>';
    }
    html += '</div>';
    document.getElementById('cal-days').innerHTML = html;
    
    document.querySelectorAll('.ptp-cal-day.avail').forEach(el => {
        el.onclick = function() {
            document.querySelectorAll('.ptp-cal-day').forEach(d => d.classList.remove('selected'));
            this.classList.add('selected');
            selectedDate = this.dataset.date;
            selectedTime = null;
            loadSlots(selectedDate);
            updateSummary();
        };
    });
}

function calPrev() { month.setMonth(month.getMonth() - 1); renderCal(); }
function calNext() { month.setMonth(month.getMonth() + 1); renderCal(); }

async function loadSlots(d) {
    const grid = document.getElementById('slots-grid');
    const titleEl = document.getElementById('slots-title');
    titleEl.textContent = new Date(d + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
    grid.innerHTML = '<div class="ptp-slots-empty">Loading...</div>';
    
    try {
        const fd = new FormData();
        fd.append('action', 'ptp_get_available_slots');
        fd.append('nonce', nonce);
        fd.append('trainer_id', trainerId);
        fd.append('date', d);
        
        const res = await fetch(ajaxUrl, { method: 'POST', body: fd });
        const data = await res.json();
        
        // Show default slots if none configured
        let slots = [];
        if (data.success && data.data && Array.isArray(data.data.slots) && data.data.slots.length > 0) {
            slots = data.data.slots;
        } else {
            // Default time slots
            slots = ['08:00','09:00','10:00','11:00','12:00','14:00','15:00','16:00','17:00','18:00','19:00'].map(t => ({start: t}));
        }
        
        grid.innerHTML = slots.map(s => {
            const time = s.start || s.time || s;
            return '<div class="ptp-slot" data-time="' + time + '">' + fmtTime(time) + '</div>';
        }).join('');
        
        document.querySelectorAll('.ptp-slot').forEach(el => {
            el.onclick = function() {
                document.querySelectorAll('.ptp-slot').forEach(s => s.classList.remove('selected'));
                this.classList.add('selected');
                selectedTime = this.dataset.time;
                updateSummary();
            };
        });
    } catch (e) {
        console.error('Load slots error:', e);
        // Show default slots on error
        const defaultSlots = ['09:00','10:00','11:00','14:00','15:00','16:00','17:00','18:00'];
        grid.innerHTML = defaultSlots.map(t => '<div class="ptp-slot" data-time="' + t + '">' + fmtTime(t) + '</div>').join('');
        
        document.querySelectorAll('.ptp-slot').forEach(el => {
            el.onclick = function() {
                document.querySelectorAll('.ptp-slot').forEach(s => s.classList.remove('selected'));
                this.classList.add('selected');
                selectedTime = this.dataset.time;
                updateSummary();
            };
        });
    }
}

function fmtTime(t) {
    if (!t) return '';
    const [h, m] = t.split(':');
    return ((+h % 12) || 12) + ':' + (m || '00') + ' ' + (+h >= 12 ? 'PM' : 'AM');
}

function updateSummary() {
    // Update summary display
    const locEl = document.getElementById('summary-location');
    const dateEl = document.getElementById('summary-date');
    const timeEl = document.getElementById('summary-time');
    
    if (locEl) locEl.textContent = selectedLocation || '-';
    if (dateEl) dateEl.textContent = selectedDate ? new Date(selectedDate + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) : '-';
    if (timeEl) timeEl.textContent = selectedTime ? fmtTime(selectedTime) : '-';
    
    // Update button state
    const btn = document.getElementById('submit-btn');
    if (btn) {
        let hasLocation = selectedLocation !== null;
        if (!hasLocation) {
            const locInput = document.getElementById('location-input');
            hasLocation = locInput && locInput.value.trim().length > 0;
        }
        
        if (selectedDate && selectedTime && selectedPlayer && hasLocation) {
            btn.disabled = false;
            btn.textContent = 'Book for $' + baseRate;
        } else if (!hasLocation) {
            btn.disabled = true;
            btn.textContent = 'Select a location';
        } else if (!selectedDate || !selectedTime) {
            btn.disabled = true;
            btn.textContent = 'Select date & time to continue';
        } else if (!selectedPlayer) {
            btn.disabled = true;
            btn.textContent = 'Select a player';
        }
    }
}

// Legacy function name for compatibility
function updateForm() {
    updateSummary();
    
    const btn = document.getElementById('submit-btn');
    if (btn) {
        // Check if we have location (either selected from list or entered in input)
        let hasLocation = selectedLocation !== null;
        if (!hasLocation) {
            const locInput = document.getElementById('location-input');
            hasLocation = locInput && locInput.value.trim().length > 0;
        }
        
        if (selectedDate && selectedTime && selectedPlayer && hasLocation) {
            btn.disabled = false;
            btn.textContent = 'Book for $' + baseRate;
        } else {
            btn.disabled = true;
            btn.textContent = 'Select a location';
        }
    }
}

// Package selection
document.querySelectorAll('.ptp-package').forEach(el => {
    el.onclick = function() {
        document.querySelectorAll('.ptp-package').forEach(p => p.classList.remove('selected'));
        this.classList.add('selected');
        selectedPackage = parseInt(this.dataset.package);
        updateForm();
    };
});

// Player selection
document.querySelectorAll('.ptp-player').forEach(el => {
    el.onclick = function() {
        document.querySelectorAll('.ptp-player').forEach(p => p.classList.remove('selected'));
        this.classList.add('selected');
        selectedPlayer = parseInt(this.dataset.player);
        updateForm();
    };
});

// Location selection
document.querySelectorAll('.ptp-location').forEach(el => {
    el.onclick = function() {
        document.querySelectorAll('.ptp-location').forEach(l => l.classList.remove('selected'));
        this.classList.add('selected');
        selectedLocation = this.dataset.location;
        updateForm();
    };
});

// If no trainer locations, listen to input changes
if (!hasTrainerLocations) {
    const locInput = document.getElementById('location-input');
    if (locInput) {
        locInput.addEventListener('input', updateForm);
    }
}

// First player selected by default
const firstPlayer = document.querySelector('.ptp-player');
if (firstPlayer) {
    firstPlayer.classList.add('selected');
    selectedPlayer = parseInt(firstPlayer.dataset.player);
}

function scrollToBooking() {
    document.getElementById('booking-section').scrollIntoView({ behavior: 'smooth' });
}

async function submitBooking() {
    const btn = document.getElementById('submit-btn');
    const notes = document.getElementById('notes-input').value.trim();
    
    // Get location from either selected location or input field
    let location;
    if (hasTrainerLocations) {
        location = selectedLocation;
    } else {
        const locInput = document.getElementById('location-input');
        location = locInput ? locInput.value.trim() : '';
    }
    
    if (!location) {
        alert('Please select a training location');
        return;
    }
    
    if (!selectedPlayer) {
        alert('Please select a player');
        return;
    }
    
    // Show payment modal instead of direct booking
    openPaymentModal(location, notes);
}

function openPaymentModal(location, notes) {
    // Store booking details for payment
    window.bookingDetails = {
        trainer_id: trainerId,
        player_id: selectedPlayer,
        date: selectedDate,
        time: selectedTime,
        package: selectedPackage,
        location: location,
        notes: notes
    };
    
    // Update order summary in modal
    const pkg = packages[selectedPackage] || packages[1];
    document.getElementById('pay-summary-trainer').textContent = '<?php echo esc_js($trainer->display_name); ?>';
    document.getElementById('pay-summary-date').textContent = new Date(selectedDate + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    document.getElementById('pay-summary-time').textContent = formatTime(selectedTime);
    document.getElementById('pay-summary-package').textContent = pkg.label;
    document.getElementById('pay-summary-total').textContent = '$' + pkg.price;
    
    // Show modal
    document.getElementById('payment-modal').style.display = 'flex';
    
    // Mount Stripe card if not already
    if (!cardMounted && stripe) {
        card.mount('#card-element');
        cardMounted = true;
    }
}

function formatTime(time) {
    if (!time) return '';
    const [h, m] = time.split(':');
    const hour = parseInt(h);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return hour12 + ':' + m + ' ' + ampm;
}

async function processPayment() {
    const btn = document.getElementById('pay-btn');
    const errorDiv = document.getElementById('pay-error');
    const phone = document.getElementById('pay-phone').value.trim();
    
    errorDiv.style.display = 'none';
    
    // Validate phone
    if (!phone || phone.length < 10) {
        errorDiv.textContent = 'Please enter a valid phone number';
        errorDiv.style.display = 'block';
        return;
    }
    
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Processing...';
    
    try {
        // Check if Stripe is available
        if (stripe && card) {
            // Step 1: Create payment intent
            const fd1 = new FormData();
            fd1.append('action', 'ptp_create_payment_intent');
            fd1.append('nonce', nonce);
            fd1.append('trainer_id', window.bookingDetails.trainer_id);
            fd1.append('package', window.bookingDetails.package);
            
            const res1 = await fetch(ajaxUrl, { method: 'POST', body: fd1 });
            const data1 = await res1.json();
            
            if (!data1.success) {
                // If payment system not configured, proceed without payment
                if (data1.data?.message?.includes('not configured')) {
                    console.log('Stripe not configured, proceeding without payment');
                    await createBookingWithoutPayment(phone);
                    return;
                }
                throw new Error(data1.data?.message || 'Failed to create payment');
            }
            
            // Step 2: Confirm card payment
            const { error, paymentIntent } = await stripe.confirmCardPayment(data1.data.client_secret, {
                payment_method: { card: card }
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            // Step 3: Create booking with payment
            const fd2 = new FormData();
            fd2.append('action', 'ptp_create_booking');
            fd2.append('nonce', nonce);
            fd2.append('trainer_id', window.bookingDetails.trainer_id);
            fd2.append('player_id', window.bookingDetails.player_id);
            fd2.append('date', window.bookingDetails.date);
            fd2.append('time', window.bookingDetails.time);
            fd2.append('package', window.bookingDetails.package);
            fd2.append('location', window.bookingDetails.location);
            fd2.append('notes', window.bookingDetails.notes);
            fd2.append('phone', phone);
            fd2.append('payment_intent_id', paymentIntent.id);
            
            const res2 = await fetch(ajaxUrl, { method: 'POST', body: fd2 });
            const data2 = await res2.json();
            
            if (data2.success) {
                window.location.href = data2.data.redirect || '<?php echo home_url('/booking-confirmation/'); ?>?booking=' + data2.data.booking_number;
            } else {
                throw new Error(data2.data?.message || 'Booking failed');
            }
        } else {
            // No Stripe - proceed without payment
            await createBookingWithoutPayment(phone);
        }
        
    } catch (e) {
        errorDiv.textContent = e.message || 'Payment failed. Please try again.';
        errorDiv.style.display = 'block';
        btn.disabled = false;
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg> Pay Now';
    }
}

async function createBookingWithoutPayment(phone) {
    const fd = new FormData();
    fd.append('action', 'ptp_create_booking');
    fd.append('nonce', nonce);
    fd.append('trainer_id', window.bookingDetails.trainer_id);
    fd.append('player_id', window.bookingDetails.player_id);
    fd.append('date', window.bookingDetails.date);
    fd.append('time', window.bookingDetails.time);
    fd.append('package', window.bookingDetails.package);
    fd.append('location', window.bookingDetails.location);
    fd.append('notes', window.bookingDetails.notes);
    fd.append('phone', phone);
    
    const res = await fetch(ajaxUrl, { method: 'POST', body: fd });
    const data = await res.json();
    
    if (data.success) {
        window.location.href = data.data.redirect || '<?php echo home_url('/booking-confirmation/'); ?>?booking=' + data.data.booking_number;
    } else {
        throw new Error(data.data?.message || 'Booking failed');
    }
}

// Stripe setup
const stripeKey = '<?php echo esc_js($stripe_key); ?>';
let stripe, elements, card, cardMounted = false;

if (stripeKey) {
    stripe = Stripe(stripeKey);
    elements = stripe.elements();
    card = elements.create('card', {
        style: {
            base: {
                fontSize: '16px',
                color: '#32325d',
                fontFamily: 'Inter, sans-serif',
                '::placeholder': { color: '#aab7c4' }
            }
        }
    });
    
    card.on('change', function(event) {
        const displayError = document.getElementById('card-errors');
        displayError.textContent = event.error ? event.error.message : '';
    });
}

// ===== Share Trainer Profile =====
const profileUrl = '<?php echo home_url('/trainer/' . $trainer->slug . '/'); ?>';
const trainerDisplayName = '<?php echo esc_js($trainer->display_name); ?>';
const shareText = `Check out ${trainerDisplayName} for private soccer training!`;

function shareTrainer(method) {
    switch(method) {
        case 'sms':
            window.open(`sms:?body=${encodeURIComponent(shareText + ' ' + profileUrl)}`);
            break;
        case 'email':
            window.open(`mailto:?subject=${encodeURIComponent('Great Soccer Trainer - ' + trainerDisplayName)}&body=${encodeURIComponent(shareText + '\n\n' + profileUrl)}`);
            break;
        case 'facebook':
            window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(profileUrl)}`, '_blank', 'width=600,height=400');
            break;
        case 'copy':
            navigator.clipboard.writeText(profileUrl).then(() => {
                const btn = document.querySelector('.ptp-share-btn.copy');
                const originalHTML = btn.innerHTML;
                btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Copied!';
                setTimeout(() => btn.innerHTML = originalHTML, 2000);
            });
            break;
    }
}

// ===== Send Message to Trainer =====
async function sendMessage() {
    const btn = document.querySelector('.ptp-msg-btn');
    const message = document.getElementById('msg-content').value.trim();
    
    if (!message) {
        alert('Please enter a message');
        return;
    }
    
    const isGuest = !isLoggedIn;
    let name = '', email = '', phone = '';
    
    if (isGuest) {
        name = document.getElementById('msg-name')?.value.trim() || '';
        email = document.getElementById('msg-email')?.value.trim() || '';
        phone = document.getElementById('msg-phone')?.value.trim() || '';
        
        if (!name || !email) {
            alert('Please enter your name and email');
            return;
        }
        
        if (!email.includes('@')) {
            alert('Please enter a valid email');
            return;
        }
    }
    
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Sending...';
    
    const fd = new FormData();
    fd.append('action', isGuest ? 'ptp_send_public_message_guest' : 'ptp_send_public_message');
    fd.append('nonce', nonce);
    fd.append('trainer_id', trainerId);
    fd.append('message', message);
    
    if (isGuest) {
        fd.append('name', name);
        fd.append('email', email);
        fd.append('phone', phone);
    }
    
    try {
        const res = await fetch(ajaxUrl, { method: 'POST', body: fd });
        const data = await res.json();
        
        if (data.success) {
            document.getElementById('message-form').style.display = 'none';
            document.getElementById('message-success').style.display = 'block';
        } else {
            alert(data.data?.message || 'Error sending message');
            btn.disabled = false;
            btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Send Message';
        }
    } catch (e) {
        alert('Error sending message');
        btn.disabled = false;
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Send Message';
    }
}

// Add spinner CSS
const style = document.createElement('style');
style.textContent = '.spinner{display:inline-block;width:14px;height:14px;border:2px solid #E5E7EB;border-top-color:#000;border-radius:50%;animation:spin 0.8s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}';
document.head.appendChild(style);

// Init
renderCal();
</script>
