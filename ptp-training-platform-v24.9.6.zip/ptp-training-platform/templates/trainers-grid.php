<?php
/**
 * Template: Find Trainers v24.9.4
 * TeachMeTo-style split view
 */
defined('ABSPATH') || exit;

$google_maps_api_key = get_option('ptp_google_maps_api_key', '');

global $wpdb;
$trainers = $wpdb->get_results("
    SELECT t.*, 
           COALESCE(AVG(r.rating), 0) as average_rating,
           COUNT(r.id) as review_count
    FROM {$wpdb->prefix}ptp_trainers t
    LEFT JOIN {$wpdb->prefix}ptp_reviews r ON t.id = r.trainer_id
    WHERE t.status = 'active'
    GROUP BY t.id
    ORDER BY t.is_featured DESC, average_rating DESC
");

$level_labels = array(
    'pro' => 'Pro', 'college_d1' => 'D1', 'college_d2' => 'D2', 
    'college_d3' => 'D3', 'academy' => 'Academy', 'semi_pro' => 'Semi-Pro'
);

$trainers_json = array();
foreach ($trainers as $t) {
    $location = trim(($t->city ?: '') . ', ' . ($t->state ?: ''), ', ') ?: $t->location ?: '';
    $training_locs = array();
    if (!empty($t->training_locations)) {
        $decoded = json_decode($t->training_locations, true);
        if (is_array($decoded)) $training_locs = $decoded;
    }
    
    $trainers_json[] = array(
        'id' => (int)$t->id,
        'name' => $t->display_name,
        'slug' => $t->slug,
        'photo' => $t->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($t->display_name) . '&size=400&background=FCB900&color=0E0F11',
        'headline' => $t->headline ?: $t->college ?: 'Soccer Trainer',
        'rate' => (int)($t->hourly_rate ?: 70),
        'rating' => $t->average_rating ? round((float)$t->average_rating, 1) : 5.0,
        'reviews' => (int)$t->review_count,
        'lat' => $t->latitude ? (float)$t->latitude : null,
        'lng' => $t->longitude ? (float)$t->longitude : null,
        'location' => $location,
        'featured' => !empty($t->is_featured),
        'verified' => !empty($t->is_verified),
        'level' => isset($level_labels[$t->playing_level]) ? $level_labels[$t->playing_level] : '',
        'college' => $t->college ?: '',
        'trainingLocations' => $training_locs,
        'hasLocations' => count($training_locs) > 0,
    );
}
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
html, body { overflow-x: hidden !important; max-width: 100vw; }

/* Reset container */
.ptp-browse { 
    font-family: 'Inter', -apple-system, sans-serif !important;
    background: #fff !important;
    min-height: 100vh;
    margin: 0 -9999px !important;
    padding: 0 9999px !important;
    position: relative;
    overflow-x: hidden;
}
.ptp-browse * { box-sizing: border-box; }

/* Header - Fixed position for better visibility */
.ptp-b-header {
    display: flex !important;
    align-items: center;
    gap: 16px;
    padding: 16px 24px;
    border-bottom: 1px solid #E5E7EB;
    background: #fff;
    margin: 0 -9999px;
    padding-left: 9999px;
    padding-right: 9999px;
}
.ptp-b-filters {
    display: flex !important;
    gap: 8px;
    flex-wrap: wrap;
}
.ptp-b-filter {
    display: inline-flex !important;
    align-items: center;
    gap: 6px;
    padding: 10px 18px;
    border: 1px solid #E5E7EB;
    border-radius: 24px;
    font-size: 14px;
    font-weight: 500;
    background: #fff;
    color: #374151;
    cursor: pointer;
    transition: all 0.15s;
}
.ptp-b-filter:hover { border-color: #111; color: #111; }
.ptp-b-filter.active { background: #111; color: #fff; border-color: #111; }
.ptp-b-filter svg { width: 16px; height: 16px; }

.ptp-b-sort {
    margin-left: auto;
    display: flex !important;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: #6B7280;
}
.ptp-b-sort select {
    padding: 10px 14px;
    border: 1px solid #E5E7EB;
    border-radius: 8px;
    font-size: 14px;
    background: #fff;
    color: #111;
    cursor: pointer;
}

/* Layout */
.ptp-b-layout {
    display: flex;
    height: calc(100vh - 57px);
}
@media (max-width: 1023px) {
    .ptp-b-layout { flex-direction: column; height: auto; min-height: calc(100vh - 57px); }
}

/* Left Panel */
.ptp-b-panel {
    width: 100%;
    overflow-y: auto;
    padding: 20px 24px;
    background: #fff;
}
@media (min-width: 1024px) {
    .ptp-b-panel {
        width: 580px;
        min-width: 580px;
        border-right: 1px solid #E5E7EB;
    }
}
@media (min-width: 1280px) {
    .ptp-b-panel { width: 640px; min-width: 640px; }
}

.ptp-b-title {
    font-size: 20px;
    font-weight: 700;
    margin: 0 0 4px;
    color: #111;
}
.ptp-b-subtitle {
    font-size: 14px;
    color: #6B7280;
    margin: 0 0 20px;
}

/* Grid */
.ptp-b-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 20px;
}
@media (min-width: 500px) {
    .ptp-b-grid { grid-template-columns: repeat(2, 1fr); }
}

/* Card - TeachMeTo Style */
.ptp-b-card {
    display: block;
    text-decoration: none !important;
    color: inherit !important;
    border-radius: 16px;
    overflow: hidden;
    background: #fff;
    transition: all 0.2s;
    box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}
.ptp-b-card:hover {
    box-shadow: 0 12px 32px rgba(0,0,0,0.12);
    transform: translateY(-4px);
}

.ptp-b-card-img {
    position: relative;
    aspect-ratio: 4/5;
    overflow: hidden;
    background: #f3f4f6;
}
.ptp-b-card-img img {
    width: 100%; height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}
.ptp-b-card:hover .ptp-b-card-img img {
    transform: scale(1.05);
}
.ptp-b-card-img::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 50%;
    background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, transparent 100%);
    pointer-events: none;
}

.ptp-b-badge {
    position: absolute;
    top: 12px; left: 12px;
    padding: 5px 12px;
    background: #FCB900;
    color: #000;
    font-size: 11px;
    font-weight: 700;
    border-radius: 8px;
    text-transform: uppercase;
    z-index: 2;
}
.ptp-b-badge.new {
    background: #8B5CF6;
    color: #fff;
}

.ptp-b-card-info {
    position: absolute;
    bottom: 0; left: 0; right: 0;
    padding: 16px;
    z-index: 2;
    color: #fff;
}
.ptp-b-card-name {
    font-size: 18px;
    font-weight: 700;
    margin: 0 0 4px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.ptp-b-card-name .verified {
    width: 18px; height: 18px;
    background: #3B82F6;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}
.ptp-b-card-name .verified svg { width: 12px; height: 12px; }
.ptp-b-card-price {
    font-size: 14px;
    opacity: 0.9;
}

.ptp-b-arrow {
    position: absolute;
    bottom: 16px; right: 16px;
    width: 40px; height: 40px;
    background: #FCB900;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2;
    transition: transform 0.2s;
}
.ptp-b-card:hover .ptp-b-arrow { transform: scale(1.1); }
.ptp-b-arrow svg { width: 20px; height: 20px; color: #000; }

/* Card Meta */
.ptp-b-meta {
    padding: 14px 16px;
    background: #fff;
}
.ptp-b-meta-top {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 8px;
}
.ptp-b-sport {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 14px;
    font-weight: 600;
    color: #111;
}
.ptp-b-sport::before { content: '⚽'; }
.ptp-b-rating {
    display: flex;
    align-items: center;
    gap: 4px;
    font-size: 14px;
    color: #111;
}
.ptp-b-rating svg {
    width: 14px; height: 14px;
    color: #FCB900; fill: #FCB900;
}
.ptp-b-new {
    font-size: 13px;
    color: #8B5CF6;
    font-weight: 600;
}
.ptp-b-details {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    font-size: 13px;
    color: #6B7280;
}
.ptp-b-details span {
    display: flex;
    align-items: center;
    gap: 4px;
}
.ptp-b-details svg { width: 14px; height: 14px; color: #EF4444; }
.ptp-b-avail { color: #059669 !important; }
.ptp-b-avail svg { color: #059669 !important; }

/* Map */
.ptp-b-map {
    display: none;
    flex: 1;
    min-height: 400px;
    background: #E5E7EB;
    position: relative;
}
@media (min-width: 1024px) {
    .ptp-b-map { display: block; }
}
#ptp-map { width: 100%; height: 100%; }
.ptp-map-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: #6B7280;
    text-align: center;
}

/* Info Banner */
.ptp-b-banner {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 16px;
    background: #F0F9FF;
    border: 1px solid #BAE6FD;
    border-radius: 12px;
    margin: 24px 0 0;
    font-size: 14px;
}
.ptp-b-banner-icon {
    width: 44px; height: 44px;
    background: #fff;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}
.ptp-b-banner strong { color: #0284C7; }

/* Mobile Toggle */
.ptp-b-toggle {
    display: flex;
    position: fixed;
    bottom: 24px; left: 50%;
    transform: translateX(-50%);
    padding: 14px 28px;
    background: #111;
    color: #fff;
    border: none;
    border-radius: 28px;
    font-size: 15px;
    font-weight: 600;
    gap: 8px;
    cursor: pointer;
    z-index: 100;
    box-shadow: 0 4px 16px rgba(0,0,0,0.3);
}
@media (min-width: 1024px) {
    .ptp-b-toggle { display: none; }
}

/* Mobile Map View */
.ptp-browse.map-view .ptp-b-panel { display: none; }
.ptp-browse.map-view .ptp-b-map { display: block; height: calc(100vh - 57px); }

/* ============================================
   MOBILE OPTIMIZATIONS
   ============================================ */
@media (max-width: 767px) {
    /* Header - Stack on mobile */
    .ptp-b-header {
        flex-direction: column;
        align-items: flex-start;
        padding: 12px 16px;
        gap: 12px;
    }
    
    .ptp-b-filters {
        width: 100%;
        overflow-x: auto;
        flex-wrap: nowrap;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
        padding-bottom: 4px;
    }
    .ptp-b-filters::-webkit-scrollbar { display: none; }
    
    .ptp-b-filter {
        padding: 10px 14px;
        font-size: 13px;
        white-space: nowrap;
        flex-shrink: 0;
        min-height: 44px;
    }
    
    .ptp-b-sort {
        width: 100%;
        margin-left: 0;
    }
    .ptp-b-sort select {
        flex: 1;
        min-height: 44px;
    }
    
    /* Panel */
    .ptp-b-panel {
        padding: 16px;
    }
    
    .ptp-b-title { font-size: 18px; }
    .ptp-b-subtitle { font-size: 13px; margin-bottom: 16px; }
    
    /* Grid - Single column on small phones */
    .ptp-b-grid {
        gap: 16px;
    }
    
    /* Card optimizations */
    .ptp-b-card {
        border-radius: 12px;
    }
    .ptp-b-photo {
        height: 180px;
    }
    .ptp-b-body {
        padding: 14px;
    }
    .ptp-b-name {
        font-size: 16px;
    }
    .ptp-b-location, .ptp-b-meta {
        font-size: 12px;
    }
    .ptp-b-price {
        font-size: 15px;
    }
    
    /* Toggle button */
    .ptp-b-toggle {
        bottom: 20px;
        padding: 14px 20px;
        font-size: 14px;
    }
    
    /* Empty state */
    .ptp-empty-state h3 {
        font-size: 20px;
    }
    .ptp-empty-state p {
        font-size: 14px;
    }
}

@media (max-width: 400px) {
    .ptp-b-grid {
        grid-template-columns: 1fr !important;
    }
    .ptp-b-photo {
        height: 200px;
    }
}
</style>

<div class="ptp-browse" id="ptp-browse">
    <div class="ptp-b-header">
        <div class="ptp-b-filters">
            <button class="ptp-b-filter active" data-filter="all">All</button>
            <button class="ptp-b-filter" data-filter="location">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                Location
            </button>
            <button class="ptp-b-filter" data-filter="availability">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                Availability
            </button>
        </div>
        <div class="ptp-b-sort">
            <span>SORT</span>
            <select id="sort-select">
                <option value="recommended">Recommended</option>
                <option value="distance">Nearest First</option>
                <option value="rating">Top Rated</option>
                <option value="price_low">Price: Low</option>
                <option value="price_high">Price: High</option>
            </select>
        </div>
    </div>
    
    <div class="ptp-b-layout">
        <div class="ptp-b-panel">
            <?php if (count($trainers) > 0): ?>
            <h1 class="ptp-b-title">Top <?php echo count($trainers); ?> coaches for lessons near you</h1>
            <p class="ptp-b-subtitle">These coaches teach at top ranked spots and have great lesson fulfillment & student reviews.</p>
            
            <!-- Distance Note -->
            <div id="distance-note" style="display: none; background: #FEF3C7; border-radius: 10px; padding: 12px 16px; margin-bottom: 16px; font-size: 13px; color: #92400E;">
                <strong>📍 Using your location</strong> — Distances shown are approximate.
            </div>
            <?php else: ?>
            <h1 class="ptp-b-title">Find Your Perfect Coach</h1>
            <p class="ptp-b-subtitle">Elite D1 and professional soccer players ready to train you.</p>
            <?php endif; ?>
            
            <div class="ptp-b-grid" id="trainers-grid">
                <?php if (count($trainers) === 0): ?>
                <!-- Empty State -->
                <div style="grid-column: 1 / -1; text-align: center; padding: 60px 24px;">
                    <div style="width: 80px; height: 80px; background: #FEF3C7; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 24px;">
                        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><circle cx="12" cy="7" r="4"/><path d="M5.5 21a7.5 7.5 0 0115 0"/></svg>
                    </div>
                    <h3 style="font-size: 20px; font-weight: 700; margin: 0 0 8px; color: #111;">Coaches Coming Soon</h3>
                    <p style="color: #6B7280; margin: 0 0 24px; max-width: 360px; margin-left: auto; margin-right: auto;">We're onboarding elite trainers in your area. Leave your email to be notified when coaches are available.</p>
                    
                    <div style="max-width: 360px; margin: 0 auto 32px;">
                        <form action="#" method="post" style="display: flex; gap: 8px;">
                            <input type="email" placeholder="Enter your email" required style="flex: 1; padding: 14px 16px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px; outline: none;">
                            <button type="submit" style="padding: 14px 24px; background: #FCB900; color: #0E0F11; border: none; border-radius: 10px; font-weight: 700; cursor: pointer; white-space: nowrap;">Notify Me</button>
                        </form>
                    </div>
                    
                    <div style="border-top: 1px solid #E5E7EB; padding-top: 24px; margin-top: 8px;">
                        <p style="color: #6B7280; font-size: 14px; margin: 0 0 16px;">In the meantime, check out our group programs:</p>
                        <div style="display: flex; justify-content: center; gap: 12px; flex-wrap: wrap;">
                            <a href="<?php echo home_url('/ptp-shop-page/'); ?>" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; background: #0E0F11; color: #FCB900; border-radius: 8px; font-weight: 600; font-size: 14px; text-decoration: none;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/></svg>
                                Summer Camps
                            </a>
                            <a href="<?php echo home_url('/ptp-shop-page/'); ?>" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; background: #fff; color: #0E0F11; border: 2px solid #E5E7EB; border-radius: 8px; font-weight: 600; font-size: 14px; text-decoration: none;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                                Skills Clinics
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="ptp-b-banner">
                <div class="ptp-b-banner-icon">
                    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#0284C7" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <div><strong>All coaches verified</strong> — Background checked, insured, and credential verified for your safety.</div>
            </div>
        </div>
        
        <div class="ptp-b-map">
            <?php if (empty($google_maps_api_key)): ?>
            <div class="ptp-map-placeholder">
                <div style="text-align: center;">
                    <div style="font-size: 48px; margin-bottom: 12px;">🗺️</div>
                    <h3 style="margin:0 0 8px; font-size: 18px; font-weight: 700;">Map Coming Soon</h3>
                    <p style="margin:0; color: #6B7280; font-size: 14px;">Trainer locations will appear here</p>
                    <?php if (current_user_can('manage_options')): ?>
                    <div style="margin-top: 16px; padding: 12px; background: #FEF3C7; border-radius: 8px; text-align: left;">
                        <strong style="color: #92400E; font-size: 13px;">⚙️ Admin:</strong>
                        <p style="margin: 4px 0 0; color: #92400E; font-size: 12px;">
                            Add Google Maps API key in<br>
                            <a href="<?php echo admin_url('admin.php?page=ptp-settings'); ?>" style="color: #B45309;">PTP Settings → General</a>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
            <div id="ptp-map"></div>
            <div id="ptp-map-loading" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; display: none;">
                <div style="font-size: 32px; margin-bottom: 8px;">⏳</div>
                <p style="margin: 0; color: #6B7280;">Loading map...</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<button class="ptp-b-toggle" id="map-toggle">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
    <span>Map</span>
</button>

<?php if (!empty($google_maps_api_key)): ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr($google_maps_api_key); ?>&libraries=places"></script>
<?php endif; ?>

<script>
const trainers = <?php echo json_encode($trainers_json); ?>;
const homeUrl = '<?php echo home_url(); ?>';
let map, markers = [], infoWindow = null, userLat = null, userLng = null;

function renderCards(list = trainers) {
    const grid = document.getElementById('trainers-grid');
    
    // If no trainers, keep the server-rendered empty state
    if (list.length === 0) {
        return;
    }
    
    // Calculate distances for all trainers
    list = list.map(t => {
        if (userLat && userLng && t.lat && t.lng) {
            t.distance = calcDist(userLat, userLng, t.lat, t.lng);
        } else {
            t.distance = null;
        }
        return t;
    });
    
    grid.innerHTML = list.map(t => {
        const rating = t.rating > 0 ? t.rating.toFixed(1) : '5.0';
        const isNew = t.reviews === 0;
        
        let distDisplay = '';
        if (t.distance !== null) {
            if (t.distance < 1) {
                distDisplay = (t.distance * 5280 / 1000).toFixed(0) + ' min walk';
            } else {
                distDisplay = t.distance.toFixed(1) + ' mi away';
            }
        }
        
        const firstLoc = t.trainingLocations && t.trainingLocations.length > 0 ? t.trainingLocations[0] : t.location;
        
        return `
            <a href="${homeUrl}/trainer/${t.slug}/" class="ptp-b-card" data-id="${t.id}">
                <div class="ptp-b-card-img">
                    <img src="${t.photo}" alt="${t.name}" loading="lazy">
                    ${t.level ? `<span class="ptp-b-badge">${t.level}</span>` : (isNew ? '<span class="ptp-b-badge new">New</span>' : '')}
                    <div class="ptp-b-card-info">
                        <h3 class="ptp-b-card-name">
                            ${t.name}
                            ${t.verified ? '<span class="verified"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></span>' : ''}
                        </h3>
                        <div class="ptp-b-card-price">$${t.rate} per session</div>
                    </div>
                    <div class="ptp-b-arrow">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </div>
                </div>
                <div class="ptp-b-meta">
                    <div class="ptp-b-meta-top">
                        <span class="ptp-b-sport">Soccer</span>
                        ${distDisplay ? `<span class="ptp-b-distance" style="color: #0284C7; font-weight: 600;">📍 ${distDisplay}</span>` : ''}
                        ${isNew ? '<span class="ptp-b-new">★ New</span>' : `<span class="ptp-b-rating"><svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>${rating} (${t.reviews})</span>`}
                    </div>
                    <div class="ptp-b-details">
                        ${firstLoc ? `<span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>${firstLoc}</span>` : ''}
                        <span class="ptp-b-avail"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>Great availability</span>
                    </div>
                </div>
            </a>
        `;
    }).join('');
    
    updateMarkers(list);
}

function calcDist(lat1, lng1, lat2, lng2) {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function updateMarkers(list) {
    if (!map) return;
    markers.forEach(m => m.setMap(null));
    markers = [];
    
    const bounds = new google.maps.LatLngBounds();
    let hasMarkers = false;
    
    // Add user marker if location available
    if (userLat && userLng) {
        const userMarker = new google.maps.Marker({
            position: {lat: userLat, lng: userLng},
            map: map,
            title: 'Your Location',
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: 8,
                fillColor: '#EF4444',
                fillOpacity: 1,
                strokeColor: '#fff',
                strokeWeight: 3,
            },
            zIndex: 1000
        });
        bounds.extend({lat: userLat, lng: userLng});
        hasMarkers = true;
    }
    
    list.forEach(t => {
        if (!t.lat || !t.lng) return;
        hasMarkers = true;
        bounds.extend({lat: t.lat, lng: t.lng});
        
        const marker = new google.maps.Marker({
            position: {lat: t.lat, lng: t.lng},
            map: map,
            title: t.name,
            icon: {
                path: google.maps.SymbolPath.CIRCLE,
                scale: 12,
                fillColor: t.featured ? '#FCB900' : '#3B82F6',
                fillOpacity: 1,
                strokeColor: '#fff',
                strokeWeight: 3,
            }
        });
        
        // Create info window content
        const distText = t.distance ? `<div style="color:#0284C7;font-weight:600;font-size:12px;margin-top:4px;">📍 ${t.distance.toFixed(1)} mi away</div>` : '';
        const infoContent = `
            <div style="padding:8px;min-width:200px;font-family:Inter,sans-serif;">
                <div style="display:flex;gap:12px;align-items:center;">
                    <img src="${t.photo}" style="width:50px;height:50px;border-radius:10px;object-fit:cover;">
                    <div>
                        <div style="font-weight:700;font-size:15px;color:#111;">${t.name}</div>
                        <div style="color:#6B7280;font-size:13px;">$${t.rate}/session</div>
                        ${distText}
                    </div>
                </div>
                <a href="${homeUrl}/trainer/${t.slug}/" style="display:block;background:#FCB900;color:#0E0F11;text-align:center;padding:10px;border-radius:8px;font-weight:700;font-size:13px;margin-top:12px;text-decoration:none;">View Profile →</a>
            </div>
        `;
        
        marker.addListener('click', () => {
            if (infoWindow) infoWindow.close();
            infoWindow = new google.maps.InfoWindow({ content: infoContent });
            infoWindow.open(map, marker);
        });
        
        markers.push(marker);
    });
    
    if (hasMarkers) {
        map.fitBounds(bounds);
        if (markers.length === 1) map.setZoom(12);
    }
}

function sortTrainers(sortType) {
    let sorted = [...trainers];
    
    // Calculate distances first
    sorted = sorted.map(t => {
        if (userLat && userLng && t.lat && t.lng) {
            t.distance = calcDist(userLat, userLng, t.lat, t.lng);
        } else {
            t.distance = 9999; // Put trainers without location at end
        }
        return t;
    });
    
    switch (sortType) {
        case 'distance':
            sorted.sort((a,b) => (a.distance || 9999) - (b.distance || 9999));
            break;
        case 'rating':
            sorted.sort((a,b) => b.rating - a.rating);
            break;
        case 'price_low':
            sorted.sort((a,b) => a.rate - b.rate);
            break;
        case 'price_high':
            sorted.sort((a,b) => b.rate - a.rate);
            break;
    }
    
    renderCards(sorted);
}

document.addEventListener('DOMContentLoaded', () => {
    renderCards();
    
    // Map init
    const mapEl = document.getElementById('ptp-map');
    const mapLoading = document.getElementById('ptp-map-loading');
    
    if (mapEl) {
        if (typeof google !== 'undefined' && typeof google.maps !== 'undefined') {
            try {
                map = new google.maps.Map(mapEl, {
                    center: {lat: 39.95, lng: -75.17}, // Philadelphia default
                    zoom: 10,
                    styles: [
                        {featureType: 'poi', stylers: [{visibility: 'off'}]},
                        {featureType: 'transit', stylers: [{visibility: 'off'}]}
                    ],
                    mapTypeControl: false,
                    streetViewControl: false,
                    fullscreenControl: true
                });
                
                // Check if any trainers have coordinates
                const trainersWithCoords = trainers.filter(t => t.lat && t.lng);
                if (trainersWithCoords.length > 0) {
                    updateMarkers(trainers);
                } else {
                    // No trainers have coordinates - show message
                    const noDataDiv = document.createElement('div');
                    noDataDiv.innerHTML = `
                        <div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);text-align:center;background:white;padding:20px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.15);z-index:10;">
                            <div style="font-size:32px;margin-bottom:8px;">📍</div>
                            <p style="margin:0;color:#6B7280;font-size:14px;">Trainer locations loading...</p>
                        </div>
                    `;
                    mapEl.style.position = 'relative';
                    mapEl.appendChild(noDataDiv);
                }
                
                console.log('PTP Map initialized successfully');
            } catch (e) {
                console.error('PTP Map initialization error:', e);
                mapEl.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100%;background:#F3F4F6;"><p style="color:#6B7280;">Map unavailable</p></div>';
            }
        } else {
            console.warn('Google Maps API not loaded');
            mapEl.innerHTML = `
                <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;background:#F3F4F6;text-align:center;padding:20px;">
                    <div style="font-size:40px;margin-bottom:12px;">🗺️</div>
                    <p style="color:#6B7280;margin:0;">Map loading...</p>
                    <p style="color:#9CA3AF;font-size:12px;margin:8px 0 0;">If this persists, the API key may need to be configured.</p>
                </div>
            `;
        }
    }
    
    // Filters
    document.querySelectorAll('.ptp-b-filter').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.ptp-b-filter').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            renderCards();
        });
    });
    
    // Sort
    document.getElementById('sort-select').addEventListener('change', e => {
        sortTrainers(e.target.value);
    });
    
    // Mobile map toggle
    document.getElementById('map-toggle').addEventListener('click', () => {
        const browse = document.getElementById('ptp-browse');
        const btn = document.getElementById('map-toggle');
        browse.classList.toggle('map-view');
        btn.querySelector('span').textContent = browse.classList.contains('map-view') ? 'List' : 'Map';
    });
    
    // Get location
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(pos => {
            userLat = pos.coords.latitude;
            userLng = pos.coords.longitude;
            
            // Show distance note
            const distNote = document.getElementById('distance-note');
            if (distNote) distNote.style.display = 'block';
            
            // Auto-sort by distance
            const sortSelect = document.getElementById('sort-select');
            if (sortSelect) {
                sortSelect.value = 'distance';
                sortTrainers('distance');
            }
            
            // Re-center map
            if (map) {
                map.setCenter({lat: userLat, lng: userLng});
            }
        }, err => {
            console.log('Location not available:', err.message);
        }, {
            enableHighAccuracy: true,
            timeout: 10000
        });
    }
});
</script>
