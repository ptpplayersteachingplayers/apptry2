<?php
/**
 * Template: Home Page - 100% Inline Styles
 */
defined('ABSPATH') || exit;

// PTP Images
$img = array(
    'hero' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1915.jpg',
    'hero2' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1899.jpg',
    'training1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1874.jpg',
    'training2' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1847.jpg',
    'action1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1797.jpg',
    'action2' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1790.jpg',
    'coach1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1595.jpg',
    'drill1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1539.jpg',
    'group1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1393.jpg',
    'skill1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1288.jpg',
    'celebration' => 'https://ptpsummercamps.com/wp-content/uploads/2025/09/august-18-soccer-camp-goal-celebration.jpg-scaled.jpg',
    'coaches' => 'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coaches-july-16-group-photo.jpg.jpg',
    'feedback' => 'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coaches-feedback-with-campers.jpg.jpg',
    '1v1' => 'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coach-versus-ptp-player-1v1-soccer-training.jpg.jpg',
    'workout' => 'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coach-workout-cole-mcevoy.jpg.jpg',
    'individual' => 'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-individual-training-coach-luke.jpg.jpg',
);
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
html, body { overflow-x: hidden !important; max-width: 100vw; }

/* Mobile Optimizations */
@media (max-width: 768px) {
    .ptp-home-hero-title { font-size: 42px !important; }
    .ptp-home-hero-subtitle { font-size: 16px !important; }
    .ptp-home-search-box { padding: 20px !important; margin: 0 12px 32px !important; }
    .ptp-home-search-box h3 { font-size: 18px !important; }
    .ptp-home-search-input { padding: 14px 16px !important; }
    .ptp-home-search-btn { padding: 14px 20px !important; }
    .ptp-home-trust-badges { gap: 16px !important; }
    .ptp-home-trust-badge { font-size: 13px !important; }
}

@media (max-width: 480px) {
    .ptp-home-hero-title { font-size: 32px !important; }
    .ptp-home-hero-subtitle { font-size: 15px !important; padding: 0 12px !important; }
    .ptp-home-search-form { flex-direction: column !important; }
    .ptp-home-search-btn { width: 100% !important; }
    .ptp-home-trust-badges { flex-direction: column !important; align-items: center !important; gap: 12px !important; }
}
</style>

<div style="font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; color: #111827; line-height: 1.6; -webkit-font-smoothing: antialiased;">

    <!-- HERO SECTION -->
    <div style="position: relative; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 120px 24px; background: #0E0F11; overflow: hidden;">
        <!-- Background Image -->
        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-image: url('<?php echo esc_url($img['hero']); ?>'); background-size: cover; background-position: center; opacity: 0.5;"></div>
        <!-- Overlay -->
        <div style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: linear-gradient(to bottom, rgba(14,15,17,0.4), rgba(14,15,17,0.9));"></div>
        
        <!-- Content -->
        <div style="position: relative; z-index: 2; text-align: center; max-width: 800px;">
            <!-- Badge -->
            <div style="display: inline-flex; align-items: center; gap: 8px; background: rgba(252,185,0,0.15); color: #FCB900; padding: 10px 20px; border-radius: 50px; font-size: 14px; font-weight: 600; margin-bottom: 28px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                Trusted by 500+ Families
            </div>
            
            <!-- Title -->
            <h1 class="ptp-home-hero-title" style="font-family: 'Inter', sans-serif; font-size: 72px; font-weight: 900; color: #FFFFFF; margin: 0 0 24px 0; line-height: 1.05; letter-spacing: -0.03em;">
                Train With<br><span style="color: #FCB900;">The Best</span>
            </h1>
            
            <!-- Subtitle -->
            <p class="ptp-home-hero-subtitle" style="font-size: 20px; color: #9CA3AF; margin: 0 0 48px 0; font-weight: 400; line-height: 1.6;">
                Connect with elite NCAA Division 1 athletes and professional soccer players for personalized 1-on-1 training sessions near you.
            </p>
            
            <!-- LOCATION SEARCH BOX -->
            <div class="ptp-home-search-box" style="background: #FFFFFF; border-radius: 20px; padding: 28px; max-width: 460px; margin: 0 auto 48px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.25);">
                <h3 style="font-family: 'Inter', sans-serif; font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 20px 0; text-align: center;">Find Trainers Near You</h3>
                
                <form action="<?php echo esc_url(home_url('/find-trainers/')); ?>" method="get">
                    <div class="ptp-home-search-form" style="display: flex; gap: 12px; margin-bottom: 16px;">
                        <input type="text" name="zip" placeholder="Enter your ZIP code" required pattern="[0-9]{5}" maxlength="5" class="ptp-home-search-input" style="flex: 1; padding: 16px 20px; border: 2px solid #E5E7EB; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 16px; outline: none; transition: border-color 0.2s; min-height: 52px;">
                        <button type="submit" class="ptp-home-search-btn" style="padding: 16px 28px; background: #FCB900; color: #0E0F11; border: none; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 16px; font-weight: 700; cursor: pointer; white-space: nowrap; min-height: 52px;">Search</button>
                    </div>
                </form>
                
                <div style="text-align: center; color: #6B7280; font-size: 14px; margin: 16px 0;">or</div>
                
                <div onclick="useMyLocation()" style="display: flex; align-items: center; justify-content: center; gap: 10px; color: #0E0F11; font-weight: 600; cursor: pointer; padding: 14px; border-radius: 10px; transition: background 0.2s; background: #F9FAFB;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="4"/><line x1="12" y1="20" x2="12" y2="22"/><line x1="2" y1="12" x2="4" y2="12"/><line x1="20" y1="12" x2="22" y2="12"/></svg>
                    Use my current location
                </div>
            </div>
            
            <!-- Trust Badges -->
            <div class="ptp-home-trust-badges" style="display: flex; justify-content: center; gap: 32px; flex-wrap: wrap;">
                <div class="ptp-home-trust-badge" style="display: flex; align-items: center; gap: 10px; color: rgba(255,255,255,0.85); font-size: 15px; font-weight: 500;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    Background Checked
                </div>
                <div style="display: flex; align-items: center; gap: 10px; color: rgba(255,255,255,0.85); font-size: 15px; font-weight: 500;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    Verified Athletes
                </div>
                <div style="display: flex; align-items: center; gap: 10px; color: rgba(255,255,255,0.85); font-size: 15px; font-weight: 500;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="#FCB900"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    5-Star Rated
                </div>
            </div>
        </div>
    </div>

    <!-- HOW IT WORKS -->
    <div style="padding: 100px 24px; background: #FFFFFF;">
        <div style="max-width: 1200px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 64px;">
                <h2 style="font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 800; color: #0E0F11; margin: 0 0 16px 0; letter-spacing: -0.02em;">How It Works</h2>
                <p style="font-size: 18px; color: #6B7280; margin: 0;">Book your first session in 3 easy steps</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 48px; max-width: 1000px; margin: 0 auto;">
                <div style="text-align: center;">
                    <div style="width: 88px; height: 88px; background: #FEF3C7; border-radius: 22px; display: flex; align-items: center; justify-content: center; margin: 0 auto 28px; font-size: 36px; font-weight: 900; color: #F59E0B;">1</div>
                    <h3 style="font-family: 'Inter', sans-serif; font-size: 22px; font-weight: 700; color: #0E0F11; margin: 0 0 12px 0;">Find a Trainer</h3>
                    <p style="color: #6B7280; margin: 0; font-size: 16px; line-height: 1.6;">Browse elite trainers near you. Filter by specialty, price, and availability.</p>
                </div>
                <div style="text-align: center;">
                    <div style="width: 88px; height: 88px; background: #FEF3C7; border-radius: 22px; display: flex; align-items: center; justify-content: center; margin: 0 auto 28px; font-size: 36px; font-weight: 900; color: #F59E0B;">2</div>
                    <h3 style="font-family: 'Inter', sans-serif; font-size: 22px; font-weight: 700; color: #0E0F11; margin: 0 0 12px 0;">Book a Session</h3>
                    <p style="color: #6B7280; margin: 0; font-size: 16px; line-height: 1.6;">Pick a time that works for you. Pay securely online.</p>
                </div>
                <div style="text-align: center;">
                    <div style="width: 88px; height: 88px; background: #FEF3C7; border-radius: 22px; display: flex; align-items: center; justify-content: center; margin: 0 auto 28px; font-size: 36px; font-weight: 900; color: #F59E0B;">3</div>
                    <h3 style="font-family: 'Inter', sans-serif; font-size: 22px; font-weight: 700; color: #0E0F11; margin: 0 0 12px 0;">Train & Improve</h3>
                    <p style="color: #6B7280; margin: 0; font-size: 16px; line-height: 1.6;">Meet your trainer and start leveling up your game.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- PHOTO GALLERY -->
    <div style="padding: 80px 24px; background: #F9FAFB;">
        <div style="max-width: 1200px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 48px;">
                <h2 style="font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 800; color: #0E0F11; margin: 0 0 16px 0; letter-spacing: -0.02em;">See PTP in Action</h2>
                <p style="font-size: 18px; color: #6B7280; margin: 0;">Real training sessions with our elite coaches</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;">
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['training1']); ?>" alt="Training" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['1v1']); ?>" alt="1v1 Training" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['skill1']); ?>" alt="Skills" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['coaches']); ?>" alt="Coaches" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['drill1']); ?>" alt="Drills" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['individual']); ?>" alt="Individual" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['feedback']); ?>" alt="Feedback" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
                <div style="aspect-ratio: 1; border-radius: 16px; overflow: hidden;"><img src="<?php echo esc_url($img['celebration']); ?>" alt="Celebration" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy"></div>
            </div>
        </div>
    </div>

    <!-- STATS SECTION -->
    <div style="padding: 100px 24px; background: #0E0F11;">
        <div style="max-width: 1200px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 64px;">
                <h2 style="font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 800; color: #FFFFFF; margin: 0 0 16px 0; letter-spacing: -0.02em;">Why Parents Choose PTP</h2>
                <p style="font-size: 18px; color: #9CA3AF; margin: 0;">We're not just coaches. We're current players who understand what it takes.</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 48px; max-width: 900px; margin: 0 auto; text-align: center;">
                <div>
                    <div style="font-family: 'Inter', sans-serif; font-size: 72px; font-weight: 900; color: #FCB900; line-height: 1; margin-bottom: 12px;">5:1</div>
                    <div style="color: #9CA3AF; font-size: 16px; font-weight: 500;">Player to Coach Ratio</div>
                </div>
                <div>
                    <div style="font-family: 'Inter', sans-serif; font-size: 72px; font-weight: 900; color: #FCB900; line-height: 1; margin-bottom: 12px;">D1+</div>
                    <div style="color: #9CA3AF; font-size: 16px; font-weight: 500;">NCAA & Pro Athletes</div>
                </div>
                <div>
                    <div style="font-family: 'Inter', sans-serif; font-size: 72px; font-weight: 900; color: #FCB900; line-height: 1; margin-bottom: 12px;">100%</div>
                    <div style="color: #9CA3AF; font-size: 16px; font-weight: 500;">Satisfaction Guaranteed</div>
                </div>
            </div>
        </div>
    </div>

    <!-- BECOME A TRAINER CTA -->
    <div style="padding: 100px 24px; background: #FFFFFF;">
        <div style="max-width: 1200px; margin: 0 auto;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
                <div>
                    <h2 style="font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 800; color: #0E0F11; margin: 0 0 20px 0; letter-spacing: -0.02em;">Are You a D1 or Pro Player?</h2>
                    <p style="font-size: 18px; color: #4B5563; margin: 0 0 36px 0; line-height: 1.7;">Share your skills, earn money on your schedule, and inspire the next generation of soccer players. Join our team of elite trainers.</p>
                    <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                        <a href="<?php echo esc_url(home_url('/apply/')); ?>" style="display: inline-flex; align-items: center; justify-content: center; padding: 18px 36px; background: #FCB900; color: #0E0F11; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 17px; font-weight: 700; text-decoration: none;">Apply Now</a>
                        <a href="<?php echo esc_url(home_url('/find-trainers/')); ?>" style="display: inline-flex; align-items: center; justify-content: center; padding: 18px 36px; background: transparent; color: #374151; border: 2px solid #E5E7EB; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 17px; font-weight: 700; text-decoration: none;">Browse Trainers</a>
                    </div>
                </div>
                <div>
                    <img src="<?php echo esc_url($img['workout']); ?>" alt="Trainer" style="width: 100%; border-radius: 24px; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.15);">
                </div>
            </div>
        </div>
    </div>

    <!-- CAMPS & CLINICS SECTION -->
    <div style="padding: 100px 24px; background: #F9FAFB;">
        <div style="max-width: 1200px; margin: 0 auto;">
            <div style="text-align: center; margin-bottom: 48px;">
                <div style="display: inline-flex; align-items: center; gap: 8px; background: #DBEAFE; color: #1E40AF; padding: 8px 16px; border-radius: 20px; font-size: 13px; font-weight: 600; margin-bottom: 16px;">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    Group Training
                </div>
                <h2 style="font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 800; color: #0E0F11; margin: 0 0 16px 0; letter-spacing: -0.02em;">Summer Camps & Clinics</h2>
                <p style="font-size: 18px; color: #6B7280; margin: 0 0 8px; max-width: 600px; margin-left: auto; margin-right: auto;">Intensive group training with elite coaches. Same quality coaching, more players, better value.</p>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 48px;">
                <!-- Camp Card 1 -->
                <div style="background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                    <div style="height: 180px; background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%); display: flex; align-items: center; justify-content: center;">
                        <div style="text-align: center; color: #0E0F11;">
                            <div style="font-size: 48px; font-weight: 900; line-height: 1;">SUMMER</div>
                            <div style="font-size: 20px; font-weight: 700;">CAMPS 2026</div>
                        </div>
                    </div>
                    <div style="padding: 24px;">
                        <h3 style="font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 8px;">Week-Long Camps</h3>
                        <p style="font-size: 14px; color: #6B7280; margin: 0 0 16px; line-height: 1.5;">Full or half-day options across PA, NJ, DE, MD & NY. Ages 6-14.</p>
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <span style="font-size: 14px; color: #6B7280;">Starting at <strong style="color: #0E0F11;">$299/week</strong></span>
                            <a href="<?php echo esc_url(home_url('/ptp-shop-page/')); ?>" style="background: #0E0F11; color: #fff; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none;">View Camps</a>
                        </div>
                    </div>
                </div>
                
                <!-- Camp Card 2 -->
                <div style="background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                    <div style="height: 180px; background: linear-gradient(135deg, #0E0F11 0%, #1a1a1a 100%); display: flex; align-items: center; justify-content: center;">
                        <div style="text-align: center; color: #fff;">
                            <div style="font-size: 48px; font-weight: 900; line-height: 1; color: #FCB900;">CLINICS</div>
                            <div style="font-size: 20px; font-weight: 700;">YEAR-ROUND</div>
                        </div>
                    </div>
                    <div style="padding: 24px;">
                        <h3 style="font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 8px;">Skills Clinics</h3>
                        <p style="font-size: 14px; color: #6B7280; margin: 0 0 16px; line-height: 1.5;">Focused 2-3 hour sessions on specific skills. Finishing, defending, goalkeeping & more.</p>
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <span style="font-size: 14px; color: #6B7280;">Starting at <strong style="color: #0E0F11;">$49/session</strong></span>
                            <a href="<?php echo esc_url(home_url('/ptp-shop-page/')); ?>" style="background: #0E0F11; color: #fff; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none;">View Clinics</a>
                        </div>
                    </div>
                </div>
                
                <!-- Camp Card 3 -->
                <div style="background: #fff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                    <div style="height: 180px; background: linear-gradient(135deg, #10B981 0%, #059669 100%); display: flex; align-items: center; justify-content: center;">
                        <div style="text-align: center; color: #fff;">
                            <div style="font-size: 48px; font-weight: 900; line-height: 1;">1-ON-1</div>
                            <div style="font-size: 20px; font-weight: 700;">TRAINING</div>
                        </div>
                    </div>
                    <div style="padding: 24px;">
                        <h3 style="font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 8px;">Private Sessions</h3>
                        <p style="font-size: 14px; color: #6B7280; margin: 0 0 16px; line-height: 1.5;">Personalized training with elite D1 and pro athletes. Flexible scheduling.</p>
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <span style="font-size: 14px; color: #6B7280;">Starting at <strong style="color: #0E0F11;">$50/hour</strong></span>
                            <a href="<?php echo esc_url(home_url('/find-trainers/')); ?>" style="background: #0E0F11; color: #fff; padding: 10px 20px; border-radius: 8px; font-size: 14px; font-weight: 600; text-decoration: none;">Find Trainers</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="<?php echo esc_url(home_url('/ptp-shop-page/')); ?>" style="display: inline-flex; align-items: center; gap: 8px; color: #0E0F11; font-weight: 600; font-size: 16px; text-decoration: none;">
                    View All Programs
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
            </div>
        </div>
    </div>

    <!-- FINAL CTA -->
    <div style="padding: 100px 24px; background: #0E0F11; text-align: center;">
        <div style="max-width: 600px; margin: 0 auto;">
            <h2 style="font-family: 'Inter', sans-serif; font-size: 44px; font-weight: 800; color: #FFFFFF; margin: 0 0 16px 0; letter-spacing: -0.02em;">Ready to <span style="color: #FCB900;">Level Up</span>?</h2>
            <p style="font-size: 20px; color: #9CA3AF; margin: 0 0 40px 0;">Find your perfect trainer and book your first session today.</p>
            <a href="<?php echo esc_url(home_url('/find-trainers/')); ?>" style="display: inline-flex; align-items: center; justify-content: center; padding: 20px 40px; background: #FCB900; color: #0E0F11; border-radius: 12px; font-family: 'Inter', sans-serif; font-size: 18px; font-weight: 700; text-decoration: none;">Find Trainers Near Me</a>
        </div>
    </div>

</div>

<script>
function useMyLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
            window.location.href = '<?php echo home_url('/find-trainers/'); ?>?lat=' + position.coords.latitude + '&lng=' + position.coords.longitude;
        }, function(error) {
            alert('Unable to get your location. Please enter your ZIP code.');
        });
    } else {
        alert('Geolocation is not supported by your browser. Please enter your ZIP code.');
    }
}
</script>
