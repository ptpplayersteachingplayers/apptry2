<?php
/**
 * Template: Login - Modern Split-Screen Design
 * v24.9.4 - Clean, professional auth page
 */
defined('ABSPATH') || exit;

$logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
$img = 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1874.jpg';
$error = '';
$explicit_redirect = isset($_GET['redirect_to']) ? esc_url($_GET['redirect_to']) : '';

if (isset($_POST['ptp_login']) && wp_verify_nonce($_POST['ptp_login_nonce'], 'ptp_login')) {
    $creds = array(
        'user_login' => sanitize_text_field($_POST['email']),
        'user_password' => $_POST['password'],
        'remember' => !empty($_POST['remember'])
    );
    
    $user = wp_signon($creds, is_ssl());
    
    if (is_wp_error($user)) {
        $error = 'Invalid email or password. Please try again.';
    } else {
        if (!empty($explicit_redirect)) {
            $redirect = $explicit_redirect;
        } else {
            $user_roles = $user->roles;
            if (in_array('administrator', $user_roles)) {
                $redirect = admin_url();
            } elseif (in_array('ptp_trainer', $user_roles)) {
                $redirect = home_url('/trainer-dashboard/');
            } else {
                $redirect = home_url('/my-training/');
            }
        }
        wp_redirect($redirect);
        exit;
    }
}

$redirect = $explicit_redirect ?: home_url('/my-training/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In | PTP Training</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { overflow-x: hidden; max-width: 100vw; }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            min-height: 100vh;
            display: flex;
            background: #fff;
        }
        
        /* Split Layout */
        .auth-layout {
            display: flex;
            width: 100%;
            min-height: 100vh;
        }
        
        /* Left Side - Form */
        .auth-form-side {
            width: 100%;
            display: flex;
            flex-direction: column;
            padding: 24px;
            overflow-y: auto;
        }
        
        @media (min-width: 1024px) {
            .auth-form-side {
                width: 50%;
                max-width: 600px;
                padding: 40px 60px;
            }
        }
        
        /* Right Side - Image */
        .auth-image-side {
            display: none;
            flex: 1;
            background: url('<?php echo esc_url($img); ?>') center/cover no-repeat;
            position: relative;
        }
        
        .auth-image-side::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(14, 15, 17, 0.7) 0%, rgba(14, 15, 17, 0.4) 100%);
        }
        
        @media (min-width: 1024px) {
            .auth-image-side { display: block; }
        }
        
        .auth-image-content {
            position: absolute;
            bottom: 60px;
            left: 60px;
            right: 60px;
            color: #fff;
            z-index: 2;
        }
        
        .auth-image-title {
            font-size: 36px;
            font-weight: 800;
            margin-bottom: 12px;
            line-height: 1.2;
        }
        
        .auth-image-text {
            font-size: 16px;
            opacity: 0.9;
            line-height: 1.6;
        }
        
        /* Header */
        .auth-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 48px;
        }
        
        .auth-logo img {
            height: 40px;
            width: auto;
        }
        
        .auth-header-link {
            font-size: 14px;
            color: #6B7280;
        }
        
        .auth-header-link a {
            color: #FCB900;
            font-weight: 600;
            text-decoration: none;
        }
        
        .auth-header-link a:hover {
            text-decoration: underline;
        }
        
        /* Form Container */
        .auth-content {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            max-width: 400px;
            margin: 0 auto;
            width: 100%;
        }
        
        .auth-title {
            font-size: 28px;
            font-weight: 800;
            color: #111;
            margin-bottom: 8px;
        }
        
        .auth-subtitle {
            font-size: 15px;
            color: #6B7280;
            margin-bottom: 32px;
        }
        
        /* Error */
        .auth-error {
            background: #FEE2E2;
            color: #991B1B;
            padding: 14px 16px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 14px;
            font-weight: 500;
        }
        
        /* Form */
        .auth-form {}
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }
        
        .form-input {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #E5E7EB;
            border-radius: 10px;
            font-size: 16px;
            font-family: inherit;
            transition: all 0.2s;
        }
        
        .form-input:focus {
            outline: none;
            border-color: #FCB900;
            box-shadow: 0 0 0 3px rgba(252, 185, 0, 0.15);
        }
        
        .form-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }
        
        .remember-check {
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }
        
        .remember-check input {
            width: 18px;
            height: 18px;
            accent-color: #FCB900;
        }
        
        .remember-check span {
            font-size: 14px;
            color: #6B7280;
        }
        
        .forgot-link {
            font-size: 14px;
            color: #6B7280;
            text-decoration: none;
        }
        
        .forgot-link:hover {
            color: #FCB900;
        }
        
        .btn-submit {
            width: 100%;
            padding: 16px;
            background: #FCB900;
            color: #0E0F11;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 700;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.2s;
        }
        
        .btn-submit:hover {
            background: #E5A800;
            transform: translateY(-1px);
        }
        
        /* Divider */
        .auth-divider {
            display: flex;
            align-items: center;
            margin: 28px 0;
            color: #9CA3AF;
            font-size: 13px;
        }
        
        .auth-divider::before,
        .auth-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #E5E7EB;
        }
        
        .auth-divider span {
            padding: 0 16px;
        }
        
        /* Trainer CTA */
        .trainer-cta {
            text-align: center;
            padding: 24px;
            background: #F9FAFB;
            border-radius: 12px;
            border: 1px solid #E5E7EB;
        }
        
        .trainer-cta p {
            font-size: 14px;
            color: #6B7280;
            margin-bottom: 12px;
        }
        
        .trainer-cta a {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            color: #0E0F11;
            font-weight: 600;
            text-decoration: none;
        }
        
        .trainer-cta a:hover {
            color: #FCB900;
        }
        
        /* Footer */
        .auth-footer {
            text-align: center;
            padding-top: 32px;
            margin-top: auto;
        }
        
        .auth-footer p {
            font-size: 13px;
            color: #9CA3AF;
        }
        
        .auth-footer a {
            color: #6B7280;
            text-decoration: none;
        }
        
        .auth-footer a:hover {
            color: #FCB900;
        }
        
        /* Mobile Optimizations */
        @media (max-width: 600px) {
            .auth-form-side {
                padding: 20px 16px;
            }
            
            .auth-header {
                margin-bottom: 24px;
            }
            
            .auth-logo-img {
                height: 36px;
            }
            
            .auth-title {
                font-size: 26px;
            }
            
            .auth-subtitle {
                font-size: 14px;
            }
            
            .form-input {
                padding: 16px;
                font-size: 16px;
                min-height: 52px;
            }
            
            .btn-submit {
                padding: 18px;
                font-size: 16px;
                min-height: 56px;
            }
            
            .form-row {
                flex-direction: column;
                align-items: flex-start;
                gap: 12px;
            }
            
            .social-btn {
                padding: 16px;
                min-height: 52px;
            }
            
            .trainer-cta {
                padding: 16px;
            }
            
            .auth-footer {
                padding-top: 24px;
            }
        }
        
        @media (max-width: 380px) {
            .auth-title {
                font-size: 22px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-layout">
        <div class="auth-form-side">
            <div class="auth-header">
                <a href="<?php echo home_url(); ?>" class="auth-logo">
                    <img src="<?php echo esc_url($logo); ?>" alt="PTP">
                </a>
                <div class="auth-header-link">
                    New here? <a href="<?php echo home_url('/register/'); ?>">Create account</a>
                </div>
            </div>
            
            <div class="auth-content">
                <h1 class="auth-title">Welcome back</h1>
                <p class="auth-subtitle">Sign in to your PTP account</p>
                
                <?php if ($error): ?>
                <div class="auth-error"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <form class="auth-form" method="post">
                    <?php wp_nonce_field('ptp_login', 'ptp_login_nonce'); ?>
                    <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect); ?>">
                    
                    <div class="form-group">
                        <label class="form-label">Email address</label>
                        <input type="email" name="email" class="form-input" placeholder="you@example.com" required autofocus>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-input" placeholder="••••••••" required>
                    </div>
                    
                    <div class="form-row">
                        <label class="remember-check">
                            <input type="checkbox" name="remember" value="1">
                            <span>Remember me</span>
                        </label>
                        <a href="<?php echo wp_lostpassword_url(); ?>" class="forgot-link">Forgot password?</a>
                    </div>
                    
                    <button type="submit" name="ptp_login" value="1" class="btn-submit">Sign In</button>
                </form>
                
                <div class="auth-divider"><span>or</span></div>
                
                <div class="trainer-cta">
                    <p>Are you a coach or trainer?</p>
                    <a href="<?php echo home_url('/apply/'); ?>">
                        Apply to become a trainer
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>
                </div>
            </div>
            
            <div class="auth-footer">
                <p>Need help? <a href="mailto:luke@ptpsummercamps.com">Contact support</a> • <a href="tel:+14845724770">(484) 572-4770</a></p>
            </div>
        </div>
        
        <div class="auth-image-side">
            <div class="auth-image-content">
                <h2 class="auth-image-title">Train with the best players</h2>
                <p class="auth-image-text">Book private 1-on-1 sessions with current college and professional soccer players. Real experience, real results.</p>
            </div>
        </div>
    </div>
</body>
</html>
