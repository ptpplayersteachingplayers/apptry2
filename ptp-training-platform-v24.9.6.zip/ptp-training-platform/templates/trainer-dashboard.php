<?php
/**
 * Template: Trainer Dashboard - Restructured v24.4.7
 * Mobile-first, sidebar navigation, calendar-focused
 * Fixed error handling for earnings and other data
 */
defined('ABSPATH') || exit;

// Ensure required variables exist with defaults
if (!isset($trainer) || !$trainer) {
    echo '<div style="padding: 40px; text-align: center;"><p>Trainer profile not found.</p></div>';
    return;
}

if (!isset($earnings) || !is_array($earnings)) {
    $earnings = array('this_month' => 0, 'total_earnings' => 0, 'pending_payout' => 0);
}
if (!isset($availability) || !is_array($availability)) {
    $availability = array();
}
if (!isset($upcoming) || !is_array($upcoming)) {
    $upcoming = array();
}
if (!isset($pending_confirmations) || !is_array($pending_confirmations)) {
    $pending_confirmations = array();
}
if (!isset($completion)) {
    $completion = array('percentage' => 100, 'missing' => array());
}

$user = wp_get_current_user();
$days = array('Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat');
$availability_by_day = array();
foreach ($availability as $slot) {
    if (isset($slot->day_of_week)) {
        $availability_by_day[$slot->day_of_week] = $slot;
    }
}

// Safely get payouts - method may not exist
$payouts = array();
if (class_exists('PTP_Payments') && method_exists('PTP_Payments', 'get_trainer_payouts')) {
    $payouts = PTP_Payments::get_trainer_payouts($trainer->id, 5);
} else {
    // Fallback: try direct query
    global $wpdb;
    $payouts_table = $wpdb->prefix . 'ptp_payouts';
    if ($wpdb->get_var("SHOW TABLES LIKE '$payouts_table'") == $payouts_table) {
        $payouts = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_payouts WHERE trainer_id = %d ORDER BY created_at DESC LIMIT 5",
            $trainer->id
        ));
    }
}

$stripe_connected = !empty($trainer->stripe_account_id);
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'schedule';
$photo = $trainer->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($trainer->display_name) . '&size=200&background=FCB900&color=0A0A0A&bold=true';

// Safely get conversations
$conversations = array();
$unread_count = 0;
if (class_exists('PTP_Messaging') && method_exists('PTP_Messaging', 'get_conversations_for_user')) {
    $conversations = PTP_Messaging::get_conversations_for_user(get_current_user_id());
    foreach ($conversations as $c) { $unread_count += $c->unread_count ?? 0; }
}
?>

<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
* { box-sizing: border-box; }
html, body { overflow-x: hidden; max-width: 100vw; }

.ptp-dash {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    background: #F3F4F6;
    min-height: 100vh;
    color: #111827;
    overflow-x: hidden;
    max-width: 100vw;
}

/* Mobile Header */
.ptp-dash-mobile-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 16px;
    background: #fff;
    border-bottom: 1px solid #E5E7EB;
    position: sticky;
    top: 0;
    z-index: 100;
}

.ptp-dash-logo { height: 28px; }

.ptp-dash-menu-btn {
    width: 40px;
    height: 40px;
    border: none;
    background: #F3F4F6;
    border-radius: 10px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.ptp-dash-menu-btn svg { width: 20px; height: 20px; color: #374151; }

/* Sidebar */
.ptp-dash-sidebar {
    position: fixed;
    top: 0;
    left: -280px;
    width: 280px;
    height: 100vh;
    background: #0F172A;
    z-index: 200;
    transition: left 0.3s ease;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
}

.ptp-dash-sidebar.open { left: 0; }

.ptp-dash-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.5);
    z-index: 150;
    display: none;
}

.ptp-dash-overlay.show { display: block; }

.ptp-dash-sidebar-header {
    padding: 20px;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.ptp-dash-sidebar-profile {
    display: flex;
    align-items: center;
    gap: 12px;
}

.ptp-dash-sidebar-avatar {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    object-fit: cover;
}

.ptp-dash-sidebar-name {
    font-weight: 700;
    font-size: 15px;
    color: #fff;
    margin: 0 0 2px;
}

.ptp-dash-sidebar-role {
    font-size: 12px;
    color: rgba(255,255,255,0.5);
}

.ptp-dash-sidebar-nav {
    padding: 16px 12px;
    flex: 1;
}

.ptp-dash-nav-section { margin-bottom: 24px; }

.ptp-dash-nav-label {
    font-size: 10px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    color: rgba(255,255,255,0.4);
    padding: 0 12px;
    margin-bottom: 8px;
}

.ptp-dash-nav-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    color: rgba(255,255,255,0.7);
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    transition: all 0.2s;
    margin-bottom: 4px;
}

.ptp-dash-nav-item:hover {
    background: rgba(255,255,255,0.05);
    color: #fff;
}

.ptp-dash-nav-item.active {
    background: #FCB900;
    color: #0F172A;
}

.ptp-dash-nav-item svg {
    width: 20px;
    height: 20px;
    flex-shrink: 0;
}

.ptp-dash-nav-badge {
    margin-left: auto;
    background: #EF4444;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 10px;
}

.ptp-dash-sidebar-footer {
    padding: 16px 20px;
    border-top: 1px solid rgba(255,255,255,0.1);
}

.ptp-dash-logout {
    display: flex;
    align-items: center;
    gap: 10px;
    color: rgba(255,255,255,0.5);
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
}

.ptp-dash-logout:hover { color: #fff; }

/* Main Content */
.ptp-dash-main { padding: 20px 16px 100px; }

.ptp-dash-page-header { margin-bottom: 24px; }

.ptp-dash-page-title {
    font-size: 24px;
    font-weight: 800;
    color: #111827;
    margin: 0 0 4px;
}

.ptp-dash-page-subtitle {
    font-size: 14px;
    color: #6B7280;
    margin: 0;
}

/* Stats */
.ptp-dash-stats {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    margin-bottom: 24px;
}

.ptp-dash-stat {
    background: #fff;
    border-radius: 16px;
    padding: 16px;
    border: 1px solid #E5E7EB;
}

.ptp-dash-stat-label {
    font-size: 12px;
    font-weight: 600;
    color: #6B7280;
    text-transform: uppercase;
    letter-spacing: 0.025em;
    margin-bottom: 8px;
}

.ptp-dash-stat-value {
    font-size: 28px;
    font-weight: 800;
    color: #111827;
    line-height: 1;
}

.ptp-dash-stat-value.money { color: #059669; }

/* Cards */
.ptp-dash-card {
    background: #fff;
    border-radius: 16px;
    border: 1px solid #E5E7EB;
    margin-bottom: 16px;
    overflow: hidden;
}

.ptp-dash-card-header {
    padding: 16px;
    border-bottom: 1px solid #E5E7EB;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.ptp-dash-card-title {
    font-size: 16px;
    font-weight: 700;
    color: #111827;
    margin: 0;
}

.ptp-dash-card-action {
    color: #FCB900;
    font-size: 13px;
    font-weight: 600;
    text-decoration: none;
}

.ptp-dash-card-body { padding: 16px; }

/* Session Item */
.ptp-dash-session {
    display: flex;
    gap: 12px;
    padding: 14px 0;
    border-bottom: 1px solid #F3F4F6;
}

.ptp-dash-session:last-child { border-bottom: none; padding-bottom: 0; }
.ptp-dash-session:first-child { padding-top: 0; }

.ptp-dash-session-date {
    width: 48px;
    height: 48px;
    background: #0F172A;
    border-radius: 12px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.ptp-dash-session-day {
    font-size: 18px;
    font-weight: 800;
    color: #FCB900;
    line-height: 1;
}

.ptp-dash-session-month {
    font-size: 10px;
    font-weight: 600;
    color: rgba(255,255,255,0.6);
    text-transform: uppercase;
}

.ptp-dash-session-info { flex: 1; min-width: 0; }

.ptp-dash-session-name {
    font-weight: 600;
    font-size: 15px;
    color: #111827;
    margin: 0 0 4px;
}

.ptp-dash-session-meta { font-size: 13px; color: #6B7280; }

.ptp-dash-session-status {
    padding: 4px 10px;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    align-self: flex-start;
}

.ptp-dash-session-status.confirmed { background: #D1FAE5; color: #065F46; }
.ptp-dash-session-status.pending { background: #FEF3C7; color: #92400E; }

/* Availability */
.ptp-dash-avail-grid {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.ptp-dash-avail-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    background: #F9FAFB;
    border-radius: 10px;
}

.ptp-dash-avail-day {
    width: 36px;
    font-weight: 700;
    font-size: 13px;
    color: #374151;
}

.ptp-dash-avail-time {
    flex: 1;
    font-size: 13px;
    color: #6B7280;
}

.ptp-dash-avail-dot {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: #D1D5DB;
}

.ptp-dash-avail-dot.active { background: #10B981; }

/* Empty State */
.ptp-dash-empty {
    text-align: center;
    padding: 40px 20px;
}

.ptp-dash-empty-icon {
    width: 64px;
    height: 64px;
    background: #F3F4F6;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 16px;
}

.ptp-dash-empty-icon svg { width: 28px; height: 28px; color: #9CA3AF; }

.ptp-dash-empty-title {
    font-size: 16px;
    font-weight: 700;
    color: #111827;
    margin: 0 0 8px;
}

.ptp-dash-empty-text {
    font-size: 14px;
    color: #6B7280;
    margin: 0;
}

/* Earnings Card */
.ptp-dash-earnings-card {
    background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
    border: none;
}

.ptp-dash-earnings-card .ptp-dash-card-header { border-bottom-color: rgba(255,255,255,0.1); }
.ptp-dash-earnings-card .ptp-dash-card-title { color: #fff; }

.ptp-dash-payout-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 0;
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.ptp-dash-payout-item:last-child { border-bottom: none; }
.ptp-dash-payout-date { font-size: 13px; color: rgba(255,255,255,0.6); }
.ptp-dash-payout-amount { font-size: 15px; font-weight: 700; color: #10B981; }

/* Desktop */
@media (min-width: 1024px) {
    .ptp-dash-mobile-header { display: none; }
    .ptp-dash-sidebar { left: 0; width: 260px; }
    .ptp-dash-overlay { display: none !important; }
    .ptp-dash-main { margin-left: 260px; padding: 32px; max-width: 1200px; }
    .ptp-dash-stats { grid-template-columns: repeat(4, 1fr); gap: 16px; }
    .ptp-dash-stat { padding: 20px; }
    .ptp-dash-grid { display: grid; grid-template-columns: 1fr 380px; gap: 24px; }
    .ptp-dash-page-title { font-size: 28px; }
    .ptp-dash-card { margin-bottom: 24px; }
    .ptp-dash-card-header, .ptp-dash-card-body { padding: 20px; }
    .ptp-dash-bottom-nav { display: none; }
}

/* Mobile Bottom Navigation */
.ptp-dash-bottom-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #fff;
    border-top: 1px solid #E5E7EB;
    display: flex;
    justify-content: space-around;
    padding: 8px 0;
    padding-bottom: max(8px, env(safe-area-inset-bottom));
    z-index: 100;
}

.ptp-dash-bottom-nav a {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    padding: 8px 12px;
    text-decoration: none;
    color: #6B7280;
    font-size: 10px;
    font-weight: 600;
    border-radius: 8px;
    transition: all 0.2s;
}

.ptp-dash-bottom-nav a svg {
    width: 22px;
    height: 22px;
}

.ptp-dash-bottom-nav a.active {
    color: #FCB900;
}

/* Small screen adjustments */
@media (max-width: 380px) {
    .ptp-dash-page-title { font-size: 20px; }
    .ptp-dash-stat-value { font-size: 22px; }
    .ptp-dash-stats { gap: 8px; }
    .ptp-dash-stat { padding: 12px; }
    .ptp-dash-main { padding: 16px 12px 90px; }
    .ptp-dash-card-header, .ptp-dash-card-body { padding: 14px; }
}

/* Welcome Modal */
.ptp-welcome-modal {
    position: fixed;
    inset: 0;
    background: rgba(0,0,0,0.7);
    z-index: 300;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
}

.ptp-welcome-content {
    background: #fff;
    border-radius: 20px;
    max-width: 480px;
    width: 100%;
    padding: 32px;
    text-align: center;
}

.ptp-welcome-icon {
    width: 80px;
    height: 80px;
    background: #D1FAE5;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 24px;
}

.ptp-welcome-icon svg { width: 40px; height: 40px; color: #059669; }

.ptp-welcome-title {
    font-size: 24px;
    font-weight: 800;
    color: #111827;
    margin: 0 0 12px;
}

.ptp-welcome-text {
    font-size: 15px;
    color: #6B7280;
    margin: 0 0 24px;
    line-height: 1.6;
}

.ptp-welcome-btn {
    display: inline-block;
    background: #FCB900;
    color: #0F172A;
    padding: 14px 32px;
    border-radius: 10px;
    font-weight: 700;
    font-size: 15px;
    text-decoration: none;
    border: none;
    cursor: pointer;
}
</style>

<div class="ptp-dash">
    <!-- Mobile Header -->
    <div class="ptp-dash-mobile-header">
        <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png" alt="PTP" class="ptp-dash-logo">
        <button class="ptp-dash-menu-btn" onclick="toggleSidebar()">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
    </div>
    
    <div class="ptp-dash-overlay" id="sidebar-overlay" onclick="toggleSidebar()"></div>
    
    <!-- Sidebar -->
    <aside class="ptp-dash-sidebar" id="sidebar">
        <div class="ptp-dash-sidebar-header">
            <div class="ptp-dash-sidebar-profile">
                <img src="<?php echo esc_url($photo); ?>" alt="" class="ptp-dash-sidebar-avatar">
                <div>
                    <h3 class="ptp-dash-sidebar-name"><?php echo esc_html($trainer->display_name); ?></h3>
                    <p class="ptp-dash-sidebar-role">Trainer</p>
                </div>
            </div>
        </div>
        
        <nav class="ptp-dash-sidebar-nav">
            <div class="ptp-dash-nav-section">
                <div class="ptp-dash-nav-label">Dashboard</div>
                <a href="<?php echo home_url('/trainer-dashboard/?tab=schedule'); ?>" class="ptp-dash-nav-item <?php echo $active_tab === 'schedule' ? 'active' : ''; ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    Schedule
                </a>
                <a href="<?php echo home_url('/trainer-dashboard/?tab=camps'); ?>" class="ptp-dash-nav-item <?php echo $active_tab === 'camps' ? 'active' : ''; ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                    Camps & Clinics
                </a>
                <a href="<?php echo home_url('/trainer-dashboard/?tab=earnings'); ?>" class="ptp-dash-nav-item <?php echo $active_tab === 'earnings' ? 'active' : ''; ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    Earnings
                </a>
                <a href="<?php echo home_url('/messages/'); ?>" class="ptp-dash-nav-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    Messages
                    <?php if ($unread_count > 0): ?><span class="ptp-dash-nav-badge"><?php echo $unread_count; ?></span><?php endif; ?>
                </a>
            </div>
            
            <div class="ptp-dash-nav-section">
                <div class="ptp-dash-nav-label">Profile</div>
                <a href="<?php echo home_url('/trainer/' . $trainer->slug . '/'); ?>" class="ptp-dash-nav-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Public Profile
                </a>
                <a href="<?php echo home_url('/trainer-onboarding/?edit=1'); ?>" class="ptp-dash-nav-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                    Edit Profile
                </a>
                <a href="<?php echo home_url('/account/'); ?>" class="ptp-dash-nav-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                    Settings
                </a>
            </div>
        </nav>
        
        <div class="ptp-dash-sidebar-footer">
            <a href="<?php echo wp_logout_url(home_url()); ?>" class="ptp-dash-logout">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                Sign Out
            </a>
        </div>
    </aside>
    
    <!-- Main Content -->
    <main class="ptp-dash-main">
        <div class="ptp-dash-page-header">
            <h1 class="ptp-dash-page-title"><?php 
                if ($active_tab === 'earnings') echo 'Earnings';
                elseif ($active_tab === 'camps') echo 'Camps & Clinics';
                else echo 'Schedule & Availability';
            ?></h1>
            <p class="ptp-dash-page-subtitle"><?php 
                if ($active_tab === 'earnings') echo 'Track your income and payouts';
                elseif ($active_tab === 'camps') echo 'Your camp and clinic assignments';
                else echo 'Manage your sessions and availability';
            ?></p>
        </div>
        
        <?php if (!$stripe_connected): ?>
        <!-- Payout Setup Banner -->
        <div style="background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border: 2px solid #F59E0B; border-radius: 16px; padding: 20px 24px; margin-bottom: 24px; display: flex; align-items: center; gap: 16px; flex-wrap: wrap;">
            <div style="width: 48px; height: 48px; background: #F59E0B; border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
            </div>
            <div style="flex: 1; min-width: 200px;">
                <h3 style="font-size: 16px; font-weight: 700; color: #92400E; margin: 0 0 4px;">💳 Set Up Your Payouts</h3>
                <p style="font-size: 14px; color: #A16207; margin: 0;">Connect your bank account via Stripe to receive payments from sessions. Secure & takes 2 minutes.</p>
            </div>
            <button id="connect-stripe-btn" onclick="connectStripe()" style="background: #0E0F11; color: #FCB900; border: none; padding: 14px 28px; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; white-space: nowrap; min-height: 48px;">
                Connect Bank Account →
            </button>
        </div>
        <?php endif; ?>
        
        <?php if ($active_tab === 'camps'): 
            // Fetch camp data from Accounting plugin
            $camp_assignments_upcoming = function_exists('ptpap_get_trainer_camp_assignments') ? ptpap_get_trainer_camp_assignments($trainer->id, 'upcoming') : array();
            $camp_assignments_past = function_exists('ptpap_get_trainer_camp_assignments') ? ptpap_get_trainer_camp_assignments($trainer->id, 'past') : array();
            $camp_earnings = function_exists('ptpap_get_trainer_camp_earnings') ? ptpap_get_trainer_camp_earnings($trainer->id) : (object) array('total_earned' => 0, 'total_paid' => 0, 'clinic_count' => 0);
        ?>
        <!-- Camps Tab -->
        <div class="ptp-dash-stats">
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Upcoming</div>
                <div class="ptp-dash-stat-value"><?php echo count($camp_assignments_upcoming); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Camp Earnings (YTD)</div>
                <div class="ptp-dash-stat-value money">$<?php echo number_format($camp_earnings->total_earned ?? 0, 0); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Paid Out</div>
                <div class="ptp-dash-stat-value money">$<?php echo number_format($camp_earnings->total_paid ?? 0, 0); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Total Camps</div>
                <div class="ptp-dash-stat-value"><?php echo intval($camp_earnings->clinic_count ?? 0); ?></div>
            </div>
        </div>
        
        <?php if (!function_exists('ptpap_get_trainer_camp_assignments')): ?>
        <div class="ptp-dash-card">
            <div class="ptp-dash-card-body" style="text-align: center; padding: 32px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="1.5" style="margin-bottom: 16px;"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                <h3 style="font-size: 18px; font-weight: 700; margin: 0 0 8px;">Camp System Not Active</h3>
                <p style="font-size: 14px; color: #6B7280; margin: 0;">Contact PTP to get added to camps and clinics.</p>
            </div>
        </div>
        <?php else: ?>
        
        <div class="ptp-dash-card" style="margin-bottom: 20px;">
            <div class="ptp-dash-card-header">
                <h3 class="ptp-dash-card-title">Upcoming Camps & Clinics</h3>
            </div>
            <div class="ptp-dash-card-body">
                <?php if (empty($camp_assignments_upcoming)): ?>
                    <div class="ptp-dash-empty">
                        <div class="ptp-dash-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg></div>
                        <h3 class="ptp-dash-empty-title">No Upcoming Camps</h3>
                        <p class="ptp-dash-empty-text">You'll see upcoming camp assignments here</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($camp_assignments_upcoming as $camp): ?>
                        <div class="ptp-dash-session">
                            <div class="ptp-dash-session-date" style="background: #FCB900; color: #0F172A;">
                                <span class="ptp-dash-session-day"><?php echo date('j', strtotime($camp->event_date)); ?></span>
                                <span class="ptp-dash-session-month"><?php echo date('M', strtotime($camp->event_date)); ?></span>
                            </div>
                            <div class="ptp-dash-session-info">
                                <h4 class="ptp-dash-session-name"><?php echo esc_html($camp->clinic_name); ?></h4>
                                <div class="ptp-dash-session-meta">
                                    <?php echo ucfirst($camp->role ?? 'Coach'); ?>
                                    <?php if ($camp->facility_name): ?> · <?php echo esc_html($camp->facility_name); ?><?php endif; ?>
                                    · <strong>$<?php echo number_format($camp->total_pay, 0); ?></strong>
                                </div>
                            </div>
                            <span class="ptp-dash-session-status confirmed">Scheduled</span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="ptp-dash-card">
            <div class="ptp-dash-card-header">
                <h3 class="ptp-dash-card-title">Past Camps & Clinics</h3>
            </div>
            <div class="ptp-dash-card-body">
                <?php if (empty($camp_assignments_past)): ?>
                    <p style="color: #6B7280; text-align: center; padding: 20px 0;">No past camp history.</p>
                <?php else: ?>
                    <?php foreach (array_slice($camp_assignments_past, 0, 10) as $camp): ?>
                        <div class="ptp-dash-session" style="opacity: 0.8;">
                            <div class="ptp-dash-session-date" style="background: #E5E7EB; color: #374151;">
                                <span class="ptp-dash-session-day"><?php echo date('j', strtotime($camp->event_date)); ?></span>
                                <span class="ptp-dash-session-month"><?php echo date('M', strtotime($camp->event_date)); ?></span>
                            </div>
                            <div class="ptp-dash-session-info">
                                <h4 class="ptp-dash-session-name"><?php echo esc_html($camp->clinic_name); ?></h4>
                                <div class="ptp-dash-session-meta">
                                    $<?php echo number_format($camp->total_pay, 0); ?>
                                </div>
                            </div>
                            <span class="ptp-dash-session-status <?php echo $camp->payment_status === 'paid' ? 'completed' : 'pending'; ?>">
                                <?php echo $camp->payment_status === 'paid' ? 'Paid' : 'Pending'; ?>
                            </span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <?php elseif ($active_tab === 'earnings'): 
            // Get camp earnings if available
            $camp_ytd = function_exists('ptpap_get_trainer_camp_earnings') ? ptpap_get_trainer_camp_earnings($trainer->id) : null;
            $camp_total = $camp_ytd ? floatval($camp_ytd->total_earned) : 0;
            $combined_total = floatval($trainer->total_earnings ?? 0) + $camp_total;
        ?>
        <!-- Earnings Tab -->
        <div class="ptp-dash-stats">
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">This Month (Sessions)</div>
                <div class="ptp-dash-stat-value money">$<?php echo number_format($earnings['this_month'] ?? 0, 0); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Sessions YTD</div>
                <div class="ptp-dash-stat-value money">$<?php echo number_format($trainer->total_earnings ?? 0, 0); ?></div>
            </div>
            <?php if ($camp_ytd && $camp_total > 0): ?>
            <div class="ptp-dash-stat" style="background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%);">
                <div class="ptp-dash-stat-label" style="color: rgba(0,0,0,0.6);">Camps YTD</div>
                <div class="ptp-dash-stat-value money" style="color: #0F172A;">$<?php echo number_format($camp_total, 0); ?></div>
            </div>
            <div class="ptp-dash-stat" style="background: linear-gradient(135deg, #10B981 0%, #059669 100%);">
                <div class="ptp-dash-stat-label" style="color: rgba(255,255,255,0.8);">Combined Total</div>
                <div class="ptp-dash-stat-value money" style="color: #fff;">$<?php echo number_format($combined_total, 0); ?></div>
            </div>
            <?php else: ?>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Total Earnings</div>
                <div class="ptp-dash-stat-value money">$<?php echo number_format($trainer->total_earnings ?? 0, 0); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Sessions</div>
                <div class="ptp-dash-stat-value"><?php echo number_format($trainer->total_sessions ?? 0); ?></div>
            </div>
            <?php endif; ?>
        </div>
        
        <?php if ($camp_ytd && $camp_total > 0): ?>
        <div style="background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%); border-radius: 16px; padding: 20px; margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
            <div>
                <div style="font-size: 13px; color: rgba(255,255,255,0.6); margin-bottom: 4px;">Total Earnings Breakdown</div>
                <div style="font-size: 14px; color: #fff;">
                    <span style="color: #10B981;">●</span> Sessions: $<?php echo number_format($trainer->total_earnings ?? 0, 0); ?> 
                    &nbsp;|&nbsp;
                    <span style="color: #FCB900;">●</span> Camps: $<?php echo number_format($camp_total, 0); ?>
                </div>
            </div>
            <a href="<?php echo home_url('/trainer-dashboard/?tab=camps'); ?>" style="background: #FCB900; color: #0F172A; padding: 10px 20px; border-radius: 8px; font-weight: 600; font-size: 13px; text-decoration: none;">View Camps →</a>
        </div>
        <?php endif; ?>
        
        <div class="ptp-dash-card ptp-dash-earnings-card">
            <div class="ptp-dash-card-header">
                <h3 class="ptp-dash-card-title">Recent Payouts</h3>
            </div>
            <div class="ptp-dash-card-body">
                <?php if (empty($payouts)): ?>
                    <div class="ptp-dash-empty">
                        <div class="ptp-dash-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></div>
                        <h3 class="ptp-dash-empty-title" style="color:#fff;">No Payouts Yet</h3>
                        <p class="ptp-dash-empty-text" style="color:rgba(255,255,255,0.6);">Complete sessions to start earning</p>
                    </div>
                <?php else: ?>
                    <?php foreach ($payouts as $payout): ?>
                        <div class="ptp-dash-payout-item">
                            <span class="ptp-dash-payout-date"><?php echo date('M j, Y', strtotime($payout->created_at)); ?></span>
                            <span class="ptp-dash-payout-amount">+$<?php echo number_format($payout->amount, 2); ?></span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
        
        <?php if (!$stripe_connected): ?>
        <div class="ptp-dash-card">
            <div class="ptp-dash-card-body" style="text-align: center; padding: 32px;">
                <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="1.5" style="margin-bottom: 16px;"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                <h3 style="font-size: 18px; font-weight: 700; margin: 0 0 8px;">Connect Your Bank</h3>
                <p style="font-size: 14px; color: #6B7280; margin: 0 0 20px;">Set up direct deposit to receive payments automatically</p>
                <button onclick="connectStripe(this)" class="ptp-welcome-btn ptp-connect-stripe-btn">Connect Bank Account</button>
            </div>
        </div>
        <?php endif; ?>
        
        <?php else: ?>
        <!-- Schedule Tab -->
        <div class="ptp-dash-stats">
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Upcoming</div>
                <div class="ptp-dash-stat-value"><?php echo count($upcoming); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Pending</div>
                <div class="ptp-dash-stat-value"><?php echo count($pending_confirmations); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">This Month</div>
                <div class="ptp-dash-stat-value money">$<?php echo number_format($earnings['this_month'] ?? 0, 0); ?></div>
            </div>
            <div class="ptp-dash-stat">
                <div class="ptp-dash-stat-label">Rating</div>
                <div class="ptp-dash-stat-value"><?php echo $trainer->average_rating ? number_format($trainer->average_rating, 1) : '-'; ?></div>
            </div>
        </div>
        
        <div class="ptp-dash-grid">
            <div>
                <div class="ptp-dash-card">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">Upcoming Sessions</h3>
                    </div>
                    <div class="ptp-dash-card-body">
                        <?php if (empty($upcoming)): ?>
                            <div class="ptp-dash-empty">
                                <div class="ptp-dash-empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg></div>
                                <h3 class="ptp-dash-empty-title">No Upcoming Sessions</h3>
                                <p class="ptp-dash-empty-text">Sessions will appear here when parents book with you</p>
                            </div>
                        <?php else: ?>
                            <?php foreach ($upcoming as $session): ?>
                                <div class="ptp-dash-session">
                                    <div class="ptp-dash-session-date">
                                        <span class="ptp-dash-session-day"><?php echo date('j', strtotime($session->session_date)); ?></span>
                                        <span class="ptp-dash-session-month"><?php echo date('M', strtotime($session->session_date)); ?></span>
                                    </div>
                                    <div class="ptp-dash-session-info">
                                        <h4 class="ptp-dash-session-name"><?php echo esc_html($session->player_name); ?></h4>
                                        <div class="ptp-dash-session-meta"><?php echo date('g:i A', strtotime($session->start_time)); ?> · <?php echo esc_html($session->parent_name); ?><?php if ($session->location): ?> · <?php echo esc_html($session->location); ?><?php endif; ?></div>
                                    </div>
                                    <span class="ptp-dash-session-status <?php echo $session->status; ?>"><?php echo ucfirst($session->status); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div>
                <?php 
                // Ensure trainer has a slug - generate one if missing
                $trainer_slug = $trainer->slug;
                if (empty($trainer_slug)) {
                    $trainer_slug = sanitize_title($trainer->display_name ?: 'trainer-' . $trainer->id);
                    global $wpdb;
                    $wpdb->update(
                        $wpdb->prefix . 'ptp_trainers',
                        array('slug' => $trainer_slug),
                        array('id' => $trainer->id)
                    );
                }
                $profile_url = home_url('/trainer/' . $trainer_slug . '/');
                ?>
                <div class="ptp-dash-card">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">Weekly Availability</h3>
                        <span id="avail-sync-status" style="font-size: 12px; color: #9CA3AF;"></span>
                    </div>
                    <div class="ptp-dash-card-body">
                        <div class="ptp-dash-avail-grid" id="availability-grid">
                            <?php foreach ($days as $i => $day): 
                                $slot = $availability_by_day[$i] ?? null;
                                $is_active = $slot && $slot->is_active;
                                $start_time = $slot ? substr($slot->start_time, 0, 5) : '16:00';
                                $end_time = $slot ? substr($slot->end_time, 0, 5) : '20:00';
                            ?>
                                <div class="ptp-dash-avail-row" data-day="<?php echo $i; ?>">
                                    <label class="ptp-dash-avail-toggle">
                                        <input type="checkbox" class="avail-day-toggle" data-day="<?php echo $i; ?>" <?php checked($is_active); ?>>
                                        <span class="ptp-dash-avail-toggle-track"></span>
                                    </label>
                                    <div class="ptp-dash-avail-day"><?php echo $day; ?></div>
                                    <div class="ptp-dash-avail-times <?php echo !$is_active ? 'disabled' : ''; ?>">
                                        <input type="time" class="ptp-avail-time-input" name="start[<?php echo $i; ?>]" value="<?php echo $start_time; ?>" <?php echo !$is_active ? 'disabled' : ''; ?>>
                                        <span>to</span>
                                        <input type="time" class="ptp-avail-time-input" name="end[<?php echo $i; ?>]" value="<?php echo $end_time; ?>" <?php echo !$is_active ? 'disabled' : ''; ?>>
                                    </div>
                                    <div class="ptp-dash-avail-dot <?php echo $is_active ? 'active' : ''; ?>"></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <button type="button" id="save-availability" class="ptp-dash-btn-small" style="margin-top: 16px; display: none;">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                            Save Changes
                        </button>
                    </div>
                </div>
                
                <!-- Messages Widget -->
                <div class="ptp-dash-card" style="margin-top: 16px;">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">💬 Recent Messages</h3>
                        <a href="<?php echo home_url('/messages/'); ?>" class="ptp-dash-card-action">View All</a>
                    </div>
                    <div class="ptp-dash-card-body">
                        <?php if (empty($conversations)): ?>
                            <div style="text-align: center; padding: 20px 12px;">
                                <div style="font-size: 32px; margin-bottom: 8px;">💬</div>
                                <p style="color: #6B7280; font-size: 13px; margin: 0;">No messages yet</p>
                                <p style="color: #9CA3AF; font-size: 12px; margin: 4px 0 0;">Messages from parents will appear here</p>
                            </div>
                        <?php else: ?>
                            <?php 
                            $shown = 0;
                            foreach ($conversations as $convo): 
                                if ($shown >= 3) break;
                                $avatar = !empty($convo->other_photo) ? $convo->other_photo : 'https://ui-avatars.com/api/?name=' . urlencode($convo->other_name) . '&size=80&background=FCB900&color=0A0A0A&bold=true';
                            ?>
                                <a href="<?php echo home_url('/messages/?conversation=' . $convo->id); ?>" style="display: flex; align-items: center; gap: 12px; padding: 12px; background: <?php echo $convo->unread_count > 0 ? '#FEF3C7' : '#F9FAFB'; ?>; border-radius: 10px; margin-bottom: 8px; text-decoration: none; transition: all 0.2s;">
                                    <img src="<?php echo esc_url($avatar); ?>" alt="" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                                    <div style="flex: 1; min-width: 0;">
                                        <div style="font-weight: 600; font-size: 14px; color: #111; display: flex; align-items: center; gap: 6px;">
                                            <?php echo esc_html($convo->other_name); ?>
                                            <?php if ($convo->unread_count > 0): ?>
                                                <span style="background: #FCB900; color: #0E0F11; font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 10px;"><?php echo $convo->unread_count; ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div style="font-size: 12px; color: #6B7280; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                                            <?php echo $convo->last_message ? esc_html(substr($convo->last_message, 0, 35)) . '...' : 'No messages yet'; ?>
                                        </div>
                                    </div>
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><path d="M9 18l6-6-6-6"/></svg>
                                </a>
                            <?php 
                                $shown++;
                            endforeach; 
                            ?>
                            <?php if (count($conversations) > 3): ?>
                                <a href="<?php echo home_url('/messages/'); ?>" style="display: block; text-align: center; padding: 12px; background: #0E0F11; color: #FCB900; border-radius: 10px; font-weight: 600; font-size: 13px; text-decoration: none; margin-top: 8px;">
                                    View All Messages (<?php echo count($conversations); ?>)
                                </a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Calendar Sync Card -->
                <div class="ptp-dash-card" style="margin-top: 16px;">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">📅 Calendar Sync</h3>
                    </div>
                    <div class="ptp-dash-card-body">
                        <?php 
                        $calendar_status = class_exists('PTP_Calendar_Sync') ? PTP_Calendar_Sync::get_connection_status(get_current_user_id()) : array('google' => array('connected' => false));
                        $ics_url = $calendar_status['ics_url'] ?? '';
                        ?>
                        
                        <!-- Google Calendar -->
                        <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #F9FAFB; border-radius: 10px; margin-bottom: 12px;">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M18 4H6a2 2 0 00-2 2v12a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2z" fill="#4285F4"/><path d="M12 8v8M8 12h8" stroke="#fff" stroke-width="2"/></svg>
                            <div style="flex: 1;">
                                <div style="font-weight: 600; font-size: 14px;">Google Calendar</div>
                                <div style="font-size: 12px; color: #6B7280;">
                                    <?php echo $calendar_status['google']['connected'] ? '✓ Connected' : 'Sync sessions automatically'; ?>
                                </div>
                            </div>
                            <?php if ($calendar_status['google']['connected']): ?>
                                <button type="button" onclick="disconnectGoogleCalendar()" class="ptp-dash-btn-outline-small">Disconnect</button>
                            <?php else: ?>
                                <button type="button" onclick="connectGoogleCalendar()" class="ptp-dash-btn-small">Connect</button>
                            <?php endif; ?>
                        </div>
                        
                        <!-- ICS Feed / Apple Calendar -->
                        <div style="display: flex; align-items: center; gap: 12px; padding: 12px; background: #F9FAFB; border-radius: 10px;">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="#000"><rect width="24" height="24" rx="5" fill="#FF3B30"/><text x="12" y="17" text-anchor="middle" fill="#fff" font-size="10" font-weight="bold">31</text></svg>
                            <div style="flex: 1;">
                                <div style="font-weight: 600; font-size: 14px;">Apple/Outlook Calendar</div>
                                <div style="font-size: 12px; color: #6B7280;">Subscribe via ICS feed</div>
                            </div>
                            <button type="button" onclick="copyICSUrl()" class="ptp-dash-btn-outline-small" id="copy-ics-btn">Copy Link</button>
                        </div>
                        <input type="hidden" id="ics-url" value="<?php echo esc_attr($ics_url); ?>">
                    </div>
                </div>
                
                <!-- Quick Help / Trainer Guide -->
                <div class="ptp-dash-card" style="margin-top: 16px;">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">📖 Trainer Guide</h3>
                        <a href="#" onclick="toggleGuide(); return false;" class="ptp-dash-card-action" id="guide-toggle">Show</a>
                    </div>
                    <div class="ptp-dash-card-body ptp-trainer-guide" id="trainer-guide" style="display: none;">
                        <div class="guide-section">
                            <h4>🚀 Getting Started</h4>
                            <ol>
                                <li><strong>Set your availability</strong> - Toggle days on/off and set your hours above</li>
                                <li><strong>Connect your calendar</strong> - Sync with Google or Apple Calendar to avoid double-booking</li>
                                <li><strong>Add training locations</strong> - <a href="<?php echo home_url('/trainer-onboarding/?edit=1'); ?>">Edit your profile</a> to add parks/fields you train at</li>
                                <li><strong>Share your profile</strong> - Send your profile link to families you want to work with</li>
                            </ol>
                        </div>
                        
                        <div class="guide-section">
                            <h4>💰 Getting Paid</h4>
                            <ul>
                                <li>Parents pay when they book - you receive 80% after each completed session</li>
                                <li><strong>Connect your bank</strong> in the <a href="<?php echo home_url('/trainer-dashboard/?tab=earnings'); ?>">Earnings tab</a> for direct deposit</li>
                                <li>Payouts process automatically within 2-3 business days</li>
                            </ul>
                        </div>
                        
                        <div class="guide-section">
                            <h4>📱 Managing Sessions</h4>
                            <ul>
                                <li>When a parent books, you'll get an email notification</li>
                                <li>Sessions appear in your <strong>Upcoming Sessions</strong> list</li>
                                <li>Use the <a href="<?php echo home_url('/messages/'); ?>">Messages</a> feature to communicate with parents</li>
                                <li>Mark sessions complete after training to get paid</li>
                            </ul>
                        </div>
                        
                        <div class="guide-section">
                            <h4>🔗 Sharing Your Profile</h4>
                            <p>Your public profile: <a href="<?php echo esc_url($profile_url); ?>" target="_blank"><?php echo esc_url($profile_url); ?></a></p>
                            <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 12px;">
                                <button type="button" onclick="shareProfile('sms')" class="ptp-dash-btn-outline-small">📱 Text</button>
                                <button type="button" onclick="shareProfile('email')" class="ptp-dash-btn-outline-small">✉️ Email</button>
                                <button type="button" onclick="shareProfile('copy')" class="ptp-dash-btn-outline-small">📋 Copy</button>
                            </div>
                        </div>
                        
                        <div class="guide-section">
                            <h4>❓ Need Help?</h4>
                            <p>Contact our team: <a href="mailto:luke@ptpsummercamps.com">luke@ptpsummercamps.com</a> or <a href="tel:+14845724770">(484) 572-4770</a></p>
                        </div>
                    </div>
                </div>
                
                <!-- Your Profile Link Card - Always Visible -->
                <div class="ptp-dash-card" style="margin-top: 16px;">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">🔗 Your Profile</h3>
                    </div>
                    <div class="ptp-dash-card-body">
                        <div style="background: #F9FAFB; border-radius: 10px; padding: 12px; margin-bottom: 12px;">
                            <div style="font-size: 12px; color: #6B7280; margin-bottom: 4px;">Public URL</div>
                            <a href="<?php echo esc_url($profile_url); ?>" target="_blank" style="color: #FCB900; font-weight: 600; font-size: 14px; word-break: break-all;"><?php echo esc_url($profile_url); ?></a>
                        </div>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                            <a href="<?php echo esc_url($profile_url); ?>" target="_blank" class="ptp-dash-btn-small" style="text-decoration: none; flex: 1; text-align: center;">
                                👁️ View Profile
                            </a>
                            <button type="button" onclick="shareProfile('copy')" class="ptp-dash-btn-outline-small" style="flex: 1;">
                                📋 Copy Link
                            </button>
                        </div>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px; margin-top: 8px;">
                            <button type="button" onclick="shareProfile('sms')" class="ptp-dash-btn-outline-small" style="flex: 1;">📱 Share via Text</button>
                            <button type="button" onclick="shareProfile('email')" class="ptp-dash-btn-outline-small" style="flex: 1;">✉️ Share via Email</button>
                        </div>
                    </div>
                </div>
                
                <?php if (isset($completion) && $completion['percentage'] < 100): ?>
                <div class="ptp-dash-card">
                    <div class="ptp-dash-card-header">
                        <h3 class="ptp-dash-card-title">Complete Profile</h3>
                        <span style="font-weight: 700; color: #FCB900;"><?php echo $completion['percentage']; ?>%</span>
                    </div>
                    <div class="ptp-dash-card-body">
                        <div style="background: #E5E7EB; border-radius: 6px; height: 8px; overflow: hidden; margin-bottom: 16px;">
                            <div style="background: #FCB900; height: 100%; width: <?php echo $completion['percentage']; ?>%;"></div>
                        </div>
                        <?php if (!empty($completion['missing'])): ?>
                        <p style="font-size: 13px; color: #6B7280; margin: 0 0 16px;">Missing: <?php echo implode(', ', array_slice(array_column($completion['missing'], 'label'), 0, 3)); ?></p>
                        <?php endif; ?>
                        <a href="<?php echo home_url('/trainer-onboarding/?edit=1'); ?>" style="display: block; background: #0F172A; color: #fff; padding: 12px; border-radius: 10px; text-align: center; font-weight: 600; font-size: 14px; text-decoration: none;">Complete Profile</a>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </main>
    
    <!-- Mobile Bottom Navigation -->
    <nav class="ptp-dash-bottom-nav">
        <a href="?tab=schedule" class="<?php echo $active_tab === 'schedule' ? 'active' : ''; ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            Schedule
        </a>
        <a href="?tab=earnings" class="<?php echo $active_tab === 'earnings' ? 'active' : ''; ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            Earnings
        </a>
        <a href="?tab=messages" class="<?php echo $active_tab === 'messages' ? 'active' : ''; ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            Messages
        </a>
        <a href="?tab=profile" class="<?php echo $active_tab === 'profile' ? 'active' : ''; ?>">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            Profile
        </a>
    </nav>
</div>

<?php if ($show_welcome): ?>
<div class="ptp-welcome-modal" id="welcome-modal">
    <div class="ptp-welcome-content">
        <div class="ptp-welcome-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg></div>
        <h2 class="ptp-welcome-title">Welcome to PTP!</h2>
        <p class="ptp-welcome-text">Your profile is complete. You're now visible to families looking for trainers in your area.</p>
        <button onclick="document.getElementById('welcome-modal').remove()" class="ptp-welcome-btn">Get Started</button>
    </div>
</div>
<?php endif; ?>

<script>
const ptpNonce = '<?php echo wp_create_nonce('ptp_nonce'); ?>';
const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
const profileUrl = '<?php echo esc_url($profile_url ?? home_url('/trainer/' . ($trainer_slug ?? $trainer->slug) . '/')); ?>';
const trainerName = '<?php echo esc_js($trainer->display_name); ?>';

function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sidebar-overlay').classList.toggle('show');
}

function connectStripe() {
    const btn = document.getElementById('connect-stripe-btn') || event.target;
    const originalText = btn.innerHTML;
    
    // Show loading state
    btn.disabled = true;
    btn.innerHTML = '<span style="display:inline-flex;align-items:center;gap:8px;"><span class="spinner" style="width:16px;height:16px;border:2px solid rgba(252,185,0,0.3);border-top-color:#FCB900;border-radius:50%;animation:spin 0.8s linear infinite;"></span> Connecting...</span>';
    
    fetch(ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=ptp_create_stripe_connect_account&nonce=' + ptpNonce
    })
    .then(r => r.json())
    .then(data => {
        if (data.success && data.data.url) {
            window.location.href = data.data.url;
        } else {
            // Show error message
            const errorMsg = data.data?.message || 'Unable to connect. Please try again or contact support.';
            alert(errorMsg);
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    })
    .catch(e => {
        console.error('Stripe connect error:', e);
        alert('Connection error. Please check your internet and try again.');
        btn.disabled = false;
        btn.innerHTML = originalText;
    });
}

// ===== Inline Availability Editing =====
let availabilityChanged = false;

document.querySelectorAll('.avail-day-toggle').forEach(toggle => {
    toggle.addEventListener('change', function() {
        const day = this.dataset.day;
        const row = this.closest('.ptp-dash-avail-row');
        const timesDiv = row.querySelector('.ptp-dash-avail-times');
        const dot = row.querySelector('.ptp-dash-avail-dot');
        const inputs = timesDiv.querySelectorAll('input');
        
        if (this.checked) {
            timesDiv.classList.remove('disabled');
            inputs.forEach(i => i.disabled = false);
            dot.classList.add('active');
        } else {
            timesDiv.classList.add('disabled');
            inputs.forEach(i => i.disabled = true);
            dot.classList.remove('active');
        }
        
        availabilityChanged = true;
        document.getElementById('save-availability').style.display = 'inline-flex';
    });
});

document.querySelectorAll('.ptp-avail-time-input').forEach(input => {
    input.addEventListener('change', function() {
        availabilityChanged = true;
        document.getElementById('save-availability').style.display = 'inline-flex';
    });
});

document.getElementById('save-availability')?.addEventListener('click', async function() {
    const btn = this;
    const statusEl = document.getElementById('avail-sync-status');
    
    // Prevent double-clicks
    if (btn.disabled) return;
    
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Saving...';
    if (statusEl) statusEl.textContent = 'Saving...';
    
    const rows = document.querySelectorAll('.ptp-dash-avail-row');
    if (!rows || rows.length === 0) {
        btn.innerHTML = 'Error - No Data';
        btn.disabled = false;
        return;
    }
    
    let successCount = 0;
    let errorCount = 0;
    let lastError = '';
    
    // Debug: Log what we're about to send
    console.log('Saving availability for', rows.length, 'days');
    console.log('AJAX URL:', ajaxUrl);
    console.log('Nonce:', ptpNonce ? 'Set (' + ptpNonce.length + ' chars)' : 'MISSING');
    
    // Save each day sequentially for better reliability
    for (const row of rows) {
        const day = row.dataset.day;
        const toggle = row.querySelector('.avail-day-toggle');
        const startInput = row.querySelector('input[name^="start"]');
        const endInput = row.querySelector('input[name^="end"]');
        
        if (!toggle || !startInput || !endInput) {
            console.warn('Missing inputs for day', day);
            errorCount++;
            continue;
        }
        
        const enabled = toggle.checked ? 1 : 0;
        let start = startInput.value || '16:00';
        let end = endInput.value || '20:00';
        
        // Normalize time format - ensure HH:MM format
        start = start.replace(/[^0-9:]/g, '').substring(0, 5);
        end = end.replace(/[^0-9:]/g, '').substring(0, 5);
        
        // Pad single digit hours (e.g., "9:00" -> "09:00")
        if (start.length === 4 && start[1] === ':') start = '0' + start;
        if (end.length === 4 && end[1] === ':') end = '0' + end;
        
        // Validate time format (be lenient)
        if (!/^\d{1,2}:\d{2}$/.test(start)) {
            console.warn('Invalid start time for day', day, ':', start);
            start = '16:00';
        }
        if (!/^\d{1,2}:\d{2}$/.test(end)) {
            console.warn('Invalid end time for day', day, ':', end);
            end = '20:00';
        }
        
        // Ensure 24-hour format padding
        if (start.length === 4) start = '0' + start;
        if (end.length === 4) end = '0' + end;
        
        try {
            const params = new URLSearchParams();
            params.append('action', 'ptp_quick_update_availability');
            params.append('nonce', ptpNonce);
            params.append('day', day);
            params.append('enabled', enabled.toString());
            params.append('start', start);
            params.append('end', end);
            
            console.log('Saving day', day, ':', { enabled, start, end });
            
            const response = await fetch(ajaxUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: params.toString(),
                credentials: 'same-origin'
            });
            
            console.log('Response status for day', day, ':', response.status);
            
            if (!response.ok) {
                throw new Error('HTTP ' + response.status);
            }
            
            const text = await response.text();
            console.log('Response for day', day, ':', text.substring(0, 100));
            
            let data;
            try {
                data = JSON.parse(text);
            } catch (parseError) {
                console.error('JSON parse error for day', day);
                console.error('Raw response:', text.substring(0, 500));
                lastError = 'Server returned invalid response';
                errorCount++;
                continue;
            }
            
            if (data.success) {
                successCount++;
            } else {
                console.error('Save failed for day', day, data);
                lastError = data.data?.message || 'Save failed';
                errorCount++;
            }
        } catch (e) {
            console.error('Network/save error for day', day, e);
            lastError = e.message || 'Network error';
            errorCount++;
        }
    }
    
    console.log('Save complete:', { successCount, errorCount, lastError });
    
    // Show result
    if (errorCount === 0) {
        btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Saved!';
        btn.style.background = '#10B981';
        if (statusEl) statusEl.textContent = 'Last saved: just now';
        
        setTimeout(() => {
            btn.style.display = 'none';
            btn.style.background = '';
            btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg> Save Changes';
            btn.disabled = false;
            availabilityChanged = false;
        }, 2000);
    } else if (successCount > 0) {
        btn.innerHTML = 'Saved ' + successCount + '/' + rows.length;
        if (statusEl) statusEl.textContent = errorCount + ' day(s) failed: ' + lastError;
        btn.disabled = false;
    } else {
        btn.innerHTML = 'Save Failed - Retry';
        if (statusEl) statusEl.textContent = lastError || 'Connection error - check console for details';
        btn.disabled = false;
        
        // Show alert with more details
        alert('Save failed: ' + lastError + '\n\nPlease check browser console (F12) for details and contact support if the issue persists.');
    }
});
        btn.innerHTML = `Saved ${successCount}/${rows.length}`;
        if (statusEl) statusEl.textContent = `${errorCount} day(s) failed - try again`;
        btn.disabled = false;
    } else {
        btn.innerHTML = 'Save Failed - Retry';
        if (statusEl) statusEl.textContent = 'Connection error - please try again';
        btn.disabled = false;
    }
});

// ===== Calendar Sync =====
function connectGoogleCalendar() {
    fetch(ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=ptp_connect_google_calendar&nonce=' + ptpNonce
    })
    .then(r => {
        if (!r.ok) throw new Error('Network error');
        return r.json();
    })
    .then(data => {
        if (data.success && data.data.auth_url) {
            window.location.href = data.data.auth_url;
        } else {
            alert(data.data?.message || 'Google Calendar not configured. Contact support.');
        }
    })
    .catch(e => {
        console.error('Calendar connect error:', e);
        alert('Connection error. Please try again.');
    });
}

function disconnectGoogleCalendar() {
    if (!confirm('Disconnect Google Calendar?')) return;
    
    fetch(ajaxUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'action=ptp_disconnect_google_calendar&nonce=' + ptpNonce
    })
    .then(r => r.json())
    .then(() => window.location.reload())
    .catch(e => {
        console.error('Disconnect error:', e);
        alert('Error disconnecting. Please try again.');
    });
}

function copyICSUrl() {
    const urlEl = document.getElementById('ics-url');
    if (!urlEl) return;
    
    const url = urlEl.value;
    if (!url) {
        alert('ICS URL not available. Please contact support.');
        return;
    }
    
    navigator.clipboard.writeText(url).then(() => {
        const btn = document.getElementById('copy-ics-btn');
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = 'Copy Link', 2000);
    });
}

// ===== Trainer Guide =====
function toggleGuide() {
    const guide = document.getElementById('trainer-guide');
    const toggle = document.getElementById('guide-toggle');
    if (guide.style.display === 'none') {
        guide.style.display = 'block';
        toggle.textContent = 'Hide';
    } else {
        guide.style.display = 'none';
        toggle.textContent = 'Show';
    }
}

// ===== Profile Sharing =====
function shareProfile(method) {
    const text = `Book private soccer training with ${trainerName}`;
    
    switch(method) {
        case 'sms':
            window.open(`sms:?body=${encodeURIComponent(text + ': ' + profileUrl)}`);
            break;
        case 'email':
            window.open(`mailto:?subject=${encodeURIComponent('Soccer Training with ' + trainerName)}&body=${encodeURIComponent(text + '\n\n' + profileUrl)}`);
            break;
        case 'copy':
            navigator.clipboard.writeText(profileUrl).then(() => {
                alert('Profile link copied to clipboard!');
            });
            break;
    }
}
</script>
<style>
/* Availability Toggle */
.ptp-dash-avail-toggle { position: relative; width: 40px; height: 22px; flex-shrink: 0; }
.ptp-dash-avail-toggle input { opacity: 0; width: 0; height: 0; position: absolute; }
.ptp-dash-avail-toggle-track { position: absolute; inset: 0; background: #E5E7EB; border-radius: 11px; transition: background 0.2s; cursor: pointer; }
.ptp-dash-avail-toggle input:checked + .ptp-dash-avail-toggle-track { background: #10B981; }
.ptp-dash-avail-toggle-track::after { content: ''; position: absolute; width: 18px; height: 18px; background: #fff; border-radius: 50%; top: 2px; left: 2px; transition: transform 0.2s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
.ptp-dash-avail-toggle input:checked + .ptp-dash-avail-toggle-track::after { transform: translateX(18px); }

/* Availability Row */
.ptp-dash-avail-row { display: flex; align-items: center; gap: 12px; padding: 10px 0; border-bottom: 1px solid #F3F4F6; }
.ptp-dash-avail-row:last-child { border-bottom: none; }
.ptp-dash-avail-day { font-weight: 600; width: 40px; font-size: 14px; }
.ptp-dash-avail-times { display: flex; align-items: center; gap: 8px; flex: 1; }
.ptp-dash-avail-times.disabled { opacity: 0.4; pointer-events: none; }
.ptp-dash-avail-times span { color: #9CA3AF; font-size: 12px; }
.ptp-avail-time-input { padding: 8px 10px; border: 1px solid #E5E7EB; border-radius: 8px; font-size: 14px; width: 110px; font-family: inherit; }
.ptp-avail-time-input:focus { outline: none; border-color: #FCB900; box-shadow: 0 0 0 3px rgba(252,185,0,0.1); }
.ptp-avail-time-input:disabled { background: #F9FAFB; cursor: not-allowed; }

/* Small Buttons */
.ptp-dash-btn-small { display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 10px 16px; background: #FCB900; color: #000; border: none; border-radius: 8px; font-size: 14px; font-weight: 600; cursor: pointer; transition: all 0.2s; text-decoration: none; min-height: 44px; }
.ptp-dash-btn-small:hover { background: #E5A800; transform: translateY(-1px); box-shadow: 0 4px 12px rgba(252, 185, 0, 0.3); }
.ptp-dash-btn-small:active { transform: translateY(0); }
.ptp-dash-btn-outline-small { display: inline-flex; align-items: center; justify-content: center; gap: 6px; padding: 10px 16px; background: #fff; color: #374151; border: 1px solid #E5E7EB; border-radius: 8px; font-size: 14px; font-weight: 500; cursor: pointer; transition: all 0.2s; min-height: 44px; }
.ptp-dash-btn-outline-small:hover { border-color: #FCB900; background: #FFFBEB; transform: translateY(-1px); }
.ptp-dash-btn-outline-small:active { transform: translateY(0); }

/* Trainer Guide */
.ptp-trainer-guide { font-size: 14px; line-height: 1.6; }
.guide-section { margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #E5E7EB; }
.guide-section:last-child { margin-bottom: 0; padding-bottom: 0; border-bottom: none; }
.guide-section h4 { margin: 0 0 12px; font-size: 15px; font-weight: 700; }
.guide-section ol, .guide-section ul { margin: 0; padding-left: 20px; }
.guide-section li { margin-bottom: 8px; }
.guide-section a { color: #FCB900; font-weight: 500; }

/* Spinner */
.spinner { display: inline-block; width: 14px; height: 14px; border: 2px solid #E5E7EB; border-top-color: #000; border-radius: 50%; animation: spin 0.8s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }

/* ===== Mobile Optimizations ===== */
@media (max-width: 768px) {
    /* Availability grid mobile layout */
    .ptp-dash-avail-row {
        flex-wrap: wrap;
        gap: 8px;
        padding: 12px 0;
    }
    .ptp-dash-avail-day {
        width: auto;
        min-width: 45px;
    }
    .ptp-dash-avail-times {
        order: 3;
        width: 100%;
        margin-top: 4px;
        padding-left: 52px;
    }
    .ptp-avail-time-input {
        flex: 1;
        width: auto;
        min-width: 0;
        padding: 10px 8px;
    }
    .ptp-dash-avail-dot {
        margin-left: auto;
    }
    
    /* Buttons full width on mobile */
    .ptp-dash-btn-small,
    .ptp-dash-btn-outline-small {
        padding: 12px 16px;
        font-size: 14px;
    }
    
    /* Calendar sync cards */
    .ptp-dash-card-body > div[style*="display: flex"] {
        flex-wrap: wrap;
    }
    
    /* Profile URL box */
    .ptp-dash-card-body a[style*="word-break"] {
        font-size: 12px !important;
    }
}

@media (max-width: 480px) {
    .ptp-dash-avail-times {
        flex-direction: column;
        align-items: stretch;
        gap: 6px;
        padding-left: 0;
        margin-top: 8px;
    }
    .ptp-dash-avail-times span {
        text-align: center;
    }
    .ptp-avail-time-input {
        width: 100%;
        text-align: center;
    }
    
    /* Stack buttons */
    .ptp-dash-btn-small,
    .ptp-dash-btn-outline-small {
        width: 100%;
    }
}
</style>
