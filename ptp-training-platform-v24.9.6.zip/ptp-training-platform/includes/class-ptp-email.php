<?php
/**
 * PTP Email System v2
 * Modern, bulletproof email templates
 */

defined('ABSPATH') || exit;

class PTP_Email {
    
    private static $from_name = 'PTP Training';
    private static $from_email = '';
    
    public static function init() {
        self::$from_email = get_option('ptp_from_email', get_option('admin_email'));
        add_filter('wp_mail_from', array(__CLASS__, 'set_from_email'));
        add_filter('wp_mail_from_name', array(__CLASS__, 'set_from_name'));
        add_filter('wp_mail_content_type', array(__CLASS__, 'set_html_content_type'));
    }
    
    public static function set_from_email($email) {
        return self::$from_email;
    }
    
    public static function set_from_name($name) {
        return self::$from_name;
    }
    
    public static function set_html_content_type() {
        return 'text/html';
    }
    
    /**
     * Send booking confirmation to parent
     */
    public static function send_booking_confirmation($booking_id) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare("
            SELECT b.*, 
                   t.display_name as trainer_name, t.photo_url as trainer_photo,
                   p.name as player_name,
                   pa.display_name as parent_name, pa.user_id as parent_user_id
            FROM {$wpdb->prefix}ptp_bookings b
            JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
            JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
            JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
            WHERE b.id = %d
        ", $booking_id));
        
        if (!$booking) return false;
        
        $user = get_user_by('ID', $booking->parent_user_id);
        if (!$user) return false;
        
        $subject = "Booking Confirmed - {$booking->booking_number}";
        
        $data = array(
            'parent_name' => $booking->parent_name,
            'trainer_name' => $booking->trainer_name,
            'trainer_photo' => $booking->trainer_photo,
            'player_name' => $booking->player_name,
            'date' => date('l, F j, Y', strtotime($booking->session_date)),
            'time' => date('g:i A', strtotime($booking->start_time)) . ' - ' . date('g:i A', strtotime($booking->end_time)),
            'location' => $booking->location,
            'total' => number_format($booking->total_amount, 2),
            'booking_number' => $booking->booking_number,
            'dashboard_url' => home_url('/my-training/'),
            'message_url' => home_url('/messages/?trainer=' . $booking->trainer_id),
        );
        
        $body = self::render_template('booking-confirmation', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send new booking notification to trainer
     */
    public static function send_trainer_new_booking($booking_id) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare("
            SELECT b.*, 
                   t.display_name as trainer_name, t.user_id as trainer_user_id,
                   p.name as player_name, p.age as player_age, p.skill_level,
                   pa.display_name as parent_name
            FROM {$wpdb->prefix}ptp_bookings b
            JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
            JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
            JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
            WHERE b.id = %d
        ", $booking_id));
        
        if (!$booking) return false;
        
        $user = get_user_by('ID', $booking->trainer_user_id);
        if (!$user) return false;
        
        $subject = "New Booking - {$booking->player_name}";
        
        $data = array(
            'trainer_name' => $booking->trainer_name,
            'parent_name' => $booking->parent_name,
            'player_name' => $booking->player_name,
            'player_age' => $booking->player_age,
            'skill_level' => ucfirst($booking->skill_level),
            'date' => date('l, F j, Y', strtotime($booking->session_date)),
            'time' => date('g:i A', strtotime($booking->start_time)),
            'location' => $booking->location,
            'notes' => $booking->notes,
            'earnings' => number_format($booking->trainer_payout, 2),
            'dashboard_url' => home_url('/trainer-dashboard/'),
        );
        
        $body = self::render_template('trainer-new-booking', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send session reminder (24 hours before)
     */
    public static function send_session_reminder($booking_id, $recipient = 'both') {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare("
            SELECT b.*, 
                   t.display_name as trainer_name, t.user_id as trainer_user_id, t.phone as trainer_phone,
                   p.name as player_name,
                   pa.display_name as parent_name, pa.user_id as parent_user_id
            FROM {$wpdb->prefix}ptp_bookings b
            JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
            JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
            JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
            WHERE b.id = %d
        ", $booking_id));
        
        if (!$booking) return false;
        
        $data = array(
            'player_name' => $booking->player_name,
            'trainer_name' => $booking->trainer_name,
            'date' => date('l, F j', strtotime($booking->session_date)),
            'time' => date('g:i A', strtotime($booking->start_time)),
            'location' => $booking->location,
        );
        
        // Send to parent
        if ($recipient === 'both' || $recipient === 'parent') {
            $parent_user = get_user_by('ID', $booking->parent_user_id);
            if ($parent_user) {
                $data['name'] = $booking->parent_name;
                $data['dashboard_url'] = home_url('/my-training/');
                $body = self::render_template('session-reminder-parent', $data);
                wp_mail($parent_user->user_email, "⏰ Reminder: Training Tomorrow", $body);
            }
        }
        
        // Send to trainer
        if ($recipient === 'both' || $recipient === 'trainer') {
            $trainer_user = get_user_by('ID', $booking->trainer_user_id);
            if ($trainer_user) {
                $data['name'] = $booking->trainer_name;
                $data['dashboard_url'] = home_url('/trainer-dashboard/');
                $body = self::render_template('session-reminder-trainer', $data);
                wp_mail($trainer_user->user_email, "⏰ Reminder: Training Tomorrow", $body);
            }
        }
        
        return true;
    }
    
    /**
     * Send cancellation notification
     */
    public static function send_cancellation($booking_id, $cancelled_by = 'parent') {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare("
            SELECT b.*, 
                   t.display_name as trainer_name, t.user_id as trainer_user_id,
                   p.name as player_name,
                   pa.display_name as parent_name, pa.user_id as parent_user_id
            FROM {$wpdb->prefix}ptp_bookings b
            JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
            JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
            JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
            WHERE b.id = %d
        ", $booking_id));
        
        if (!$booking) return false;
        
        $data = array(
            'player_name' => $booking->player_name,
            'trainer_name' => $booking->trainer_name,
            'parent_name' => $booking->parent_name,
            'date' => date('l, F j, Y', strtotime($booking->session_date)),
            'time' => date('g:i A', strtotime($booking->start_time)),
            'cancelled_by' => $cancelled_by,
            'reason' => $booking->cancellation_reason,
        );
        
        // Notify the other party
        if ($cancelled_by === 'parent') {
            $user = get_user_by('ID', $booking->trainer_user_id);
            $data['name'] = $booking->trainer_name;
            $subject = "Session Cancelled - {$booking->player_name}";
        } else {
            $user = get_user_by('ID', $booking->parent_user_id);
            $data['name'] = $booking->parent_name;
            $subject = "Session Cancelled by {$booking->trainer_name}";
        }
        
        if (!$user) return false;
        
        $body = self::render_template('booking-cancelled', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send payout notification to trainer
     */
    public static function send_payout_notification($payout_id) {
        global $wpdb;
        
        $payout = $wpdb->get_row($wpdb->prepare("
            SELECT p.*, t.display_name, t.user_id
            FROM {$wpdb->prefix}ptp_payouts p
            JOIN {$wpdb->prefix}ptp_trainers t ON p.trainer_id = t.id
            WHERE p.id = %d
        ", $payout_id));
        
        if (!$payout) return false;
        
        $user = get_user_by('ID', $payout->user_id);
        if (!$user) return false;
        
        $subject = "Payout Processed - $" . number_format($payout->amount, 2);
        
        $data = array(
            'name' => $payout->display_name,
            'amount' => number_format($payout->amount, 2),
            'method' => ucfirst($payout->payout_method),
            'date' => date('F j, Y'),
            'dashboard_url' => home_url('/trainer-dashboard/'),
        );
        
        $body = self::render_template('payout-processed', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send application received confirmation to applicant
     */
    public static function send_application_received($email, $name) {
        $subject = "We've Received Your Application!";
        
        $data = array(
            'name' => $name,
            'status_url' => home_url('/login/'),
        );
        
        $body = self::render_template('application-received', $data);
        
        return wp_mail($email, $subject, $body);
    }
    
    /**
     * Send application approved notification with login details
     */
    public static function send_application_approved($email, $name, $password = null) {
        $subject = "You're Approved - Welcome to PTP Training!";
        
        $data = array(
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'login_url' => home_url('/login/'),
            'dashboard_url' => home_url('/trainer-dashboard/'),
        );
        
        $body = self::render_template('application-approved', $data);
        
        return wp_mail($email, $subject, $body);
    }
    
    /**
     * Send application rejected notification
     */
    public static function send_application_rejected($email, $name) {
        $subject = "Update on Your PTP Trainer Application";
        
        $data = array(
            'name' => $name,
            'reapply_url' => home_url('/apply/'),
        );
        
        $body = self::render_template('application-rejected', $data);
        
        return wp_mail($email, $subject, $body);
    }
    
    /**
     * Send contractor agreement confirmation with full agreement text
     */
    public static function send_contractor_agreement($trainer_id) {
        global $wpdb;
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
            $trainer_id
        ));
        
        if (!$trainer) return false;
        
        $user = get_user_by('ID', $trainer->user_id);
        if (!$user) return false;
        
        $subject = "Your PTP Independent Contractor Agreement";
        
        $data = array(
            'name' => $trainer->display_name,
            'signed_date' => date('F j, Y \a\t g:i A', strtotime($trainer->contractor_agreement_signed_at)),
            'ip_address' => $trainer->contractor_agreement_ip ?: 'Not recorded',
            'dashboard_url' => home_url('/trainer-dashboard/'),
        );
        
        $body = self::render_template('contractor-agreement', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send onboarding complete email with profile link
     */
    public static function send_onboarding_complete($trainer_id) {
        global $wpdb;
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
            $trainer_id
        ));
        
        if (!$trainer) return false;
        
        $user = get_user_by('ID', $trainer->user_id);
        if (!$user) return false;
        
        $subject = "Your Trainer Profile is Live!";
        
        $data = array(
            'name' => $trainer->display_name,
            'profile_url' => home_url('/trainer/' . $trainer->slug . '/'),
            'dashboard_url' => home_url('/trainer-dashboard/'),
        );
        
        $body = self::render_template('onboarding-complete', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send new message notification
     */
    public static function send_message_notification($message_id) {
        global $wpdb;
        
        $message = $wpdb->get_row($wpdb->prepare("
            SELECT m.*, c.trainer_id, c.parent_id
            FROM {$wpdb->prefix}ptp_messages m
            JOIN {$wpdb->prefix}ptp_conversations c ON m.conversation_id = c.id
            WHERE m.id = %d
        ", $message_id));
        
        if (!$message) return false;
        
        // Get sender and recipient info
        $sender_id = $message->sender_id;
        $trainer = PTP_Trainer::get($message->trainer_id);
        $parent = PTP_Parent::get($message->parent_id);
        
        // Determine recipient
        if ($sender_id == $trainer->user_id) {
            $recipient_user = get_user_by('ID', $parent->user_id);
            $sender_name = $trainer->display_name;
        } else {
            $recipient_user = get_user_by('ID', $trainer->user_id);
            $sender_name = $parent->display_name;
        }
        
        if (!$recipient_user) return false;
        
        $subject = "New message from {$sender_name}";
        
        $data = array(
            'sender_name' => $sender_name,
            'message_preview' => wp_trim_words($message->message, 20),
            'messages_url' => home_url('/messages/?conversation=' . $message->conversation_id),
        );
        
        $body = self::render_template('new-message', $data);
        
        return wp_mail($recipient_user->user_email, $subject, $body);
    }
    
    /**
     * Send review request after completed session
     */
    public static function send_review_request($booking_id) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare("
            SELECT b.*, 
                   t.display_name as trainer_name, t.slug as trainer_slug,
                   p.name as player_name,
                   pa.display_name as parent_name, pa.user_id as parent_user_id
            FROM {$wpdb->prefix}ptp_bookings b
            JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
            JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
            JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
            WHERE b.id = %d
        ", $booking_id));
        
        if (!$booking) return false;
        
        $user = get_user_by('ID', $booking->parent_user_id);
        if (!$user) return false;
        
        $subject = "How was {$booking->player_name}'s session?";
        
        $data = array(
            'parent_name' => $booking->parent_name,
            'trainer_name' => $booking->trainer_name,
            'player_name' => $booking->player_name,
            'review_url' => home_url('/trainer/' . $booking->trainer_slug . '?review=1&booking=' . $booking_id),
        );
        
        $body = self::render_template('review-request', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Send welcome email to new parent
     */
    public static function send_welcome_parent($user_id) {
        $user = get_user_by('ID', $user_id);
        if (!$user) return false;
        
        $subject = "Welcome to PTP Training!";
        
        $data = array(
            'name' => $user->first_name ?: $user->display_name,
            'trainers_url' => home_url('/find-trainers/'),
            'dashboard_url' => home_url('/my-training/'),
        );
        
        $body = self::render_template('welcome-parent', $data);
        
        return wp_mail($user->user_email, $subject, $body);
    }
    
    /**
     * Render email template with PTP branded design
     */
    private static function render_template($template, $data) {
        ob_start();
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>PTP Training</title>
    <!--[if mso]>
    <noscript>
        <xml>
            <o:OfficeDocumentSettings>
                <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
        </xml>
    </noscript>
    <![endif]-->
    <style>
        body, table, td { margin: 0; padding: 0; }
        img { border: 0; display: block; }
        body { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
        @media (prefers-color-scheme: dark) {
            .email-body { background-color: #0E0F11 !important; }
            .email-content { background-color: #1A1B1E !important; }
            .email-content h1, .email-content h2, .email-content h3 { color: #ffffff !important; }
            .email-content p { color: #9CA3AF !important; }
        }
    </style>
</head>
<body style="margin: 0; padding: 0; background-color: #0E0F11; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; -webkit-font-smoothing: antialiased;">
    
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #0E0F11;" class="email-body">
        <tr>
            <td align="center" style="padding: 40px 20px;">
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width: 560px;">
                    
                    <!-- Logo Header -->
                    <tr>
                        <td align="center" style="padding-bottom: 32px;">
                            <a href="<?php echo home_url(); ?>" style="display: inline-block;">
                                <img src="https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png" alt="PTP Training" width="120" height="auto" style="display: block; max-width: 120px; height: auto;">
                            </a>
                        </td>
                    </tr>
                    
                    <!-- Content Card -->
                    <tr>
                        <td>
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.3);" class="email-content">
                                
                                <!-- Yellow Accent Bar -->
                                <tr>
                                    <td style="background: #FCB900; height: 6px;"></td>
                                </tr>
                                
                                <!-- Main Content -->
                                <tr>
                                    <td style="padding: 40px 36px 36px;">
                                        <?php echo self::get_template_content($template, $data); ?>
                                    </td>
                                </tr>
                                
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="padding: 32px 20px; text-align: center;">
                            <p style="margin: 0 0 8px; font-size: 14px; color: #9CA3AF;">
                                PTP Soccer - Elite 1-on-1 Training
                            </p>
                            <p style="margin: 0 0 16px; font-size: 13px; color: #6B7280;">
                                PA | NJ | DE | MD | NY
                            </p>
                            <p style="margin: 0; font-size: 12px; color: #4B5563;">
                                <a href="<?php echo home_url(); ?>" style="color: #FCB900; text-decoration: none;">Website</a>
                                <span style="color: #374151; margin: 0 8px;">|</span>
                                <a href="<?php echo home_url('/account/'); ?>" style="color: #FCB900; text-decoration: none;">Account</a>
                                <span style="color: #374151; margin: 0 8px;">|</span>
                                <a href="<?php echo home_url('/messages/'); ?>" style="color: #FCB900; text-decoration: none;">Messages</a>
                            </p>
                        </td>
                    </tr>
                    
                </table>
                
            </td>
        </tr>
    </table>
    
</body>
</html>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Get template-specific content - PTP branded, no emojis
     */
    private static function get_template_content($template, $data) {
        // PTP branded button style
        $btn = 'display: inline-block; background-color: #FCB900; color: #0E0F11; padding: 16px 32px; text-decoration: none; border-radius: 10px; font-weight: 700; font-size: 15px; text-align: center;';
        $btn_outline = 'display: inline-block; background-color: transparent; color: #374151; padding: 14px 28px; text-decoration: none; border-radius: 10px; font-weight: 600; font-size: 14px; border: 2px solid #e5e7eb;';
        
        ob_start();
        
        switch ($template) {
            
            case 'booking-confirmation':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 800; color: #0E0F11;">Booking Confirmed</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Hi <?php echo esc_html($data['parent_name']); ?>, your training session is all set.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #F9FAFB; border-radius: 12px; margin-bottom: 28px; border: 1px solid #E5E7EB;">
                    <tr>
                        <td style="padding: 24px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Booking Number</span><br>
                                        <span style="font-size: 16px; font-weight: 700; color: #0E0F11;"><?php echo esc_html($data['booking_number']); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Trainer</span><br>
                                        <span style="font-size: 16px; font-weight: 600; color: #0E0F11;"><?php echo esc_html($data['trainer_name']); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Player</span><br>
                                        <span style="font-size: 16px; font-weight: 600; color: #0E0F11;"><?php echo esc_html($data['player_name']); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Date & Time</span><br>
                                        <span style="font-size: 16px; font-weight: 600; color: #0E0F11;"><?php echo esc_html($data['date']); ?></span><br>
                                        <span style="font-size: 14px; color: #374151;"><?php echo esc_html($data['time']); ?></span>
                                    </td>
                                </tr>
                                <?php if (!empty($data['location'])): ?>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Location</span><br>
                                        <span style="font-size: 15px; color: #0E0F11;"><?php echo esc_html($data['location']); ?></span>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td style="padding: 12px 0;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Total Paid</span><br>
                                        <span style="font-size: 20px; font-weight: 800; color: #0E0F11;">$<?php echo esc_html($data['total']); ?></span>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['dashboard_url']); ?>" style="<?php echo $btn; ?>">View Booking Details</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'trainer-new-booking':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 800; color: #0E0F11;">New Booking</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Great news <?php echo esc_html($data['trainer_name']); ?>, you have a new training session booked.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #F9FAFB; border-radius: 12px; margin-bottom: 28px; border: 1px solid #E5E7EB;">
                    <tr>
                        <td style="padding: 24px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Player</span><br>
                                        <span style="font-size: 16px; font-weight: 600; color: #0E0F11;"><?php echo esc_html($data['player_name']); ?></span>
                                        <?php if (!empty($data['player_age'])): ?>
                                        <span style="font-size: 14px; color: #6b7280;"> - <?php echo esc_html($data['player_age']); ?> years old</span>
                                        <?php endif; ?>
                                        <?php if (!empty($data['skill_level'])): ?>
                                        <br><span style="font-size: 13px; color: #6b7280;"><?php echo esc_html($data['skill_level']); ?> level</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Parent</span><br>
                                        <span style="font-size: 15px; color: #0E0F11;"><?php echo esc_html($data['parent_name']); ?></span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Date & Time</span><br>
                                        <span style="font-size: 16px; font-weight: 600; color: #0E0F11;"><?php echo esc_html($data['date']); ?></span><br>
                                        <span style="font-size: 14px; color: #374151;"><?php echo esc_html($data['time']); ?></span>
                                    </td>
                                </tr>
                                <?php if (!empty($data['location'])): ?>
                                <tr>
                                    <td style="padding: 12px 0; border-bottom: 1px solid #E5E7EB;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Location</span><br>
                                        <span style="font-size: 15px; color: #0E0F11;"><?php echo esc_html($data['location']); ?></span>
                                    </td>
                                </tr>
                                <?php endif; ?>
                                <tr>
                                    <td style="padding: 12px 0;">
                                        <span style="font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px;">Your Earnings</span><br>
                                        <span style="font-size: 22px; font-weight: 800; color: #10B981;">$<?php echo esc_html($data['earnings']); ?></span>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                
                <?php if (!empty($data['notes'])): ?>
                <div style="background-color: #FEF3C7; border-radius: 10px; padding: 16px; margin-bottom: 28px; border-left: 4px solid #FCB900;">
                    <p style="margin: 0 0 4px; font-size: 12px; font-weight: 700; color: #92400e; text-transform: uppercase;">Note from parent</p>
                    <p style="margin: 0; font-size: 14px; color: #78350f;"><?php echo esc_html($data['notes']); ?></p>
                </div>
                <?php endif; ?>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['dashboard_url']); ?>" style="<?php echo $btn; ?>">View Dashboard</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'session-reminder-parent':
            case 'session-reminder-trainer':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Training Tomorrow! ⏰</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Hi <?php echo esc_html($data['name']); ?>, just a friendly reminder about tomorrow's session.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 8px; font-size: 14px; color: #6b7280;">Session Details</p>
                            <p style="margin: 0 0 4px; font-size: 18px; font-weight: 600; color: #111827;"><?php echo esc_html($data['date']); ?> at <?php echo esc_html($data['time']); ?></p>
                            <p style="margin: 0 0 12px; font-size: 15px; color: #374151;">
                                <?php if ($template === 'session-reminder-parent'): ?>
                                Trainer: <?php echo esc_html($data['trainer_name']); ?>
                                <?php else: ?>
                                Player: <?php echo esc_html($data['player_name']); ?>
                                <?php endif; ?>
                            </p>
                            <?php if (!empty($data['location'])): ?>
                            <p style="margin: 0; font-size: 14px; color: #6b7280;">📍 <?php echo esc_html($data['location']); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['dashboard_url']); ?>" style="<?php echo $btn; ?>">View Details</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'booking-cancelled':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Session Cancelled</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Hi <?php echo esc_html($data['name']); ?>, the following session has been cancelled.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #fef2f2; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 4px; font-size: 15px; color: #991b1b;">
                                <?php echo esc_html($data['date']); ?> at <?php echo esc_html($data['time']); ?>
                            </p>
                            <p style="margin: 0; font-size: 14px; color: #7f1d1d;">
                                Player: <?php echo esc_html($data['player_name']); ?> • Trainer: <?php echo esc_html($data['trainer_name']); ?>
                            </p>
                            <?php if (!empty($data['reason'])): ?>
                            <p style="margin: 12px 0 0; font-size: 14px; color: #991b1b;">Reason: <?php echo esc_html($data['reason']); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                
                <p style="margin: 0; font-size: 14px; color: #6b7280;">If you have any questions, please contact us.</p>
                <?php
                break;
                
            case 'payout-processed':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Payout Sent! 💵</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Great news <?php echo esc_html($data['name']); ?>, your earnings have been processed.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #ecfdf5; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 32px; text-align: center;">
                            <p style="margin: 0 0 4px; font-size: 14px; color: #065f46;">Amount Deposited</p>
                            <p style="margin: 0; font-size: 36px; font-weight: 700; color: #047857;">$<?php echo esc_html($data['amount']); ?></p>
                            <p style="margin: 8px 0 0; font-size: 14px; color: #6b7280;">via <?php echo esc_html($data['method']); ?> • <?php echo esc_html($data['date']); ?></p>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['dashboard_url']); ?>" style="<?php echo $btn; ?>">View Earnings</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'application-received':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Application Received! ⚽</h1>
                <p style="margin: 0 0 24px; font-size: 16px; color: #6b7280; line-height: 1.6;">Hi <?php echo esc_html($data['name']); ?>, thanks for applying to become a PTP trainer!</p>
                
                <p style="margin: 0 0 28px; font-size: 15px; color: #374151; line-height: 1.6;">We're excited that you want to share your soccer expertise with the next generation of players. Our team will review your application and get back to you within <strong>2-3 business days</strong>.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 16px; font-size: 15px; font-weight: 600; color: #111827;">What happens next?</p>
                            <table role="presentation" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">1</span>
                                        We'll review your playing experience
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">2</span>
                                        If approved, you'll get login credentials
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">3</span>
                                        Complete your profile & set availability
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">4</span>
                                        Start accepting bookings!
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                
                <p style="margin: 0; font-size: 14px; color: #6b7280;">Questions? Just reply to this email.</p>
                <?php
                break;
                
            case 'application-approved':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">You're Approved! 🎉</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Congratulations <?php echo esc_html($data['name']); ?>! Welcome to the PTP trainer team.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 16px; font-size: 15px; font-weight: 600; color: #111827;">Your Login Details</p>
                            <p style="margin: 0 0 8px; font-size: 14px; color: #374151;">
                                <strong>Email:</strong> <?php echo esc_html($data['email']); ?>
                            </p>
                            <?php if (!empty($data['password'])): ?>
                            <p style="margin: 0; font-size: 14px; color: #374151;">
                                <strong>Temporary Password:</strong> <code style="background: #e5e7eb; padding: 2px 8px; border-radius: 4px;"><?php echo esc_html($data['password']); ?></code>
                            </p>
                            <p style="margin: 16px 0 0; font-size: 13px; color: #6b7280;">Please change your password after logging in.</p>
                            <?php else: ?>
                            <p style="margin: 0; font-size: 14px; color: #374151;">
                                <strong>Password:</strong> Use the password you created when you applied
                            </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                
                <p style="margin: 0 0 28px; font-size: 15px; color: #374151; line-height: 1.6;">Log in now to complete your profile, set your availability, and start accepting booking requests from families in your area.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['login_url']); ?>" style="<?php echo $btn; ?>">Login & Get Started</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'application-rejected':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Application Update</h1>
                <p style="margin: 0 0 24px; font-size: 16px; color: #6b7280;">Hi <?php echo esc_html($data['name']); ?>, thank you for your interest in PTP Training.</p>
                
                <p style="margin: 0 0 20px; font-size: 15px; color: #374151; line-height: 1.6;">After reviewing your application, we've decided not to move forward at this time. This could be due to trainer capacity in your area or our current program requirements.</p>
                
                <p style="margin: 0 0 28px; font-size: 15px; color: #374151; line-height: 1.6;">We encourage you to reapply in the future, especially as you gain additional playing or coaching experience.</p>
                
                <p style="margin: 0; font-size: 14px; color: #6b7280;">We appreciate your interest and wish you the best in your soccer journey.</p>
                <?php
                break;
            
            case 'contractor-agreement':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Contractor Agreement Signed ✓</h1>
                <p style="margin: 0 0 24px; font-size: 16px; color: #6b7280;">Hi <?php echo esc_html($data['name']); ?>, this confirms your acceptance of the PTP Independent Contractor Agreement.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f0fdf4; border-radius: 12px; margin-bottom: 28px; border: 1px solid #bbf7d0;">
                    <tr>
                        <td style="padding: 20px;">
                            <p style="margin: 0 0 8px; font-size: 14px; color: #166534;"><strong>✓ Agreement Signed</strong></p>
                            <p style="margin: 0 0 4px; font-size: 13px; color: #374151;"><strong>Date:</strong> <?php echo esc_html($data['signed_date']); ?></p>
                            <p style="margin: 0 0 4px; font-size: 13px; color: #374151;"><strong>IP Address:</strong> <?php echo esc_html($data['ip_address']); ?></p>
                            <p style="margin: 0; font-size: 13px; color: #374151;"><strong>Agreement Version:</strong> 1.0</p>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 16px; font-size: 16px; font-weight: 700; color: #111827;">INDEPENDENT CONTRACTOR AGREEMENT</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>1. INDEPENDENT CONTRACTOR STATUS</strong><br>
                            You are an independent contractor, not an employee. You are responsible for your own taxes, insurance, and business expenses. PTP will issue Form 1099-NEC for earnings of $600 or more.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>2. SERVICES</strong><br>
                            You will provide soccer training services to clients booked through the PTP platform. You have sole discretion over training methods.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>3. COMPENSATION</strong><br>
                            You set your own hourly rate. PTP retains 20% as a platform fee. The remaining 80% is paid via Stripe Connect within 2-3 business days after session completion.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>4. TAXES</strong><br>
                            You are solely responsible for all federal, state, and local taxes. PTP will provide Form 1099-NEC as required by law.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>5. INSURANCE & LIABILITY</strong><br>
                            You are responsible for maintaining appropriate liability insurance and assume all liability for injuries or damages arising from training sessions.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>6. BACKGROUND CHECK & SAFESPORT</strong><br>
                            You agree to provide valid SafeSport certification and may be subject to background verification.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>7. CONDUCT</strong><br>
                            You agree to conduct all training sessions professionally and in accordance with all applicable laws. Violation results in immediate termination.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>8. TERMINATION</strong><br>
                            Either party may terminate this Agreement at any time for any reason.</p>
                            
                            <p style="margin: 0 0 12px; font-size: 13px; color: #374151; line-height: 1.6;"><strong>9. CONFIDENTIALITY</strong><br>
                            You agree to keep confidential all client information and PTP business practices.</p>
                            
                            <p style="margin: 0; font-size: 13px; color: #374151; line-height: 1.6;"><strong>10. NO SOLICITATION</strong><br>
                            You agree not to solicit PTP clients outside the platform for 12 months after your last session.</p>
                        </td>
                    </tr>
                </table>
                
                <p style="margin: 0 0 28px; font-size: 14px; color: #6b7280;">Please save this email for your records. If you have questions about this agreement, contact us at support@ptpsummercamps.com.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['dashboard_url']); ?>" style="<?php echo $btn; ?>">Go to Dashboard</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
            
            case 'onboarding-complete':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Profile Complete! 🎉</h1>
                <p style="margin: 0 0 24px; font-size: 16px; color: #6b7280;">Congratulations <?php echo esc_html($data['name']); ?>! Your trainer profile is now live.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f0fdf4; border-radius: 12px; margin-bottom: 28px; border: 1px solid #bbf7d0;">
                    <tr>
                        <td style="padding: 20px; text-align: center;">
                            <p style="margin: 0 0 8px; font-size: 24px;">✅</p>
                            <p style="margin: 0; font-size: 16px; font-weight: 600; color: #166534;">You're Ready to Accept Bookings!</p>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 16px; font-size: 15px; font-weight: 600; color: #111827;">What's next:</p>
                            <table role="presentation" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding: 8px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">1</span>
                                        Set up Stripe to receive payments
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">2</span>
                                        Share your profile with potential clients
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 8px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">3</span>
                                        Respond quickly when bookings come in
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                
                <p style="margin: 0 0 16px; font-size: 15px; color: #374151;"><strong>Your Profile Link:</strong></p>
                <p style="margin: 0 0 28px; font-size: 14px; color: #3b82f6; word-break: break-all;"><a href="<?php echo esc_url($data['profile_url']); ?>" style="color: #3b82f6;"><?php echo esc_url($data['profile_url']); ?></a></p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['dashboard_url']); ?>" style="<?php echo $btn; ?>">Go to Dashboard</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'new-message':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">New Message 💬</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">You have a new message from <strong><?php echo esc_html($data['sender_name']); ?></strong></p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0; font-size: 15px; color: #374151; font-style: italic; line-height: 1.6;">"<?php echo esc_html($data['message_preview']); ?>..."</p>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['messages_url']); ?>" style="<?php echo $btn; ?>">Reply Now</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'review-request':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">How was the session? ⭐</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280; line-height: 1.6;">Hi <?php echo esc_html($data['parent_name']); ?>, we hope <?php echo esc_html($data['player_name']); ?> had a great session with <?php echo esc_html($data['trainer_name']); ?>!</p>
                
                <p style="margin: 0 0 28px; font-size: 15px; color: #374151; line-height: 1.6;">Your feedback helps other families find great trainers and helps trainers improve. It only takes a minute!</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['review_url']); ?>" style="<?php echo $btn; ?>">Leave a Review</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            case 'welcome-parent':
                ?>
                <h1 style="margin: 0 0 8px; font-size: 28px; font-weight: 700; color: #0a0a0a;">Welcome to PTP! ⚽</h1>
                <p style="margin: 0 0 28px; font-size: 16px; color: #6b7280;">Hi <?php echo esc_html($data['name']); ?>, welcome to the PTP family!</p>
                
                <p style="margin: 0 0 28px; font-size: 15px; color: #374151; line-height: 1.6;">You now have access to elite soccer trainers who can help your child reach their full potential through personalized 1-on-1 training.</p>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; border-radius: 12px; margin-bottom: 28px;">
                    <tr>
                        <td style="padding: 24px;">
                            <p style="margin: 0 0 16px; font-size: 15px; font-weight: 600; color: #111827;">Get started in 3 easy steps:</p>
                            <table role="presentation" cellpadding="0" cellspacing="0">
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">1</span>
                                        Browse our verified trainers
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">2</span>
                                        Add your player's profile
                                    </td>
                                </tr>
                                <tr>
                                    <td style="padding: 6px 0; font-size: 14px; color: #374151;">
                                        <span style="display: inline-block; width: 24px; height: 24px; background: #FCB900; color: #000; border-radius: 50%; text-align: center; line-height: 24px; font-weight: 600; font-size: 12px; margin-right: 12px;">3</span>
                                        Book your first session!
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
                
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="center">
                            <a href="<?php echo esc_url($data['trainers_url']); ?>" style="<?php echo $btn; ?>">Find a Trainer</a>
                        </td>
                    </tr>
                </table>
                <?php
                break;
                
            default:
                ?>
                <p style="margin: 0; font-size: 15px; color: #374151;">Thank you for using PTP Training.</p>
                <?php
        }
        
        return ob_get_clean();
    }
    
    /**
     * Schedule session reminders (run via WP Cron)
     */
    public static function schedule_reminders() {
        global $wpdb;
        
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        
        $bookings = $wpdb->get_results($wpdb->prepare("
            SELECT id FROM {$wpdb->prefix}ptp_bookings 
            WHERE session_date = %s 
            AND status IN ('confirmed', 'pending')
            AND reminder_sent = 0
        ", $tomorrow));
        
        foreach ($bookings as $booking) {
            self::send_session_reminder($booking->id);
            
            // Also send SMS if enabled
            if (class_exists('PTP_SMS')) {
                PTP_SMS::send_session_reminder($booking->id);
            }
            
            $wpdb->update(
                $wpdb->prefix . 'ptp_bookings',
                array('reminder_sent' => 1),
                array('id' => $booking->id)
            );
        }
    }
}
