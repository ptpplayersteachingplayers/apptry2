<?php
/**
 * PTP Calendar Sync
 * Google Calendar and Apple Calendar (ICS) integration for trainers
 */

defined('ABSPATH') || exit;

class PTP_Calendar_Sync {
    
    private static $google_client_id;
    private static $google_client_secret;
    private static $google_redirect_uri;
    
    public static function init() {
        self::$google_client_id = get_option('ptp_google_client_id', '');
        self::$google_client_secret = get_option('ptp_google_client_secret', '');
        self::$google_redirect_uri = home_url('/ptp-calendar-callback/');
        
        // OAuth callback
        add_action('init', array(__CLASS__, 'handle_oauth_callback'));
        
        // AJAX endpoints
        add_action('wp_ajax_ptp_connect_google_calendar', array(__CLASS__, 'ajax_connect_google'));
        add_action('wp_ajax_ptp_disconnect_google_calendar', array(__CLASS__, 'ajax_disconnect_google'));
        add_action('wp_ajax_ptp_sync_calendar', array(__CLASS__, 'ajax_sync_calendar'));
        add_action('wp_ajax_ptp_export_ics', array(__CLASS__, 'ajax_export_ics'));
        
        // Sync on booking changes
        add_action('ptp_booking_created', array(__CLASS__, 'sync_booking_to_calendar'), 10, 1);
        add_action('ptp_booking_updated', array(__CLASS__, 'sync_booking_to_calendar'), 10, 1);
        add_action('ptp_booking_cancelled', array(__CLASS__, 'remove_from_calendar'), 10, 1);
        
        // REST endpoint for ICS feed
        add_action('rest_api_init', array(__CLASS__, 'register_ics_endpoint'));
    }
    
    /**
     * Create database table for calendar connections
     */
    public static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}ptp_calendar_connections (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            provider enum('google','apple','outlook') NOT NULL,
            access_token text,
            refresh_token text,
            token_expires datetime DEFAULT NULL,
            calendar_id varchar(255) DEFAULT 'primary',
            sync_enabled tinyint(1) DEFAULT 1,
            last_sync datetime DEFAULT NULL,
            ics_token varchar(64) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_provider (user_id, provider),
            KEY ics_token (ics_token)
        ) $charset_collate;";
        dbDelta($sql);
        
        // Add google_event_id to bookings
        $wpdb->query("ALTER TABLE {$wpdb->prefix}ptp_bookings 
                      ADD COLUMN google_event_id varchar(255) DEFAULT NULL,
                      ADD COLUMN calendar_synced tinyint(1) DEFAULT 0;");
    }
    
    /**
     * Check if Google Calendar is configured
     */
    public static function is_google_configured() {
        return !empty(self::$google_client_id) && !empty(self::$google_client_secret);
    }
    
    /**
     * Get Google OAuth URL
     */
    public static function get_google_auth_url($user_id) {
        if (!self::is_google_configured()) {
            return false;
        }
        
        $state = wp_create_nonce('ptp_google_oauth_' . $user_id);
        set_transient('ptp_oauth_state_' . $state, $user_id, 600);
        
        $params = array(
            'client_id' => self::$google_client_id,
            'redirect_uri' => self::$google_redirect_uri,
            'response_type' => 'code',
            'scope' => 'https://www.googleapis.com/auth/calendar.events',
            'access_type' => 'offline',
            'prompt' => 'consent',
            'state' => $state,
        );
        
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query($params);
    }
    
    /**
     * Handle OAuth callback
     */
    public static function handle_oauth_callback() {
        if (!isset($_GET['code']) || strpos($_SERVER['REQUEST_URI'], 'ptp-calendar-callback') === false) {
            return;
        }
        
        $code = sanitize_text_field($_GET['code']);
        $state = sanitize_text_field($_GET['state'] ?? '');
        
        $user_id = get_transient('ptp_oauth_state_' . $state);
        if (!$user_id) {
            wp_die('Invalid or expired OAuth state');
        }
        
        delete_transient('ptp_oauth_state_' . $state);
        
        // Exchange code for tokens
        $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'code' => $code,
                'client_id' => self::$google_client_id,
                'client_secret' => self::$google_client_secret,
                'redirect_uri' => self::$google_redirect_uri,
                'grant_type' => 'authorization_code',
            ),
        ));
        
        if (is_wp_error($response)) {
            wp_die('Failed to connect to Google');
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            wp_die('Google error: ' . $body['error_description']);
        }
        
        // Save tokens
        global $wpdb;
        $expires = new DateTime();
        $expires->modify('+' . intval($body['expires_in']) . ' seconds');
        
        $wpdb->replace($wpdb->prefix . 'ptp_calendar_connections', array(
            'user_id' => $user_id,
            'provider' => 'google',
            'access_token' => $body['access_token'],
            'refresh_token' => $body['refresh_token'] ?? '',
            'token_expires' => $expires->format('Y-m-d H:i:s'),
            'ics_token' => wp_generate_password(32, false),
        ));
        
        // Redirect back to account page
        wp_redirect(home_url('/account/?tab=calendar&connected=google'));
        exit;
    }
    
    /**
     * Refresh Google access token
     */
    private static function refresh_google_token($connection) {
        if (empty($connection->refresh_token)) {
            return false;
        }
        
        $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id' => self::$google_client_id,
                'client_secret' => self::$google_client_secret,
                'refresh_token' => $connection->refresh_token,
                'grant_type' => 'refresh_token',
            ),
        ));
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['error'])) {
            return false;
        }
        
        global $wpdb;
        $expires = new DateTime();
        $expires->modify('+' . intval($body['expires_in']) . ' seconds');
        
        $wpdb->update(
            $wpdb->prefix . 'ptp_calendar_connections',
            array(
                'access_token' => $body['access_token'],
                'token_expires' => $expires->format('Y-m-d H:i:s'),
            ),
            array('id' => $connection->id)
        );
        
        $connection->access_token = $body['access_token'];
        return $connection;
    }
    
    /**
     * Get valid access token
     */
    private static function get_valid_token($user_id, $provider = 'google') {
        global $wpdb;
        
        $connection = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_calendar_connections 
             WHERE user_id = %d AND provider = %s",
            $user_id, $provider
        ));
        
        if (!$connection) {
            return false;
        }
        
        // Check if token is expired
        if (strtotime($connection->token_expires) < time()) {
            $connection = self::refresh_google_token($connection);
            if (!$connection) {
                return false;
            }
        }
        
        return $connection->access_token;
    }
    
    /**
     * Sync a booking to Google Calendar
     */
    public static function sync_booking_to_calendar($booking_id) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT b.*, t.user_id as trainer_user_id, t.display_name as trainer_name,
                    pa.display_name as parent_name, pl.name as player_name
             FROM {$wpdb->prefix}ptp_bookings b
             JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
             JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
             JOIN {$wpdb->prefix}ptp_players pl ON b.player_id = pl.id
             WHERE b.id = %d",
            $booking_id
        ));
        
        if (!$booking) return;
        
        $access_token = self::get_valid_token($booking->trainer_user_id, 'google');
        if (!$access_token) return;
        
        // Build event data
        $start = new DateTime($booking->session_date . ' ' . $booking->start_time);
        $end = new DateTime($booking->session_date . ' ' . $booking->end_time);
        
        $event = array(
            'summary' => 'Training: ' . $booking->player_name,
            'description' => sprintf(
                "Player: %s\nParent: %s\nBooking #: %s\n\n%s",
                $booking->player_name,
                $booking->parent_name,
                $booking->booking_number,
                $booking->notes ?? ''
            ),
            'location' => $booking->location,
            'start' => array(
                'dateTime' => $start->format('c'),
                'timeZone' => wp_timezone_string(),
            ),
            'end' => array(
                'dateTime' => $end->format('c'),
                'timeZone' => wp_timezone_string(),
            ),
            'reminders' => array(
                'useDefault' => false,
                'overrides' => array(
                    array('method' => 'popup', 'minutes' => 60),
                    array('method' => 'popup', 'minutes' => 15),
                ),
            ),
        );
        
        // Create or update event
        if ($booking->google_event_id) {
            // Update existing event
            $url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events/' . $booking->google_event_id;
            $method = 'PUT';
        } else {
            // Create new event
            $url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';
            $method = 'POST';
        }
        
        $response = wp_remote_request($url, array(
            'method' => $method,
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($event),
        ));
        
        if (!is_wp_error($response)) {
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if (isset($body['id'])) {
                $wpdb->update(
                    $wpdb->prefix . 'ptp_bookings',
                    array(
                        'google_event_id' => $body['id'],
                        'calendar_synced' => 1,
                    ),
                    array('id' => $booking_id)
                );
            }
        }
    }
    
    /**
     * Remove booking from calendar
     */
    public static function remove_from_calendar($booking_id) {
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT b.*, t.user_id as trainer_user_id
             FROM {$wpdb->prefix}ptp_bookings b
             JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
             WHERE b.id = %d",
            $booking_id
        ));
        
        if (!$booking || !$booking->google_event_id) return;
        
        $access_token = self::get_valid_token($booking->trainer_user_id, 'google');
        if (!$access_token) return;
        
        wp_remote_request(
            'https://www.googleapis.com/calendar/v3/calendars/primary/events/' . $booking->google_event_id,
            array(
                'method' => 'DELETE',
                'headers' => array(
                    'Authorization' => 'Bearer ' . $access_token,
                ),
            )
        );
        
        $wpdb->update(
            $wpdb->prefix . 'ptp_bookings',
            array('google_event_id' => null, 'calendar_synced' => 0),
            array('id' => $booking_id)
        );
    }
    
    /**
     * Sync trainer availability to Google Calendar as recurring events
     * This creates "Available for Training" blocks on the calendar
     */
    public static function sync_availability_to_calendar($user_id) {
        $access_token = self::get_valid_token($user_id, 'google');
        if (!$access_token) return false;
        
        global $wpdb;
        $trainer = PTP_Trainer::get_by_user_id($user_id);
        if (!$trainer) return false;
        
        // Get availability
        $availability = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_availability WHERE trainer_id = %d AND is_active = 1",
            $trainer->id
        ));
        
        // For now, we'll just log that sync was requested
        // Full implementation would create/update recurring events
        error_log('PTP: Calendar sync requested for trainer ' . $trainer->id);
        
        // Update last sync time
        $wpdb->update(
            $wpdb->prefix . 'ptp_calendar_connections',
            array('last_sync' => current_time('mysql')),
            array('user_id' => $user_id, 'provider' => 'google')
        );
        
        return true;
    }
    
    /**
     * Generate ICS file for a trainer
     */
    public static function generate_ics($trainer_id, $weeks = 12) {
        global $wpdb;
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
            $trainer_id
        ));
        
        if (!$trainer) return '';
        
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT b.*, pa.display_name as parent_name, pl.name as player_name
             FROM {$wpdb->prefix}ptp_bookings b
             JOIN {$wpdb->prefix}ptp_parents pa ON b.parent_id = pa.id
             JOIN {$wpdb->prefix}ptp_players pl ON b.player_id = pl.id
             WHERE b.trainer_id = %d 
             AND b.session_date >= CURDATE()
             AND b.session_date <= DATE_ADD(CURDATE(), INTERVAL %d WEEK)
             AND b.status NOT IN ('cancelled')
             ORDER BY b.session_date ASC",
            $trainer_id, $weeks
        ));
        
        $ics = "BEGIN:VCALENDAR\r\n";
        $ics .= "VERSION:2.0\r\n";
        $ics .= "PRODID:-//PTP Training//Calendar//EN\r\n";
        $ics .= "CALSCALE:GREGORIAN\r\n";
        $ics .= "METHOD:PUBLISH\r\n";
        $ics .= "X-WR-CALNAME:PTP Training - " . $trainer->display_name . "\r\n";
        
        foreach ($bookings as $booking) {
            $start = new DateTime($booking->session_date . ' ' . $booking->start_time);
            $end = new DateTime($booking->session_date . ' ' . $booking->end_time);
            $created = new DateTime($booking->created_at);
            
            $ics .= "BEGIN:VEVENT\r\n";
            $ics .= "UID:" . $booking->booking_number . "@ptpsummercamps.com\r\n";
            $ics .= "DTSTART:" . $start->format('Ymd\THis') . "\r\n";
            $ics .= "DTEND:" . $end->format('Ymd\THis') . "\r\n";
            $ics .= "DTSTAMP:" . $created->format('Ymd\THis') . "Z\r\n";
            $ics .= "SUMMARY:Training: " . self::ics_escape($booking->player_name) . "\r\n";
            $ics .= "DESCRIPTION:Player: " . self::ics_escape($booking->player_name) . "\\nParent: " . self::ics_escape($booking->parent_name) . "\\nBooking: " . $booking->booking_number . "\r\n";
            if ($booking->location) {
                $ics .= "LOCATION:" . self::ics_escape($booking->location) . "\r\n";
            }
            $ics .= "STATUS:" . ($booking->status === 'confirmed' ? 'CONFIRMED' : 'TENTATIVE') . "\r\n";
            $ics .= "END:VEVENT\r\n";
        }
        
        $ics .= "END:VCALENDAR\r\n";
        
        return $ics;
    }
    
    /**
     * Escape string for ICS format
     */
    private static function ics_escape($string) {
        return str_replace(
            array('\\', ';', ',', "\n", "\r"),
            array('\\\\', '\\;', '\\,', '\\n', ''),
            $string
        );
    }
    
    /**
     * Register ICS feed endpoint
     */
    public static function register_ics_endpoint() {
        register_rest_route('ptp/v1', '/calendar/(?P<token>[a-zA-Z0-9]+)', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'serve_ics_feed'),
            'permission_callback' => '__return_true',
        ));
    }
    
    /**
     * Serve ICS feed
     */
    public static function serve_ics_feed($request) {
        global $wpdb;
        
        $token = $request->get_param('token');
        
        $connection = $wpdb->get_row($wpdb->prepare(
            "SELECT c.*, t.id as trainer_id 
             FROM {$wpdb->prefix}ptp_calendar_connections c
             JOIN {$wpdb->prefix}ptp_trainers t ON c.user_id = t.user_id
             WHERE c.ics_token = %s",
            $token
        ));
        
        if (!$connection) {
            return new WP_Error('invalid_token', 'Invalid calendar token', array('status' => 404));
        }
        
        $ics = self::generate_ics($connection->trainer_id);
        
        $response = new WP_REST_Response($ics);
        $response->set_headers(array(
            'Content-Type' => 'text/calendar; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="ptp-training.ics"',
        ));
        
        return $response;
    }
    
    /**
     * Get ICS subscription URL for trainer
     */
    public static function get_ics_url($user_id) {
        global $wpdb;
        
        $connection = $wpdb->get_row($wpdb->prepare(
            "SELECT ics_token FROM {$wpdb->prefix}ptp_calendar_connections WHERE user_id = %d",
            $user_id
        ));
        
        if (!$connection) {
            // Create a connection with ICS token
            $token = wp_generate_password(32, false);
            $wpdb->insert($wpdb->prefix . 'ptp_calendar_connections', array(
                'user_id' => $user_id,
                'provider' => 'apple',
                'ics_token' => $token,
            ));
        } else {
            $token = $connection->ics_token;
            if (!$token) {
                $token = wp_generate_password(32, false);
                $wpdb->update(
                    $wpdb->prefix . 'ptp_calendar_connections',
                    array('ics_token' => $token),
                    array('user_id' => $user_id)
                );
            }
        }
        
        return rest_url('ptp/v1/calendar/' . $token);
    }
    
    /**
     * Get trainer's calendar connection status
     */
    public static function get_connection_status($user_id) {
        global $wpdb;
        
        $connections = $wpdb->get_results($wpdb->prepare(
            "SELECT provider, last_sync, sync_enabled FROM {$wpdb->prefix}ptp_calendar_connections WHERE user_id = %d",
            $user_id
        ));
        
        $status = array(
            'google' => array('connected' => false, 'last_sync' => null),
            'ics_url' => self::get_ics_url($user_id),
        );
        
        foreach ($connections as $conn) {
            if ($conn->provider === 'google') {
                $status['google'] = array(
                    'connected' => true,
                    'last_sync' => $conn->last_sync,
                    'sync_enabled' => $conn->sync_enabled,
                );
            }
        }
        
        return $status;
    }
    
    /**
     * AJAX: Connect Google Calendar
     */
    public static function ajax_connect_google() {
        check_ajax_referer('ptp_nonce', 'nonce');
        
        $auth_url = self::get_google_auth_url(get_current_user_id());
        
        if ($auth_url) {
            wp_send_json_success(array('auth_url' => $auth_url));
        } else {
            wp_send_json_error(array('message' => 'Google Calendar not configured'));
        }
    }
    
    /**
     * AJAX: Disconnect Google Calendar
     */
    public static function ajax_disconnect_google() {
        check_ajax_referer('ptp_nonce', 'nonce');
        
        global $wpdb;
        $wpdb->delete(
            $wpdb->prefix . 'ptp_calendar_connections',
            array('user_id' => get_current_user_id(), 'provider' => 'google')
        );
        
        wp_send_json_success(array('message' => 'Google Calendar disconnected'));
    }
    
    /**
     * AJAX: Sync all bookings to calendar
     */
    public static function ajax_sync_calendar() {
        check_ajax_referer('ptp_nonce', 'nonce');
        
        global $wpdb;
        $trainer = PTP_Trainer::get_by_user_id(get_current_user_id());
        
        if (!$trainer) {
            wp_send_json_error(array('message' => 'Not a trainer'));
        }
        
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_bookings 
             WHERE trainer_id = %d AND session_date >= CURDATE() AND status != 'cancelled'",
            $trainer->id
        ));
        
        $synced = 0;
        foreach ($bookings as $booking) {
            self::sync_booking_to_calendar($booking->id);
            $synced++;
        }
        
        // Update last sync time
        $wpdb->update(
            $wpdb->prefix . 'ptp_calendar_connections',
            array('last_sync' => current_time('mysql')),
            array('user_id' => get_current_user_id(), 'provider' => 'google')
        );
        
        wp_send_json_success(array('synced' => $synced));
    }
    
    /**
     * AJAX: Export ICS file
     */
    public static function ajax_export_ics() {
        check_ajax_referer('ptp_nonce', 'nonce');
        
        $trainer = PTP_Trainer::get_by_user_id(get_current_user_id());
        if (!$trainer) {
            wp_send_json_error(array('message' => 'Not a trainer'));
        }
        
        $ics = self::generate_ics($trainer->id);
        
        wp_send_json_success(array(
            'ics' => base64_encode($ics),
            'filename' => 'ptp-training-calendar.ics'
        ));
    }
}
