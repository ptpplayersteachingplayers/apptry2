<?php
/**
 * Availability Class
 * BULLETPROOF v24.6.0 - Comprehensive error handling and validation
 */

defined('ABSPATH') || exit;

class PTP_Availability {
    
    private static $table_checked = false;
    private static $exceptions_table_checked = false;
    
    /**
     * Ensure availability table exists
     */
    public static function ensure_table() {
        if (self::$table_checked) {
            return true;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ptp_availability';
        
        try {
            $table_exists = $wpdb->get_var(
                $wpdb->prepare("SHOW TABLES LIKE %s", $table_name)
            );
            
            if ($table_exists === $table_name) {
                self::$table_checked = true;
                return true;
            }
            
            $charset_collate = $wpdb->get_charset_collate();
            
            $sql = "CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                trainer_id bigint(20) UNSIGNED NOT NULL,
                day_of_week tinyint(1) NOT NULL DEFAULT 0,
                start_time time NOT NULL DEFAULT '09:00:00',
                end_time time NOT NULL DEFAULT '17:00:00',
                is_active tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY trainer_id (trainer_id),
                KEY trainer_day (trainer_id, day_of_week)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
            
            self::$table_checked = true;
            return true;
            
        } catch (Exception $e) {
            error_log('PTP Availability Table Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Ensure exceptions table exists
     */
    public static function ensure_exceptions_table() {
        if (self::$exceptions_table_checked) {
            return true;
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . 'ptp_availability_exceptions';
        
        try {
            $table_exists = $wpdb->get_var(
                $wpdb->prepare("SHOW TABLES LIKE %s", $table_name)
            );
            
            if ($table_exists === $table_name) {
                self::$exceptions_table_checked = true;
                return true;
            }
            
            $charset_collate = $wpdb->get_charset_collate();
            
            $sql = "CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                trainer_id bigint(20) UNSIGNED NOT NULL,
                exception_date date NOT NULL,
                exception_type varchar(20) DEFAULT 'blocked',
                is_available tinyint(1) DEFAULT 0,
                start_time time DEFAULT NULL,
                end_time time DEFAULT NULL,
                reason varchar(255) DEFAULT '',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY trainer_id (trainer_id),
                UNIQUE KEY trainer_date (trainer_id, exception_date)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
            
            self::$exceptions_table_checked = true;
            return true;
            
        } catch (Exception $e) {
            error_log('PTP Exceptions Table Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Get all weekly availability for a trainer (including inactive days)
     */
    public static function get_weekly($trainer_id, $active_only = false) {
        if (!$trainer_id || !is_numeric($trainer_id)) {
            return array();
        }
        
        global $wpdb;
        
        try {
            self::ensure_table();
            
            $where = $active_only ? "AND is_active = 1" : "";
            
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_availability WHERE trainer_id = %d $where ORDER BY day_of_week ASC, start_time ASC",
                intval($trainer_id)
            ));
            
            return is_array($results) ? $results : array();
            
        } catch (Exception $e) {
            error_log('PTP Get Weekly Error: ' . $e->getMessage());
            return array();
        }
    }
    
    /**
     * Get active weekly availability for a trainer
     */
    public static function get_active_weekly($trainer_id) {
        return self::get_weekly($trainer_id, true);
    }
    
    /**
     * Set weekly availability (bulk update)
     */
    public static function set_weekly($trainer_id, $availability) {
        if (!$trainer_id || !is_numeric($trainer_id)) {
            return false;
        }
        
        if (!is_array($availability)) {
            return false;
        }
        
        global $wpdb;
        
        try {
            self::ensure_table();
            
            // Clear existing
            $wpdb->delete(
                $wpdb->prefix . 'ptp_availability', 
                array('trainer_id' => intval($trainer_id)),
                array('%d')
            );
            
            // Insert new
            foreach ($availability as $day => $slots) {
                $day = intval($day);
                if ($day < 0 || $day > 6) continue;
                
                if (!empty($slots['enabled']) && !empty($slots['start']) && !empty($slots['end'])) {
                    $wpdb->insert($wpdb->prefix . 'ptp_availability', array(
                        'trainer_id' => intval($trainer_id),
                        'day_of_week' => $day,
                        'start_time' => self::sanitize_time($slots['start']),
                        'end_time' => self::sanitize_time($slots['end']),
                        'is_active' => 1,
                    ), array('%d', '%d', '%s', '%s', '%d'));
                }
            }
            
            return true;
            
        } catch (Exception $e) {
            error_log('PTP Set Weekly Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Sanitize time to HH:MM:SS format
     */
    private static function sanitize_time($time) {
        $time = sanitize_text_field($time);
        
        // Handle HH:MM format
        if (preg_match('/^(\d{1,2}):(\d{2})$/', $time, $matches)) {
            return sprintf('%02d:%02d:00', intval($matches[1]), intval($matches[2]));
        }
        
        // Handle HH:MM:SS format
        if (preg_match('/^(\d{1,2}):(\d{2}):(\d{2})$/', $time, $matches)) {
            return sprintf('%02d:%02d:%02d', intval($matches[1]), intval($matches[2]), intval($matches[3]));
        }
        
        // Default
        return '09:00:00';
    }
    
    /**
     * Get available time slots for a trainer on a specific date
     * BULLETPROOF: Full validation and graceful error handling
     */
    public static function get_available_slots($trainer_id, $date) {
        // Validate inputs
        if (!$trainer_id || !is_numeric($trainer_id) || $trainer_id < 1) {
            return array();
        }
        
        if (empty($date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return array();
        }
        
        // Validate date is real
        $parts = explode('-', $date);
        if (!checkdate((int)$parts[1], (int)$parts[2], (int)$parts[0])) {
            return array();
        }
        
        global $wpdb;
        
        try {
            self::ensure_table();
            
            $day_of_week = (int) date('w', strtotime($date));
            
            // Get weekly availability for this day
            $weekly = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_availability 
                 WHERE trainer_id = %d AND day_of_week = %d AND is_active = 1",
                intval($trainer_id), 
                $day_of_week
            ));
            
            if (!$weekly || !isset($weekly->start_time) || !isset($weekly->end_time)) {
                return array();
            }
            
            // Check for exceptions (if table exists)
            $exception = null;
            self::ensure_exceptions_table();
            
            $exception = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_availability_exceptions 
                 WHERE trainer_id = %d AND exception_date = %s",
                intval($trainer_id), 
                $date
            ));
            
            // Day is blocked
            if ($exception && isset($exception->is_available) && !$exception->is_available) {
                return array();
            }
            
            // Determine actual start/end times
            $start_time = ($exception && !empty($exception->start_time)) ? $exception->start_time : $weekly->start_time;
            $end_time = ($exception && !empty($exception->end_time)) ? $exception->end_time : $weekly->end_time;
            
            // Parse times safely
            $current = @strtotime($start_time);
            $end = @strtotime($end_time);
            
            if ($current === false || $end === false || $current >= $end) {
                return array();
            }
            
            // Generate hourly slots
            $slots = array();
            $now = time();
            $is_today = ($date === date('Y-m-d'));
            $max_slots = 24; // Safety limit
            $slot_count = 0;
            
            while ($current < $end && $slot_count < $max_slots) {
                $slot_count++;
                $time = date('H:i', $current);
                $time_full = $time . ':00';
                
                // Skip past times for today
                if ($is_today && $current <= $now) {
                    $current += 3600;
                    continue;
                }
                
                // Check if slot is already booked (with error handling)
                $is_booked = false;
                if (class_exists('PTP_Booking') && method_exists('PTP_Booking', 'is_slot_booked')) {
                    try {
                        $is_booked = PTP_Booking::is_slot_booked($trainer_id, $date, $time_full);
                    } catch (Exception $e) {
                        error_log('PTP Booking Check Error: ' . $e->getMessage());
                    }
                }
                
                // Only add unbooked slots
                if (!$is_booked) {
                    $slots[] = array(
                        'start' => $time,
                        'time' => $time_full,
                        'display' => date('g:i A', $current),
                        'booked' => false,
                    );
                }
                
                $current += 3600; // 1 hour
            }
            
            return $slots;
            
        } catch (Exception $e) {
            error_log('PTP Get Available Slots Error: ' . $e->getMessage());
            return array();
        }
    }
    
    /**
     * Get dates with available slots in a month
     */
    public static function get_available_dates($trainer_id, $month, $year) {
        if (!$trainer_id || !is_numeric($trainer_id)) {
            return array();
        }
        
        $month = intval($month);
        $year = intval($year);
        
        if ($month < 1 || $month > 12 || $year < 2020 || $year > 2100) {
            return array();
        }
        
        try {
            $dates = array();
            $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
            $today = date('Y-m-d');
            
            for ($day = 1; $day <= $days_in_month; $day++) {
                $date = sprintf('%04d-%02d-%02d', $year, $month, $day);
                
                if ($date < $today) {
                    continue;
                }
                
                $slots = self::get_available_slots($trainer_id, $date);
                
                if (!empty($slots)) {
                    $dates[] = $date;
                }
            }
            
            return $dates;
            
        } catch (Exception $e) {
            error_log('PTP Get Available Dates Error: ' . $e->getMessage());
            return array();
        }
    }
    
    /**
     * Add an availability exception (block or modify a specific date)
     */
    public static function add_exception($trainer_id, $date, $data = array()) {
        if (!$trainer_id || !is_numeric($trainer_id)) {
            return false;
        }
        
        if (empty($date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            return false;
        }
        
        global $wpdb;
        
        try {
            self::ensure_exceptions_table();
            
            // Remove existing exception for this date
            $wpdb->delete(
                $wpdb->prefix . 'ptp_availability_exceptions', 
                array(
                    'trainer_id' => intval($trainer_id),
                    'exception_date' => $date,
                ),
                array('%d', '%s')
            );
            
            return $wpdb->insert($wpdb->prefix . 'ptp_availability_exceptions', array(
                'trainer_id' => intval($trainer_id),
                'exception_date' => $date,
                'exception_type' => sanitize_text_field($data['exception_type'] ?? 'blocked'),
                'is_available' => intval($data['is_available'] ?? 0),
                'start_time' => !empty($data['start_time']) ? self::sanitize_time($data['start_time']) : null,
                'end_time' => !empty($data['end_time']) ? self::sanitize_time($data['end_time']) : null,
                'reason' => sanitize_text_field(substr($data['reason'] ?? '', 0, 255)),
            ), array('%d', '%s', '%s', '%d', '%s', '%s', '%s'));
            
        } catch (Exception $e) {
            error_log('PTP Add Exception Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Remove an availability exception
     */
    public static function remove_exception($trainer_id, $date) {
        if (!$trainer_id || !is_numeric($trainer_id)) {
            return false;
        }
        
        if (empty($date)) {
            return false;
        }
        
        global $wpdb;
        
        try {
            self::ensure_exceptions_table();
            
            return $wpdb->delete(
                $wpdb->prefix . 'ptp_availability_exceptions', 
                array(
                    'trainer_id' => intval($trainer_id),
                    'exception_date' => $date,
                ),
                array('%d', '%s')
            );
            
        } catch (Exception $e) {
            error_log('PTP Remove Exception Error: ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Check if trainer has any availability set
     */
    public static function has_availability($trainer_id) {
        if (!$trainer_id || !is_numeric($trainer_id)) {
            return false;
        }
        
        global $wpdb;
        
        try {
            self::ensure_table();
            
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_availability 
                 WHERE trainer_id = %d AND is_active = 1",
                intval($trainer_id)
            ));
            
            return intval($count) > 0;
            
        } catch (Exception $e) {
            return false;
        }
    }
}
