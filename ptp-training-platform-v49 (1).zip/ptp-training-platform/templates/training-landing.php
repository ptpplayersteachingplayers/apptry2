<?php
/**
 * Template: Private Training Landing Page v36.1
 * - Bigger hero with mentorship focus
 * - Trust bar removed, embedded in hero
 * - Swipeable gallery on mobile
 * - Enhanced mobile optimization
 */
defined('ABSPATH') || exit;

// Get featured trainers
global $wpdb;
$featured_trainers = $wpdb->get_results("
    SELECT t.*, COALESCE(AVG(r.rating), 5.0) as avg_rating, COUNT(r.id) as review_count
    FROM {$wpdb->prefix}ptp_trainers t
    LEFT JOIN {$wpdb->prefix}ptp_reviews r ON t.id = r.trainer_id
    WHERE t.status = 'active'
    GROUP BY t.id
    ORDER BY t.is_featured DESC, avg_rating DESC
    LIMIT 6
");

$level_labels = array('pro'=>'PRO','college_d1'=>'D1','college_d2'=>'D2','college_d3'=>'D3','academy'=>'ACADEMY','semi_pro'=>'SEMI-PRO');
$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';

// Training page URL
$training_url = home_url('/training/');
$find_trainers_url = home_url('/find-trainers/');
$apply_url = home_url('/apply/');
$shop_url = home_url('/shop/');

// Hero background
$hero_bg = 'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coaches-versus-camps-winning-pic-july-25.jpg-scaled.jpg';

// Gallery images
$gallery_images = array(
    'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1595.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1288.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1272.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A5677.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A8333.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A5256.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A6557.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-guests-picture-summer-camp-5.jpg-scaled.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/09/BG7A7184-scaled.jpg',
    'https://ptpsummercamps.com/wp-content/uploads/2025/09/BG7A5234-1.jpg',
);
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800;900&display=swap');

.ptp-training{font-family:'Inter',-apple-system,sans-serif;color:#0A0A0A;-webkit-font-smoothing:antialiased;background:#fff}
.ptp-training *{box-sizing:border-box;margin:0;padding:0}

/* Hero - Full viewport, impactful */
.ptr-hero{
    min-height:100vh;
    background:linear-gradient(135deg,#0A0A0A 0%,#1a1a1a 100%);
    padding:0 24px;
    display:flex;
    align-items:center;
    justify-content:center;
    text-align:center;
    position:relative;
    overflow:hidden;
}
.ptr-hero::before{
    content:'';
    position:absolute;
    top:0;left:0;right:0;bottom:0;
    background:url('<?php echo esc_url($hero_bg); ?>') center/cover;
    opacity:0.25;
}
.ptr-hero::after{
    content:'';
    position:absolute;
    bottom:0;left:0;right:0;
    height:200px;
    background:linear-gradient(to top,#0A0A0A,transparent);
}
.ptr-hero-content{
    position:relative;
    z-index:2;
    max-width:900px;
    padding:40px 0;
}
.ptr-hero h1{
    font-family:'Oswald',sans-serif;
    font-size:clamp(48px,12vw,90px);
    font-weight:700;
    color:#fff;
    text-transform:uppercase;
    letter-spacing:-0.02em;
    line-height:1;
    margin-bottom:24px;
}
.ptr-hero h1 span{color:#FCB900}
.ptr-hero-tagline{
    font-family:'Oswald',sans-serif;
    font-size:clamp(18px,3vw,26px);
    color:#FCB900;
    text-transform:uppercase;
    letter-spacing:0.1em;
    margin-bottom:20px;
    font-weight:600;
}
.ptr-hero p{
    font-size:clamp(16px,2vw,20px);
    color:rgba(255,255,255,0.9);
    max-width:650px;
    margin:0 auto 40px;
    line-height:1.6;
}
.ptr-hero-btns{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;margin-bottom:60px}
.ptr-btn{
    display:inline-flex;align-items:center;gap:8px;
    padding:18px 40px;
    font-family:'Oswald',sans-serif;
    font-size:16px;font-weight:700;
    text-transform:uppercase;letter-spacing:0.02em;
    text-decoration:none;
    border:2px solid transparent;
    transition:all 0.2s;
    cursor:pointer;
}
.ptr-btn-primary{background:#FCB900;color:#0A0A0A;border-color:#FCB900}
.ptr-btn-primary:hover{background:#e5a800;border-color:#e5a800;transform:translateY(-2px)}
.ptr-btn-outline{background:transparent;color:#fff;border-color:#fff}
.ptr-btn-outline:hover{background:#fff;color:#0A0A0A}

/* Hero trust indicators */
.ptr-hero-trust{
    display:flex;
    justify-content:center;
    gap:40px;
    flex-wrap:wrap;
}
.ptr-hero-trust-item{
    display:flex;
    align-items:center;
    gap:10px;
    color:rgba(255,255,255,0.8);
    font-size:14px;
}
.ptr-hero-trust-item svg{color:#FCB900}
.ptr-hero-trust-item strong{color:#fff;font-size:16px}

/* Section */
.ptr-section{padding:100px 24px}
.ptr-section-dark{background:#0A0A0A;color:#fff}
.ptr-section-gray{background:#F9FAFB}
.ptr-container{max-width:1200px;margin:0 auto}
.ptr-section-header{text-align:center;margin-bottom:60px}
.ptr-section-title{
    font-family:'Oswald',sans-serif;
    font-size:clamp(36px,6vw,52px);
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:-0.01em;
    margin-bottom:16px;
}
.ptr-section-subtitle{font-size:18px;color:#6B7280;max-width:600px;margin:0 auto;line-height:1.6}
.ptr-section-dark .ptr-section-subtitle{color:rgba(255,255,255,0.7)}

/* Mentorship Section */
.ptr-mentorship{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:60px;
    align-items:center;
}
.ptr-mentorship-content h2{
    font-family:'Oswald',sans-serif;
    font-size:clamp(32px,5vw,44px);
    font-weight:700;
    text-transform:uppercase;
    margin-bottom:24px;
    color:#fff;
}
.ptr-mentorship-content h2 span{color:#FCB900}
.ptr-mentorship-content p{
    font-size:17px;
    color:rgba(255,255,255,0.8);
    line-height:1.7;
    margin-bottom:20px;
}
.ptr-mentorship-list{
    display:flex;
    flex-direction:column;
    gap:16px;
    margin-top:32px;
}
.ptr-mentorship-item{
    display:flex;
    align-items:center;
    gap:14px;
    font-size:16px;
    color:#fff;
}
.ptr-mentorship-item svg{color:#FCB900;flex-shrink:0}
.ptr-mentorship-img{
    position:relative;
}
.ptr-mentorship-img img{
    width:100%;
    height:500px;
    object-fit:cover;
    border:4px solid #FCB900;
}
.ptr-mentorship-badge{
    position:absolute;
    bottom:-20px;
    right:-20px;
    background:#FCB900;
    color:#0A0A0A;
    padding:20px 24px;
    font-family:'Oswald',sans-serif;
    text-align:center;
}
.ptr-mentorship-badge-num{font-size:36px;font-weight:700;display:block}
.ptr-mentorship-badge-text{font-size:12px;text-transform:uppercase;letter-spacing:0.05em}

/* How it works */
.ptr-steps{display:grid;grid-template-columns:repeat(3,1fr);gap:32px}
.ptr-step{
    text-align:center;
    padding:40px 32px;
    background:#fff;
    border:2px solid #E5E5E5;
    transition:all 0.3s;
}
.ptr-step:hover{border-color:#FCB900;transform:translateY(-4px)}
.ptr-step-num{
    width:64px;height:64px;
    background:#FCB900;
    font-family:'Oswald',sans-serif;
    font-size:28px;font-weight:700;
    display:flex;align-items:center;justify-content:center;
    margin:0 auto 24px;
}
.ptr-step h3{font-family:'Oswald',sans-serif;font-size:22px;font-weight:700;text-transform:uppercase;margin-bottom:12px;color:#0A0A0A}
.ptr-step p{font-size:15px;color:#6B7280;line-height:1.6}

/* Trainers */
.ptr-trainers{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:20px}
.ptr-trainer{
    position:relative;
    aspect-ratio:3/4;
    overflow:hidden;
    text-decoration:none;
    color:#fff;
}
.ptr-trainer img{width:100%;height:100%;object-fit:cover;transition:transform 0.3s}
.ptr-trainer:hover img{transform:scale(1.05)}
.ptr-trainer::after{
    content:'';
    position:absolute;
    inset:0;
    background:linear-gradient(to top,rgba(0,0,0,0.85) 0%,transparent 60%);
}
.ptr-trainer-info{
    position:absolute;
    bottom:16px;left:16px;right:16px;
    z-index:2;
}
.ptr-trainer-name{font-family:'Oswald',sans-serif;font-size:18px;font-weight:700;text-transform:uppercase;margin-bottom:4px}
.ptr-trainer-meta{font-size:13px;opacity:0.9}
.ptr-trainer-badge{
    position:absolute;
    top:12px;left:12px;
    background:#FCB900;
    color:#0A0A0A;
    padding:4px 10px;
    font-family:'Oswald',sans-serif;
    font-size:11px;font-weight:700;
    text-transform:uppercase;
    z-index:2;
}

/* Gallery Section */
.ptr-gallery-section{
    background:#0A0A0A;
    padding:60px 0 0;
}
.ptr-gallery-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    max-width:1200px;
    margin:0 auto 24px;
    padding:0 24px;
}
.ptr-gallery-title{
    font-family:'Oswald',sans-serif;
    font-size:28px;
    font-weight:700;
    text-transform:uppercase;
    color:#fff;
    margin:0;
}
.ptr-gallery-swipe{
    display:none;
    font-size:14px;
    color:#FCB900;
    font-weight:600;
}
.ptr-gallery{
    display:grid;
    grid-template-columns:repeat(5,1fr);
    gap:4px;
}
.ptr-gallery-item{
    aspect-ratio:1;
    overflow:hidden;
}
.ptr-gallery-item img{
    width:100%;
    height:100%;
    object-fit:cover;
    transition:transform 0.3s;
}
.ptr-gallery-item:hover img{
    transform:scale(1.1);
}

/* CTA */
.ptr-cta{
    text-align:center;
    padding:100px 24px;
    background:linear-gradient(135deg,#FCB900 0%,#f0a500 100%);
}
.ptr-cta h2{
    font-family:'Oswald',sans-serif;
    font-size:clamp(36px,6vw,56px);
    font-weight:700;
    text-transform:uppercase;
    color:#0A0A0A;
    margin-bottom:20px;
}
.ptr-cta p{font-size:20px;color:#0A0A0A;opacity:0.8;margin-bottom:40px}
.ptr-cta .ptr-btn-primary{background:#0A0A0A;color:#FCB900;border-color:#0A0A0A}
.ptr-cta .ptr-btn-primary:hover{background:#222;border-color:#222}

/* Mobile */
@media(max-width:1024px){
    .ptr-mentorship{grid-template-columns:1fr;gap:40px}
    .ptr-mentorship-img{order:-1}
    .ptr-mentorship-img img{height:400px}
    .ptr-steps{grid-template-columns:1fr}
}
@media(max-width:768px){
    .ptr-hero{min-height:auto;padding:80px 20px}
    .ptr-hero-content{padding:20px 0}
    .ptr-section{padding:60px 20px}
    .ptr-hero-trust{gap:24px}
    .ptr-hero-trust-item{flex-direction:column;text-align:center;gap:4px}
    .ptr-mentorship-badge{position:static;margin-top:16px}
    .ptr-mentorship-img img{height:300px}
    
    /* Gallery section mobile */
    .ptr-gallery-section{padding:40px 0 0}
    .ptr-gallery-header{padding:0 20px;margin-bottom:16px}
    .ptr-gallery-title{font-size:22px}
    .ptr-gallery-swipe{display:block}
    
    /* Swipeable gallery on mobile */
    .ptr-gallery{
        display:flex;
        overflow-x:auto;
        scroll-snap-type:x mandatory;
        -webkit-overflow-scrolling:touch;
        gap:8px;
        padding:0 20px 20px;
    }
    .ptr-gallery::-webkit-scrollbar{display:none}
    .ptr-gallery{-ms-overflow-style:none;scrollbar-width:none}
    .ptr-gallery-item{
        flex:0 0 280px;
        scroll-snap-align:start;
        aspect-ratio:4/3;
        border-radius:8px;
    }
    .ptr-gallery-item img{border-radius:8px}
}
@media(max-width:480px){
    .ptr-btn{width:100%;justify-content:center;padding:16px 24px}
    .ptr-hero-btns{flex-direction:column}
    .ptr-gallery-item{flex:0 0 85vw}
}
</style>

<div class="ptp-training">
    <!-- Hero -->
    <section class="ptr-hero">
        <div class="ptr-hero-content">
            <div class="ptr-hero-tagline">Players Teaching Players</div>
            <h1><span>Learn From</span> The Pros</h1>
            <p>Train 1-on-1 with current MLS players and NCAA Division 1 athletes. Real mentorship. Real results.</p>
            <div class="ptr-hero-btns">
                <a href="<?php echo esc_url($find_trainers_url); ?>" class="ptr-btn ptr-btn-primary">
                    Find Your Trainer
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
                <a href="<?php echo esc_url($apply_url); ?>" class="ptr-btn ptr-btn-outline">Become a Trainer</a>
            </div>
            <div class="ptr-hero-trust">
                <div class="ptr-hero-trust-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    <span><strong>4.9</strong> Rating</span>
                </div>
                <div class="ptr-hero-trust-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                    <span><strong>D1 & Pro</strong> Coaches</span>
                </div>
                <div class="ptr-hero-trust-item">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    <span><strong>500+</strong> Sessions</span>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Mentorship Section -->
    <section class="ptr-section ptr-section-dark">
        <div class="ptr-container">
            <div class="ptr-mentorship">
                <div class="ptr-mentorship-content">
                    <h2>Real <span>Mentorship</span> From Current Players</h2>
                    <p>This isn't just training—it's mentorship. Every PTP coach is a current professional or NCAA Division 1 athlete who knows what it takes to compete at the highest level.</p>
                    <p>They've been where your player wants to go. They share the mindset, the habits, and the skills that got them there.</p>
                    <div class="ptr-mentorship-list">
                        <div class="ptr-mentorship-item">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span>Current MLS & NCAA D1 athletes only</span>
                        </div>
                        <div class="ptr-mentorship-item">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span>5:1 player-to-coach ratio</span>
                        </div>
                        <div class="ptr-mentorship-item">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span>Teaching what team coaches don't</span>
                        </div>
                        <div class="ptr-mentorship-item">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span>High-rep, game-realistic training</span>
                        </div>
                    </div>
                </div>
                <div class="ptr-mentorship-img">
                    <img src="https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coach-sam-signing-ball-soccer-camp.jpg-scaled.jpg" alt="PTP Mentor coaching">
                    <div class="ptr-mentorship-badge">
                        <span class="ptr-mentorship-badge-num">100%</span>
                        <span class="ptr-mentorship-badge-text">Verified Athletes</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- How It Works -->
    <section class="ptr-section">
        <div class="ptr-container">
            <div class="ptr-section-header">
                <h2 class="ptr-section-title">How It Works</h2>
                <p class="ptr-section-subtitle">Book your personalized session in minutes</p>
            </div>
            <div class="ptr-steps">
                <div class="ptr-step">
                    <div class="ptr-step-num">1</div>
                    <h3>Choose Your Mentor</h3>
                    <p>Browse verified D1 and pro athletes. View their playing background and specialties.</p>
                </div>
                <div class="ptr-step">
                    <div class="ptr-step-num">2</div>
                    <h3>Book a Session</h3>
                    <p>Pick a time and location that works for you. Instant confirmation.</p>
                </div>
                <div class="ptr-step">
                    <div class="ptr-step-num">3</div>
                    <h3>Train & Grow</h3>
                    <p>Get personalized coaching focused on what you want to develop.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Featured Trainers -->
    <?php if (!empty($featured_trainers)): ?>
    <section class="ptr-section ptr-section-gray">
        <div class="ptr-container">
            <div class="ptr-section-header">
                <h2 class="ptr-section-title">Meet Your Mentors</h2>
                <p class="ptr-section-subtitle">Current players ready to help you improve</p>
            </div>
            <div class="ptr-trainers">
                <?php foreach ($featured_trainers as $trainer): 
                    $photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 400);
                    $level = isset($level_labels[$trainer->playing_level]) ? $level_labels[$trainer->playing_level] : '';
                    $slug = $trainer->slug ?: sanitize_title($trainer->display_name);
                ?>
                <a href="<?php echo home_url('/trainer/' . $slug . '/'); ?>" class="ptr-trainer">
                    <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>" loading="lazy">
                    <?php if ($level): ?>
                    <span class="ptr-trainer-badge"><?php echo esc_html($level); ?></span>
                    <?php endif; ?>
                    <div class="ptr-trainer-info">
                        <div class="ptr-trainer-name"><?php echo esc_html($trainer->display_name); ?></div>
                        <div class="ptr-trainer-meta">$<?php echo intval($trainer->hourly_rate ?: 80); ?>/session</div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            <div style="text-align:center;margin-top:48px">
                <a href="<?php echo esc_url($find_trainers_url); ?>" class="ptr-btn ptr-btn-primary">
                    View All Trainers
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- CTA -->
    <section class="ptr-cta">
        <h2>Ready to Level Up?</h2>
        <p>Find your trainer and book your first session today.</p>
        <a href="<?php echo esc_url($find_trainers_url); ?>" class="ptr-btn ptr-btn-primary">
            Book Your Session
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
        </a>
    </section>
    
    <!-- Gallery -->
    <section class="ptr-gallery-section">
        <div class="ptr-gallery-header">
            <h2 class="ptr-gallery-title">The PTP Experience</h2>
            <span class="ptr-gallery-swipe">Swipe to explore →</span>
        </div>
        <div class="ptr-gallery">
            <?php foreach ($gallery_images as $img): ?>
            <div class="ptr-gallery-item">
                <img src="<?php echo esc_url($img); ?>" alt="PTP Soccer Training" loading="lazy">
            </div>
            <?php endforeach; ?>
        </div>
    </section>
</div>
