<?php
/**
 * Template: Trainer Pending Approval - PTP Style v41.0
 */
defined('ABSPATH') || exit;

$user = wp_get_current_user();
$first_name = $user->first_name ?: $user->display_name;
$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>Application Under Review - PTP Training</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    html, body { overflow-x: hidden !important; max-width: 100vw; font-family: 'Inter', -apple-system, sans-serif; -webkit-tap-highlight-color: transparent; }
    
    /* Hide theme elements */
    body #page, body #content, body .site-content, body .entry-content,
    body > header, body > footer, body .site-header, body .site-footer,
    body #masthead, body .main-navigation { display: none !important; }
    
    .ptp-pending-wrap { min-height: 100vh; background: linear-gradient(135deg, #0E0F11 0%, #1a1a1a 100%); display: flex; align-items: center; justify-content: center; padding: 16px; overflow-x: hidden; }
    .ptp-pending-card { background: #fff; max-width: 480px; width: 100%; overflow: hidden; box-shadow: 0 25px 80px rgba(0,0,0,0.4); }
    .ptp-pending-header { background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%); padding: 32px 20px; text-align: center; }
    .ptp-pending-logo { height: 36px; margin-bottom: 20px; }
    .ptp-pending-icon { width: 80px; height: 80px; background: #fff; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px; animation: pulse 2s ease-in-out infinite; box-shadow: 0 8px 24px rgba(0,0,0,0.15); }
    .ptp-pending-icon svg { width: 40px; height: 40px; color: #FCB900; }
    @keyframes pulse { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.03); } }
    .ptp-pending-title { font-family: 'Oswald', sans-serif; font-size: 22px; font-weight: 700; color: #0E0F11; margin: 0 0 6px; text-transform: uppercase; letter-spacing: 0.02em; }
    .ptp-pending-subtitle { font-size: 14px; color: rgba(0,0,0,0.7); margin: 0; }
    .ptp-pending-body { padding: 24px 20px; }
    .ptp-pending-message { font-size: 15px; color: #4B5563; line-height: 1.6; margin: 0 0 20px; text-align: center; }
    .ptp-pending-message strong { color: #111827; }
    .ptp-pending-steps { background: #F9FAFB; padding: 20px 16px; margin-bottom: 24px; border: 2px solid #E5E5E5; }
    .ptp-pending-steps-title { font-family: 'Oswald', sans-serif; font-size: 14px; font-weight: 600; color: #111827; margin: 0 0 14px; display: flex; align-items: center; gap: 8px; text-transform: uppercase; }
    .ptp-pending-step { display: flex; align-items: flex-start; gap: 10px; padding: 10px 0; border-bottom: 1px solid #E5E7EB; }
    .ptp-pending-step:last-child { border-bottom: none; padding-bottom: 0; }
    .ptp-pending-step:first-of-type { padding-top: 0; }
    .ptp-pending-step-num { width: 26px; height: 26px; background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%); display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 12px; color: #0E0F11; flex-shrink: 0; }
    .ptp-pending-step-text { font-size: 13px; color: #4B5563; line-height: 1.5; }
    .ptp-pending-actions { display: flex; gap: 10px; flex-wrap: wrap; }
    .ptp-pending-btn { flex: 1; min-width: 120px; padding: 14px 16px; font-family: 'Oswald', sans-serif; font-weight: 700; font-size: 14px; text-decoration: none; text-align: center; transition: all 0.15s; text-transform: uppercase; letter-spacing: 0.02em; border: 2px solid #0A0A0A; min-height: 48px; display: flex; align-items: center; justify-content: center; }
    .ptp-pending-btn-primary { background: #FCB900; color: #0E0F11; }
    .ptp-pending-btn-primary:hover, .ptp-pending-btn-primary:active { background: #e5a800; }
    .ptp-pending-btn-outline { background: transparent; border: 2px solid #E5E5E5; color: #374151; }
    .ptp-pending-btn-outline:hover, .ptp-pending-btn-outline:active { background: #F9FAFB; border-color: #0A0A0A; }
    .ptp-pending-faq { margin-top: 24px; padding-top: 24px; border-top: 2px solid #E5E5E5; }
    .ptp-pending-faq-title { font-family: 'Oswald', sans-serif; font-size: 16px; font-weight: 600; color: #111827; margin: 0 0 16px; text-transform: uppercase; }
    .ptp-pending-faq-item { margin-bottom: 16px; }
    .ptp-pending-faq-item:last-child { margin-bottom: 0; }
    .ptp-pending-faq-q { font-weight: 600; font-size: 13px; color: #111827; margin: 0 0 4px; }
    .ptp-pending-faq-a { font-size: 13px; color: #6B7280; margin: 0; line-height: 1.5; }
    
    @media (min-width: 480px) {
        .ptp-pending-wrap { padding: 24px; }
        .ptp-pending-card { max-width: 520px; }
        .ptp-pending-header { padding: 40px 32px; }
        .ptp-pending-logo { height: 40px; margin-bottom: 24px; }
        .ptp-pending-icon { width: 90px; height: 90px; }
        .ptp-pending-icon svg { width: 45px; height: 45px; }
        .ptp-pending-title { font-size: 26px; }
        .ptp-pending-body { padding: 32px; }
        .ptp-pending-steps { padding: 24px; }
        .ptp-pending-btn { padding: 16px 20px; font-size: 15px; }
    }
    </style>
</head>
<body>

<div class="ptp-pending-wrap">
    <div class="ptp-pending-card">
        <div class="ptp-pending-header">
            <?php if ($logo_url): ?>
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" class="ptp-pending-logo">
            <?php endif; ?>
            <div class="ptp-pending-icon">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <polyline points="12 6 12 12 16 14"/>
                </svg>
            </div>
            <h1 class="ptp-pending-title">Application Under Review</h1>
            <p class="ptp-pending-subtitle">We're reviewing your trainer application</p>
        </div>
        
        <div class="ptp-pending-body">
            <p class="ptp-pending-message">
                Hi <strong><?php echo esc_html($first_name); ?></strong>! Your application has been submitted successfully. 
                Our team will review your information and you'll receive an email within <strong>48 hours</strong>.
            </p>
            
            <div class="ptp-pending-steps">
                <div class="ptp-pending-steps-title">
                    <span>📋</span> What happens next?
                </div>
                <div class="ptp-pending-step">
                    <span class="ptp-pending-step-num">1</span>
                    <span class="ptp-pending-step-text">We verify your playing experience and credentials</span>
                </div>
                <div class="ptp-pending-step">
                    <span class="ptp-pending-step-num">2</span>
                    <span class="ptp-pending-step-text">You'll receive an approval email with login instructions</span>
                </div>
                <div class="ptp-pending-step">
                    <span class="ptp-pending-step-num">3</span>
                    <span class="ptp-pending-step-text">Complete your profile with photos and availability</span>
                </div>
                <div class="ptp-pending-step">
                    <span class="ptp-pending-step-num">4</span>
                    <span class="ptp-pending-step-text">Start accepting bookings and training players!</span>
                </div>
            </div>
            
            <div class="ptp-pending-actions">
                <a href="<?php echo esc_url(home_url('/logout/')); ?>" class="ptp-pending-btn ptp-pending-btn-outline">Log Out</a>
                <a href="mailto:luke@ptpsummercamps.com" class="ptp-pending-btn ptp-pending-btn-primary">Contact Support</a>
            </div>
            
            <div class="ptp-pending-faq">
                <h3 class="ptp-pending-faq-title">FAQs</h3>
                <div class="ptp-pending-faq-item">
                    <h4 class="ptp-pending-faq-q">How long does approval take?</h4>
                    <p class="ptp-pending-faq-a">Most applications are reviewed within 24-48 hours. You'll receive an email notification once approved.</p>
                </div>
                <div class="ptp-pending-faq-item">
                    <h4 class="ptp-pending-faq-q">Can I edit my application?</h4>
                    <p class="ptp-pending-faq-a">Once approved, you can update all your profile information from your trainer dashboard.</p>
                </div>
                <div class="ptp-pending-faq-item">
                    <h4 class="ptp-pending-faq-q">Didn't receive a confirmation email?</h4>
                    <p class="ptp-pending-faq-a">Check your spam folder. If you still can't find it, contact us at luke@ptpsummercamps.com.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php wp_footer(); ?>
</body>
</html>
