<?php
/**
 * Template: Checkout v42.0.0
 * Complete standalone checkout: player info, billing, account creation, Stripe payment
 * Sends confirmation emails to admin, parent, and trainer
 * Mobile-first with 44px touch targets
 */
defined('ABSPATH') || exit;

$logo_url = PTP_Images::logo();

// Get booking data from URL params
$trainer_id = isset($_GET['trainer_id']) ? intval($_GET['trainer_id']) : 0;
$date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
$time = isset($_GET['time']) ? sanitize_text_field($_GET['time']) : '';
$location = isset($_GET['location']) ? sanitize_text_field($_GET['location']) : '';

// Get trainer
$trainer = null;
if ($trainer_id) {
    $trainer = PTP_Trainer::get($trainer_id);
}

// Redirect if no trainer or missing data
if (!$trainer || !$date || !$time) {
    wp_redirect(home_url('/training/'));
    exit;
}

// Calculate amounts
$rate = floatval($trainer->hourly_rate ?: 80);
$platform_fee = round($rate * 0.20, 2);
$trainer_earnings = $rate - $platform_fee;

// Trainer data
$trainer_photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 120);
$trainer_slug = $trainer->slug ?: sanitize_title($trainer->display_name);

// Format date/time for display
$display_date = date('l, F j, Y', strtotime($date));
$display_time = date('g:i A', strtotime($time));
$end_time = date('g:i A', strtotime($time . ' +1 hour'));

// Check if user logged in
$is_logged_in = is_user_logged_in();
$current_user = $is_logged_in ? wp_get_current_user() : null;

// Get existing parent profile and players if logged in
$parent = null;
$players = array();
if ($is_logged_in) {
    $parent = PTP_Parent::get_by_user_id(get_current_user_id());
    if ($parent) {
        $players = PTP_Player::get_by_parent($parent->id);
    }
}

// Stripe
$stripe_key = class_exists('PTP_Stripe') ? PTP_Stripe::get_publishable_key() : '';
$stripe_enabled = class_exists('PTP_Stripe') ? PTP_Stripe::is_enabled() : false;

wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Training Session - PTP Soccer</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Inter', -apple-system, sans-serif; background: #F3F4F6; min-height: 100vh; -webkit-font-smoothing: antialiased; }
    .co-wrap { max-width: 900px; margin: 0 auto; padding: 20px; }
    .co-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 12px; }
    .co-back { display: flex; align-items: center; gap: 8px; color: #6B7280; text-decoration: none; font-size: 14px; font-weight: 500; }
    .co-back:hover { color: #111; }
    .co-secure { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #059669; font-weight: 600; }
    .co-grid { display: grid; grid-template-columns: 1fr 380px; gap: 24px; }
    @media (max-width: 800px) { .co-grid { grid-template-columns: 1fr; } .co-summary { order: -1; } }
    .co-card { background: #fff; border-radius: 16px; padding: 24px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
    .co-card-title { font-size: 17px; font-weight: 700; color: #111; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; }
    .co-card-title .num { width: 28px; height: 28px; background: #FCB900; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 700; color: #0E0F11; }
    .co-row { display: flex; gap: 16px; margin-bottom: 16px; }
    .co-row > * { flex: 1; }
    @media (max-width: 500px) { 
        .co-row { flex-direction: column; gap: 16px; } 
        .co-wrap { padding: 16px 12px; }
        .co-card { padding: 20px 16px; }
        .co-input { font-size: 16px !important; min-height: 48px; }
        .co-btn { min-height: 48px; }
        .co-check { padding: 14px 12px; }
    }
    @media (max-width: 380px) {
        .co-wrap { padding: 12px 10px; }
        .co-card { padding: 16px 12px; }
        .co-card-title { font-size: 15px; }
    }
    .co-field { margin-bottom: 16px; }
    .co-label { display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px; }
    .co-input { width: 100%; padding: 14px 16px; border: 2px solid #E5E7EB; border-radius: 10px; font-family: inherit; font-size: 15px; color: #111; transition: border-color 0.2s; }
    .co-input:focus { outline: none; border-color: #FCB900; }
    .co-input::placeholder { color: #9CA3AF; }
    select.co-input { background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E") no-repeat right 14px center; appearance: none; padding-right: 44px; }
    .co-check { display: flex; align-items: flex-start; gap: 12px; padding: 16px; background: #F9FAFB; border-radius: 10px; cursor: pointer; }
    .co-check input { width: 20px; height: 20px; margin-top: 2px; accent-color: #FCB900; }
    .co-check-text { font-size: 14px; color: #374151; line-height: 1.5; }
    .co-check-text strong { color: #111; }
    
    /* Trainer card */
    .co-trainer { display: flex; gap: 16px; align-items: center; padding: 20px; background: #F9FAFB; border-radius: 12px; margin-bottom: 20px; }
    .co-trainer img { width: 64px; height: 64px; border-radius: 12px; object-fit: cover; }
    .co-trainer-name { font-size: 17px; font-weight: 700; color: #111; }
    .co-trainer-sub { font-size: 14px; color: #6B7280; margin-top: 4px; }
    
    /* Session details */
    .co-detail { display: flex; align-items: center; gap: 14px; padding: 14px 16px; background: #F9FAFB; border-radius: 10px; margin-bottom: 10px; }
    .co-detail-icon { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
    .co-detail-text { font-size: 15px; font-weight: 600; color: #111; }
    .co-detail-sub { font-size: 13px; color: #6B7280; margin-top: 2px; }
    
    /* Summary */
    .co-sum-row { display: flex; justify-content: space-between; padding: 10px 0; font-size: 14px; }
    .co-sum-row.total { border-top: 2px solid #E5E7EB; margin-top: 12px; padding-top: 16px; }
    .co-sum-row.total span:first-child { font-size: 16px; font-weight: 700; }
    .co-sum-row.total span:last-child { font-size: 24px; font-weight: 800; }
    
    /* Button */
    .co-btn { width: 100%; padding: 18px; background: #FCB900; color: #0E0F11; border: none; border-radius: 12px; font-family: inherit; font-size: 17px; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 10px; transition: background 0.2s; }
    .co-btn:hover { background: #E5A800; }
    .co-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    
    /* Card element */
    #card-element { padding: 16px; border: 2px solid #E5E7EB; border-radius: 10px; background: #fff; }
    #card-errors { color: #DC2626; font-size: 13px; margin-top: 8px; min-height: 20px; }
    
    /* Player selector */
    .co-player-list { display: flex; flex-direction: column; gap: 10px; margin-bottom: 16px; }
    .co-player-opt { display: flex; align-items: center; gap: 12px; padding: 14px 16px; background: #F9FAFB; border: 2px solid #E5E7EB; border-radius: 10px; cursor: pointer; transition: all 0.2s; }
    .co-player-opt:hover { border-color: #FCB900; }
    .co-player-opt.selected { border-color: #FCB900; background: #FFFBEB; }
    .co-player-opt input { width: 18px; height: 18px; accent-color: #FCB900; }
    .co-player-info { flex: 1; }
    .co-player-name { font-weight: 600; color: #111; }
    .co-player-meta { font-size: 13px; color: #6B7280; }
    
    /* New player form */
    .co-new-player { display: none; padding: 20px; background: #F9FAFB; border-radius: 12px; margin-top: 16px; }
    .co-new-player.show { display: block; }
    
    /* Trust badges */
    .co-trust { display: flex; align-items: center; justify-content: center; gap: 20px; flex-wrap: wrap; padding: 16px; color: #6B7280; font-size: 12px; }
    .co-trust span { display: flex; align-items: center; gap: 6px; }
    
    /* Loading */
    .co-loading { display: none; position: fixed; inset: 0; background: rgba(255,255,255,0.95); z-index: 9999; align-items: center; justify-content: center; flex-direction: column; gap: 16px; }
    .co-loading.show { display: flex; }
    .co-spinner { width: 48px; height: 48px; border: 4px solid #E5E7EB; border-top-color: #FCB900; border-radius: 50%; animation: spin 1s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
    
    /* Policy */
    .co-policy { text-align: center; padding: 20px; background: #F9FAFB; border-radius: 12px; margin-top: 16px; }
    .co-policy p { font-size: 13px; color: #6B7280; line-height: 1.6; }
    </style>
</head>
<body>

<div class="co-wrap">
    <!-- Header -->
    <div class="co-header">
        <a href="<?php echo esc_url(home_url('/trainer/' . $trainer_slug . '/')); ?>" class="co-back">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            Back to Profile
        </a>
        <div class="co-secure">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Secure Checkout
        </div>
    </div>

    <form id="checkout-form">
        <input type="hidden" name="trainer_id" value="<?php echo (int)$trainer->id; ?>">
        <input type="hidden" name="date" value="<?php echo esc_attr($date); ?>">
        <input type="hidden" name="time" value="<?php echo esc_attr($time); ?>">
        <input type="hidden" name="location" value="<?php echo esc_attr($location); ?>">
        <input type="hidden" name="amount" value="<?php echo esc_attr($rate); ?>">
        
        <div class="co-grid">
            <!-- Left Column - Forms -->
            <div>
                <!-- Player Information -->
                <div class="co-card">
                    <div class="co-card-title"><span class="num">1</span> Player Information</div>
                    
                    <?php if (!empty($players)): ?>
                    <div class="co-player-list">
                        <?php foreach ($players as $i => $player): ?>
                        <label class="co-player-opt <?php echo $i === 0 ? 'selected' : ''; ?>">
                            <input type="radio" name="player_id" value="<?php echo $player->id; ?>" <?php checked($i, 0); ?> onchange="selectPlayer(this)">
                            <div class="co-player-info">
                                <div class="co-player-name"><?php echo esc_html($player->name); ?></div>
                                <div class="co-player-meta"><?php echo esc_html($player->age); ?> years old • <?php echo esc_html(ucfirst($player->skill_level ?: 'Beginner')); ?></div>
                            </div>
                        </label>
                        <?php endforeach; ?>
                        <label class="co-player-opt" id="new-player-opt">
                            <input type="radio" name="player_id" value="new" onchange="selectPlayer(this)">
                            <div class="co-player-info">
                                <div class="co-player-name">+ Add New Player</div>
                                <div class="co-player-meta">Register a different child</div>
                            </div>
                        </label>
                    </div>
                    <?php endif; ?>
                    
                    <div id="new-player-form" class="co-new-player <?php echo empty($players) ? 'show' : ''; ?>">
                        <div class="co-row">
                            <div class="co-field">
                                <label class="co-label">Player's First Name *</label>
                                <input type="text" name="player_first_name" class="co-input" placeholder="First name" <?php echo empty($players) ? 'required' : ''; ?>>
                            </div>
                            <div class="co-field">
                                <label class="co-label">Player's Last Name *</label>
                                <input type="text" name="player_last_name" class="co-input" placeholder="Last name" <?php echo empty($players) ? 'required' : ''; ?>>
                            </div>
                        </div>
                        <div class="co-row">
                            <div class="co-field">
                                <label class="co-label">Player's Age *</label>
                                <select name="player_age" class="co-input" <?php echo empty($players) ? 'required' : ''; ?>>
                                    <option value="">Select age</option>
                                    <?php for ($a = 5; $a <= 18; $a++): ?>
                                    <option value="<?php echo $a; ?>"><?php echo $a; ?> years old</option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="co-field">
                                <label class="co-label">Skill Level *</label>
                                <select name="player_skill" class="co-input" <?php echo empty($players) ? 'required' : ''; ?>>
                                    <option value="">Select level</option>
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate">Intermediate</option>
                                    <option value="advanced">Advanced</option>
                                    <option value="competitive">Competitive/Club</option>
                                </select>
                            </div>
                        </div>
                        <div class="co-field" style="margin-bottom:0">
                            <label class="co-label">Goals or Focus Areas (optional)</label>
                            <textarea name="player_notes" class="co-input" rows="2" placeholder="E.g., wants to improve dribbling, preparing for tryouts..."></textarea>
                        </div>
                    </div>
                </div>

                <!-- Parent / Billing Information -->
                <div class="co-card">
                    <div class="co-card-title"><span class="num">2</span> Your Information</div>
                    
                    <?php if (!$is_logged_in): ?>
                    <div class="co-row">
                        <div class="co-field">
                            <label class="co-label">First Name *</label>
                            <input type="text" name="first_name" class="co-input" placeholder="Your first name" required>
                        </div>
                        <div class="co-field">
                            <label class="co-label">Last Name *</label>
                            <input type="text" name="last_name" class="co-input" placeholder="Your last name" required>
                        </div>
                    </div>
                    <div class="co-field">
                        <label class="co-label">Email Address *</label>
                        <input type="email" name="email" class="co-input" placeholder="your@email.com" required>
                    </div>
                    <?php else: ?>
                    <input type="hidden" name="first_name" value="<?php echo esc_attr($current_user->first_name ?: $current_user->display_name); ?>">
                    <input type="hidden" name="last_name" value="<?php echo esc_attr($current_user->last_name); ?>">
                    <input type="hidden" name="email" value="<?php echo esc_attr($current_user->user_email); ?>">
                    <div style="padding:16px;background:#D1FAE5;border-radius:10px;margin-bottom:16px;display:flex;align-items:center;gap:12px">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <div>
                            <div style="font-weight:600;color:#065F46">Logged in as <?php echo esc_html($current_user->display_name); ?></div>
                            <div style="font-size:13px;color:#047857"><?php echo esc_html($current_user->user_email); ?></div>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="co-field">
                        <label class="co-label">Phone Number *</label>
                        <input type="tel" name="phone" class="co-input" placeholder="(555) 123-4567" value="<?php echo $parent ? esc_attr($parent->phone) : ''; ?>" required>
                    </div>
                    
                    <?php if (!$is_logged_in): ?>
                    <label class="co-check">
                        <input type="checkbox" name="create_account" value="1" checked>
                        <div class="co-check-text">
                            <strong>Create an account</strong><br>
                            Save your info for faster checkout and track all your sessions in one place.
                        </div>
                    </label>
                    
                    <div id="password-field" class="co-field" style="margin-top:16px">
                        <label class="co-label">Password *</label>
                        <input type="password" name="password" class="co-input" placeholder="Create a password (min 8 characters)" minlength="8">
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Payment Information -->
                <div class="co-card">
                    <div class="co-card-title"><span class="num">3</span> Secure Payment</div>
                    
                    <div class="co-field">
                        <div id="card-element"></div>
                        <div id="card-errors"></div>
                    </div>
                    
                    <!-- Simple trust indicator -->
                    <div style="display:flex;align-items:center;gap:8px;margin-top:12px;padding:12px;background:#F0FDF4;border-radius:8px">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        <span style="font-size:13px;color:#065F46">Your payment is secured by Stripe</span>
                    </div>
                    
                    <div class="co-field" style="margin-top:16px;margin-bottom:0">
                        <label class="co-label">Notes for Trainer (optional)</label>
                        <textarea name="notes" class="co-input" rows="2" placeholder="Any specific requests or things the trainer should know?"></textarea>
                    </div>
                </div>
            </div>

            <!-- Right Column - Summary -->
            <div>
                <div class="co-card" style="position:sticky;top:20px">
                    <!-- Trainer -->
                    <div class="co-trainer">
                        <img src="<?php echo esc_url($trainer_photo); ?>" alt="">
                        <div>
                            <div class="co-trainer-name"><?php echo esc_html($trainer->display_name); ?></div>
                            <div class="co-trainer-sub"><?php echo esc_html($trainer->headline ?: 'Soccer Trainer'); ?></div>
                        </div>
                    </div>
                    
                    <!-- Session Details -->
                    <div class="co-detail">
                        <div class="co-detail-icon" style="background:#FEF3C7">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        </div>
                        <div>
                            <div class="co-detail-text"><?php echo esc_html($display_date); ?></div>
                            <div class="co-detail-sub">Date</div>
                        </div>
                    </div>
                    
                    <div class="co-detail">
                        <div class="co-detail-icon" style="background:#DBEAFE">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#3B82F6" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        </div>
                        <div>
                            <div class="co-detail-text"><?php echo esc_html($display_time); ?> - <?php echo esc_html($end_time); ?></div>
                            <div class="co-detail-sub">Time (1 hour)</div>
                        </div>
                    </div>
                    
                    <div class="co-detail">
                        <div class="co-detail-icon" style="background:#FCE7F3">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EC4899" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        </div>
                        <div>
                            <div class="co-detail-text"><?php echo esc_html($location ?: 'To be confirmed'); ?></div>
                            <div class="co-detail-sub">Location</div>
                        </div>
                    </div>
                    
                    <!-- Summary -->
                    <div style="margin-top:20px;padding-top:20px;border-top:2px solid #E5E7EB">
                        <div class="co-sum-row">
                            <span style="color:#6B7280">1-Hour Training Session</span>
                            <span style="font-weight:600">$<?php echo number_format($rate, 2); ?></span>
                        </div>
                        <div class="co-sum-row">
                            <span style="color:#6B7280">Platform Fee</span>
                            <span style="color:#6B7280">Included</span>
                        </div>
                        <div class="co-sum-row total">
                            <span>Total</span>
                            <span>$<?php echo number_format($rate, 2); ?></span>
                        </div>
                    </div>
                    
                    <!-- Submit -->
                    <button type="submit" id="submit-btn" class="co-btn" style="margin-top:20px">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        Pay $<?php echo number_format($rate, 2); ?>
                    </button>
                    
                    <!-- Free Cancellation Notice -->
                    <div style="margin-top:16px;padding:14px;background:#ECFDF5;border-radius:10px;border:1px solid #D1FAE5">
                        <div style="display:flex;align-items:center;gap:8px">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span style="font-size:14px;font-weight:600;color:#065F46">Free Cancellation</span>
                        </div>
                        <p style="margin:6px 0 0 26px;font-size:13px;color:#047857">Cancel up to 24 hours before for a full refund</p>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- Loading Overlay -->
<div id="loading" class="co-loading">
    <div class="co-spinner"></div>
    <p style="font-size:16px;font-weight:600;color:#111">Processing your booking...</p>
</div>

<script>
(function() {
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    const nonce = '<?php echo wp_create_nonce('ptp_checkout'); ?>';
    const isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
    
    // Player selection
    window.selectPlayer = function(input) {
        document.querySelectorAll('.co-player-opt').forEach(el => el.classList.remove('selected'));
        input.closest('.co-player-opt').classList.add('selected');
        
        const newForm = document.getElementById('new-player-form');
        const newInputs = newForm.querySelectorAll('input, select');
        
        if (input.value === 'new') {
            newForm.classList.add('show');
            newInputs.forEach(i => { if (i.name.startsWith('player_')) i.required = true; });
        } else {
            newForm.classList.remove('show');
            newInputs.forEach(i => { if (i.name.startsWith('player_')) i.required = false; });
        }
    };
    
    // Account creation toggle
    <?php if (!$is_logged_in): ?>
    document.querySelector('input[name="create_account"]')?.addEventListener('change', function() {
        const pwField = document.getElementById('password-field');
        const pwInput = pwField.querySelector('input');
        if (this.checked) {
            pwField.style.display = 'block';
            pwInput.required = true;
        } else {
            pwField.style.display = 'none';
            pwInput.required = false;
        }
    });
    <?php endif; ?>
    
    // Stripe setup
    <?php if ($stripe_enabled && $stripe_key): ?>
    const stripe = Stripe('<?php echo esc_js($stripe_key); ?>');
    const elements = stripe.elements();
    const cardElement = elements.create('card', {
        style: {
            base: {
                fontSize: '16px',
                color: '#111827',
                fontFamily: 'Inter, -apple-system, sans-serif',
                '::placeholder': { color: '#9CA3AF' }
            },
            invalid: { color: '#DC2626' }
        }
    });
    cardElement.mount('#card-element');
    
    cardElement.on('change', function(e) {
        document.getElementById('card-errors').textContent = e.error ? e.error.message : '';
    });
    
    // Form submission
    document.getElementById('checkout-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const btn = document.getElementById('submit-btn');
        const form = this;
        
        // Basic validation
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        btn.disabled = true;
        btn.innerHTML = 'Processing...';
        document.getElementById('loading').classList.add('show');
        
        try {
            // Collect form data
            const formData = new FormData(form);
            formData.append('action', 'ptp_process_checkout');
            formData.append('nonce', nonce);
            
            // Step 1: Create booking and payment intent
            const response = await fetch(ajaxUrl, { method: 'POST', body: formData });
            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.data?.message || 'Failed to create booking');
            }
            
            // Step 2: Confirm payment with Stripe
            const { error, paymentIntent } = await stripe.confirmCardPayment(data.data.client_secret, {
                payment_method: { card: cardElement }
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            // Step 3: Confirm payment on server
            const confirmData = new FormData();
            confirmData.append('action', 'ptp_confirm_checkout_payment');
            confirmData.append('nonce', nonce);
            confirmData.append('booking_id', data.data.booking_id);
            confirmData.append('payment_intent_id', paymentIntent.id);
            
            const confirmResponse = await fetch(ajaxUrl, { method: 'POST', body: confirmData });
            const confirmResult = await confirmResponse.json();
            
            if (!confirmResult.success) {
                throw new Error(confirmResult.data?.message || 'Payment confirmation failed');
            }
            
            // Success! Redirect to confirmation
            window.location.href = confirmResult.data.redirect;
            
        } catch (err) {
            document.getElementById('card-errors').textContent = err.message;
            btn.disabled = false;
            btn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> Pay $<?php echo number_format($rate, 2); ?>';
            document.getElementById('loading').classList.remove('show');
        }
    });
    <?php else: ?>
    document.getElementById('checkout-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Payment processing is not configured. Please contact support.');
    });
    <?php endif; ?>
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
