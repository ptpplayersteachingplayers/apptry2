<?php
/**
 * PTP Debug Tool
 */

defined('ABSPATH') || exit;

add_action('admin_menu', function() {
    add_submenu_page(
        'ptp-dashboard',
        'Debug',
        '🔧 Debug',
        'manage_options',
        'ptp-debug',
        'ptp_debug_page'
    );
}, 99);

function ptp_debug_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Access denied');
    }
    
    // Wrap everything in try/catch to prevent fatal errors
    try {
        global $wpdb;
    
    // Handle actions
    if (isset($_POST['ptp_debug_action']) && check_admin_referer('ptp_debug_nonce')) {
        $action = sanitize_text_field($_POST['ptp_debug_action']);
        
        if ($action === 'repair_tables') {
            if (class_exists('PTP_Database')) {
                PTP_Database::create_tables();
                if (method_exists('PTP_Database', 'repair_tables')) {
                    PTP_Database::repair_tables();
                }
                echo '<div class="notice notice-success"><p>✅ Tables repaired!</p></div>';
            } else {
                echo '<div class="notice notice-error"><p>❌ PTP_Database class not found</p></div>';
            }
        }
        
        if ($action === 'flush_rules') {
            flush_rewrite_rules();
            echo '<div class="notice notice-success"><p>✅ Permalinks flushed!</p></div>';
        }
        
        if ($action === 'link_trainer' && isset($_POST['trainer_id'])) {
            $trainer_id = intval($_POST['trainer_id']);
            $current_user_id = get_current_user_id();
            
            $wpdb->update(
                $wpdb->prefix . 'ptp_trainers',
                array('user_id' => $current_user_id),
                array('id' => $trainer_id),
                array('%d'),
                array('%d')
            );
            
            // Also add ptp_trainer role if not present
            $user = wp_get_current_user();
            if (!in_array('ptp_trainer', (array) $user->roles)) {
                $user->add_role('ptp_trainer');
            }
            
            echo '<div class="notice notice-success"><p>✅ Trainer ID ' . $trainer_id . ' linked to User ID ' . $current_user_id . '!</p></div>';
        }
        
        if ($action === 'fix_trainer_slug' && isset($_POST['trainer_id'])) {
            $trainer_id = intval($_POST['trainer_id']);
            $trainer = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d", $trainer_id));
            if ($trainer) {
                $slug = sanitize_title($trainer->display_name);
                $counter = 1;
                while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE slug = %s AND id != %d", $slug, $trainer_id))) {
                    $slug = sanitize_title($trainer->display_name) . '-' . $counter;
                    $counter++;
                }
                $wpdb->update($wpdb->prefix . 'ptp_trainers', array('slug' => $slug), array('id' => $trainer_id));
                echo '<div class="notice notice-success"><p>✅ Trainer slug set to: ' . esc_html($slug) . '</p></div>';
            }
        }
        
        if ($action === 'complete_onboarding' && isset($_POST['trainer_id'])) {
            $trainer_id = intval($_POST['trainer_id']);
            $trainer = $wpdb->get_row($wpdb->prepare("SELECT user_id FROM {$wpdb->prefix}ptp_trainers WHERE id = %d", $trainer_id));
            if ($trainer && $trainer->user_id) {
                update_user_meta($trainer->user_id, 'ptp_onboarding_completed', current_time('mysql'));
                echo '<div class="notice notice-success"><p>✅ Onboarding marked as completed for trainer ID ' . $trainer_id . '</p></div>';
            }
        }
        
        if ($action === 'create_pages') {
            $pages = array(
                'training' => array('title' => 'PTP Training', 'content' => '[ptp_home]'),
                'find-trainers' => array('title' => 'Find Trainers', 'content' => '[ptp_trainers_grid]'),
                'trainer' => array('title' => 'Trainer Profile', 'content' => '[ptp_trainer_profile]'),
                'book-session' => array('title' => 'Book Session', 'content' => '[ptp_booking_form]'),
                'booking-confirmation' => array('title' => 'Booking Confirmed', 'content' => '[ptp_booking_confirmation]'),
                'my-training' => array('title' => 'My Training', 'content' => '[ptp_my_training]'),
                'trainer-dashboard' => array('title' => 'Trainer Dashboard', 'content' => '[ptp_trainer_dashboard]'),
                'trainer-onboarding' => array('title' => 'Complete Your Profile', 'content' => '[ptp_trainer_onboarding]'),
                'messages' => array('title' => 'Messages', 'content' => '[ptp_messaging]'),
                'account' => array('title' => 'Account', 'content' => '[ptp_account]'),
                'login' => array('title' => 'Login', 'content' => '[ptp_login]'),
                'register' => array('title' => 'Register', 'content' => '[ptp_register]'),
                'apply' => array('title' => 'Become a Trainer', 'content' => '[ptp_apply]'),
                'parent-dashboard' => array('title' => 'Parent Dashboard', 'content' => '[ptp_parent_dashboard]'),
                'player-progress' => array('title' => 'Player Progress', 'content' => '[ptp_player_progress]'),
                'training-plans' => array('title' => 'Training Plans', 'content' => '[ptp_training_plans]'),
                'logout' => array('title' => 'Log Out', 'content' => '[ptp_logout]'),
            );
            
            $created = 0;
            foreach ($pages as $slug => $page) {
                if (!get_page_by_path($slug)) {
                    wp_insert_post(array(
                        'post_title' => $page['title'],
                        'post_name' => $slug,
                        'post_content' => $page['content'],
                        'post_status' => 'publish',
                        'post_type' => 'page',
                    ));
                    $created++;
                }
            }
            flush_rewrite_rules();
            echo '<div class="notice notice-success"><p>✅ Created ' . $created . ' missing pages. Permalinks flushed.</p></div>';
        }
        
        if ($action === 'activate_trainer' && isset($_POST['trainer_id'])) {
            $trainer_id = intval($_POST['trainer_id']);
            $wpdb->update(
                $wpdb->prefix . 'ptp_trainers',
                array('status' => 'active'),
                array('id' => $trainer_id)
            );
            echo '<div class="notice notice-success"><p>✅ Trainer ID ' . $trainer_id . ' activated!</p></div>';
        }
        
        if ($action === 'geocode_trainer' && isset($_POST['trainer_id'])) {
            $trainer_id = intval($_POST['trainer_id']);
            $trainer = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d", $trainer_id));
            
            if ($trainer && !empty($trainer->location) && class_exists('PTP_Geocoding')) {
                $geo = PTP_Geocoding::geocode($trainer->location);
                if (!empty($geo['success']) && !empty($geo['latitude'])) {
                    $wpdb->update(
                        $wpdb->prefix . 'ptp_trainers',
                        array(
                            'latitude' => floatval($geo['latitude']),
                            'longitude' => floatval($geo['longitude']),
                            'city' => isset($geo['city']) ? $geo['city'] : '',
                            'state' => isset($geo['state']) ? $geo['state'] : ''
                        ),
                        array('id' => $trainer_id)
                    );
                    echo '<div class="notice notice-success"><p>✅ Trainer geocoded: ' . esc_html($geo['latitude']) . ', ' . esc_html($geo['longitude']) . '</p></div>';
                } else {
                    echo '<div class="notice notice-error"><p>❌ Geocoding failed for: ' . esc_html($trainer->location) . '</p></div>';
                }
            } else {
                echo '<div class="notice notice-error"><p>❌ No location set for trainer or geocoding class not available</p></div>';
            }
        }
        
        if ($action === 'set_default_coords' && isset($_POST['trainer_id'])) {
            $trainer_id = intval($_POST['trainer_id']);
            // Default to Philadelphia area
            $wpdb->update(
                $wpdb->prefix . 'ptp_trainers',
                array(
                    'latitude' => 39.9526,
                    'longitude' => -75.1652,
                    'city' => 'Philadelphia',
                    'state' => 'PA'
                ),
                array('id' => $trainer_id)
            );
            echo '<div class="notice notice-success"><p>✅ Trainer set to Philadelphia Area (39.9526, -75.1652)</p></div>';
        }
    }
    
    ?>
    <div class="wrap">
        <h1>🔧 PTP Debug Report</h1>
        <p>Generated: <?php echo esc_html(current_time('Y-m-d H:i:s')); ?></p>
        
        <h2>1. Environment</h2>
        <table class="widefat" style="max-width:500px">
            <tr><td>PHP Version</td><td><?php echo PHP_VERSION; ?></td></tr>
            <tr><td>WordPress</td><td><?php echo get_bloginfo('version'); ?></td></tr>
            <tr><td>PTP Version</td><td><?php echo defined('PTP_VERSION') ? PTP_VERSION : 'NOT DEFINED'; ?></td></tr>
            <tr><td>Plugin Dir</td><td><?php echo defined('PTP_PLUGIN_DIR') ? (is_dir(PTP_PLUGIN_DIR) ? '✅ Exists' : '❌ Missing') : 'NOT DEFINED'; ?></td></tr>
        </table>
        
        <h2>2. Database Tables</h2>
        <table class="widefat" style="max-width:500px">
            <thead><tr><th>Table</th><th>Status</th><th>Rows</th></tr></thead>
            <tbody>
            <?php
            $tables = array('ptp_trainers', 'ptp_parents', 'ptp_players', 'ptp_bookings', 'ptp_availability', 'ptp_payouts', 'ptp_messages');
            foreach ($tables as $table) {
                $full_name = $wpdb->prefix . $table;
                $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $full_name)) === $full_name;
                if ($exists) {
                    $count = $wpdb->get_var("SELECT COUNT(*) FROM `{$full_name}`");
                    echo "<tr><td>{$table}</td><td>✅</td><td>{$count}</td></tr>";
                } else {
                    echo "<tr><td>{$table}</td><td>❌ Missing</td><td>-</td></tr>";
                }
            }
            ?>
            </tbody>
        </table>
        
        <h2>3. Classes</h2>
        <table class="widefat" style="max-width:500px">
            <tbody>
            <?php
            $classes = array('PTP_Training_Platform', 'PTP_Database', 'PTP_Trainer', 'PTP_Booking', 'PTP_Availability', 'PTP_Ajax', 'PTP_Stripe', 'PTP_Trainer_Payouts', 'PTP_Admin');
            foreach ($classes as $class) {
                $status = class_exists($class) ? '✅' : '❌';
                echo "<tr><td>{$class}</td><td>{$status}</td></tr>";
            }
            ?>
            </tbody>
        </table>
        
        <h2>4. Critical Methods</h2>
        <table class="widefat" style="max-width:500px">
            <tbody>
            <?php
            $methods = array(
                array('PTP_Trainer_Payouts', 'get_payout_queue'),
                array('PTP_Trainer_Payouts', 'get_payout_instructions'),
                array('PTP_Database', 'create_tables'),
                array('PTP_Availability', 'get_weekly'),
            );
            foreach ($methods as $m) {
                $exists = class_exists($m[0]) && method_exists($m[0], $m[1]);
                $status = $exists ? '✅' : '❌ MISSING';
                echo "<tr><td>{$m[0]}::{$m[1]}()</td><td>{$status}</td></tr>";
            }
            ?>
            </tbody>
        </table>
        
        <h2>5. Quick Actions</h2>
        <form method="post" style="display:flex;gap:10px;flex-wrap:wrap">
            <?php wp_nonce_field('ptp_debug_nonce'); ?>
            <button type="submit" name="ptp_debug_action" value="repair_tables" class="button button-primary">🔧 Repair Tables</button>
            <button type="submit" name="ptp_debug_action" value="flush_rules" class="button">🔄 Flush Permalinks</button>
            <button type="submit" name="ptp_debug_action" value="create_pages" class="button">📄 Create Missing Pages</button>
        </form>
        
        <h2>5a. Google Maps API Status</h2>
        <?php 
        $google_maps_key = get_option('ptp_google_maps_key', '');
        $key_status = !empty($google_maps_key) ? 'configured' : 'not set';
        $key_preview = !empty($google_maps_key) ? substr($google_maps_key, 0, 10) . '...' . substr($google_maps_key, -5) : 'N/A';
        ?>
        <table class="widefat" style="max-width:700px;margin-bottom:20px">
            <tr>
                <th style="width:150px">API Key</th>
                <td>
                    <?php if (!empty($google_maps_key)): ?>
                        <span style="color:#059669;font-weight:600">✅ Configured</span>
                        <code style="margin-left:10px"><?php echo esc_html($key_preview); ?></code>
                    <?php else: ?>
                        <span style="color:#dc2626;font-weight:600">❌ Not Set</span>
                        <span style="margin-left:10px;color:#6B7280">Go to PTP → Settings to add your API key</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Required APIs</th>
                <td>
                    Maps JavaScript API, Places API, Geocoding API<br>
                    <small style="color:#6B7280">Enable these in <a href="https://console.cloud.google.com/apis/library" target="_blank">Google Cloud Console</a></small>
                </td>
            </tr>
        </table>
        
        <h2>5b. PTP Pages Status</h2>
        <div style="background:#e7f3ff;border:1px solid #0073aa;padding:10px;margin-bottom:15px;border-radius:4px">
            <strong>💡 Admin Tip:</strong> As an admin, you can view any trainer's dashboard:
            <ul style="margin:5px 0 0 20px">
                <li><a href="<?php echo home_url('/trainer-dashboard/'); ?>">/trainer-dashboard/</a> - Auto-loads first active trainer</li>
                <li><code>/trainer-dashboard/?trainer_id=X</code> - View specific trainer</li>
                <li><code>/trainer-dashboard/?skip_onboarding=1</code> - Skip onboarding redirect</li>
            </ul>
        </div>
        <table class="widefat" style="max-width:700px">
            <thead><tr><th>Page Slug</th><th>Status</th><th>ID</th><th>URL</th></tr></thead>
            <tbody>
            <?php
            $required_pages = array(
                'trainer-dashboard', 'trainer-onboarding', 'parent-dashboard', 
                'find-trainers', 'trainer', 'book-session', 'booking-confirmation',
                'my-training', 'messages', 'account', 'login', 'register', 'apply', 'logout'
            );
            foreach ($required_pages as $slug) {
                $page = get_page_by_path($slug);
                if ($page) {
                    $status = $page->post_status === 'publish' ? '✅ Published' : '⚠️ ' . $page->post_status;
                    echo '<tr>';
                    echo '<td>' . esc_html($slug) . '</td>';
                    echo '<td>' . $status . '</td>';
                    echo '<td>' . esc_html($page->ID) . '</td>';
                    echo '<td><a href="' . get_permalink($page->ID) . '" target="_blank">View</a></td>';
                    echo '</tr>';
                } else {
                    echo '<tr style="background:#f8d7da">';
                    echo '<td>' . esc_html($slug) . '</td>';
                    echo '<td>❌ Missing</td>';
                    echo '<td>-</td>';
                    echo '<td>-</td>';
                    echo '</tr>';
                }
            }
            ?>
            </tbody>
        </table>
        
        <h2>6. Current User Trainer Status</h2>
        <?php
        $current_user_id = get_current_user_id();
        $current_user = wp_get_current_user();
        echo '<table class="widefat" style="max-width:600px">';
        echo '<tr><td>User ID</td><td>' . esc_html($current_user_id) . '</td></tr>';
        echo '<tr><td>Email</td><td>' . esc_html($current_user->user_email) . '</td></tr>';
        echo '<tr><td>Roles</td><td>' . esc_html(implode(', ', $current_user->roles)) . '</td></tr>';
        
        // Try to find trainer by user_id
        $trainer_by_user = null;
        if (class_exists('PTP_Trainer')) {
            $trainer_by_user = PTP_Trainer::get_by_user_id($current_user_id);
        }
        
        if ($trainer_by_user) {
            echo '<tr><td style="background:#d4edda">Trainer Found (by user_id)</td><td style="background:#d4edda">✅ ID: ' . esc_html($trainer_by_user->id) . '</td></tr>';
            echo '<tr><td>Display Name</td><td>' . esc_html($trainer_by_user->display_name) . '</td></tr>';
            echo '<tr><td>Slug</td><td>' . esc_html($trainer_by_user->slug ?: '<em>Not set</em>');
            if (empty($trainer_by_user->slug)) {
                echo ' <form method="post" style="display:inline">';
                wp_nonce_field('ptp_debug_nonce');
                echo '<input type="hidden" name="ptp_debug_action" value="fix_trainer_slug">';
                echo '<input type="hidden" name="trainer_id" value="' . esc_attr($trainer_by_user->id) . '">';
                echo '<button type="submit" class="button button-small">Fix Slug</button>';
                echo '</form>';
            }
            echo '</td></tr>';
            echo '<tr><td>Status</td><td>' . esc_html($trainer_by_user->status) . '</td></tr>';
            $onboarding_done = get_user_meta($current_user_id, 'ptp_onboarding_completed', true);
            echo '<tr><td>Onboarding Completed</td><td>' . ($onboarding_done ? '✅ Yes' : '❌ No');
            if (!$onboarding_done) {
                echo ' <form method="post" style="display:inline">';
                wp_nonce_field('ptp_debug_nonce');
                echo '<input type="hidden" name="ptp_debug_action" value="complete_onboarding">';
                echo '<input type="hidden" name="trainer_id" value="' . esc_attr($trainer_by_user->id) . '">';
                echo '<button type="submit" class="button button-small">Mark Complete</button>';
                echo '</form>';
            }
            echo '</td></tr>';
        } else {
            echo '<tr><td style="background:#f8d7da">Trainer Not Found (by user_id)</td><td style="background:#f8d7da">❌</td></tr>';
            
            // Try to find by email
            $trainer_by_email = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE email = %s",
                $current_user->user_email
            ));
            
            if ($trainer_by_email) {
                echo '<tr><td style="background:#fff3cd">Trainer Found (by email)</td><td style="background:#fff3cd">⚠️ ID: ' . esc_html($trainer_by_email->id) . ' - user_id: ' . esc_html($trainer_by_email->user_id ?: 'NULL') . '</td></tr>';
                echo '<tr><td>Display Name</td><td>' . esc_html($trainer_by_email->display_name) . '</td></tr>';
                echo '<tr><td>Status</td><td>' . esc_html($trainer_by_email->status) . '</td></tr>';
                
                // Offer to link
                if (empty($trainer_by_email->user_id) || $trainer_by_email->user_id == 0) {
                    echo '<tr><td colspan="2">';
                    echo '<form method="post" style="margin:0">';
                    wp_nonce_field('ptp_debug_nonce');
                    echo '<input type="hidden" name="ptp_debug_action" value="link_trainer">';
                    echo '<input type="hidden" name="trainer_id" value="' . esc_attr($trainer_by_email->id) . '">';
                    echo '<button type="submit" class="button button-primary">🔗 Link Trainer to Current User</button>';
                    echo '</form>';
                    echo '</td></tr>';
                }
            } else {
                echo '<tr><td>Trainer by Email</td><td>❌ Not found</td></tr>';
            }
        }
        echo '</table>';
        ?>
        
        <h2>7. All Trainers in Database</h2>
        <?php
        $all_trainers = $wpdb->get_results("SELECT id, user_id, display_name, email, slug, status, location, latitude, longitude FROM {$wpdb->prefix}ptp_trainers ORDER BY id DESC LIMIT 20");
        if ($all_trainers) {
            echo '<table class="widefat" style="max-width:1100px">';
            echo '<thead><tr><th>ID</th><th>User ID</th><th>Name</th><th>Location</th><th>Lat/Lng</th><th>Status</th><th>Actions</th></tr></thead><tbody>';
            foreach ($all_trainers as $t) {
                $has_coords = !empty($t->latitude) && !empty($t->longitude);
                echo '<tr>';
                echo '<td>' . esc_html($t->id) . '</td>';
                echo '<td>' . esc_html($t->user_id ?: '<em>NULL</em>') . '</td>';
                echo '<td>' . esc_html($t->display_name) . '</td>';
                echo '<td>' . esc_html($t->location ?: '<em>Not set</em>') . '</td>';
                echo '<td>' . ($has_coords ? esc_html(round($t->latitude, 4) . ', ' . round($t->longitude, 4)) : '<span style="color:#dc2626">❌ Missing</span>') . '</td>';
                echo '<td>' . esc_html($t->status) . '</td>';
                echo '<td style="white-space:nowrap">';
                
                // Action buttons
                if ($t->status !== 'active') {
                    echo '<form method="post" style="display:inline">';
                    wp_nonce_field('ptp_debug_nonce');
                    echo '<input type="hidden" name="ptp_debug_action" value="activate_trainer">';
                    echo '<input type="hidden" name="trainer_id" value="' . esc_attr($t->id) . '">';
                    echo '<button type="submit" class="button button-small button-primary">Activate</button>';
                    echo '</form> ';
                }
                
                if (empty($t->slug)) {
                    echo '<form method="post" style="display:inline">';
                    wp_nonce_field('ptp_debug_nonce');
                    echo '<input type="hidden" name="ptp_debug_action" value="fix_trainer_slug">';
                    echo '<input type="hidden" name="trainer_id" value="' . esc_attr($t->id) . '">';
                    echo '<button type="submit" class="button button-small">Fix Slug</button>';
                    echo '</form> ';
                }
                
                if (!$has_coords) {
                    if (!empty($t->location)) {
                        echo '<form method="post" style="display:inline">';
                        wp_nonce_field('ptp_debug_nonce');
                        echo '<input type="hidden" name="ptp_debug_action" value="geocode_trainer">';
                        echo '<input type="hidden" name="trainer_id" value="' . esc_attr($t->id) . '">';
                        echo '<button type="submit" class="button button-small" style="background:#3b82f6;color:#fff;border:none">📍 Geocode</button>';
                        echo '</form> ';
                    }
                    echo '<form method="post" style="display:inline">';
                    wp_nonce_field('ptp_debug_nonce');
                    echo '<input type="hidden" name="ptp_debug_action" value="set_default_coords">';
                    echo '<input type="hidden" name="trainer_id" value="' . esc_attr($t->id) . '">';
                    echo '<button type="submit" class="button button-small">Set Philly</button>';
                    echo '</form> ';
                }
                
                if (empty($t->user_id) || $t->user_id == 0) {
                    echo '<form method="post" style="display:inline">';
                    wp_nonce_field('ptp_debug_nonce');
                    echo '<input type="hidden" name="ptp_debug_action" value="link_trainer">';
                    echo '<input type="hidden" name="trainer_id" value="' . esc_attr($t->id) . '">';
                    echo '<button type="submit" class="button button-small">Link to Me</button>';
                    echo '</form>';
                }
                
                echo '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        } else {
            echo '<p>No trainers found in database.</p>';
        }
        ?>
        
        <h2>8. Recent Errors</h2>
        <?php
        $log = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($log) && is_readable($log)) {
            $lines = @file($log);
            if ($lines) {
                $ptp_errors = array_filter($lines, function($l) {
                    return stripos($l, 'ptp') !== false || stripos($l, 'fatal') !== false;
                });
                $ptp_errors = array_slice($ptp_errors, -15);
                if ($ptp_errors) {
                    echo '<pre style="background:#1e1e1e;color:#d4d4d4;padding:15px;overflow:auto;max-height:300px;font-size:11px;border-radius:4px">';
                    echo esc_html(implode('', $ptp_errors));
                    echo '</pre>';
                } else {
                    echo '<p style="color:green">✅ No recent PTP errors</p>';
                }
            }
        } else {
            echo '<p style="color:#666">debug.log not found. Add to wp-config.php:</p>';
            echo '<pre style="background:#f5f5f5;padding:10px">define(\'WP_DEBUG\', true);
define(\'WP_DEBUG_LOG\', true);</pre>';
        }
        ?>
    </div>
    <?php
    } catch (Exception $e) {
        echo '<div class="notice notice-error"><p><strong>Debug Error:</strong> ' . esc_html($e->getMessage()) . '</p></div>';
        error_log('PTP Debug Page Error: ' . $e->getMessage());
    } catch (Error $e) {
        echo '<div class="notice notice-error"><p><strong>Debug Fatal Error:</strong> ' . esc_html($e->getMessage()) . '</p></div>';
        error_log('PTP Debug Page Fatal: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    }
}
