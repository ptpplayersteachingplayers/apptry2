<?php
/**
 * Template: Trainer Dashboard v42.0.0
 * - Auto-save schedule that syncs with frontend booking
 * - Multiple training locations with Google Maps Places autocomplete
 * - Real-time status feedback
 * - Mobile-first responsive design
 * - Touch target optimization (44px minimum)
 */
defined('ABSPATH') || exit;

if (!isset($trainer) || !$trainer) {
    echo '<div style="padding:40px;text-align:center;font-family:Inter,sans-serif"><p>Trainer profile not found.</p><a href="' . home_url('/apply/') . '">Apply as Trainer</a></div>';
    return;
}

$logo_url = PTP_Images::logo();
$google_maps_key = get_option('ptp_google_maps_key', '');

// Safe defaults
$earnings = isset($earnings) && is_array($earnings) ? $earnings : array('this_month' => 0, 'total_earnings' => 0, 'pending_payout' => 0);
$upcoming = isset($upcoming) && is_array($upcoming) ? $upcoming : array();

// Get availability from database
$availability = array();
if (class_exists('PTP_Availability')) {
    $availability = PTP_Availability::get_weekly($trainer->id);
}
$avail_by_day = array();
foreach ($availability as $slot) {
    if (isset($slot->day_of_week)) {
        $avail_by_day[intval($slot->day_of_week)] = $slot;
    }
}

// Get training locations
$training_locations = array();
if (!empty($trainer->training_locations)) {
    $decoded = json_decode($trainer->training_locations, true);
    if (is_array($decoded)) {
        $training_locations = $decoded;
    }
}

$day_names = array('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
$active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'schedule';
$photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 200);
$trainer_slug = $trainer->slug ?: sanitize_title($trainer->display_name);
$profile_url = home_url('/trainer/' . $trainer_slug . '/');

// Conversations
$unread_count = 0;
if (class_exists('PTP_Messaging') && method_exists('PTP_Messaging', 'get_conversations_for_user')) {
    $conversations = PTP_Messaging::get_conversations_for_user(get_current_user_id());
    foreach ($conversations as $c) { $unread_count += $c->unread_count ?? 0; }
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trainer Dashboard - PTP Soccer</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <?php if ($google_maps_key): ?>
    <script>
    // Robust Google Maps loading - after wp_head to detect other scripts
    (function() {
        // Check if Google Maps is already fully loaded
        if (window.google && window.google.maps && window.google.maps.Map) {
            console.log('[PTP Dashboard] Google Maps already loaded');
            return;
        } 
        // Check if a Google Maps script is already loading
        else if (document.querySelector('script[src*="maps.googleapis.com"]')) {
            console.log('[PTP Dashboard] Google Maps script found, waiting...');
            return; // Let the existing script load
        }
        // No Google Maps at all - load it
        else {
            console.log('[PTP Dashboard] Loading Google Maps API');
            var script = document.createElement('script');
            script.src = 'https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr($google_maps_key); ?>&libraries=places&loading=async';
            script.async = true;
            script.defer = true;
            document.head.appendChild(script);
        }
    })();
    </script>
    <?php endif; ?>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Inter', -apple-system, sans-serif; background: #FFFFFF; min-height: 100vh; -webkit-font-smoothing: antialiased; -webkit-tap-highlight-color: transparent; }
    
    /* Hide all theme elements */
    body #page, body #content, body .site-content, body .entry-content,
    body > header:not(.td-header), body > footer, body .site-header, body .site-footer,
    body #masthead, body .main-navigation, nav.main-navigation,
    .header-inner, .navigation-top, .site-branding, .menu-toggle, .primary-menu,
    .wp-block-template-part, .wp-site-blocks > header, .has-global-padding > header,
    header.wp-block-template-part, .wp-block-group.alignfull header,
    #site-navigation, .ast-primary-header, .site-primary-header-wrap,
    .astra-hfb-header, header.site-header, .starter-starter { display: none !important; }
    
    /* Header */
    .td-header { background: #0A0A0A; padding: 12px 16px; color: #fff; position: sticky; top: 0; z-index: 100; }
    .td-header-inner { max-width: 1100px; margin: 0 auto; display: flex; align-items: center; gap: 12px; }
    .td-logo { height: 28px; max-width: 100px; width: auto; object-fit: contain; }
    .td-avatar { width: 40px; height: 40px; object-fit: cover; border: 2px solid #FCB900; flex-shrink: 0; }
    .td-name { font-family: 'Oswald', sans-serif; font-size: 16px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.02em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .td-role { font-size: 12px; color: #9CA3AF; display: none; }
    .td-header-info { flex: 1; min-width: 0; }
    
    /* Main */
    .td-main { max-width: 1100px; margin: 0 auto; padding: 16px; }
    
    /* Tabs - horizontal scroll on mobile */
    .td-tabs { display: flex; gap: 6px; margin-bottom: 20px; overflow-x: auto; -webkit-overflow-scrolling: touch; scrollbar-width: none; padding-bottom: 4px; }
    .td-tabs::-webkit-scrollbar { display: none; }
    .td-tab { padding: 10px 14px; background: #fff; border: 2px solid #E5E5E5; font-family: 'Oswald', sans-serif; font-size: 13px; font-weight: 700; color: #6B7280; cursor: pointer; white-space: nowrap; text-decoration: none; transition: all 0.15s; text-transform: uppercase; letter-spacing: 0.02em; min-height: 44px; display: flex; align-items: center; }
    .td-tab:hover, .td-tab:active { border-color: #FCB900; }
    .td-tab.active { background: #FCB900; border-color: #0A0A0A; color: #0A0A0A; }
    
    /* Grid */
    .td-grid { display: grid; grid-template-columns: 1fr; gap: 16px; }
    
    /* Cards */
    .td-card { background: #fff; border: 2px solid #E5E5E5; padding: 16px; margin-bottom: 16px; }
    .td-card-title { font-family: 'Oswald', sans-serif; font-size: 16px; font-weight: 700; margin-bottom: 6px; display: flex; align-items: center; gap: 8px; text-transform: uppercase; letter-spacing: 0.02em; flex-wrap: wrap; }
    .td-card-subtitle { color: #6B7280; font-size: 13px; margin-bottom: 16px; line-height: 1.5; }
    
    /* Buttons */
    .td-btn { padding: 12px 20px; background: #FCB900; color: #0A0A0A; border: 2px solid #0A0A0A; font-family: 'Oswald', sans-serif; font-size: 14px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; gap: 8px; transition: all 0.15s; text-transform: uppercase; letter-spacing: 0.02em; min-height: 44px; text-decoration: none; }
    .td-btn:hover, .td-btn:active { background: #e5a800; }
    .td-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .td-btn-sm { padding: 10px 14px; font-size: 13px; min-height: 40px; }
    .td-btn-outline { background: transparent; border: 2px solid #E5E5E5; color: #374151; }
    .td-btn-outline:hover, .td-btn-outline:active { border-color: #FCB900; background: #FFFBEB; }
    
    /* Schedule rows */
    .sched-row { display: grid; grid-template-columns: 44px 1fr; gap: 12px; padding: 12px; background: #F9FAFB; border: 2px solid #E5E5E5; margin-bottom: 8px; align-items: center; }
    .sched-row.inactive { opacity: 0.5; }
    .sched-toggle { position: relative; width: 44px; height: 26px; flex-shrink: 0; }
    .sched-toggle input { opacity: 0; width: 100%; height: 100%; position: absolute; cursor: pointer; z-index: 1; margin: 0; }
    .sched-toggle-track { position: absolute; inset: 0; background: #D1D5DB; transition: background 0.15s; pointer-events: none; }
    .sched-toggle input:checked + .sched-toggle-track { background: #059669; }
    .sched-toggle-track::after { content: ''; position: absolute; width: 20px; height: 20px; background: #fff; top: 3px; left: 3px; transition: transform 0.15s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
    .sched-toggle input:checked + .sched-toggle-track::after { transform: translateX(18px); }
    .sched-content { display: flex; flex-direction: column; gap: 8px; }
    .sched-day { font-weight: 700; font-size: 14px; font-family: 'Oswald', sans-serif; text-transform: uppercase; letter-spacing: 0.02em; }
    .sched-times { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
    .sched-time { padding: 10px 8px; border: 2px solid #E5E5E5; font-size: 14px; font-family: inherit; width: 100px; text-align: center; min-height: 44px; background: #fff; }
    .sched-time:focus { outline: none; border-color: #FCB900; }
    .sched-time:disabled { background: #F3F4F6; color: #9CA3AF; }
    .sched-status { font-size: 11px; font-weight: 600; }
    .sched-status.saved { color: #059669; }
    .sched-status.saving { color: #D97706; }
    .sched-status.error { color: #DC2626; }
    
    /* Location rows */
    .loc-row { background: #F9FAFB; border: 2px solid #E5E5E5; padding: 12px; margin-bottom: 10px; }
    .loc-row-header { display: flex; align-items: center; gap: 10px; }
    .loc-icon { width: 36px; height: 36px; background: #fff; display: flex; align-items: center; justify-content: center; flex-shrink: 0; border: 2px solid #E5E5E5; }
    .loc-input { flex: 1; min-width: 0; padding: 10px 12px; border: 2px solid #E5E5E5; font-size: 14px; font-family: inherit; min-height: 44px; }
    .loc-input:focus { outline: none; border-color: #FCB900; }
    .loc-remove { width: 44px; height: 44px; border: none; background: #FEE2E2; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #DC2626; flex-shrink: 0; }
    .loc-remove:hover, .loc-remove:active { background: #DC2626; color: #fff; }
    .loc-address { font-size: 12px; color: #6B7280; margin-top: 8px; padding-left: 46px; line-height: 1.4; }
    .loc-address a { color: #3B82F6; text-decoration: none; }
    
    /* Stats */
    .td-stat { background: #F9FAFB; border: 2px solid #E5E5E5; padding: 12px; text-align: center; }
    .td-stat-value { font-family: 'Oswald', sans-serif; font-size: 22px; font-weight: 700; }
    .td-stat-label { font-size: 11px; color: #6B7280; margin-top: 2px; text-transform: uppercase; letter-spacing: 0.02em; }
    
    /* Session rows */
    .td-session { display: flex; align-items: center; gap: 12px; padding: 12px; background: #F9FAFB; margin-bottom: 10px; border: 2px solid #E5E5E5; }
    .td-session-date { width: 44px; height: 52px; background: #0A0A0A; display: flex; flex-direction: column; align-items: center; justify-content: center; color: #fff; flex-shrink: 0; }
    .td-session-day { font-size: 18px; font-weight: 800; color: #FCB900; }
    .td-session-month { font-size: 9px; text-transform: uppercase; color: #9CA3AF; }
    
    /* Toast */
    .td-toast { position: fixed; bottom: 16px; left: 16px; right: 16px; padding: 14px 16px; background: #0A0A0A; color: #fff; font-size: 14px; font-weight: 500; z-index: 9999; display: none; text-align: center; }
    .td-toast.success { background: #059669; }
    .td-toast.error { background: #DC2626; }
    
    @keyframes spin { to { transform: rotate(360deg); } }
    .spin { animation: spin 0.8s linear infinite; }
    
    /* Google Places */
    .pac-container { border: none; box-shadow: 0 4px 20px rgba(0,0,0,0.15); margin-top: 4px; font-family: 'Inter', -apple-system, sans-serif; }
    .pac-item { padding: 12px 14px; cursor: pointer; min-height: 44px; }
    .pac-item:hover { background: #F9FAFB; }
    .pac-item-query { font-size: 14px; font-weight: 600; }
    .pac-icon { display: none; }
    
    /* Tablet+ */
    @media (min-width: 640px) {
        .td-header { padding: 16px 20px; }
        .td-header-inner { gap: 16px; }
        .td-logo { height: 32px; max-width: 120px; }
        .td-avatar { width: 48px; height: 48px; }
        .td-name { font-size: 18px; }
        .td-role { display: block; }
        .td-main { padding: 20px; }
        .td-tabs { gap: 8px; }
        .td-tab { padding: 12px 18px; font-size: 14px; }
        .td-card { padding: 20px; }
        .td-card-title { font-size: 18px; }
        .sched-row { grid-template-columns: 44px auto 1fr auto; padding: 14px 16px; }
        .sched-content { flex-direction: row; align-items: center; gap: 12px; }
        .sched-day { width: 90px; }
        .sched-time { width: 105px; }
        .td-toast { bottom: 24px; left: auto; right: 24px; max-width: 360px; }
    }
    
    /* Extra small mobile */
    @media (max-width: 380px) {
        .td-header { padding: 10px 12px; }
        .td-main { padding: 12px 10px; }
        .td-tabs { gap: 4px; }
        .td-tab { padding: 10px 12px; font-size: 12px; }
        .td-card { padding: 14px; margin-bottom: 12px; }
        .td-card-title { font-size: 14px; }
        .sched-row { padding: 10px; }
        .sched-time { width: 85px; padding: 8px 6px; font-size: 13px; }
        .td-btn { padding: 10px 14px; font-size: 12px; }
        .td-stat-value { font-size: 18px; }
    }
    
    /* Desktop */
    @media (min-width: 900px) {
        .td-header { padding: 20px; }
        .td-logo { height: 36px; max-width: 140px; }
        .td-avatar { width: 56px; height: 56px; }
        .td-name { font-size: 20px; }
        .td-main { padding: 24px 20px; }
        .td-grid { grid-template-columns: 1fr 380px; gap: 24px; }
        .td-card { padding: 24px; margin-bottom: 20px; }
    }
    </style>
</head>
<body>

<div class="td-header">
    <div class="td-header-inner">
        <a href="<?php echo esc_url(home_url('/training/')); ?>">
            <img src="<?php echo esc_url($logo_url); ?>" class="td-logo" alt="PTP Soccer">
        </a>
        <img src="<?php echo esc_url($photo); ?>" class="td-avatar" alt="">
        <div class="td-header-info">
            <div class="td-name"><?php echo esc_html($trainer->display_name); ?></div>
            <div class="td-role">Trainer Dashboard</div>
        </div>
        <a href="<?php echo esc_url($profile_url); ?>" class="td-btn td-btn-sm td-btn-outline" style="color:#fff;border-color:rgba(255,255,255,0.3);display:none" target="_blank">View Profile</a>
        <a href="<?php echo esc_url(home_url('/logout/')); ?>" class="td-btn td-btn-sm td-btn-outline" style="color:#fff;border-color:rgba(255,255,255,0.3);padding:10px">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
        </a>
    </div>
</div>

<div class="td-main">
    <!-- Tabs -->
    <div class="td-tabs">
        <a href="?tab=schedule" class="td-tab <?php echo $active_tab === 'schedule' ? 'active' : ''; ?>">📅 Schedule</a>
        <a href="?tab=sessions" class="td-tab <?php echo $active_tab === 'sessions' ? 'active' : ''; ?>">⚽ Sessions</a>
        <a href="?tab=earnings" class="td-tab <?php echo $active_tab === 'earnings' ? 'active' : ''; ?>">💰 Earnings</a>
        <a href="<?php echo home_url('/messages/'); ?>" class="td-tab">💬 Messages <?php if($unread_count): ?><span style="background:#EF4444;color:#fff;padding:2px 8px;border-radius:10px;font-size:12px;margin-left:4px"><?php echo $unread_count; ?></span><?php endif; ?></a>
        <a href="<?php echo home_url('/trainer-onboarding/?edit=1'); ?>" class="td-tab">⚙️ Profile</a>
    </div>

    <?php if ($active_tab === 'schedule'): ?>
    <!-- SCHEDULE TAB -->
    <div class="td-grid">
        <div>
            <!-- Weekly Availability -->
            <div class="td-card">
                <div class="td-card-title">📅 Weekly Availability</div>
                <p class="td-card-subtitle">Set your available hours for each day. Changes save automatically and update your booking calendar.</p>
                
                <div id="schedule-grid">
                    <?php for ($day = 0; $day <= 6; $day++): 
                        $slot = $avail_by_day[$day] ?? null;
                        $is_active = $slot && $slot->is_active;
                        $start_time = $slot ? substr($slot->start_time, 0, 5) : '16:00';
                        $end_time = $slot ? substr($slot->end_time, 0, 5) : '20:00';
                    ?>
                    <div class="sched-row <?php echo !$is_active ? 'inactive' : ''; ?>" data-day="<?php echo $day; ?>">
                        <label class="sched-toggle">
                            <input type="checkbox" class="day-toggle" <?php checked($is_active); ?>>
                            <span class="sched-toggle-track"></span>
                        </label>
                        <div class="sched-content">
                            <div class="sched-day"><?php echo $day_names[$day]; ?></div>
                            <div class="sched-times">
                                <input type="time" class="sched-time start-time" value="<?php echo esc_attr($start_time); ?>" <?php echo !$is_active ? 'disabled' : ''; ?>>
                                <span style="color:#9CA3AF;font-size:13px">to</span>
                                <input type="time" class="sched-time end-time" value="<?php echo esc_attr($end_time); ?>" <?php echo !$is_active ? 'disabled' : ''; ?>>
                                <span class="sched-status"></span>
                            </div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>
            </div>
            
            <!-- Training Locations -->
            <div class="td-card">
                <div class="td-card-title">
                    📍 Training Locations
                    <span id="loc-status" style="margin-left:auto;font-size:13px;font-weight:500;color:#6B7280"></span>
                </div>
                <p class="td-card-subtitle">Add locations where you offer training. Parents will choose from these when booking. <?php if ($google_maps_key): ?>Start typing to search for places.<?php endif; ?></p>
                
                <div id="locations-list">
                    <?php if (empty($training_locations)): ?>
                    <div class="loc-empty" style="text-align:center;padding:32px;background:#F9FAFB;border-radius:12px;color:#6B7280">
                        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" stroke-width="1.5" style="margin:0 auto 12px;display:block"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <p style="margin:0;font-size:15px">No training locations added yet</p>
                        <p style="margin:8px 0 0;font-size:13px">Add your first location below</p>
                    </div>
                    <?php else: ?>
                    <?php foreach ($training_locations as $i => $loc): 
                        $loc_id = $loc['id'] ?? 'loc_' . $i;
                        $loc_name = $loc['name'] ?? '';
                        $loc_address = $loc['address'] ?? '';
                        $loc_lat = $loc['lat'] ?? null;
                        $loc_lng = $loc['lng'] ?? null;
                        $maps_url = $loc_lat && $loc_lng 
                            ? "https://www.google.com/maps/search/?api=1&query={$loc_lat},{$loc_lng}"
                            : "https://www.google.com/maps/search/?api=1&query=" . urlencode($loc_name . ' ' . $loc_address);
                    ?>
                    <div class="loc-row" data-id="<?php echo esc_attr($loc_id); ?>">
                        <div class="loc-row-header">
                            <div class="loc-icon">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            </div>
                            <input type="text" class="loc-input loc-name" placeholder="Location name (e.g. Radnor Memorial Park)" value="<?php echo esc_attr($loc_name); ?>">
                            <button type="button" class="loc-remove" onclick="removeLocation(this)">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                        </div>
                        <?php if ($loc_address): ?>
                        <div class="loc-address">
                            📍 <?php echo esc_html($loc_address); ?> — <a href="<?php echo esc_url($maps_url); ?>" target="_blank">Open in Maps</a>
                        </div>
                        <?php endif; ?>
                        <input type="hidden" class="loc-address-data" value="<?php echo esc_attr($loc_address); ?>">
                        <input type="hidden" class="loc-lat" value="<?php echo esc_attr($loc_lat); ?>">
                        <input type="hidden" class="loc-lng" value="<?php echo esc_attr($loc_lng); ?>">
                    </div>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <div style="margin-top:16px;display:flex;gap:12px;flex-wrap:wrap">
                    <button type="button" onclick="addLocation()" class="td-btn td-btn-outline td-btn-sm">+ Add Location</button>
                    <button type="button" id="save-locations-btn" onclick="saveLocations()" class="td-btn td-btn-sm">Save Locations</button>
                </div>
            </div>
        </div>

        <div>
            <!-- Stats -->
            <div class="td-card">
                <div class="td-card-title">📊 This Month</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                    <div class="td-stat">
                        <div class="td-stat-value">$<?php echo number_format($earnings['this_month'] ?? 0); ?></div>
                        <div class="td-stat-label">Earned</div>
                    </div>
                    <div class="td-stat">
                        <div class="td-stat-value"><?php echo count($upcoming); ?></div>
                        <div class="td-stat-label">Sessions</div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Tips -->
            <div class="td-card" style="background:#FFFBEB;border:1px solid #FCD34D">
                <div class="td-card-title" style="margin-bottom:12px">💡 Tips</div>
                <ul style="margin:0;padding-left:20px;font-size:14px;color:#92400E;line-height:1.8">
                    <li>Enable more days to get more bookings</li>
                    <li>Add multiple locations for flexibility</li>
                    <li>Specific addresses help parents find you</li>
                </ul>
            </div>
        </div>
    </div>

    <?php elseif ($active_tab === 'sessions'): ?>
    <!-- SESSIONS TAB -->
    <div class="td-card">
        <div class="td-card-title">⚽ Upcoming Sessions</div>
        <?php if (empty($upcoming)): ?>
        <div style="text-align:center;padding:48px 20px;color:#6B7280">
            <div style="font-size:56px;margin-bottom:16px">📅</div>
            <p style="font-size:17px;font-weight:600;color:#111;margin:0 0 8px">No upcoming sessions</p>
            <p style="font-size:14px;margin:0">Sessions will appear here once parents book with you</p>
        </div>
        <?php else: ?>
        <?php foreach ($upcoming as $session): 
            $session_date = strtotime($session->session_date ?? $session->date ?? 'now');
        ?>
        <div class="td-session">
            <div class="td-session-date">
                <div class="td-session-day"><?php echo date('j', $session_date); ?></div>
                <div class="td-session-month"><?php echo date('M', $session_date); ?></div>
            </div>
            <div style="flex:1">
                <div style="font-weight:600;font-size:16px;margin-bottom:4px"><?php echo esc_html($session->player_name ?? $session->parent_name ?? 'Player'); ?></div>
                <div style="font-size:14px;color:#6B7280">
                    <?php echo date('g:i A', $session_date); ?> • <?php echo esc_html($session->location ?? 'TBD'); ?>
                </div>
            </div>
            <span style="padding:8px 14px;background:<?php echo ($session->status ?? '') === 'confirmed' ? '#D1FAE5' : '#FEF3C7'; ?>;color:<?php echo ($session->status ?? '') === 'confirmed' ? '#065F46' : '#92400E'; ?>;border-radius:8px;font-size:13px;font-weight:600"><?php echo ucfirst($session->status ?? 'pending'); ?></span>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
    
    <!-- How to Get Paid -->
    <div class="td-card" style="margin-top:20px;background:#FFFBEB;border-color:#FCB900">
        <div class="td-card-title" style="color:#92400E">💰 How to Get Paid</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit, minmax(200px, 1fr));gap:20px">
            <div style="display:flex;gap:12px;align-items:flex-start">
                <div style="width:32px;height:32px;background:#FCB900;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-weight:700;font-size:14px">1</div>
                <div>
                    <div style="font-weight:600;margin-bottom:4px">Complete the Session</div>
                    <div style="font-size:13px;color:#6B7280">Train the player at the scheduled time and location</div>
                </div>
            </div>
            <div style="display:flex;gap:12px;align-items:flex-start">
                <div style="width:32px;height:32px;background:#FCB900;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-weight:700;font-size:14px">2</div>
                <div>
                    <div style="font-weight:600;margin-bottom:4px">Mark as Completed</div>
                    <div style="font-size:13px;color:#6B7280">Click the session above and mark it complete. The parent will be asked to confirm.</div>
                </div>
            </div>
            <div style="display:flex;gap:12px;align-items:flex-start">
                <div style="width:32px;height:32px;background:#10B981;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-weight:700;color:#fff;font-size:14px">$</div>
                <div>
                    <div style="font-weight:600;margin-bottom:4px">Get Paid</div>
                    <div style="font-size:13px;color:#6B7280">Once confirmed, your 80% earnings are released to your Stripe account within 2-3 days.</div>
                </div>
            </div>
        </div>
    </div>

    <?php elseif ($active_tab === 'earnings'): ?>
    <!-- EARNINGS TAB -->
    <?php 
    if (file_exists(PTP_PLUGIN_DIR . 'templates/partials/trainer-earnings.php')) {
        include PTP_PLUGIN_DIR . 'templates/partials/trainer-earnings.php';
    } else {
        echo '<div class="td-card"><p>Earnings data coming soon.</p></div>';
    }
    ?>
    <?php endif; ?>
</div>

<!-- Toast -->
<div id="toast" class="td-toast"></div>

<script>
(function() {
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    const nonce = '<?php echo wp_create_nonce('ptp_nonce'); ?>';
    
    // Check dynamically if Google Maps is available
    function hasGoogleMaps() {
        return typeof google !== 'undefined' && google.maps && google.maps.places && google.maps.places.Autocomplete;
    }
    
    // Wait for Google Maps to be ready
    function waitForGoogleMaps(callback, attempts = 0) {
        if (hasGoogleMaps()) {
            callback();
        } else if (attempts < 50) {
            setTimeout(() => waitForGoogleMaps(callback, attempts + 1), 100);
        } else {
            console.warn('[PTP Dashboard] Google Maps not available after waiting');
        }
    }
    
    // Toast notification
    function showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        toast.textContent = message;
        toast.className = 'td-toast ' + type;
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 3000);
    }
    
    // ========== SCHEDULE MANAGEMENT ==========
    let saveTimeouts = {};
    
    async function saveDay(dayEl) {
        const day = dayEl.dataset.day;
        const toggle = dayEl.querySelector('.day-toggle');
        const startInput = dayEl.querySelector('.start-time');
        const endInput = dayEl.querySelector('.end-time');
        const statusEl = dayEl.querySelector('.sched-status');
        
        const enabled = toggle.checked ? '1' : '0';
        const start = startInput.value || '16:00';
        const end = endInput.value || '20:00';
        
        statusEl.textContent = 'Saving...';
        statusEl.className = 'sched-status saving';
        
        try {
            const formData = new FormData();
            formData.append('action', 'ptp_save_trainer_schedule');
            formData.append('nonce', nonce);
            formData.append('day', day);
            formData.append('enabled', enabled);
            formData.append('start', start);
            formData.append('end', end);
            
            const response = await fetch(ajaxUrl, { method: 'POST', body: formData });
            const data = await response.json();
            
            if (data.success) {
                statusEl.textContent = '✓ Saved';
                statusEl.className = 'sched-status saved';
                setTimeout(() => { statusEl.textContent = ''; }, 2000);
            } else {
                throw new Error(data.data?.message || 'Save failed');
            }
        } catch (e) {
            console.error('Schedule save error:', e);
            statusEl.textContent = '✗ Error';
            statusEl.className = 'sched-status error';
            showToast('Error saving: ' + e.message, 'error');
        }
    }
    
    function scheduleSave(dayEl) {
        const day = dayEl.dataset.day;
        if (saveTimeouts[day]) clearTimeout(saveTimeouts[day]);
        
        const statusEl = dayEl.querySelector('.sched-status');
        statusEl.textContent = 'Unsaved...';
        statusEl.className = 'sched-status';
        
        saveTimeouts[day] = setTimeout(() => saveDay(dayEl), 600);
    }
    
    // Toggle handlers
    document.querySelectorAll('.day-toggle').forEach(toggle => {
        toggle.addEventListener('change', function() {
            const row = this.closest('.sched-row');
            const startInput = row.querySelector('.start-time');
            const endInput = row.querySelector('.end-time');
            
            if (this.checked) {
                row.classList.remove('inactive');
                startInput.disabled = false;
                endInput.disabled = false;
            } else {
                row.classList.add('inactive');
                startInput.disabled = true;
                endInput.disabled = true;
            }
            scheduleSave(row);
        });
    });
    
    // Time input handlers
    document.querySelectorAll('.start-time, .end-time').forEach(input => {
        input.addEventListener('change', function() {
            scheduleSave(this.closest('.sched-row'));
        });
    });
    
    // ========== TRAINING LOCATIONS ==========
    let locIndex = document.querySelectorAll('.loc-row').length;
    
    function initPlacesAutocomplete(input) {
        if (!hasGoogleMaps()) return;
        
        const autocomplete = new google.maps.places.Autocomplete(input, {
            types: ['establishment', 'geocode'],
            componentRestrictions: { country: 'us' }
        });
        
        autocomplete.addListener('place_changed', function() {
            const place = autocomplete.getPlace();
            const row = input.closest('.loc-row');
            
            if (place.geometry) {
                row.querySelector('.loc-lat').value = place.geometry.location.lat();
                row.querySelector('.loc-lng').value = place.geometry.location.lng();
            }
            
            if (place.formatted_address) {
                row.querySelector('.loc-address-data').value = place.formatted_address;
                
                // Update address display
                let addrDiv = row.querySelector('.loc-address');
                if (!addrDiv) {
                    addrDiv = document.createElement('div');
                    addrDiv.className = 'loc-address';
                    row.appendChild(addrDiv);
                }
                const lat = row.querySelector('.loc-lat').value;
                const lng = row.querySelector('.loc-lng').value;
                const mapsUrl = lat && lng 
                    ? `https://www.google.com/maps/search/?api=1&query=${lat},${lng}`
                    : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(place.formatted_address)}`;
                addrDiv.innerHTML = `📍 ${place.formatted_address} — <a href="${mapsUrl}" target="_blank">Open in Maps</a>`;
            }
            
            showLocSaveBtn();
        });
    }
    
    window.addLocation = function() {
        const list = document.getElementById('locations-list');
        const empty = list.querySelector('.loc-empty');
        if (empty) empty.remove();
        
        const id = 'loc_' + Date.now();
        const row = document.createElement('div');
        row.className = 'loc-row';
        row.dataset.id = id;
        row.innerHTML = `
            <div class="loc-row-header">
                <div class="loc-icon">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                </div>
                <input type="text" class="loc-input loc-name" placeholder="${hasGoogleMaps() ? 'Search for a park, field, or address...' : 'Location name'}">
                <button type="button" class="loc-remove" onclick="removeLocation(this)">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
            </div>
            <input type="hidden" class="loc-address-data" value="">
            <input type="hidden" class="loc-lat" value="">
            <input type="hidden" class="loc-lng" value="">
        `;
        list.appendChild(row);
        
        const nameInput = row.querySelector('.loc-name');
        nameInput.focus();
        initPlacesAutocomplete(nameInput);
        showLocSaveBtn();
    };
    
    window.removeLocation = function(btn) {
        btn.closest('.loc-row').remove();
        showLocSaveBtn();
        
        const list = document.getElementById('locations-list');
        if (!list.querySelector('.loc-row')) {
            list.innerHTML = `
                <div class="loc-empty" style="text-align:center;padding:32px;background:#F9FAFB;border-radius:12px;color:#6B7280">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#D1D5DB" stroke-width="1.5" style="margin:0 auto 12px;display:block"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <p style="margin:0;font-size:15px">No training locations added yet</p>
                </div>
            `;
        }
    };
    
    function showLocSaveBtn() {
        document.getElementById('loc-status').textContent = 'Unsaved changes';
        document.getElementById('loc-status').style.color = '#D97706';
    }
    
    // Input change detection
    document.getElementById('locations-list')?.addEventListener('input', function(e) {
        if (e.target.classList.contains('loc-name')) {
            showLocSaveBtn();
        }
    });
    
    window.saveLocations = async function() {
        const btn = document.getElementById('save-locations-btn');
        const statusEl = document.getElementById('loc-status');
        
        btn.disabled = true;
        btn.innerHTML = '<svg class="spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 11-6.219-8.56"/></svg> Saving...';
        
        const locations = [];
        document.querySelectorAll('.loc-row').forEach(row => {
            const name = row.querySelector('.loc-name')?.value.trim();
            if (name) {
                locations.push({
                    id: row.dataset.id,
                    name: name,
                    address: row.querySelector('.loc-address-data')?.value || '',
                    lat: row.querySelector('.loc-lat')?.value || null,
                    lng: row.querySelector('.loc-lng')?.value || null
                });
            }
        });
        
        try {
            const formData = new FormData();
            formData.append('action', 'ptp_update_training_locations');
            formData.append('nonce', nonce);
            formData.append('locations', JSON.stringify(locations));
            
            const response = await fetch(ajaxUrl, { method: 'POST', body: formData });
            const data = await response.json();
            
            if (data.success) {
                btn.innerHTML = '✓ Saved!';
                btn.style.background = '#10B981';
                statusEl.textContent = 'Saved';
                statusEl.style.color = '#059669';
                showToast('Locations saved!');
                
                setTimeout(() => {
                    btn.style.background = '';
                    btn.innerHTML = 'Save Locations';
                    btn.disabled = false;
                    statusEl.textContent = '';
                }, 2000);
            } else {
                throw new Error(data.data?.message || 'Save failed');
            }
        } catch (e) {
            btn.innerHTML = 'Save Locations';
            btn.disabled = false;
            statusEl.textContent = 'Error saving';
            statusEl.style.color = '#DC2626';
            showToast('Error: ' + e.message, 'error');
        }
    };
    
    // Initialize Places autocomplete on existing inputs when Google Maps is ready
    waitForGoogleMaps(function() {
        console.log('[PTP Dashboard] Google Maps ready, initializing autocomplete');
        document.querySelectorAll('.loc-name').forEach(initPlacesAutocomplete);
    });
})();
</script>

<?php wp_footer(); ?>
</body>
</html>
