# PTP Training Platform

**Version: 42.3.5**

## Changelog

### v42.3.5 (Security & Performance Improvements)
- **Security**: Added rate limiting to login (5 attempts/5min) and register (3 attempts/5min) endpoints
- **Security**: Added rate limiting to forgot_password endpoint
- **Security**: Removed sensitive data from error logs (print_r calls removed)
- **Security**: Wrapped debug logging in WP_DEBUG checks
- **Performance**: Added object caching to PTP_Trainer::get() and get_by_user_id()
- **Performance**: Added cache invalidation on trainer updates
- **Reliability**: Added database transactions to booking creation for atomicity
- **Reliability**: Improved error handling in booking flow with proper rollback

### v42.3.2 (Google Maps Robust Loading)
- **Fixed**: Google Maps not loading on trainer-onboarding page
- **Fixed**: Google Maps loading on trainer-dashboard page
- **Added**: More robust Google Maps detection and initialization
  - Handles cases where theme/plugin already loads Google Maps
  - Retry logic if Google Maps not ready when callback fires
  - Console logging for debugging map issues
- **Added**: Google Maps API Status section in Debug page
  - Shows if API key is configured
  - Shows which APIs need to be enabled
- **Improved**: wp_head() now called before Google Maps script in trainer-dashboard

### v42.3.1 (Google Maps Fix)
- **Fixed**: Google Maps loading multiple times on /find-trainers/
  - PTP_Maps class now skips find-trainers page (handled by template)
  - Added `loading=async` to all Google Maps script loads
  - Better detection of already-loaded Google Maps
  - Prevents double initialization of map
- **Fixed**: Console version numbers updated (were showing old v42.0 and v19)
- **Improved**: Map initialization with retry logic if Google Maps not ready

### v42.3.0 (Gallery, Map Fix, Mobile Optimization)
- **Added**: Trainer profile gallery section for action shots
  - Displays in 3-column grid on desktop, 2-column on mobile
  - Fullscreen lightbox with keyboard navigation
  - Supports up to 6 images
- **Added**: Gallery upload in trainer onboarding
  - Drag-and-drop style upload
  - Preview before saving
  - Remove individual images
- **Fixed**: Google Maps trainer markers on /find-trainers/
  - Added debug logging for map initialization
  - Better handling of trainers without coordinates
  - Console logs show coordinate status
- **Added**: Geocoding tools in Debug page
  - "Geocode" button to auto-fetch coordinates from location text
  - "Set Philly" button to set default Philadelphia coordinates
  - Lat/Lng column in trainers table
- **Improved**: Map update function with coordinate parsing
- **Mobile**: Gallery responsive grid (3-col desktop, 2-col mobile)
- **Mobile**: Lightbox touch-friendly navigation

### v42.2.0 (Admin Dashboard Access Fix)
- **Fixed**: Main plugin `template_redirect` hook now has same fixes as shortcode
- **Added**: Admin bypass - admins can always view trainer dashboard
  - `/trainer-dashboard/` - auto-loads first active trainer
  - `/trainer-dashboard/?trainer_id=X` - view specific trainer
  - `/trainer-dashboard/?skip_onboarding=1` - bypass onboarding redirect
- **Added**: Email fallback in main redirect handler
- **Added**: Auto trainer-user linking in main redirect handler
- **Added**: Admin tips section in debug page

### v42.1.0 (Trainer Dashboard Fix)
- **Fixed**: Trainer dashboard redirect to apply page issue
- **Fixed**: Trainer lookup now tries email matching if user_id lookup fails
- **Fixed**: Automatic trainer-to-user linking when found by email
- **Added**: Enhanced debug page with trainer diagnostics
  - Shows current user trainer status
  - Lists all trainers with status
  - Quick actions: Activate trainer, Fix slug, Link to user
- **Added**: PTP Pages status check in debug page
- **Added**: "Create Missing Pages" button to recreate plugin pages
- **Added**: `get_by_email()` method to PTP_Trainer class
- **Added**: `link_to_user()` method to PTP_Trainer class
- **Improved**: `is_new_trainer()` method robustness
- **Improved**: Trainer dashboard shortcode with better error handling

### v42.0.0 (Mobile Optimization & Bug Fixes)
- **Mobile-First Optimization**: All templates now fully optimized for mobile devices
- **Touch Target Compliance**: All interactive elements now have 44px minimum touch targets
- **iOS Zoom Prevention**: Form inputs use 16px font-size to prevent iOS auto-zoom
- **Safe Area Support**: Added safe-area-inset support for notched devices
- **Touch Feedback**: Added active states for touch devices
- **Responsive Improvements**: 
  - New extra-small breakpoint (380px) for compact phones
  - Improved tablet breakpoints (768px, 1024px)
  - Better spacing and padding at all breakpoints
- **Template Updates**: All major templates updated with enhanced mobile styles
  - trainer-dashboard.php
  - parent-dashboard.php
  - trainer-profile.php
  - trainers-grid.php
  - book-session.php
  - checkout.php
  - login.php
  - register.php
- **CSS Updates**: 
  - frontend.css updated with comprehensive responsive system
  - Touch-specific styles for non-hover devices
  - Smooth scrolling with reduced-motion support
  - Print styles cleanup
- **JavaScript Updates**: frontend.js v42.0 with mobile touch optimization

### v40.3.0 (Google Maps Wiring Complete)
- Fixed: Find Trainers location search now uses Google Places autocomplete
- Fixed: Location search accepts city names, not just ZIP codes
- Fixed: Map auto-centers on user location when using geolocation
- Enhanced: Trainer onboarding already has Google Maps Places integration for training locations
- Enhanced: Both trainer onboarding and find trainers properly load Google Maps Places API
- Verified: Training locations are saved with lat/lng coordinates and displayed on map

### v40.2.0 (Google Maps Integration)
- Enhanced: Find Trainers page now shows all trainer training locations on map
- Enhanced: Location search with Google Places autocomplete (city/ZIP search)
- Enhanced: Map info windows show trainer's training locations list
- Enhanced: Training location markers (blue) separate from trainer markers (gold)
- Added: training_locations field to API response for map display
- Fixed: Location search integration with Google Places API

### v40.1.0 (Fix)
- Fixed: Trainer profile routing now works correctly - shortcode passes trainer data to template
- Fixed: Templates class handles subdirectory WordPress installations for trainer URLs
- Fixed: AJAX get_trainers now auto-generates slugs for trainers missing them
- Added: Global $ptp_current_trainer variable for template access

### v40.0.0
- Added: Logout shortcode and template
- Added: Training landing page shortcode and template
- Added: Auto-hide page titles on PTP shortcode pages
- Added: Trust elements on trainer profile pages
- Improved: Google Maps loading to prevent duplicates
- Improved: Geocoding fallback for trainer locations

## Debug Report (v38 → v39 Fixed)

### ✅ No Syntax Errors
All PHP files pass lint checks.

### 🔴 CRITICAL BUGS FIXED

#### 1. Missing Methods Causing Fatal Error (FIXED)
`class-ptp-admin-payouts.php` called two methods that didn't exist in `PTP_Trainer_Payouts`:
- `get_payout_queue()` - **Added**
- `get_payout_instructions($payout)` - **Added**

This was causing the "Critical Error" on payout pages.

#### 2. Duplicate Menu Registration Conflict (FIXED)
Both `class-ptp-admin.php` and `class-ptp-admin-payouts.php` were trying to register `ptp-payouts` menu item with different parent slugs:
- Admin class: parent = `ptp-dashboard` ✓
- Admin payouts class: parent = `ptp-training` ✗ (doesn't exist)

Commented out the duplicate registration in `class-ptp-admin-payouts.php`.

#### 3. Rewrite Rules Flushing on Every Page Load (FIXED)
Version check was comparing against hardcoded string instead of `PTP_VERSION`.

#### 4. Debug Logging in Production (FIXED)
Schedule save was logging all POST data unconditionally. Now only logs when `WP_DEBUG` is true.

### 🔧 Debug Tool Added
Access at **WP Admin → PTP Training → 🔧 Debug**

### Common Issues & Fixes

| Issue | Symptom | Fix |
|-------|---------|-----|
| Tables missing | "Table doesn't exist" errors | Deactivate/reactivate plugin |
| AJAX fails | "Security check failed" | Clear browser cache |
| 404 on trainer profiles | `/trainer/slug/` returns 404 | Settings → Permalinks → Save |
| Stripe not working | Payment errors | Check API keys in PTP → Settings |

--- v29.0.0

Complete 1-on-1 soccer training marketplace with bulletproof inline styling for all devices.

## What's New in v29.0.0

### 100% Bulletproof Inline Styling
- All templates now use inline CSS that works on every device
- No external CSS dependencies - everything renders correctly
- Mobile-first responsive design
- Professional, modern UI consistent across all pages

### Updated Templates
- **Home Page**: Hero with search, featured trainers, how it works, stats, programs
- **Find Trainers**: Filterable grid with Google Maps integration
- **Trainer Profile**: Complete profile with booking calendar and availability
- **Checkout**: Secure Stripe payment processing
- **Booking Confirmation**: Success page with session details
- **Login/Register**: Clean authentication flows
- **Apply as Trainer**: Professional application form

### Features
- Trainer profiles with photos, bios, specialties, reviews
- Real-time availability calendar
- Secure Stripe payments with Connect for trainer payouts
- Google Calendar sync
- SMS notifications (Twilio)
- Review system
- Training location management
- Background check verification badges

## Installation

1. Upload the plugin folder to `/wp-content/plugins/`
2. Activate through WordPress admin
3. Configure settings under PTP Training menu
4. Add required API keys:
   - Stripe (payments)
   - Google Maps (location features)
   - Twilio (SMS notifications)

## Shortcodes

- `[ptp_home]` - Home page
- `[ptp_trainers]` - Find trainers grid
- `[ptp_trainer_profile]` - Individual trainer profile
- `[ptp_checkout]` - Checkout/payment page
- `[ptp_login]` - Login form
- `[ptp_register]` - Registration form
- `[ptp_apply]` - Trainer application form
- `[ptp_my_training]` - Parent dashboard
- `[ptp_trainer_dashboard]` - Trainer dashboard

## Brand Colors

- Primary Yellow: #FCB900
- Dark: #0E0F11
- Gray Background: #F3F4F6
- Success Green: #10B981
- Error Red: #EF4444

## Support

Contact: support@ptpsummercamps.com
