<?php
/**
 * PTP Camps API - Mobile App integration for WooCommerce camps/clinics
 * 
 * @version 1.0.0
 */

defined('ABSPATH') || exit;

class PTP_Camps_API {
    
    public static function init() {
        add_action('rest_api_init', array(__CLASS__, 'register_routes'));
    }
    
    public static function register_routes() {
        $ns = 'ptp/v1';
        
        // Get all camps/clinics
        register_rest_route($ns, '/camps', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_camps'),
            'permission_callback' => '__return_true',
        ));
        
        // Get single camp
        register_rest_route($ns, '/camps/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_camp'),
            'permission_callback' => '__return_true',
        ));
        
        // Get featured camps
        register_rest_route($ns, '/camps/featured', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_featured'),
            'permission_callback' => '__return_true',
        ));
        
        // Get camps by location
        register_rest_route($ns, '/camps/by-location', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_by_location'),
            'permission_callback' => '__return_true',
        ));
        
        // Get upcoming camps
        register_rest_route($ns, '/camps/upcoming', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_upcoming'),
            'permission_callback' => '__return_true',
        ));
        
        // Get user registrations
        register_rest_route($ns, '/camps/my-registrations', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_my_registrations'),
            'permission_callback' => array('PTP_REST_API', 'check_auth'),
        ));
        
        // Check availability
        register_rest_route($ns, '/camps/(?P<id>\d+)/availability', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'check_availability'),
            'permission_callback' => '__return_true',
        ));
        
        // Get schedule/sessions
        register_rest_route($ns, '/camps/(?P<id>\d+)/schedule', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_schedule'),
            'permission_callback' => '__return_true',
        ));
        
        // Get categories
        register_rest_route($ns, '/camps/categories', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'get_categories'),
            'permission_callback' => '__return_true',
        ));
        
        // Search
        register_rest_route($ns, '/camps/search', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'search_camps'),
            'permission_callback' => '__return_true',
        ));
    }
    
    /**
     * Get all camps/clinics - ALL WooCommerce products are treated as camps
     */
    public static function get_camps($request) {
        if (!class_exists('WooCommerce')) {
            return new WP_Error('woocommerce_required', 'WooCommerce not installed', array('status' => 400));
        }
        
        $page = max(1, (int) $request->get_param('page'));
        $per_page = min(50, max(1, (int) $request->get_param('per_page') ?: 20));
        $type = sanitize_text_field($request->get_param('type')); // camp, clinic, all
        $state = sanitize_text_field($request->get_param('state'));
        $category = sanitize_text_field($request->get_param('category'));
        $age_group = sanitize_text_field($request->get_param('age_group'));
        $sort = sanitize_text_field($request->get_param('sort')) ?: 'date';
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'meta_query' => array(),
        );
        
        // Filter by type
        if ($type && $type !== 'all') {
            $args['meta_query'][] = array(
                'key' => '_ptp_camp_type',
                'value' => $type,
            );
        }
        
        // Filter by state
        if ($state) {
            $args['meta_query'][] = array(
                'key' => '_ptp_state',
                'value' => $state,
            );
        }
        
        // Filter by age group
        if ($age_group) {
            $args['meta_query'][] = array(
                'key' => '_ptp_age_groups',
                'value' => $age_group,
                'compare' => 'LIKE',
            );
        }
        
        // Category filter
        if ($category) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $category,
                ),
            );
        }
        
        // Sorting
        switch ($sort) {
            case 'price_low':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = '_price';
                $args['order'] = 'ASC';
                break;
            case 'price_high':
                $args['orderby'] = 'meta_value_num';
                $args['meta_key'] = '_price';
                $args['order'] = 'DESC';
                break;
            case 'name':
                $args['orderby'] = 'title';
                $args['order'] = 'ASC';
                break;
            case 'date':
            default:
                $args['orderby'] = 'meta_value';
                $args['meta_key'] = '_ptp_start_date';
                $args['order'] = 'ASC';
                break;
        }
        
        $query = new WP_Query($args);
        
        $camps = array();
        foreach ($query->posts as $post) {
            $camps[] = self::format_camp($post->ID);
        }
        
        return rest_ensure_response(array(
            'camps' => $camps,
            'total' => $query->found_posts,
            'pages' => $query->max_num_pages,
            'page' => $page,
            'per_page' => $per_page,
        ));
    }
    
    /**
     * Get single camp
     */
    public static function get_camp($request) {
        $id = (int) $request->get_param('id');
        
        $product = wc_get_product($id);
        if (!$product) {
            return new WP_Error('not_found', 'Camp not found', array('status' => 404));
        }
        
        return rest_ensure_response(self::format_camp($id, true));
    }
    
    /**
     * Get featured camps
     */
    public static function get_featured($request) {
        $limit = min(20, max(1, (int) $request->get_param('limit') ?: 6));
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'meta_query' => array(
                array(
                    'key' => '_featured',
                    'value' => 'yes',
                ),
            ),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        $query = new WP_Query($args);
        
        $camps = array();
        foreach ($query->posts as $post) {
            $camps[] = self::format_camp($post->ID);
        }
        
        return rest_ensure_response(array('featured' => $camps));
    }
    
    /**
     * Get camps by location
     */
    public static function get_by_location($request) {
        $latitude = (float) $request->get_param('latitude');
        $longitude = (float) $request->get_param('longitude');
        $radius = min(100, max(1, (int) $request->get_param('radius') ?: 25));
        $limit = min(50, max(1, (int) $request->get_param('limit') ?: 20));
        
        if (!$latitude || !$longitude) {
            return new WP_Error('location_required', 'Latitude and longitude required', array('status' => 400));
        }
        
        global $wpdb;
        
        // Get all products with coordinates
        $camps_raw = $wpdb->get_results($wpdb->prepare("
            SELECT p.ID,
                   pm_lat.meta_value as latitude,
                   pm_lng.meta_value as longitude,
                   (
                       3959 * acos(
                           cos(radians(%f)) * cos(radians(pm_lat.meta_value)) *
                           cos(radians(pm_lng.meta_value) - radians(%f)) +
                           sin(radians(%f)) * sin(radians(pm_lat.meta_value))
                       )
                   ) AS distance
            FROM {$wpdb->posts} p
            JOIN {$wpdb->postmeta} pm_lat ON p.ID = pm_lat.post_id AND pm_lat.meta_key = '_ptp_latitude'
            JOIN {$wpdb->postmeta} pm_lng ON p.ID = pm_lng.post_id AND pm_lng.meta_key = '_ptp_longitude'
            WHERE p.post_type = 'product' AND p.post_status = 'publish'
            AND pm_lat.meta_value != '' AND pm_lng.meta_value != ''
            HAVING distance <= %d
            ORDER BY distance ASC
            LIMIT %d
        ", $latitude, $longitude, $latitude, $radius, $limit));
        
        $camps = array();
        foreach ($camps_raw as $camp) {
            $data = self::format_camp($camp->ID);
            $data['distance'] = round($camp->distance, 1);
            $camps[] = $data;
        }
        
        return rest_ensure_response(array(
            'camps' => $camps,
            'center' => array(
                'latitude' => $latitude,
                'longitude' => $longitude,
            ),
            'radius' => $radius,
        ));
    }
    
    /**
     * Get upcoming camps
     */
    public static function get_upcoming($request) {
        $limit = min(50, max(1, (int) $request->get_param('limit') ?: 10));
        $days = min(90, max(1, (int) $request->get_param('days') ?: 30));
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_ptp_start_date',
                    'value' => array(date('Y-m-d'), date('Y-m-d', strtotime("+{$days} days"))),
                    'compare' => 'BETWEEN',
                    'type' => 'DATE',
                ),
            ),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        $query = new WP_Query($args);
        
        $camps = array();
        foreach ($query->posts as $post) {
            $camps[] = self::format_camp($post->ID);
        }
        
        return rest_ensure_response(array('upcoming' => $camps));
    }
    
    /**
     * Get user's registrations
     */
    public static function get_my_registrations($request) {
        $auth = PTP_REST_API::get_auth_user($request);
        $status = sanitize_text_field($request->get_param('status')) ?: 'all';
        
        $args = array(
            'customer_id' => $auth['user_id'],
            'limit' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
        );
        
        if ($status !== 'all') {
            $args['status'] = $status;
        }
        
        $orders = wc_get_orders($args);
        
        $registrations = array();
        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                $is_camp = get_post_meta($product_id, '_ptp_is_camp', true);
                
                if ($is_camp === 'yes') {
                    $registrations[] = array(
                        'order_id' => $order->get_id(),
                        'order_status' => $order->get_status(),
                        'order_date' => $order->get_date_created()->format('Y-m-d H:i:s'),
                        'camp' => self::format_camp($product_id),
                        'quantity' => $item->get_quantity(),
                        'total' => (float) $item->get_total(),
                        'player_name' => $item->get_meta('player_name'),
                        'player_age' => $item->get_meta('player_age'),
                    );
                }
            }
        }
        
        return rest_ensure_response(array('registrations' => $registrations));
    }
    
    /**
     * Check availability
     */
    public static function check_availability($request) {
        $id = (int) $request->get_param('id');
        
        $product = wc_get_product($id);
        if (!$product) {
            return new WP_Error('not_found', 'Camp not found', array('status' => 404));
        }
        
        $max_capacity = (int) get_post_meta($id, '_ptp_max_capacity', true);
        $sold = (int) get_post_meta($id, '_ptp_sold_count', true);
        $remaining = max(0, $max_capacity - $sold);
        
        return rest_ensure_response(array(
            'product_id' => $id,
            'available' => $product->is_in_stock() && $remaining > 0,
            'spots_remaining' => $remaining,
            'max_capacity' => $max_capacity,
            'sold' => $sold,
            'status' => $product->get_stock_status(),
        ));
    }
    
    /**
     * Get camp schedule
     */
    public static function get_schedule($request) {
        $id = (int) $request->get_param('id');
        
        $schedule = get_post_meta($id, '_ptp_schedule', true);
        
        if (!$schedule) {
            // Generate from date range
            $start = get_post_meta($id, '_ptp_start_date', true);
            $end = get_post_meta($id, '_ptp_end_date', true);
            $times = get_post_meta($id, '_ptp_daily_times', true) ?: array(
                'start' => '09:00',
                'end' => '15:00',
            );
            
            $schedule = array();
            $current = strtotime($start);
            $end_ts = strtotime($end);
            
            $day_num = 1;
            while ($current <= $end_ts) {
                // Skip weekends if configured
                $skip_weekends = get_post_meta($id, '_ptp_skip_weekends', true) === 'yes';
                $day_of_week = date('w', $current);
                
                if (!$skip_weekends || ($day_of_week > 0 && $day_of_week < 6)) {
                    $schedule[] = array(
                        'day' => $day_num,
                        'date' => date('Y-m-d', $current),
                        'day_name' => date('l', $current),
                        'start_time' => $times['start'],
                        'end_time' => $times['end'],
                        'activities' => get_post_meta($id, "_ptp_day_{$day_num}_activities", true) ?: array(),
                    );
                    $day_num++;
                }
                
                $current = strtotime('+1 day', $current);
            }
        }
        
        return rest_ensure_response(array(
            'product_id' => $id,
            'schedule' => $schedule,
        ));
    }
    
    /**
     * Get camp categories
     */
    public static function get_categories($request) {
        $terms = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => true,
            'meta_query' => array(
                array(
                    'key' => '_ptp_camp_category',
                    'value' => 'yes',
                ),
            ),
        ));
        
        // If no special camp categories, get all product cats
        if (empty($terms)) {
            $terms = get_terms(array(
                'taxonomy' => 'product_cat',
                'hide_empty' => true,
            ));
        }
        
        $categories = array();
        foreach ($terms as $term) {
            $categories[] = array(
                'id' => $term->term_id,
                'name' => $term->name,
                'slug' => $term->slug,
                'count' => $term->count,
                'image' => get_term_meta($term->term_id, 'thumbnail_id', true) 
                    ? wp_get_attachment_url(get_term_meta($term->term_id, 'thumbnail_id', true))
                    : null,
            );
        }
        
        return rest_ensure_response(array('categories' => $categories));
    }
    
    /**
     * Search camps
     */
    public static function search_camps($request) {
        $query = sanitize_text_field($request->get_param('q'));
        $limit = min(50, max(1, (int) $request->get_param('limit') ?: 20));
        
        if (strlen($query) < 2) {
            return new WP_Error('query_too_short', 'Search query must be at least 2 characters', array('status' => 400));
        }
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            's' => $query,
        );
        
        $search = new WP_Query($args);
        
        $camps = array();
        foreach ($search->posts as $post) {
            $camps[] = self::format_camp($post->ID);
        }
        
        return rest_ensure_response(array(
            'query' => $query,
            'results' => $camps,
            'total' => $search->found_posts,
        ));
    }
    
    /**
     * Format camp for API response
     */
    private static function format_camp($id, $full_details = false) {
        $product = wc_get_product($id);
        $post = get_post($id);
        
        if (!$product) {
            return null;
        }
        
        // Get images
        $image_id = $product->get_image_id();
        $gallery_ids = $product->get_gallery_image_ids();
        
        $images = array();
        if ($image_id) {
            $images[] = array(
                'id' => $image_id,
                'url' => wp_get_attachment_url($image_id),
                'thumbnail' => wp_get_attachment_image_url($image_id, 'thumbnail'),
                'medium' => wp_get_attachment_image_url($image_id, 'medium'),
                'large' => wp_get_attachment_image_url($image_id, 'large'),
            );
        }
        
        foreach ($gallery_ids as $gid) {
            $images[] = array(
                'id' => $gid,
                'url' => wp_get_attachment_url($gid),
                'thumbnail' => wp_get_attachment_image_url($gid, 'thumbnail'),
                'medium' => wp_get_attachment_image_url($gid, 'medium'),
            );
        }
        
        // Auto-detect type from name if not set
        $camp_type = get_post_meta($id, '_ptp_camp_type', true);
        if (empty($camp_type)) {
            $name_lower = strtolower($product->get_name());
            if (strpos($name_lower, 'clinic') !== false) {
                $camp_type = 'clinic';
            } elseif (strpos($name_lower, 'academy') !== false) {
                $camp_type = 'academy';
            } else {
                $camp_type = 'camp';
            }
        }
        
        $data = array(
            'id' => $id,
            'name' => $product->get_name(),
            'slug' => $post->post_name,
            'type' => $camp_type,
            'short_description' => $product->get_short_description(),
            'price' => (float) $product->get_price(),
            'regular_price' => (float) $product->get_regular_price(),
            'sale_price' => $product->get_sale_price() ? (float) $product->get_sale_price() : null,
            'on_sale' => $product->is_on_sale(),
            'featured_image' => !empty($images) ? $images[0] : null,
            'start_date' => get_post_meta($id, '_ptp_start_date', true),
            'end_date' => get_post_meta($id, '_ptp_end_date', true),
            'location_name' => get_post_meta($id, '_ptp_location_name', true),
            'address' => get_post_meta($id, '_ptp_address', true),
            'city' => get_post_meta($id, '_ptp_city', true),
            'state' => get_post_meta($id, '_ptp_state', true),
            'age_groups' => get_post_meta($id, '_ptp_age_groups', true) ?: array(),
            'skill_levels' => get_post_meta($id, '_ptp_skill_levels', true) ?: array(),
            'is_featured' => $product->is_featured(),
            'available' => $product->is_in_stock(),
        );
        
        if ($full_details) {
            $data['description'] = $product->get_description();
            $data['images'] = $images;
            $data['daily_times'] = get_post_meta($id, '_ptp_daily_times', true);
            $data['max_capacity'] = (int) get_post_meta($id, '_ptp_max_capacity', true);
            $data['spots_remaining'] = max(0, $data['max_capacity'] - (int) get_post_meta($id, '_ptp_sold_count', true));
            $data['coaches'] = get_post_meta($id, '_ptp_coaches', true) ?: array();
            $data['what_to_bring'] = get_post_meta($id, '_ptp_what_to_bring', true);
            $data['included'] = get_post_meta($id, '_ptp_included', true);
            $data['latitude'] = (float) get_post_meta($id, '_ptp_latitude', true);
            $data['longitude'] = (float) get_post_meta($id, '_ptp_longitude', true);
            $data['contact_email'] = get_post_meta($id, '_ptp_contact_email', true);
            $data['contact_phone'] = get_post_meta($id, '_ptp_contact_phone', true);
            
            // Categories
            $cats = wp_get_post_terms($id, 'product_cat');
            $data['categories'] = array_map(function($cat) {
                return array('id' => $cat->term_id, 'name' => $cat->name, 'slug' => $cat->slug);
            }, $cats);
        }
        
        return $data;
    }
}

// Initialize
PTP_Camps_API::init();
