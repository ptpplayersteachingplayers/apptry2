<?php
/**
 * Coach Application Form - v7.1
 * TeachMeTo-inspired design with PTP branding
 * Split-screen hero + professional multi-section form
 */

defined('ABSPATH') || exit;

// Handle form submission
$submitted = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_application_nonce'])) {
    if (wp_verify_nonce($_POST['ptp_application_nonce'], 'ptp_application_submit')) {
        global $wpdb;
        
        // Ensure table exists
        $table_name = $wpdb->prefix . 'ptp_applications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
            // Create table if it doesn't exist
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                email varchar(255) NOT NULL,
                first_name varchar(100) NOT NULL,
                last_name varchar(100) NOT NULL,
                phone varchar(50),
                role_type varchar(50) DEFAULT 'trainer',
                experience_summary text,
                playing_background text,
                coaching_experience text,
                certifications text,
                location_city varchar(100),
                location_state varchar(50),
                location_zip varchar(20),
                intro_video_url varchar(500),
                resume_url varchar(500),
                instagram_handle varchar(100),
                referral_source varchar(255),
                why_join text,
                availability_notes text,
                status varchar(20) DEFAULT 'pending',
                admin_notes text,
                reviewed_by bigint(20) UNSIGNED,
                reviewed_at datetime,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY email (email),
                KEY status (status)
            ) $charset_collate;";
            dbDelta($sql);
        }
        
        // Validate required fields
        $required = array('first_name', 'last_name', 'email', 'phone');
        $missing = array();
        
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                $missing[] = $field;
            }
        }
        
        if (!empty($missing)) {
            $error = 'Please fill in all required fields.';
        } elseif (!is_email($_POST['email'])) {
            $error = 'Please enter a valid email address.';
        } else {
            // Check if email already exists
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}ptp_applications WHERE email = %s",
                sanitize_email($_POST['email'])
            ));
            
            if ($exists) {
                $error = 'An application with this email already exists. We\'ll be in touch soon!';
            } else {
                // Insert application
                $result = $wpdb->insert(
                    "{$wpdb->prefix}ptp_applications",
                    array(
                        'email' => sanitize_email($_POST['email']),
                        'first_name' => sanitize_text_field($_POST['first_name']),
                        'last_name' => sanitize_text_field($_POST['last_name']),
                        'phone' => sanitize_text_field($_POST['phone']),
                        'role_type' => 'trainer',
                        'playing_background' => sanitize_textarea_field($_POST['playing_background'] ?? ''),
                        'coaching_experience' => sanitize_textarea_field($_POST['coaching_experience'] ?? ''),
                        'certifications' => sanitize_text_field($_POST['certifications'] ?? ''),
                        'location_city' => sanitize_text_field($_POST['location_city'] ?? ''),
                        'location_state' => sanitize_text_field($_POST['location_state'] ?? ''),
                        'location_zip' => sanitize_text_field($_POST['location_zip'] ?? ''),
                        'intro_video_url' => esc_url_raw($_POST['intro_video_url'] ?? ''),
                        'instagram_handle' => sanitize_text_field($_POST['instagram_handle'] ?? ''),
                        'referral_source' => sanitize_text_field($_POST['referral_source'] ?? ''),
                        'why_join' => sanitize_textarea_field($_POST['why_join'] ?? ''),
                        'status' => 'pending',
                        'created_at' => current_time('mysql')
                    )
                );
                
                if ($result) {
                    $submitted = true;
                    
                    // Notify admin
                    $admin_email = get_option('admin_email');
                    $name = sanitize_text_field($_POST['first_name']) . ' ' . sanitize_text_field($_POST['last_name']);
                    $subject = "New Coach Application: $name";
                    $message = "New coach application received.\n\n";
                    $message .= "Name: $name\n";
                    $message .= "Email: " . sanitize_email($_POST['email']) . "\n";
                    $message .= "Phone: " . sanitize_text_field($_POST['phone']) . "\n";
                    $message .= "Location: " . sanitize_text_field($_POST['location_city'] ?? '') . ", " . sanitize_text_field($_POST['location_state'] ?? '') . "\n\n";
                    $message .= "Review applications: " . admin_url('admin.php?page=ptp-training-applications');
                    wp_mail($admin_email, $subject, $message);
                } else {
                    $error = 'Something went wrong. Please try again or email us directly.';
                }
            }
        }
    }
}

// Get dynamic stats
global $wpdb;
$trainer_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_trainers WHERE status = 'approved'");
$trainer_count = max(intval($trainer_count), 10); // Minimum display

$hero_image = 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1797.jpg';
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Become a Coach - PTP Soccer</title>
    <?php wp_head(); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,600;9..40,700;9..40,800;9..40,900&display=swap" rel="stylesheet">
    <link rel="preload" as="image" href="<?php echo esc_url($hero_image); ?>">
    <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    
    body.ptp-app-body {
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        background: #fff;
        color: #0E0F11;
        -webkit-font-smoothing: antialiased;
        overflow-x: hidden;
    }
    
    /* Hide ALL theme elements */
    body.ptp-app-body #starter-starter > header,
    body.ptp-app-body .starter-header,
    body.ptp-app-body header.site-header,
    body.ptp-app-body #masthead,
    body.ptp-app-body .ast-header,
    body.ptp-app-body footer.site-footer,
    body.ptp-app-body .site-footer,
    body.ptp-app-body #colophon,
    body.ptp-app-body .starter-starter > footer { display: none !important; }
    
    .ptp-app-page { min-height: 100vh; }
    
    /* Split Layout */
    .ptp-split {
        display: grid;
        grid-template-columns: 1fr 1fr;
        min-height: 100vh;
    }
    
    /* Left: Hero Image */
    .ptp-split-image {
        position: relative;
        background: url('<?php echo esc_url($hero_image); ?>') center center / cover no-repeat;
        display: flex;
        flex-direction: column;
        justify-content: flex-end;
        padding: 48px;
    }
    
    .ptp-split-image::before {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(to top, rgba(14,15,17,0.9) 0%, rgba(14,15,17,0.3) 50%, rgba(14,15,17,0.1) 100%);
    }
    
    .ptp-image-content {
        position: relative;
        z-index: 1;
        color: #fff;
    }
    
    .ptp-image-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 18px;
        background: rgba(252,185,0,0.15);
        border: 1px solid rgba(252,185,0,0.4);
        border-radius: 100px;
        font-size: 13px;
        font-weight: 700;
        color: #FCB900;
        margin-bottom: 20px;
    }
    
    .ptp-image-title {
        font-size: 48px;
        font-weight: 900;
        line-height: 1.1;
        margin-bottom: 16px;
        letter-spacing: -1px;
    }
    
    .ptp-image-subtitle {
        font-size: 18px;
        color: rgba(255,255,255,0.8);
        line-height: 1.6;
        max-width: 500px;
    }
    
    .ptp-testimonial {
        margin-top: 40px;
        padding: 24px;
        background: rgba(255,255,255,0.05);
        border: 1px solid rgba(255,255,255,0.1);
        border-radius: 16px;
        backdrop-filter: blur(10px);
    }
    
    .ptp-testimonial-text {
        font-size: 16px;
        font-style: italic;
        color: rgba(255,255,255,0.9);
        line-height: 1.6;
        margin-bottom: 16px;
    }
    
    .ptp-testimonial-author {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .ptp-testimonial-avatar {
        width: 44px;
        height: 44px;
        background: #FCB900;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
        color: #0E0F11;
        font-size: 16px;
    }
    
    .ptp-testimonial-name {
        font-weight: 700;
        color: #fff;
        font-size: 15px;
    }
    
    .ptp-testimonial-role {
        font-size: 13px;
        color: rgba(255,255,255,0.6);
    }
    
    /* Right: Form */
    .ptp-split-form {
        display: flex;
        flex-direction: column;
        background: #fff;
        overflow-y: auto;
        max-height: 100vh;
    }
    
    /* Header */
    .ptp-form-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 20px 48px;
        border-bottom: 1px solid #E5E7EB;
        position: sticky;
        top: 0;
        background: #fff;
        z-index: 10;
    }
    
    .ptp-form-header img { height: 36px; }
    
    .ptp-form-header a.login-link {
        color: #6B7280;
        text-decoration: none;
        font-weight: 600;
        font-size: 14px;
        transition: color 0.2s;
    }
    
    .ptp-form-header a.login-link:hover { color: #FCB900; }
    
    /* Form Container */
    .ptp-form-wrap {
        flex: 1;
        padding: 40px 48px 48px;
        max-width: 560px;
    }
    
    .ptp-form-intro {
        margin-bottom: 32px;
    }
    
    .ptp-form-intro h1 {
        font-size: 32px;
        font-weight: 900;
        margin-bottom: 8px;
        letter-spacing: -0.5px;
    }
    
    .ptp-form-intro h1 span { color: #FCB900; }
    
    .ptp-form-intro p {
        font-size: 16px;
        color: #6B7280;
        line-height: 1.5;
    }
    
    /* Form */
    .ptp-form { display: flex; flex-direction: column; gap: 20px; }
    
    .ptp-form-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }
    
    .ptp-form-group { display: flex; flex-direction: column; gap: 6px; }
    
    .ptp-form-group label {
        font-size: 14px;
        font-weight: 600;
        color: #374151;
    }
    
    .ptp-form-group label .req { color: #EF4444; }
    
    .ptp-form-group input,
    .ptp-form-group select,
    .ptp-form-group textarea {
        padding: 14px 16px;
        border: 2px solid #E5E7EB;
        border-radius: 10px;
        font-size: 15px;
        font-family: inherit;
        transition: all 0.2s;
        background: #fff;
        width: 100%;
    }
    
    .ptp-form-group input:focus,
    .ptp-form-group select:focus,
    .ptp-form-group textarea:focus {
        border-color: #FCB900;
        outline: none;
        box-shadow: 0 0 0 4px rgba(252,185,0,0.1);
    }
    
    .ptp-form-group input::placeholder,
    .ptp-form-group textarea::placeholder { color: #9CA3AF; }
    
    .ptp-form-group textarea { min-height: 100px; resize: vertical; }
    
    .ptp-form-group .hint {
        font-size: 12px;
        color: #9CA3AF;
        margin-top: 4px;
    }
    
    /* Section */
    .ptp-section {
        display: flex;
        align-items: center;
        gap: 12px;
        margin: 12px 0 4px;
        padding-top: 16px;
        border-top: 1px solid #F3F4F6;
    }
    
    .ptp-section:first-of-type { border-top: none; margin-top: 0; padding-top: 0; }
    
    .ptp-section-icon {
        width: 32px;
        height: 32px;
        background: #FEFCE8;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    
    .ptp-section-icon svg { width: 18px; height: 18px; stroke: #CA8A04; }
    
    .ptp-section h3 {
        font-size: 15px;
        font-weight: 700;
        color: #0E0F11;
    }
    
    /* Submit */
    .ptp-submit {
        width: 100%;
        padding: 16px 32px;
        background: #FCB900;
        color: #0E0F11;
        font-size: 16px;
        font-weight: 800;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        transition: all 0.2s;
        margin-top: 8px;
    }
    
    .ptp-submit:hover {
        background: #E5A800;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(252,185,0,0.3);
    }
    
    .ptp-submit:disabled {
        opacity: 0.6;
        cursor: not-allowed;
        transform: none;
    }
    
    .ptp-form-footer {
        font-size: 12px;
        color: #9CA3AF;
        text-align: center;
        margin-top: 16px;
    }
    
    /* Messages */
    .ptp-msg {
        padding: 14px 18px;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 20px;
    }
    
    .ptp-msg-error { background: #FEE2E2; color: #991B1B; }
    .ptp-msg-success { background: #D1FAE5; color: #065F46; }
    
    /* Success State */
    .ptp-success {
        text-align: center;
        padding: 80px 20px;
    }
    
    .ptp-success-icon {
        width: 80px;
        height: 80px;
        background: linear-gradient(135deg, #FCB900, #F59E0B);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 24px;
        box-shadow: 0 10px 30px rgba(252,185,0,0.3);
    }
    
    .ptp-success-icon svg { width: 40px; height: 40px; stroke: #0E0F11; stroke-width: 3; }
    
    .ptp-success h2 {
        font-size: 32px;
        font-weight: 800;
        margin-bottom: 12px;
    }
    
    .ptp-success p {
        font-size: 16px;
        color: #6B7280;
        line-height: 1.6;
        max-width: 400px;
        margin: 0 auto 32px;
    }
    
    .ptp-success-btn {
        display: inline-flex;
        padding: 14px 28px;
        background: #0E0F11;
        color: #fff;
        text-decoration: none;
        border-radius: 10px;
        font-weight: 700;
        transition: all 0.2s;
    }
    
    .ptp-success-btn:hover { background: #1F2937; transform: translateY(-2px); }
    
    /* Mobile */
    @media (max-width: 1024px) {
        .ptp-split { grid-template-columns: 1fr; }
        
        .ptp-split-image {
            min-height: 50vh;
            padding: 32px 24px;
        }
        
        .ptp-image-title { font-size: 36px; }
        .ptp-testimonial { display: none; }
        .ptp-form-header { padding: 16px 24px; }
        .ptp-form-wrap { padding: 32px 24px; }
        .ptp-form-row { grid-template-columns: 1fr; }
    }
    
    @media (max-width: 640px) {
        .ptp-split-image { min-height: 40vh; padding: 24px 20px; }
        .ptp-image-title { font-size: 28px; }
        .ptp-image-subtitle { font-size: 15px; }
        .ptp-form-header { padding: 14px 20px; }
        .ptp-form-wrap { padding: 24px 20px; }
        .ptp-form-intro h1 { font-size: 26px; }
    }
    </style>
</head>
<body class="ptp-app-body">
    <div class="ptp-app-page">
        <div class="ptp-split">
            <!-- Left: Hero Image -->
            <div class="ptp-split-image">
                <div class="ptp-image-content">
                    <div class="ptp-image-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                        Teaching What Team Coaches Don't
                    </div>
                    
                    <h1 class="ptp-image-title">Train the Next Generation</h1>
                    <p class="ptp-image-subtitle">Join <?php echo esc_html($trainer_count); ?>+ coaches across PA, NJ, DE, MD & NY helping young athletes develop skills that set them apart.</p>
                    
                    <div class="ptp-testimonial">
                        <p class="ptp-testimonial-text">"Coaching with PTP lets me give back to the game while earning on my own schedule. The platform handles everything - I just focus on training."</p>
                        <div class="ptp-testimonial-author">
                            <div class="ptp-testimonial-avatar">L</div>
                            <div>
                                <div class="ptp-testimonial-name">Luke, Founder</div>
                                <div class="ptp-testimonial-role">Former Philadelphia Union Academy</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Right: Form -->
            <div class="ptp-split-form">
                <header class="ptp-form-header">
                    <a href="<?php echo home_url(); ?>">
                        <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer">
                    </a>
                    <a href="<?php echo home_url('/login/'); ?>" class="login-link">Already a coach? Log in →</a>
                </header>
                
                <div class="ptp-form-wrap">
                    <?php if ($submitted): ?>
                        <div class="ptp-success">
                            <div class="ptp-success-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
                                    <path d="M20 6L9 17l-5-5"/>
                                </svg>
                            </div>
                            <h2>Application Received!</h2>
                            <p>Thanks for applying to coach with PTP. We review applications within 2-3 business days and will reach out via email.</p>
                            <a href="<?php echo home_url(); ?>" class="ptp-success-btn">Back to Home</a>
                        </div>
                    <?php else: ?>
                        <div class="ptp-form-intro">
                            <h1>Apply to <span>Coach</span></h1>
                            <p>Share your experience and start training athletes in your area.</p>
                        </div>
                        
                        <?php if ($error): ?>
                            <div class="ptp-msg ptp-msg-error"><?php echo esc_html($error); ?></div>
                        <?php endif; ?>
                        
                        <form class="ptp-form" method="POST" id="ptp-app-form">
                            <?php wp_nonce_field('ptp_application_submit', 'ptp_application_nonce'); ?>
                            
                            <!-- Contact Info -->
                            <div class="ptp-section">
                                <div class="ptp-section-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2">
                                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                                    </svg>
                                </div>
                                <h3>Contact Info</h3>
                            </div>
                            
                            <div class="ptp-form-row">
                                <div class="ptp-form-group">
                                    <label>First Name <span class="req">*</span></label>
                                    <input type="text" name="first_name" required placeholder="John" value="<?php echo esc_attr($_POST['first_name'] ?? ''); ?>">
                                </div>
                                <div class="ptp-form-group">
                                    <label>Last Name <span class="req">*</span></label>
                                    <input type="text" name="last_name" required placeholder="Smith" value="<?php echo esc_attr($_POST['last_name'] ?? ''); ?>">
                                </div>
                            </div>
                            
                            <div class="ptp-form-row">
                                <div class="ptp-form-group">
                                    <label>Email <span class="req">*</span></label>
                                    <input type="email" name="email" required placeholder="john@example.com" value="<?php echo esc_attr($_POST['email'] ?? ''); ?>">
                                </div>
                                <div class="ptp-form-group">
                                    <label>Phone <span class="req">*</span></label>
                                    <input type="tel" name="phone" required placeholder="(555) 123-4567" value="<?php echo esc_attr($_POST['phone'] ?? ''); ?>">
                                </div>
                            </div>
                            
                            <!-- Location -->
                            <div class="ptp-section">
                                <div class="ptp-section-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2">
                                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                                    </svg>
                                </div>
                                <h3>Training Location</h3>
                            </div>
                            
                            <div class="ptp-form-row">
                                <div class="ptp-form-group">
                                    <label>City</label>
                                    <input type="text" name="location_city" placeholder="Philadelphia" value="<?php echo esc_attr($_POST['location_city'] ?? ''); ?>">
                                </div>
                                <div class="ptp-form-group">
                                    <label>State</label>
                                    <select name="location_state">
                                        <option value="">Select State</option>
                                        <option value="PA" <?php selected($_POST['location_state'] ?? '', 'PA'); ?>>Pennsylvania</option>
                                        <option value="NJ" <?php selected($_POST['location_state'] ?? '', 'NJ'); ?>>New Jersey</option>
                                        <option value="DE" <?php selected($_POST['location_state'] ?? '', 'DE'); ?>>Delaware</option>
                                        <option value="MD" <?php selected($_POST['location_state'] ?? '', 'MD'); ?>>Maryland</option>
                                        <option value="NY" <?php selected($_POST['location_state'] ?? '', 'NY'); ?>>New York</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="ptp-form-group" style="max-width: 200px;">
                                <label>ZIP Code</label>
                                <input type="text" name="location_zip" placeholder="19103" maxlength="10" value="<?php echo esc_attr($_POST['location_zip'] ?? ''); ?>">
                            </div>
                            
                            <!-- Experience -->
                            <div class="ptp-section">
                                <div class="ptp-section-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2">
                                        <circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>
                                    </svg>
                                </div>
                                <h3>Your Experience</h3>
                            </div>
                            
                            <div class="ptp-form-group">
                                <label>Playing Background</label>
                                <textarea name="playing_background" placeholder="Tell us about your soccer career - teams, level of play, positions, achievements..."><?php echo esc_textarea($_POST['playing_background'] ?? ''); ?></textarea>
                                <span class="hint">Current or former teams, positions played, notable achievements</span>
                            </div>
                            
                            <div class="ptp-form-group">
                                <label>Coaching/Training Experience</label>
                                <textarea name="coaching_experience" placeholder="Any experience coaching, mentoring, or training younger players..."><?php echo esc_textarea($_POST['coaching_experience'] ?? ''); ?></textarea>
                            </div>
                            
                            <div class="ptp-form-group">
                                <label>Certifications</label>
                                <input type="text" name="certifications" placeholder="USSF, USC, CPR, etc." value="<?php echo esc_attr($_POST['certifications'] ?? ''); ?>">
                            </div>
                            
                            <!-- Optional -->
                            <div class="ptp-section">
                                <div class="ptp-section-icon">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke-width="2">
                                        <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                                        <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
                                    </svg>
                                </div>
                                <h3>Additional Info (Optional)</h3>
                            </div>
                            
                            <div class="ptp-form-row">
                                <div class="ptp-form-group">
                                    <label>Instagram</label>
                                    <input type="text" name="instagram_handle" placeholder="@yourhandle" value="<?php echo esc_attr($_POST['instagram_handle'] ?? ''); ?>">
                                </div>
                                <div class="ptp-form-group">
                                    <label>How'd you hear about us?</label>
                                    <select name="referral_source">
                                        <option value="">Select one</option>
                                        <option value="instagram" <?php selected($_POST['referral_source'] ?? '', 'instagram'); ?>>Instagram</option>
                                        <option value="friend" <?php selected($_POST['referral_source'] ?? '', 'friend'); ?>>Friend/Teammate</option>
                                        <option value="coach" <?php selected($_POST['referral_source'] ?? '', 'coach'); ?>>Coach</option>
                                        <option value="google" <?php selected($_POST['referral_source'] ?? '', 'google'); ?>>Google</option>
                                        <option value="camp" <?php selected($_POST['referral_source'] ?? '', 'camp'); ?>>Attended PTP Camp</option>
                                        <option value="other" <?php selected($_POST['referral_source'] ?? '', 'other'); ?>>Other</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div class="ptp-form-group">
                                <label>Intro Video URL</label>
                                <input type="url" name="intro_video_url" placeholder="YouTube, Vimeo, or Instagram link" value="<?php echo esc_attr($_POST['intro_video_url'] ?? ''); ?>">
                                <span class="hint">A short video helps your application stand out</span>
                            </div>
                            
                            <div class="ptp-form-group">
                                <label>Why do you want to coach with PTP?</label>
                                <textarea name="why_join" placeholder="What motivates you to train young athletes?"><?php echo esc_textarea($_POST['why_join'] ?? ''); ?></textarea>
                            </div>
                            
                            <button type="submit" class="ptp-submit" id="submit-btn">Submit Application</button>
                            
                            <p class="ptp-form-footer">
                                By submitting, you agree to our terms and background check policy.
                            </p>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('ptp-app-form');
        const btn = document.getElementById('submit-btn');
        
        if (form && btn) {
            form.addEventListener('submit', function() {
                btn.disabled = true;
                btn.textContent = 'Submitting...';
            });
        }
        
        // Format phone number
        const phoneInput = document.querySelector('input[name="phone"]');
        if (phoneInput) {
            phoneInput.addEventListener('input', function(e) {
                let val = e.target.value.replace(/\D/g, '');
                if (val.length >= 6) {
                    val = '(' + val.substring(0,3) + ') ' + val.substring(3,6) + '-' + val.substring(6,10);
                } else if (val.length >= 3) {
                    val = '(' + val.substring(0,3) + ') ' + val.substring(3);
                }
                e.target.value = val;
            });
        }
    });
    </script>
    
    <?php wp_footer(); ?>
</body>
</html>
<?php exit; ?>
