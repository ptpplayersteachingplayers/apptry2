<?php
/**
 * PTP Custom Login Page
 * Professional login/password reset matching PTP branding
 * 
 * Shortcode: [ptp_login]
 * Handles: Login, Password Reset Request, Password Reset
 */

defined('ABSPATH') || exit;

// If already logged in, redirect
if (is_user_logged_in() && !isset($_GET['action'])) {
    $current_user = wp_get_current_user();
    
    // Check if trainer
    global $wpdb;
    $is_trainer = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
        $current_user->ID
    ));
    
    if ($is_trainer) {
        wp_redirect(home_url('/trainer-dashboard/'));
    } else {
        wp_redirect(home_url('/my-training/'));
    }
    exit;
}

// Determine action
$action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'login';
$error_message = '';
$success_message = '';

// Process login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_login_nonce'])) {
    if (wp_verify_nonce($_POST['ptp_login_nonce'], 'ptp_login')) {
        $creds = array(
            'user_login' => sanitize_text_field($_POST['log']),
            'user_password' => $_POST['pwd'],
            'remember' => isset($_POST['rememberme'])
        );
        
        $user = wp_signon($creds, is_ssl());
        
        if (is_wp_error($user)) {
            $error_message = 'Invalid email/username or password.';
        } else {
            // Check if trainer
            global $wpdb;
            $is_trainer = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
                $user->ID
            ));
            
            $redirect = isset($_POST['redirect_to']) ? esc_url($_POST['redirect_to']) : '';
            if (empty($redirect)) {
                $redirect = $is_trainer ? home_url('/trainer-dashboard/') : home_url('/my-training/');
            }
            
            wp_redirect($redirect);
            exit;
        }
    }
}

// Process password reset request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_reset_nonce'])) {
    if (wp_verify_nonce($_POST['ptp_reset_nonce'], 'ptp_reset')) {
        $user_login = sanitize_text_field($_POST['user_login']);
        $user = get_user_by('email', $user_login);
        
        if (!$user) {
            $user = get_user_by('login', $user_login);
        }
        
        if ($user) {
            $reset_key = get_password_reset_key($user);
            if (!is_wp_error($reset_key)) {
                $reset_url = home_url("/login/?action=rp&key=$reset_key&login=" . rawurlencode($user->user_login));
                
                // Send email
                $subject = 'Password Reset - PTP Soccer';
                $message = "Hi,\n\nYou requested a password reset for your PTP account.\n\n";
                $message .= "Click here to reset your password:\n{$reset_url}\n\n";
                $message .= "If you didn't request this, you can ignore this email.\n\n";
                $message .= "- PTP Soccer Team";
                
                wp_mail($user->user_email, $subject, $message);
            }
        }
        
        // Always show success to prevent email enumeration
        $success_message = 'If an account exists with that email, you will receive password reset instructions.';
        $action = 'login';
    }
}

// Process password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_newpass_nonce'])) {
    if (wp_verify_nonce($_POST['ptp_newpass_nonce'], 'ptp_newpass')) {
        $rp_key = sanitize_text_field($_POST['rp_key']);
        $rp_login = sanitize_text_field($_POST['rp_login']);
        $pass1 = $_POST['pass1'];
        $pass2 = $_POST['pass2'];
        
        $user = check_password_reset_key($rp_key, $rp_login);
        
        if (is_wp_error($user)) {
            $error_message = 'This password reset link has expired or is invalid. Please request a new one.';
            $action = 'lostpassword';
        } elseif ($pass1 !== $pass2) {
            $error_message = 'Passwords do not match.';
            $action = 'rp';
        } elseif (strlen($pass1) < 8) {
            $error_message = 'Password must be at least 8 characters.';
            $action = 'rp';
        } else {
            reset_password($user, $pass1);
            $success_message = 'Your password has been reset! You can now log in.';
            $action = 'login';
        }
    }
}

// Handle password reset link from email
if ($action === 'rp' && isset($_GET['key']) && isset($_GET['login'])) {
    $rp_key = sanitize_text_field($_GET['key']);
    $rp_login = sanitize_text_field($_GET['login']);
    
    $user = check_password_reset_key($rp_key, $rp_login);
    
    if (is_wp_error($user)) {
        $error_message = 'This password reset link has expired or is invalid. Please request a new one.';
        $action = 'lostpassword';
    }
}

$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
$redirect_to = isset($_GET['redirect_to']) ? esc_url($_GET['redirect_to']) : '';
?>

<style>
body:has(.ptp-login-wrap) #starter-starter > header,
body:has(.ptp-login-wrap) .starter-header,
body:has(.ptp-login-wrap) header.site-header { display: none !important; }
body:has(.ptp-login-wrap) footer { display: none !important; }

.ptp-login-wrap {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%);
    padding: 40px 20px;
    font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
}

.ptp-login-card {
    background: #fff;
    border-radius: 24px;
    padding: 48px;
    max-width: 440px;
    width: 100%;
    box-shadow: 0 20px 60px rgba(0,0,0,0.3);
}

.ptp-login-header {
    text-align: center;
    margin-bottom: 32px;
}

.ptp-login-logo {
    height: 50px;
    margin-bottom: 24px;
}

.ptp-login-title {
    font-size: 28px;
    font-weight: 800;
    margin: 0 0 8px 0;
    color: #0E0F11;
}

.ptp-login-subtitle {
    color: #6B7280;
    margin: 0;
    font-size: 15px;
}

.ptp-login-form label {
    display: block;
    font-weight: 600;
    font-size: 14px;
    color: #374151;
    margin-bottom: 6px;
}

.ptp-login-form input[type="text"],
.ptp-login-form input[type="email"],
.ptp-login-form input[type="password"] {
    width: 100%;
    padding: 14px 16px;
    border: 2px solid #E5E7EB;
    border-radius: 12px;
    font-size: 16px;
    margin-bottom: 16px;
    transition: border-color 0.2s;
    box-sizing: border-box;
}

.ptp-login-form input:focus {
    border-color: #FCB900;
    outline: none;
}

.ptp-login-form input[type="submit"],
.ptp-login-btn {
    width: 100%;
    padding: 16px;
    background: #FCB900;
    color: #0E0F11;
    font-size: 16px;
    font-weight: 700;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    transition: background 0.2s;
}

.ptp-login-form input[type="submit"]:hover,
.ptp-login-btn:hover {
    background: #E5A800;
}

.ptp-login-remember {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 20px;
    font-size: 14px;
    color: #6B7280;
}

.ptp-login-remember input {
    width: auto;
    margin: 0;
}

.ptp-login-links {
    margin-top: 16px;
    text-align: center;
}

.ptp-login-links a {
    color: #FCB900;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
}

.ptp-login-links a:hover {
    text-decoration: underline;
}

.ptp-login-error {
    background: #FEE2E2;
    color: #991B1B;
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 14px;
    font-weight: 500;
}

.ptp-login-success {
    background: #D1FAE5;
    color: #065F46;
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 14px;
    font-weight: 500;
}

.ptp-login-footer {
    margin-top: 24px;
    padding-top: 24px;
    border-top: 1px solid #E5E7EB;
    text-align: center;
}

.ptp-login-footer p {
    color: #6B7280;
    font-size: 14px;
    margin: 0;
}

.ptp-login-footer a {
    color: #FCB900;
    font-weight: 600;
    text-decoration: none;
}

.ptp-back-link {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    color: #FCB900;
    text-decoration: none;
    font-size: 14px;
    font-weight: 600;
    margin-bottom: 24px;
}

.ptp-password-requirements {
    font-size: 13px;
    color: #6B7280;
    margin: -8px 0 16px 0;
}

@media (max-width: 480px) {
    .ptp-login-card {
        padding: 32px 24px;
    }
    .ptp-login-title {
        font-size: 24px;
    }
}
</style>

<div class="ptp-login-wrap ptp-page-wrap">
    <div class="ptp-login-card">
        
        <?php if ($action === 'login'): ?>
            <!-- LOGIN FORM -->
            <div class="ptp-login-header">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer" class="ptp-login-logo">
                <h1 class="ptp-login-title">Welcome Back</h1>
                <p class="ptp-login-subtitle">Sign in to your PTP account</p>
            </div>
            
            <?php if ($error_message): ?>
                <div class="ptp-login-error"><?php echo esc_html($error_message); ?></div>
            <?php endif; ?>
            
            <?php if ($success_message): ?>
                <div class="ptp-login-success"><?php echo esc_html($success_message); ?></div>
            <?php endif; ?>
            
            <form method="post" class="ptp-login-form">
                <?php wp_nonce_field('ptp_login', 'ptp_login_nonce'); ?>
                <input type="hidden" name="redirect_to" value="<?php echo esc_attr($redirect_to); ?>">
                
                <label for="user_login">Email or Username</label>
                <input type="text" name="log" id="user_login" autocomplete="username" required>
                
                <label for="user_pass">Password</label>
                <input type="password" name="pwd" id="user_pass" autocomplete="current-password" required>
                
                <label class="ptp-login-remember">
                    <input type="checkbox" name="rememberme" value="forever">
                    Remember me
                </label>
                
                <input type="submit" value="Sign In">
                
                <div class="ptp-login-links">
                    <a href="?action=lostpassword">Forgot your password?</a>
                </div>
            </form>
            
            <div class="ptp-login-footer">
                <p>Don't have an account? <a href="<?php echo home_url('/coach-application/'); ?>">Apply to be a trainer</a></p>
            </div>
            
        <?php elseif ($action === 'lostpassword'): ?>
            <!-- PASSWORD RESET REQUEST -->
            <a href="<?php echo home_url('/login/'); ?>" class="ptp-back-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to login
            </a>
            
            <div class="ptp-login-header">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer" class="ptp-login-logo">
                <h1 class="ptp-login-title">Reset Password</h1>
                <p class="ptp-login-subtitle">Enter your email to receive reset instructions</p>
            </div>
            
            <?php if ($error_message): ?>
                <div class="ptp-login-error"><?php echo esc_html($error_message); ?></div>
            <?php endif; ?>
            
            <form method="post" class="ptp-login-form">
                <?php wp_nonce_field('ptp_reset', 'ptp_reset_nonce'); ?>
                
                <label for="user_login">Email Address</label>
                <input type="email" name="user_login" id="user_login" autocomplete="email" required>
                
                <input type="submit" value="Send Reset Link">
            </form>
            
        <?php elseif ($action === 'rp'): ?>
            <!-- SET NEW PASSWORD -->
            <a href="<?php echo home_url('/login/'); ?>" class="ptp-back-link">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to login
            </a>
            
            <div class="ptp-login-header">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer" class="ptp-login-logo">
                <h1 class="ptp-login-title">Set New Password</h1>
                <p class="ptp-login-subtitle">Create a secure password for your account</p>
            </div>
            
            <?php if ($error_message): ?>
                <div class="ptp-login-error"><?php echo esc_html($error_message); ?></div>
            <?php endif; ?>
            
            <form method="post" class="ptp-login-form">
                <?php wp_nonce_field('ptp_newpass', 'ptp_newpass_nonce'); ?>
                <input type="hidden" name="rp_key" value="<?php echo esc_attr($_GET['key'] ?? ''); ?>">
                <input type="hidden" name="rp_login" value="<?php echo esc_attr($_GET['login'] ?? ''); ?>">
                
                <label for="pass1">New Password</label>
                <input type="password" name="pass1" id="pass1" autocomplete="new-password" required>
                <p class="ptp-password-requirements">At least 8 characters</p>
                
                <label for="pass2">Confirm Password</label>
                <input type="password" name="pass2" id="pass2" autocomplete="new-password" required>
                
                <input type="submit" value="Set Password">
            </form>
            
        <?php endif; ?>
        
    </div>
</div>
