<?php
/**
 * Private Training Landing Page - v7.0
 * Full-width hero with background image
 * Real data, dynamic stats
 * Mobile-first responsive design
 */

defined('ABSPATH') || exit;

global $wpdb;

// Get real stats from database
$total_trainers = $wpdb->get_var(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_trainers WHERE status = 'approved'"
);

$total_sessions = $wpdb->get_var(
    "SELECT SUM(total_sessions) FROM {$wpdb->prefix}ptp_trainers WHERE status = 'approved'"
) ?: 0;

$avg_rating = $wpdb->get_var(
    "SELECT AVG(avg_rating) FROM {$wpdb->prefix}ptp_trainers WHERE status = 'approved' AND avg_rating > 0"
);
$avg_rating = $avg_rating ? round($avg_rating, 1) : 0;

// Get featured trainers
$featured_trainers = $wpdb->get_results(
    "SELECT * FROM {$wpdb->prefix}ptp_trainers 
     WHERE status = 'approved' 
     ORDER BY is_featured DESC, avg_rating DESC, total_sessions DESC 
     LIMIT 4"
);

// PTP Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';

// Hero background image
$hero_bg = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A7286.jpg';
?>

<style id="ptp-critical-fullwidth">
.ptp-page-wrap, .ptp-landing-wrap { 
    width: 100vw !important; 
    max-width: 100vw !important; 
    margin-left: calc(50% - 50vw) !important; 
    margin-right: calc(50% - 50vw) !important; 
    position: relative !important; 
    background: #fff !important;
    display: block !important;
    padding: 0 !important;
}
.entry-content, .post-content, .page-content, .site-content, .content-area, article, main, #main, #content, .container, .site-main { 
    max-width: 100% !important; 
    width: 100% !important; 
    padding-left: 0 !important; 
    padding-right: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
}
body { overflow-x: hidden !important; }
</style>

<div class="ptp-landing-wrap ptp-page-wrap">
    
    <?php 
    // Include unified header
    $ptp_active_page = 'private-training';
    include PTP_TRAINING_PATH . 'templates/frontend/header-component.php';
    ?>
    
    <!-- Hero Section with Background Image -->
    <section class="ptp-hero" style="background-image: url('<?php echo esc_url($hero_bg); ?>'); min-height: 600px;">
        <div class="ptp-hero-content">
            <div class="ptp-hero-logo">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer">
            </div>
            
            <h1 class="ptp-hero-title">
                Train Like the <span>Pros</span>
            </h1>
            <p class="ptp-hero-subtitle">
                1-on-1 private soccer training with current MLS players and NCAA Division 1 athletes. Teaching what team coaches don't.
            </p>
            
            <div class="ptp-hero-buttons">
                <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-btn-primary">
                    Find Your Trainer
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
                <a href="<?php echo home_url('/coach-application/'); ?>" class="ptp-btn-secondary">
                    Apply to Coach
                </a>
            </div>
            
            <!-- Stats Row -->
            <?php if ($total_trainers > 0 || $total_sessions > 0): ?>
            <div class="ptp-stats-row">
                <?php if ($total_trainers > 0): ?>
                <div class="ptp-stat-item">
                    <div class="ptp-stat-number"><?php echo $total_trainers; ?>+</div>
                    <div class="ptp-stat-label">Elite Trainers</div>
                </div>
                <?php endif; ?>
                
                <?php if ($total_sessions > 0): ?>
                <div class="ptp-stat-item">
                    <div class="ptp-stat-number"><?php echo number_format($total_sessions); ?>+</div>
                    <div class="ptp-stat-label">Sessions Completed</div>
                </div>
                <?php endif; ?>
                
                <?php if ($avg_rating > 0): ?>
                <div class="ptp-stat-item">
                    <div class="ptp-stat-number"><?php echo $avg_rating; ?>★</div>
                    <div class="ptp-stat-label">Avg Rating</div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- How It Works -->
    <section class="ptp-section" style="background: #fff;">
        <div class="ptp-section-inner">
            <div class="ptp-section-header">
                <h2 class="ptp-section-title">How It Works</h2>
                <p class="ptp-section-subtitle">Book your first session in minutes</p>
            </div>
            
            <div class="ptp-how-grid">
                <div class="ptp-how-item">
                    <div class="ptp-how-icon yellow">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    </div>
                    <h3 class="ptp-how-title">1. Find Your Coach</h3>
                    <p class="ptp-how-text">Browse our roster of elite trainers by location, specialty, and availability.</p>
                </div>
                
                <div class="ptp-how-item">
                    <div class="ptp-how-icon black">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    </div>
                    <h3 class="ptp-how-title">2. Book Sessions</h3>
                    <p class="ptp-how-text">Choose a single session or save with a multi-session pack. Schedule at your convenience.</p>
                </div>
                
                <div class="ptp-how-item">
                    <div class="ptp-how-icon green">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </div>
                    <h3 class="ptp-how-title">3. Level Up</h3>
                    <p class="ptp-how-text">Train 1-on-1 with your coach and develop skills that separate you from the competition.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Scrolling Image Gallery -->
    <section class="ptp-gallery-section" style="background: #0E0F11; padding: 60px 0; overflow: hidden;">
        <div style="max-width: 1200px; margin: 0 auto 40px; padding: 0 24px; text-align: center;">
            <h2 style="font-size: 32px; font-weight: 800; color: #fff; margin: 0 0 12px 0;">
                The <span style="color: #FCB900;">PTP</span> Experience
            </h2>
            <p style="font-size: 16px; color: rgba(255,255,255,0.7); margin: 0;">
                Teaching what team coaches don't
            </p>
        </div>
        
        <div class="ptp-gallery-track" style="display: flex; gap: 20px; animation: scrollGallery 40s linear infinite;">
            <?php 
            $gallery_images = [
                'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1595.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A5670.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/11/BG7A8346.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-soccer-clinic-shot-view.jpg.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptpcoach-signing-gear.jpg.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-coach-sam-signing-ball-soccer-camp.jpg-scaled.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptpcoaches-award-ceremony.jpg.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/ptp-guests-signing-2.jpg-scaled.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/BG7A5741.jpg',
                'https://ptpsummercamps.com/wp-content/uploads/2025/09/BG7A5836.jpg',
            ];
            // Double the images for seamless loop
            $all_images = array_merge($gallery_images, $gallery_images);
            foreach ($all_images as $img): 
            ?>
            <div class="ptp-gallery-card" style="flex: 0 0 320px; height: 240px; border-radius: 16px; overflow: hidden; position: relative;">
                <img src="<?php echo esc_url($img); ?>" alt="PTP Training" style="width: 100%; height: 100%; object-fit: cover;" loading="lazy">
                <div style="position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.3) 0%, transparent 50%);"></div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <style>
        @keyframes scrollGallery {
            0% { transform: translateX(0); }
            100% { transform: translateX(calc(-320px * 10 - 200px)); }
        }
        .ptp-gallery-track:hover {
            animation-play-state: paused;
        }
        @media (max-width: 768px) {
            .ptp-gallery-card {
                flex: 0 0 260px !important;
                height: 200px !important;
            }
            @keyframes scrollGallery {
                0% { transform: translateX(0); }
                100% { transform: translateX(calc(-260px * 10 - 200px)); }
            }
        }
        </style>
    </section>
    
    <!-- Featured Trainers -->
    <?php if (!empty($featured_trainers)): ?>
    <section class="ptp-section" style="background: #F9FAFB;">
        <div class="ptp-section-inner">
            <div class="ptp-section-header">
                <h2 class="ptp-section-title">Meet Our <span>Trainers</span></h2>
                <p class="ptp-section-subtitle">MLS players and NCAA D1 athletes ready to help you improve</p>
            </div>
            
            <div class="ptp-trainers-grid">
                <?php foreach ($featured_trainers as $trainer): 
                    $specialties = json_decode($trainer->specialties ?? '[]', true) ?: [];
                    $photo = $trainer->profile_photo ?: 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg';
                    $has_reviews = ($trainer->avg_rating ?? 0) > 0 && ($trainer->total_reviews ?? 0) > 0;
                    $is_mls = stripos($trainer->credentials ?? '', 'MLS') !== false;
                ?>
                <a href="<?php echo home_url('/trainer/'); ?>?id=<?php echo $trainer->id; ?>" class="ptp-trainer-card">
                    <div class="ptp-card-image">
                        <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>" loading="lazy">
                        <?php if ($is_mls): ?>
                        <span class="ptp-card-badge">
                            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
                            MLS
                        </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ptp-card-content">
                        <h3 class="ptp-card-name"><?php echo esc_html($trainer->display_name); ?></h3>
                        <p class="ptp-card-location">
                            <?php 
                                $location = array_filter([
                                    $trainer->primary_location_city,
                                    $trainer->primary_location_state
                                ]);
                                echo esc_html(implode(', ', $location) ?: 'Location TBD');
                            ?>
                        </p>
                        
                        <?php if ($has_reviews): ?>
                        <div class="ptp-card-rating">
                            <span class="star">★</span>
                            <?php echo number_format($trainer->avg_rating, 1); ?>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($specialties)): ?>
                        <div class="ptp-card-tags">
                            <?php foreach (array_slice($specialties, 0, 2) as $spec): ?>
                            <span class="ptp-card-tag"><?php echo esc_html($spec); ?></span>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            
            <div class="ptp-text-center" style="margin-top: 40px;">
                <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-btn-primary" style="background: #0E0F11;">
                    View All Trainers
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
            </div>
        </div>
    </section>
    <?php else: ?>
    <!-- No Trainers Yet -->
    <section class="ptp-section" style="background: #F9FAFB;">
        <div class="ptp-section-inner">
            <div class="ptp-empty-state">
                <div class="ptp-empty-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
                </div>
                <h3 class="ptp-empty-title">Trainers Coming Soon</h3>
                <p class="ptp-empty-text">
                    We're building our network of elite trainers. Are you an MLS player or NCAA D1 athlete? Join our team!
                </p>
                <a href="<?php echo home_url('/coach-application/'); ?>" class="ptp-btn-primary">
                    Apply to Coach
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <!-- Why PTP -->
    <section class="ptp-section" style="background: #fff;">
        <div class="ptp-section-inner">
            <div class="ptp-section-header">
                <h2 class="ptp-section-title">Why Train With <span>PTP</span>?</h2>
                <p class="ptp-section-subtitle">Teaching what team coaches don't</p>
            </div>
            
            <div class="ptp-why-grid">
                <div class="ptp-why-item">
                    <div class="ptp-why-icon" style="background: #FCB900;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                    </div>
                    <h3 class="ptp-why-title">They've Been in Your Shoes</h3>
                    <p class="ptp-why-text">Our trainers are current MLS players and NCAA D1 athletes who understand exactly where you are in your journey. They're mentors, not just coaches.</p>
                </div>
                
                <div class="ptp-why-item">
                    <div class="ptp-why-icon" style="background: #0E0F11;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    </div>
                    <h3 class="ptp-why-title">Real Mentorship</h3>
                    <p class="ptp-why-text">More than just drills. Build a relationship with someone who can guide your development both on and off the field.</p>
                </div>
                
                <div class="ptp-why-item">
                    <div class="ptp-why-icon" style="background: #10B981;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                    </div>
                    <h3 class="ptp-why-title">Vetted & Background Checked</h3>
                    <p class="ptp-why-text">Every PTP trainer is verified, vetted, and background checked. Your child's safety is our top priority.</p>
                </div>
                
                <div class="ptp-why-item">
                    <div class="ptp-why-icon" style="background: #FCB900;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                    </div>
                    <h3 class="ptp-why-title">Secure & Simple</h3>
                    <p class="ptp-why-text">Easy online booking with secure payments. Manage sessions from your parent dashboard.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- CTA Section -->
    <section class="ptp-cta-section">
        <div class="ptp-cta-inner">
            <h2 class="ptp-cta-title">
                Ready to <span>Level Up?</span>
            </h2>
            <p class="ptp-cta-text">
                Join thousands of young athletes who are taking their game to the next level with PTP private training.
            </p>
            <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-btn-primary">
                Find Your Trainer
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </a>
        </div>
    </section>
</div>
