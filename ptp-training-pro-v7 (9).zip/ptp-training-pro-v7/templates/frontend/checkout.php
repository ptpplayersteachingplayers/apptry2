<?php
/**
 * Training Checkout Template - v7.0
 * Full-width layout, improved UX
 * Real data only - NO fake/fallback data
 * WooCommerce/Stripe integration
 */

defined('ABSPATH') || exit;

global $wpdb;

// Get checkout data from URL
$trainer_id = isset($_GET['trainer']) ? intval($_GET['trainer']) : 0;
$package_type = isset($_GET['package']) ? sanitize_text_field($_GET['package']) : 'single';

// Get trainer from database - NO FALLBACK
$trainer = null;
if ($trainer_id) {
    $trainer = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d AND status = 'approved'",
        $trainer_id
    ));
}

// PTP Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';

// Check if trainer exists and has pricing
$hourly_rate = $trainer ? floatval($trainer->hourly_rate) : 0;
$has_valid_trainer = $trainer && $hourly_rate > 0;

// Output critical styles
echo '<style id="ptp-critical-fullwidth">
.ptp-page-wrap, .ptp-checkout-wrap { 
    width: 100vw !important; 
    max-width: 100vw !important; 
    margin-left: calc(50% - 50vw) !important; 
    margin-right: calc(50% - 50vw) !important; 
    position: relative !important; 
    background: #fff !important;
    display: block !important;
    padding: 0 !important;
}
.entry-content, .post-content, .page-content, .site-content, .content-area, article, main, #main, #content, .container, .site-main { 
    max-width: 100% !important; 
    width: 100% !important; 
    padding-left: 0 !important; 
    padding-right: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
}
body { overflow-x: hidden !important; }
</style>';

// If no valid trainer/pricing, show error page
if (!$has_valid_trainer) {
    ?>
    <div class="ptp-checkout-wrap ptp-page-wrap" style="min-height: 100vh; display: flex; flex-direction: column;">
        <header class="ptp-unified-header">
            <div class="ptp-header-inner">
                <a href="<?php echo home_url('/find-trainers/'); ?>" style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500; color: #FCB900; text-decoration: none;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    Back
                </a>
                <a href="<?php echo home_url(); ?>" class="ptp-header-logo">
                    <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP" style="height: 44px; width: auto;">
                </a>
                <div style="width: 80px;"></div>
            </div>
        </header>
        
        <div style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 48px 24px; background: #F9FAFB;">
            <div class="ptp-empty-state" style="padding: 60px 40px;">
                <div class="ptp-empty-icon" style="background: #FEE2E2;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                </div>
                <h1 class="ptp-empty-title">
                    <?php echo $trainer ? 'Pricing Unavailable' : 'Trainer Not Found'; ?>
                </h1>
                <p class="ptp-empty-text">
                    <?php if ($trainer): ?>
                        This trainer hasn't set up their pricing yet. Please check back later or browse other trainers.
                    <?php else: ?>
                        We couldn't find this trainer. They may no longer be available.
                    <?php endif; ?>
                </p>
                <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-btn-primary">
                    Browse Trainers
                </a>
            </div>
        </div>
    </div>
    <?php
    return;
}

// Calculate pricing
switch ($package_type) {
    case '5pack':
        $sessions = 5;
        $discount = 0.10;
        $package_name = '5-Session Pack';
        break;
    case '10pack':
        $sessions = 10;
        $discount = 0.20;
        $package_name = '10-Session Pack';
        break;
    default:
        $sessions = 1;
        $discount = 0;
        $package_name = 'Single Session';
        $package_type = 'single';
}

$subtotal = $hourly_rate * $sessions;
$discount_amount = $subtotal * $discount;
$total = $subtotal - $discount_amount;

// Get current user
$current_user = wp_get_current_user();
$is_logged_in = is_user_logged_in();

// Stripe key
$stripe_pk = get_option('ptp_stripe_public_key', '');

// Photo
$photo = $trainer->profile_photo ?: PTP_TRAINING_URL . 'assets/images/default-avatar.svg';
?>

<div class="ptp-checkout-wrap" style="font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif; color: #0E0F11; background: #F9FAFB; min-height: 100vh;">
    
    <!-- Header -->
    <div style="background: #0E0F11; padding: 16px 24px;">
        <div style="max-width: 1200px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between;">
            <a href="<?php echo home_url('/trainer/'); ?>?id=<?php echo $trainer->id; ?>" style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500; color: #FCB900; text-decoration: none;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back
            </a>
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP" style="height: 44px; width: auto;">
            </a>
            <div style="display: flex; align-items: center; gap: 6px; font-size: 14px; color: #10B981; font-weight: 600;">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                Secure Checkout
            </div>
        </div>
    </div>
    
    <!-- Progress Bar -->
    <div style="background: #fff; border-bottom: 1px solid #E5E7EB; padding: 20px 24px;">
        <div style="max-width: 600px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="width: 28px; height: 28px; background: #FCB900; color: #0E0F11; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800;">1</span>
                <span style="font-size: 14px; font-weight: 600; color: #0E0F11;">Details</span>
            </div>
            <div style="flex: 1; height: 2px; background: #E5E7EB; margin: 0 16px;"></div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="width: 28px; height: 28px; background: #E5E7EB; color: #9CA3AF; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800;">2</span>
                <span style="font-size: 14px; font-weight: 500; color: #9CA3AF;">Payment</span>
            </div>
            <div style="flex: 1; height: 2px; background: #E5E7EB; margin: 0 16px;"></div>
            <div style="display: flex; align-items: center; gap: 8px;">
                <span style="width: 28px; height: 28px; background: #E5E7EB; color: #9CA3AF; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 13px; font-weight: 800;">3</span>
                <span style="font-size: 14px; font-weight: 500; color: #9CA3AF;">Done</span>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div style="max-width: 1100px; margin: 0 auto; padding: 32px 24px;">
        <div style="display: grid; grid-template-columns: 1fr 380px; gap: 32px; align-items: start;" class="ptp-checkout-grid">
            
            <!-- Left: Form -->
            <div>
                <form id="ptp-checkout-form">
                    <!-- Athlete Info -->
                    <div style="background: #fff; border: 1px solid #E5E7EB; border-radius: 20px; padding: 28px; margin-bottom: 24px;">
                        <h2 style="font-size: 18px; font-weight: 700; color: #0E0F11; margin: 0 0 20px 0; display: flex; align-items: center; gap: 10px;">
                            <span style="width: 36px; height: 36px; background: #FCB900; border-radius: 10px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg></span>
                            Athlete Information
                        </h2>
                        
                        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px; margin-bottom: 16px;" class="ptp-form-row">
                            <div>
                                <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Athlete Name *</label>
                                <input type="text" name="athlete_name" required style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; box-sizing: border-box;" placeholder="Player's full name">
                            </div>
                            <div>
                                <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Age *</label>
                                <input type="number" name="athlete_age" required min="5" max="18" style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; box-sizing: border-box;" placeholder="Age">
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Skill Level *</label>
                            <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px;" class="ptp-skill-grid">
                                <label class="ptp-skill-option" style="display: flex; flex-direction: column; align-items: center; padding: 14px 10px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; text-align: center;">
                                    <input type="radio" name="skill_level" value="beginner" required style="display: none;">
                                    <span style="font-size: 12px; font-weight: 600;">Beginner</span>
                                </label>
                                <label class="ptp-skill-option" style="display: flex; flex-direction: column; align-items: center; padding: 14px 10px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; text-align: center;">
                                    <input type="radio" name="skill_level" value="intermediate" style="display: none;">
                                    <span style="font-size: 12px; font-weight: 600;">Intermediate</span>
                                </label>
                                <label class="ptp-skill-option" style="display: flex; flex-direction: column; align-items: center; padding: 14px 10px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; text-align: center;">
                                    <input type="radio" name="skill_level" value="advanced" style="display: none;">
                                    <span style="font-size: 12px; font-weight: 600;">Advanced</span>
                                </label>
                                <label class="ptp-skill-option" style="display: flex; flex-direction: column; align-items: center; padding: 14px 10px; border: 2px solid #E5E7EB; border-radius: 12px; cursor: pointer; text-align: center;">
                                    <input type="radio" name="skill_level" value="elite" style="display: none;">
                                    <span style="font-size: 12px; font-weight: 600;">Elite</span>
                                </label>
                            </div>
                        </div>
                        
                        <div>
                            <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Training Goals <span style="color: #9CA3AF; font-weight: 400;">(Optional)</span></label>
                            <textarea name="goals" rows="3" placeholder="What would you like to focus on? Any specific skills, upcoming tryouts, etc." style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; resize: vertical; box-sizing: border-box;"></textarea>
                        </div>
                    </div>
                    
                    <!-- Contact Info -->
                    <div style="background: #fff; border: 1px solid #E5E7EB; border-radius: 20px; padding: 28px; margin-bottom: 24px;">
                        <h2 style="font-size: 18px; font-weight: 700; color: #0E0F11; margin: 0 0 20px 0; display: flex; align-items: center; gap: 10px;">
                            <span style="width: 36px; height: 36px; background: #0E0F11; border-radius: 10px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg></span>
                            Parent/Guardian Contact
                        </h2>
                        
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px;" class="ptp-form-row">
                            <div>
                                <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">First Name *</label>
                                <input type="text" name="first_name" required value="<?php echo esc_attr($current_user->first_name ?? ''); ?>" style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; box-sizing: border-box;">
                            </div>
                            <div>
                                <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Last Name *</label>
                                <input type="text" name="last_name" required value="<?php echo esc_attr($current_user->last_name ?? ''); ?>" style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; box-sizing: border-box;">
                            </div>
                        </div>
                        
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Email *</label>
                            <input type="email" name="email" required value="<?php echo esc_attr($current_user->user_email ?? ''); ?>" style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; box-sizing: border-box;">
                        </div>
                        
                        <div>
                            <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Phone *</label>
                            <input type="tel" name="phone" required style="width: 100%; padding: 14px 18px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; font-family: inherit; box-sizing: border-box;" placeholder="(555) 123-4567">
                        </div>
                    </div>
                    
                    <!-- Payment -->
                    <div style="background: #fff; border: 1px solid #E5E7EB; border-radius: 20px; padding: 28px;">
                        <h2 style="font-size: 18px; font-weight: 700; color: #0E0F11; margin: 0 0 20px 0; display: flex; align-items: center; gap: 10px;">
                            <span style="width: 36px; height: 36px; background: #10B981; border-radius: 10px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg></span>
                            Payment
                        </h2>
                        
                        <?php if ($stripe_pk): ?>
                            <div style="margin-bottom: 16px;">
                                <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Card Number</label>
                                <div id="card-number" style="padding: 16px 18px; border: 2px solid #E5E7EB; border-radius: 12px; background: #fff;"></div>
                            </div>
                            
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                                <div>
                                    <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">Expiration</label>
                                    <div id="card-expiry" style="padding: 16px 18px; border: 2px solid #E5E7EB; border-radius: 12px; background: #fff;"></div>
                                </div>
                                <div>
                                    <label style="display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 8px;">CVC</label>
                                    <div id="card-cvc" style="padding: 16px 18px; border: 2px solid #E5E7EB; border-radius: 12px; background: #fff;"></div>
                                </div>
                            </div>
                            <div id="card-errors" style="color: #DC2626; font-size: 14px; margin-top: 12px;"></div>
                        <?php else: ?>
                            <div style="background: #F3F4F6; border-radius: 12px; padding: 20px; text-align: center;">
                                <p style="color: #6B7280; margin: 0;">Payment will be processed after submission.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <input type="hidden" name="trainer_id" value="<?php echo $trainer->id; ?>">
                    <input type="hidden" name="package_type" value="<?php echo esc_attr($package_type); ?>">
                    <input type="hidden" name="action" value="ptp_process_checkout">
                    <?php wp_nonce_field('ptp_checkout', 'ptp_checkout_nonce'); ?>
                </form>
            </div>
            
            <!-- Right: Order Summary -->
            <div class="ptp-order-summary">
                <div style="background: #0E0F11; border-radius: 24px; padding: 28px; color: #fff;">
                    <h3 style="font-size: 18px; font-weight: 700; margin: 0 0 24px 0;">Order Summary</h3>
                    
                    <!-- Trainer Card -->
                    <div style="display: flex; gap: 16px; padding-bottom: 24px; margin-bottom: 24px; border-bottom: 1px solid #374151;">
                        <img src="<?php echo esc_url($photo); ?>" alt="" style="width: 80px; height: 80px; border-radius: 14px; object-fit: cover; border: 2px solid #FCB900;">
                        <div>
                            <h4 style="font-size: 17px; font-weight: 700; margin: 0 0 6px 0;">Coach <?php echo esc_html($trainer->display_name); ?></h4>
                            <p style="font-size: 14px; color: #9CA3AF; margin: 0; display: flex; align-items: center; gap: 4px;">
                                <?php if ($trainer->total_reviews > 0): ?>
                                <span style="color: #FCB900;">★</span>
                                <?php echo number_format($trainer->avg_rating ?? 0, 1); ?>
                                (<?php echo intval($trainer->total_reviews); ?> reviews)
                                <?php else: ?>
                                New Trainer
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                    
                    <!-- Package Details -->
                    <div style="margin-bottom: 24px;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                            <span style="color: #9CA3AF;"><?php echo $package_name; ?></span>
                            <span style="font-weight: 600;">$<?php echo number_format($subtotal, 2); ?></span>
                        </div>
                        <?php if ($discount > 0): ?>
                        <div style="display: flex; justify-content: space-between; margin-bottom: 12px; color: #10B981;">
                            <span>Discount (<?php echo intval($discount * 100); ?>% off)</span>
                            <span>-$<?php echo number_format($discount_amount, 2); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Total -->
                    <div style="border-top: 1px solid #374151; padding-top: 20px; margin-bottom: 24px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-size: 16px; font-weight: 600;">Total</span>
                            <span style="font-size: 28px; font-weight: 800; color: #FCB900;">$<?php echo number_format($total, 2); ?></span>
                        </div>
                    </div>
                    
                    <!-- Submit Button -->
                    <button type="submit" form="ptp-checkout-form" id="ptp-submit-btn" style="width: 100%; padding: 18px; background: #FCB900; color: #0E0F11; font-size: 16px; font-weight: 700; border: none; border-radius: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px;">
                        <span id="ptp-btn-text">Complete Purchase</span>
                        <svg id="ptp-btn-spinner" style="display: none; animation: spin 1s linear infinite;" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    </button>
                    
                    <p style="font-size: 12px; color: #6B7280; text-align: center; margin: 16px 0 0 0;">
                        By completing this purchase you agree to our Terms of Service
                    </p>
                </div>
                
                <!-- Trust Badges -->
                <div style="margin-top: 20px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; text-align: center;">
                    <div style="padding: 16px; background: #fff; border-radius: 12px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" style="margin-bottom: 8px;"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        <div style="font-size: 11px; font-weight: 600; color: #374151;">Secure</div>
                    </div>
                    <div style="padding: 16px; background: #fff; border-radius: 12px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" style="margin-bottom: 8px;"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        <div style="font-size: 11px; font-weight: 600; color: #374151;">Guaranteed</div>
                    </div>
                    <div style="padding: 16px; background: #fff; border-radius: 12px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2" style="margin-bottom: 8px;"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/></svg>
                        <div style="font-size: 11px; font-weight: 600; color: #374151;">Verified</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

.ptp-skill-option input:checked + span {
    color: #FCB900;
}
.ptp-skill-option:has(input:checked) {
    border-color: #FCB900 !important;
    background: #FFFBEB;
}

@media (max-width: 900px) {
    .ptp-checkout-grid { grid-template-columns: 1fr !important; }
    .ptp-order-summary { order: -1; }
    .ptp-form-row { grid-template-columns: 1fr !important; }
    .ptp-skill-grid { grid-template-columns: repeat(2, 1fr) !important; }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('ptp-checkout-form');
    const submitBtn = document.getElementById('ptp-submit-btn');
    const btnText = document.getElementById('ptp-btn-text');
    const btnSpinner = document.getElementById('ptp-btn-spinner');
    
    if (!form) return;
    
    // Skill level selection visual feedback
    document.querySelectorAll('.ptp-skill-option input').forEach(function(radio) {
        radio.addEventListener('change', function() {
            document.querySelectorAll('.ptp-skill-option').forEach(function(label) {
                label.style.borderColor = '#E5E7EB';
                label.style.background = '#fff';
            });
            if (this.checked) {
                this.closest('.ptp-skill-option').style.borderColor = '#FCB900';
                this.closest('.ptp-skill-option').style.background = '#FFFBEB';
            }
        });
    });
    
    // Form submission
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Validate form
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        // Show loading
        btnText.textContent = 'Processing...';
        btnSpinner.style.display = 'block';
        submitBtn.disabled = true;
        
        try {
            const formData = new FormData(form);
            
            const response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                btnText.textContent = 'Success!';
                if (result.data.redirect) {
                    window.location.href = result.data.redirect;
                }
            } else {
                throw new Error(result.data?.message || 'Something went wrong');
            }
        } catch (error) {
            alert(error.message);
            btnText.textContent = 'Complete Purchase';
            btnSpinner.style.display = 'none';
            submitBtn.disabled = false;
        }
    });
});
</script>

<?php if ($stripe_pk): ?>
<script src="https://js.stripe.com/v3/"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const stripe = Stripe('<?php echo esc_js($stripe_pk); ?>');
    const elements = stripe.elements();
    
    const style = {
        base: {
            fontSize: '15px',
            fontFamily: "'DM Sans', sans-serif",
            color: '#0E0F11',
            '::placeholder': { color: '#9CA3AF' }
        }
    };
    
    const cardNumber = elements.create('cardNumber', { style });
    const cardExpiry = elements.create('cardExpiry', { style });
    const cardCvc = elements.create('cardCvc', { style });
    
    cardNumber.mount('#card-number');
    cardExpiry.mount('#card-expiry');
    cardCvc.mount('#card-cvc');
    
    // Handle errors
    [cardNumber, cardExpiry, cardCvc].forEach(function(element) {
        element.on('change', function(event) {
            const displayError = document.getElementById('card-errors');
            displayError.textContent = event.error ? event.error.message : '';
        });
    });
});
</script>
<?php endif; ?>
