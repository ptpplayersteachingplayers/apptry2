<?php
/**
 * Trainer Marketplace Template - v7.0
 * Full-width hero with background image
 * Improved location-based UX with geolocation
 * Mobile-first responsive design
 */

defined('ABSPATH') || exit;

global $wpdb;

// Get search/filter parameters
$search_zip = isset($_GET['zip']) ? sanitize_text_field($_GET['zip']) : '';
$search_lat = isset($_GET['lat']) ? floatval($_GET['lat']) : 0;
$search_lng = isset($_GET['lng']) ? floatval($_GET['lng']) : 0;
$search_radius = isset($_GET['radius']) ? intval($_GET['radius']) : 25;
$filter_type = isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '';
$filter_specialty = isset($_GET['specialty']) ? sanitize_text_field($_GET['specialty']) : '';

// Build trainer query
$where_clauses = ["t.status = 'approved'"];
$has_distance = false;

// Distance-based search (if we have lat/lng)
if ($search_lat && $search_lng) {
    $has_distance = true;
}

// Filter by trainer type (credentials)
if ($filter_type === 'mls') {
    $where_clauses[] = "t.credentials LIKE '%MLS%'";
} elseif ($filter_type === 'd1') {
    $where_clauses[] = "(t.credentials LIKE '%D1%' OR t.credentials LIKE '%Division 1%' OR t.credentials LIKE '%NCAA%')";
}

// Filter by specialty
if ($filter_specialty) {
    $where_clauses[] = $wpdb->prepare("t.specialties LIKE %s", '%' . $wpdb->esc_like($filter_specialty) . '%');
}

$where_sql = implode(' AND ', $where_clauses);

// Build full query
if ($has_distance) {
    $sql = $wpdb->prepare(
        "SELECT t.*, 
            (3959 * acos(
                cos(radians(%f)) * cos(radians(t.primary_location_lat)) * 
                cos(radians(t.primary_location_lng) - radians(%f)) + 
                sin(radians(%f)) * sin(radians(t.primary_location_lat))
            )) AS distance
         FROM {$wpdb->prefix}ptp_trainers t
         WHERE $where_sql
         AND t.primary_location_lat IS NOT NULL 
         AND t.primary_location_lat != 0
         HAVING distance <= %d
         ORDER BY distance ASC, t.is_featured DESC, t.avg_rating DESC
         LIMIT 50",
        $search_lat, $search_lng, $search_lat, $search_radius
    );
} else {
    $sql = "SELECT t.* FROM {$wpdb->prefix}ptp_trainers t 
            WHERE $where_sql 
            ORDER BY t.is_featured DESC, t.avg_rating DESC, t.total_sessions DESC 
            LIMIT 50";
}

$trainers = $wpdb->get_results($sql);

// PTP Logo URL
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';

// Hero background image
$hero_bg = 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1278.jpg';
?>

<style id="ptp-critical-fullwidth">
.ptp-page-wrap, .ptp-marketplace-wrap { 
    width: 100vw !important; 
    max-width: 100vw !important; 
    margin-left: calc(50% - 50vw) !important; 
    margin-right: calc(50% - 50vw) !important; 
    position: relative !important; 
    background: #fff !important;
    display: block !important;
    padding: 0 !important;
}
.entry-content, .post-content, .page-content, .site-content, .content-area, article, main, #main, #content, .container, .site-main, .starter-starter, .starter-canvas { 
    max-width: 100% !important; 
    width: 100% !important; 
    padding-left: 0 !important; 
    padding-right: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
}
body { overflow-x: hidden !important; }
</style>

<div class="ptp-marketplace-wrap ptp-page-wrap">
    
    <?php 
    // Include unified header
    $ptp_active_page = 'find-trainers';
    include PTP_TRAINING_PATH . 'templates/frontend/header-component.php';
    ?>
    
    <!-- Hero Section with Background Image -->
    <section class="ptp-hero" style="background-image: url('<?php echo esc_url($hero_bg); ?>');">
        <div class="ptp-hero-content">
            <div class="ptp-hero-logo">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer">
            </div>
            
            <h1 class="ptp-hero-title">
                Find Your <span>Perfect</span> Trainer
            </h1>
            <p class="ptp-hero-subtitle">
                1-on-1 private soccer training with MLS players and NCAA D1 athletes
            </p>
            
            <!-- Location Search Form -->
            <form id="ptp-location-form" action="" method="get" class="ptp-location-search">
                <div class="ptp-search-box">
                    <div class="ptp-search-input-wrap">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
                        <input type="text" 
                               name="zip" 
                               id="ptp-zip-input" 
                               class="ptp-search-input"
                               placeholder="Enter your ZIP code" 
                               value="<?php echo esc_attr($search_zip); ?>" 
                               pattern="[0-9]{5}" 
                               maxlength="5">
                    </div>
                    
                    <button type="button" id="ptp-gps-btn" class="ptp-gps-btn" title="Use my location">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/></svg>
                    </button>
                    
                    <select name="radius" id="ptp-radius" class="ptp-search-select">
                        <option value="10" <?php selected($search_radius, 10); ?>>10 miles</option>
                        <option value="25" <?php selected($search_radius, 25); ?>>25 miles</option>
                        <option value="50" <?php selected($search_radius, 50); ?>>50 miles</option>
                        <option value="100" <?php selected($search_radius, 100); ?>>100 miles</option>
                    </select>
                    
                    <button type="submit" id="ptp-search-btn" class="ptp-search-btn">
                        <span id="ptp-search-text">Search</span>
                        <svg id="ptp-search-spinner" class="ptp-hidden ptp-spin" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
                    </button>
                </div>
                
                <input type="hidden" name="lat" id="ptp-lat-input" value="<?php echo esc_attr($search_lat); ?>">
                <input type="hidden" name="lng" id="ptp-lng-input" value="<?php echo esc_attr($search_lng); ?>">
                <?php if ($filter_type): ?><input type="hidden" name="type" value="<?php echo esc_attr($filter_type); ?>"><?php endif; ?>
                
                <p id="ptp-search-error" class="ptp-search-error"></p>
            </form>
            
            <?php if ($search_zip && $has_distance): ?>
            <p style="color: rgba(255,255,255,0.7); font-size: 14px; margin-top: 16px;">
                Showing trainers within <?php echo $search_radius; ?> miles of <?php echo esc_html($search_zip); ?>
                <a href="<?php echo esc_url(remove_query_arg(['zip', 'lat', 'lng', 'radius'])); ?>" style="color: #FCB900; margin-left: 8px;">Clear</a>
            </p>
            <?php endif; ?>
            
            <!-- Filter Badges -->
            <div class="ptp-filter-badges">
                <a href="<?php echo esc_url(add_query_arg('type', 'mls', remove_query_arg('type'))); ?>" 
                   class="ptp-filter-badge <?php echo $filter_type === 'mls' ? 'active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="none"><circle cx="12" cy="12" r="10"/></svg>
                    MLS Players
                </a>
                <a href="<?php echo esc_url(add_query_arg('type', 'd1', remove_query_arg('type'))); ?>" 
                   class="ptp-filter-badge <?php echo $filter_type === 'd1' ? 'active' : ''; ?>">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>
                    NCAA D1 Athletes
                </a>
                <?php if ($filter_type): ?>
                <a href="<?php echo esc_url(remove_query_arg('type')); ?>" class="ptp-filter-badge">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    Clear Filter
                </a>
                <?php endif; ?>
            </div>
        </div>
    </section>
    
    <!-- Results Section -->
    <section class="ptp-section" style="background: #F9FAFB;">
        <div class="ptp-section-inner">
            
            <?php if (!empty($trainers)): ?>
                <!-- Results Header -->
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 32px; flex-wrap: wrap; gap: 16px;">
                    <div>
                        <h2 style="font-size: 24px; font-weight: 800; color: #0E0F11; margin: 0 0 4px 0;">
                            <?php echo count($trainers); ?> Trainer<?php echo count($trainers) !== 1 ? 's' : ''; ?> Available
                        </h2>
                        <p style="font-size: 15px; color: #6B7280; margin: 0;">
                            <?php if ($has_distance): ?>
                                Near <?php echo esc_html($search_zip); ?>
                            <?php else: ?>
                                Browse all trainers
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <select id="ptp-sort" style="padding: 12px 16px; border: 1px solid #E5E7EB; border-radius: 10px; font-size: 14px; background: #fff;">
                        <option value="recommended">Recommended</option>
                        <option value="rating">Highest Rated</option>
                        <option value="price-low">Price: Low to High</option>
                        <option value="price-high">Price: High to Low</option>
                    </select>
                </div>
                
                <!-- Trainers Grid -->
                <div class="ptp-trainers-grid">
                    <?php foreach ($trainers as $trainer): 
                        $specialties = json_decode($trainer->specialties ?? '[]', true) ?: [];
                        $photo = $trainer->profile_photo ?: 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg';
                        $has_reviews = ($trainer->avg_rating ?? 0) > 0 && ($trainer->total_reviews ?? 0) > 0;
                        $is_mls = stripos($trainer->credentials ?? '', 'MLS') !== false;
                    ?>
                    <a href="<?php echo home_url('/trainer/'); ?>?id=<?php echo $trainer->id; ?>" class="ptp-trainer-card">
                        <div class="ptp-card-image">
                            <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>" loading="lazy">
                            <?php if ($is_mls): ?>
                            <span class="ptp-card-badge">
                                <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
                                MLS
                            </span>
                            <?php elseif ($trainer->is_featured): ?>
                            <span class="ptp-card-badge">Featured</span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="ptp-card-content">
                            <h3 class="ptp-card-name"><?php echo esc_html($trainer->display_name); ?></h3>
                            <p class="ptp-card-location">
                                <?php 
                                    $location = array_filter([
                                        $trainer->primary_location_city,
                                        $trainer->primary_location_state
                                    ]);
                                    echo esc_html(implode(', ', $location) ?: 'Location TBD');
                                    
                                    if ($has_distance && isset($trainer->distance)) {
                                        echo ' · ' . round($trainer->distance, 1) . ' mi';
                                    }
                                ?>
                            </p>
                            
                            <?php if ($has_reviews): ?>
                            <div class="ptp-card-rating">
                                <span class="star">★</span>
                                <?php echo number_format($trainer->avg_rating, 1); ?>
                                <span style="color: #9CA3AF; font-weight: 400;">(<?php echo intval($trainer->total_reviews); ?>)</span>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($specialties)): ?>
                            <div class="ptp-card-tags">
                                <?php foreach (array_slice($specialties, 0, 3) as $spec): ?>
                                <span class="ptp-card-tag"><?php echo esc_html($spec); ?></span>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                            
                            <div class="ptp-card-footer">
                                <?php if ($trainer->hourly_rate > 0): ?>
                                <span class="ptp-card-price">
                                    $<?php echo intval($trainer->hourly_rate); ?><span>/hr</span>
                                </span>
                                <?php else: ?>
                                <span style="font-size: 14px; color: #6B7280;">Contact for pricing</span>
                                <?php endif; ?>
                                
                                <span style="font-size: 13px; color: #FCB900; font-weight: 600;">View Profile →</span>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                
            <?php else: ?>
                <!-- Empty State -->
                <div class="ptp-empty-state">
                    <div class="ptp-empty-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    </div>
                    <h3 class="ptp-empty-title">Trainers Coming Soon</h3>
                    <p class="ptp-empty-text">
                        We're building our network of elite trainers. 
                        <?php if ($search_zip): ?>
                            Try expanding your search radius or <a href="<?php echo esc_url(remove_query_arg(['zip', 'lat', 'lng', 'radius'])); ?>" style="color: #FCB900;">view all trainers</a>.
                        <?php else: ?>
                            Enter your ZIP code above to find trainers near you.
                        <?php endif; ?>
                    </p>
                    <a href="<?php echo home_url('/coach-application/'); ?>" class="ptp-btn-primary" style="display: inline-flex;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
                        Apply to Coach
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- CTA Section -->
    <section class="ptp-cta-section">
        <div class="ptp-cta-inner">
            <h2 class="ptp-cta-title">
                Are You an <span>Elite Player?</span>
            </h2>
            <p class="ptp-cta-text">
                MLS players and NCAA D1 athletes - become a mentor and help train the next generation. Teaching what team coaches don't.
            </p>
            <a href="<?php echo home_url('/coach-application/'); ?>" class="ptp-btn-primary">
                Apply to Coach
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </a>
        </div>
    </section>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('ptp-location-form');
    const zipInput = document.getElementById('ptp-zip-input');
    const latInput = document.getElementById('ptp-lat-input');
    const lngInput = document.getElementById('ptp-lng-input');
    const gpsBtn = document.getElementById('ptp-gps-btn');
    const searchBtn = document.getElementById('ptp-search-btn');
    const searchText = document.getElementById('ptp-search-text');
    const searchSpinner = document.getElementById('ptp-search-spinner');
    const errorEl = document.getElementById('ptp-search-error');
    
    if (!form) return;
    
    // Show error message
    function showError(msg) {
        errorEl.textContent = msg;
        errorEl.classList.add('visible');
    }
    
    // Hide error message
    function hideError() {
        errorEl.classList.remove('visible');
    }
    
    // Set loading state
    function setLoading(loading) {
        if (loading) {
            searchText.textContent = 'Searching...';
            searchSpinner.classList.remove('ptp-hidden');
            searchBtn.disabled = true;
        } else {
            searchText.textContent = 'Search';
            searchSpinner.classList.add('ptp-hidden');
            searchBtn.disabled = false;
        }
    }
    
    // Geocode ZIP code using API
    async function geocodeZip(zip) {
        const response = await fetch(`https://api.zippopotam.us/us/${zip}`);
        if (!response.ok) throw new Error('Invalid ZIP code');
        const data = await response.json();
        if (data.places && data.places[0]) {
            return {
                lat: data.places[0].latitude,
                lng: data.places[0].longitude,
                city: data.places[0]['place name'],
                state: data.places[0]['state abbreviation']
            };
        }
        throw new Error('Could not find location');
    }
    
    // Handle form submission
    form.addEventListener('submit', async function(e) {
        const zip = zipInput.value.trim();
        hideError();
        
        // If no ZIP, show all trainers
        if (!zip) {
            latInput.value = '';
            lngInput.value = '';
            return true;
        }
        
        // Validate ZIP format
        if (!/^\d{5}$/.test(zip)) {
            e.preventDefault();
            showError('Please enter a valid 5-digit ZIP code');
            return false;
        }
        
        // If we already have lat/lng, submit
        if (latInput.value && lngInput.value) {
            return true;
        }
        
        // Geocode the ZIP
        e.preventDefault();
        setLoading(true);
        
        try {
            const location = await geocodeZip(zip);
            latInput.value = location.lat;
            lngInput.value = location.lng;
            form.submit();
        } catch (error) {
            showError('Could not find that ZIP code. Please check and try again.');
            setLoading(false);
        }
    });
    
    // Clear lat/lng when ZIP changes
    zipInput.addEventListener('input', function() {
        latInput.value = '';
        lngInput.value = '';
        hideError();
    });
    
    // GPS Button - Use browser geolocation
    if (gpsBtn && navigator.geolocation) {
        gpsBtn.addEventListener('click', function() {
            gpsBtn.classList.add('locating');
            hideError();
            
            navigator.geolocation.getCurrentPosition(
                async function(position) {
                    latInput.value = position.coords.latitude;
                    lngInput.value = position.coords.longitude;
                    
                    // Try to reverse geocode to get ZIP
                    try {
                        const response = await fetch(
                            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${position.coords.latitude}&lon=${position.coords.longitude}`
                        );
                        const data = await response.json();
                        if (data.address && data.address.postcode) {
                            zipInput.value = data.address.postcode.substring(0, 5);
                        }
                    } catch (e) {
                        // If reverse geocode fails, just use coords
                        zipInput.value = 'Current Location';
                    }
                    
                    gpsBtn.classList.remove('locating');
                    form.submit();
                },
                function(error) {
                    gpsBtn.classList.remove('locating');
                    showError('Could not get your location. Please enter a ZIP code.');
                },
                { enableHighAccuracy: true, timeout: 10000 }
            );
        });
    } else if (gpsBtn) {
        gpsBtn.style.display = 'none';
    }
});
</script>
