<?php
/**
 * Trainer Profile Template - v7.0
 * Full-width layout, improved UX
 * Real data only - NO fake/fallback data
 */

defined('ABSPATH') || exit;

global $wpdb;

// Get trainer ID from URL
$trainer_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Get trainer from database
$trainer = null;
if ($trainer_id) {
    $trainer = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d AND status = 'approved'",
        $trainer_id
    ));
}

// PTP Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';

// Inline critical styles for full-width
$ptp_critical_styles = '
<style id="ptp-critical-fullwidth">
.ptp-page-wrap, .ptp-profile-wrap { 
    width: 100vw !important; 
    max-width: 100vw !important; 
    margin-left: calc(50% - 50vw) !important; 
    margin-right: calc(50% - 50vw) !important; 
    position: relative !important; 
    background: #fff !important;
    display: block !important;
    padding: 0 !important;
}
.entry-content, .post-content, .page-content, .site-content, .content-area, article, main, #main, #content, .container, .site-main { 
    max-width: 100% !important; 
    width: 100% !important; 
    padding-left: 0 !important; 
    padding-right: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
}
body { overflow-x: hidden !important; }
</style>
';
echo $ptp_critical_styles;

// 404 if trainer not found
if (!$trainer) {
    ?>
    <div class="ptp-profile-wrap ptp-page-wrap" style="min-height: 100vh; display: flex; flex-direction: column;">
        <!-- Header -->
        <header class="ptp-unified-header">
            <div class="ptp-header-inner">
                <a href="<?php echo home_url('/find-trainers/'); ?>" style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500; color: #FCB900; text-decoration: none;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                    Back
                </a>
                <a href="<?php echo home_url(); ?>" class="ptp-header-logo">
                    <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer">
                </a>
                <div style="width: 80px;"></div>
            </div>
        </header>
        
        <div style="flex: 1; display: flex; align-items: center; justify-content: center; padding: 48px 24px; background: #F9FAFB;">
            <div class="ptp-empty-state" style="padding: 60px 40px;">
                <div class="ptp-empty-icon" style="background: #FEE2E2;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/></svg>
                </div>
                <h1 class="ptp-empty-title">Trainer Not Found</h1>
                <p class="ptp-empty-text">
                    We couldn't find this trainer. They may no longer be available.
                </p>
                <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-btn-primary">
                    Browse Trainers
                </a>
            </div>
        </div>
    </div>
    <?php
    return;
}

// Get trainer's reviews
$reviews = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}ptp_reviews 
     WHERE trainer_id = %d AND status = 'published' 
     ORDER BY created_at DESC 
     LIMIT 20",
    $trainer_id
));

// Parse trainer data
$specialties = json_decode($trainer->specialties ?? '[]', true) ?: [];
$hourly_rate = floatval($trainer->hourly_rate);
$has_pricing = $hourly_rate > 0;
$photo = $trainer->profile_photo ?: PTP_TRAINING_URL . 'assets/images/default-avatar.svg';

// Calculate package pricing
$single_price = $hourly_rate;
$five_pack_price = $hourly_rate * 5 * 0.90;
$ten_pack_price = $hourly_rate * 10 * 0.80;

// Stats
$total_sessions = intval($trainer->total_sessions ?? 0);
$avg_rating = floatval($trainer->avg_rating ?? 0);
$total_reviews = intval($trainer->total_reviews ?? 0);
$is_mls = stripos($trainer->credentials ?? '', 'MLS') !== false;

// Checkout URL
$checkout_url = home_url('/training-checkout/');
?>

<div class="ptp-profile-wrap ptp-page-wrap">
    
    <!-- Header -->
    <header class="ptp-unified-header">
        <div class="ptp-header-inner">
            <a href="<?php echo home_url('/find-trainers/'); ?>" style="display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500; color: #FCB900; text-decoration: none;">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to Trainers
            </a>
            <a href="<?php echo home_url(); ?>" class="ptp-header-logo">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer">
            </a>
            <div class="ptp-header-actions" style="min-width: 120px; justify-content: flex-end;">
                <?php if (is_user_logged_in()): 
                    $current_user = wp_get_current_user();
                ?>
                    <a href="<?php echo home_url('/my-training/'); ?>" class="ptp-header-cta" style="padding: 8px 16px; font-size: 13px;">
                        My Training
                    </a>
                <?php else: ?>
                    <a href="<?php echo wp_login_url(get_permalink()); ?>" style="padding: 8px 16px; color: #fff; font-size: 13px; font-weight: 600; text-decoration: none;">
                        Log In
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <!-- Main Content -->
    <div class="ptp-profile-content" style="background: #F9FAFB; min-height: calc(100vh - 68px);">
        <div class="ptp-profile-grid">
            
            <!-- Left Column -->
            <div>
                <!-- Hero Card -->
                <div style="background: #fff; border-radius: 24px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 24px;">
                    <div style="display: grid; grid-template-columns: 280px 1fr; gap: 0;" class="ptp-hero-grid">
                        <img src="<?php echo esc_url($photo); ?>" 
                             alt="<?php echo esc_attr($trainer->display_name); ?>" 
                             style="width: 100%; aspect-ratio: 1/1; object-fit: cover; background: #F3F4F6;">
                        
                        <div style="padding: 32px;">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                                <h1 style="font-size: 28px; font-weight: 800; color: #0E0F11; margin: 0;">
                                    <?php echo esc_html($trainer->display_name); ?>
                                </h1>
                                <?php if ($is_mls): ?>
                                <span style="display: inline-flex; align-items: center; gap: 4px; padding: 6px 12px; background: #FCB900; color: #0E0F11; font-size: 11px; font-weight: 700; border-radius: 100px; text-transform: uppercase;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
                                    MLS
                                </span>
                                <?php endif; ?>
                            </div>
                            
                            <p style="font-size: 16px; color: #6B7280; margin: 0 0 20px 0;">
                                <?php 
                                    $location = array_filter([
                                        $trainer->primary_location_city,
                                        $trainer->primary_location_state
                                    ]);
                                    echo esc_html(implode(', ', $location) ?: 'Location TBD');
                                ?>
                            </p>
                            
                            <?php if ($avg_rating > 0): ?>
                            <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 20px;">
                                <div style="display: flex; align-items: center; gap: 8px; padding: 12px 16px; background: #F9FAFB; border-radius: 12px;">
                                    <span style="font-size: 24px; font-weight: 800; color: #0E0F11;"><?php echo number_format($avg_rating, 1); ?></span>
                                    <span style="color: #FCB900; font-size: 20px;">★</span>
                                </div>
                                <div>
                                    <div style="font-size: 14px; font-weight: 600; color: #0E0F11;"><?php echo intval($total_reviews); ?> reviews</div>
                                    <div style="font-size: 13px; color: #6B7280;"><?php echo intval($total_sessions); ?> sessions</div>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($specialties)): ?>
                            <div style="display: flex; flex-wrap: wrap; gap: 8px;">
                                <?php foreach ($specialties as $spec): ?>
                                <span style="padding: 8px 14px; background: #F3F4F6; color: #374151; border-radius: 100px; font-size: 13px; font-weight: 600;">
                                    <?php echo esc_html($spec); ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Bio Section -->
                <?php if (!empty($trainer->bio)): ?>
                <div style="background: #fff; border-radius: 24px; padding: 28px; box-shadow: 0 4px 20px rgba(0,0,0,0.06); margin-bottom: 24px;">
                    <h2 style="font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 16px 0;">About</h2>
                    <p style="font-size: 15px; line-height: 1.7; color: #4B5563; margin: 0; white-space: pre-line;">
                        <?php echo esc_html($trainer->bio); ?>
                    </p>
                </div>
                <?php endif; ?>
                
                <!-- Reviews Section -->
                <?php if (!empty($reviews)): ?>
                <div style="background: #fff; border-radius: 24px; padding: 28px; box-shadow: 0 4px 20px rgba(0,0,0,0.06);">
                    <h2 style="font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 24px 0;">
                        Reviews (<?php echo count($reviews); ?>)
                    </h2>
                    
                    <div style="display: flex; flex-direction: column; gap: 20px;">
                        <?php foreach ($reviews as $review): ?>
                        <div style="padding-bottom: 20px; border-bottom: 1px solid #E5E7EB;">
                            <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
                                <div style="display: flex; align-items: center; gap: 10px;">
                                    <div style="width: 40px; height: 40px; background: #FCB900; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: #0E0F11;">
                                        <?php echo strtoupper(substr($review->reviewer_name ?? 'A', 0, 1)); ?>
                                    </div>
                                    <div>
                                        <div style="font-weight: 600; color: #0E0F11; font-size: 14px;">
                                            <?php echo esc_html($review->reviewer_name ?? 'Anonymous'); ?>
                                        </div>
                                        <div style="font-size: 12px; color: #9CA3AF;">
                                            <?php echo date('F j, Y', strtotime($review->created_at)); ?>
                                        </div>
                                    </div>
                                </div>
                                <div style="color: #FCB900; font-size: 14px;">
                                    <?php echo str_repeat('★', intval($review->rating)); ?><?php echo str_repeat('☆', 5 - intval($review->rating)); ?>
                                </div>
                            </div>
                            <p style="font-size: 15px; color: #374151; line-height: 1.6; margin: 0;">
                                <?php echo esc_html($review->review_text); ?>
                            </p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Right Column: Booking Card -->
            <div class="ptp-booking-sidebar">
                <div style="background: #fff; border-radius: 24px; padding: 28px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); position: sticky; top: 100px;">
                    
                    <?php if ($has_pricing): ?>
                        <div style="text-align: center; margin-bottom: 24px;">
                            <div style="font-size: 14px; color: #6B7280; margin-bottom: 4px;">Starting at</div>
                            <div style="font-size: 36px; font-weight: 800; color: #0E0F11;">
                                $<?php echo intval($hourly_rate); ?><span style="font-size: 18px; font-weight: 500; color: #6B7280;">/session</span>
                            </div>
                        </div>
                        
                        <div style="display: grid; gap: 12px; margin-bottom: 24px;">
                            <!-- Single Session -->
                            <a href="<?php echo esc_url($checkout_url . '?trainer=' . $trainer_id . '&package=single'); ?>" 
                               style="display: block; padding: 20px; border: 2px solid #E5E7EB; border-radius: 14px; text-decoration: none; color: inherit; transition: all 0.2s;">
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-weight: 700; font-size: 16px; color: #0E0F11;">Single Session</div>
                                        <div style="font-size: 13px; color: #6B7280;">1 hour of training</div>
                                    </div>
                                    <div style="font-size: 20px; font-weight: 700; color: #0E0F11;">$<?php echo intval($single_price); ?></div>
                                </div>
                            </a>
                            
                            <!-- 5-Pack -->
                            <a href="<?php echo esc_url($checkout_url . '?trainer=' . $trainer_id . '&package=5pack'); ?>" 
                               style="display: block; padding: 20px; border: 2px solid #FCB900; border-radius: 14px; text-decoration: none; color: inherit; position: relative; background: #FFFBEB;">
                                <span style="position: absolute; top: -10px; right: 16px; background: #FCB900; color: #0E0F11; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700;">SAVE 10%</span>
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-weight: 700; font-size: 16px; color: #0E0F11;">5-Session Pack</div>
                                        <div style="font-size: 13px; color: #6B7280;">Best for skill building</div>
                                    </div>
                                    <div>
                                        <div style="font-size: 20px; font-weight: 700; color: #0E0F11;">$<?php echo intval($five_pack_price); ?></div>
                                        <div style="font-size: 12px; color: #6B7280; text-decoration: line-through;">$<?php echo intval($hourly_rate * 5); ?></div>
                                    </div>
                                </div>
                            </a>
                            
                            <!-- 10-Pack -->
                            <a href="<?php echo esc_url($checkout_url . '?trainer=' . $trainer_id . '&package=10pack'); ?>" 
                               style="display: block; padding: 20px; border: 2px solid #E5E7EB; border-radius: 14px; text-decoration: none; color: inherit; position: relative; transition: all 0.2s;">
                                <span style="position: absolute; top: -10px; right: 16px; background: #10B981; color: #fff; padding: 4px 12px; border-radius: 20px; font-size: 11px; font-weight: 700;">SAVE 20%</span>
                                <div style="display: flex; justify-content: space-between; align-items: center;">
                                    <div>
                                        <div style="font-weight: 700; font-size: 16px; color: #0E0F11;">10-Session Pack</div>
                                        <div style="font-size: 13px; color: #6B7280;">Maximum value</div>
                                    </div>
                                    <div>
                                        <div style="font-size: 20px; font-weight: 700; color: #0E0F11;">$<?php echo intval($ten_pack_price); ?></div>
                                        <div style="font-size: 12px; color: #6B7280; text-decoration: line-through;">$<?php echo intval($hourly_rate * 10); ?></div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php else: ?>
                        <div style="text-align: center; padding: 20px;">
                            <div style="width: 60px; height: 60px; background: #F3F4F6; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                            </div>
                            <h3 style="font-size: 18px; font-weight: 700; margin: 0 0 8px 0; color: #0E0F11;">Pricing Coming Soon</h3>
                            <p style="font-size: 14px; color: #6B7280; margin: 0 0 20px 0;">
                                Contact us to book a session with <?php echo esc_html($trainer->display_name); ?>
                            </p>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Trust Signals -->
                    <div style="border-top: 1px solid #E5E7EB; padding-top: 20px;">
                        <div style="display: grid; gap: 12px;">
                            <div style="display: flex; align-items: center; gap: 10px; font-size: 13px; color: #6B7280;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22,4 12,14.01 9,11.01"/></svg>
                                Background checked
                            </div>
                            <div style="display: flex; align-items: center; gap: 10px; font-size: 13px; color: #6B7280;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                                Secure payments
                            </div>
                            <div style="display: flex; align-items: center; gap: 10px; font-size: 13px; color: #6B7280;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                                Satisfaction guaranteed
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
@media (max-width: 900px) {
    .ptp-profile-grid {
        grid-template-columns: 1fr !important;
    }
    .ptp-hero-grid {
        grid-template-columns: 1fr !important;
    }
    .ptp-booking-sidebar {
        order: -1;
    }
    .ptp-booking-sidebar > div {
        position: relative !important;
        top: 0 !important;
    }
}
</style>
