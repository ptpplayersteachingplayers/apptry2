<?php
/**
 * My Training Dashboard - v7.0
 * Full-width layout, improved header UX
 * Mobile-first responsive design
 */

defined('ABSPATH') || exit;

// Require login
if (!is_user_logged_in()) {
    wp_redirect(wp_login_url(get_permalink()));
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;
$first_name = $current_user->first_name ?: $current_user->display_name;

// Get user's data from database
global $wpdb;

// Get lesson packs
$packs = $wpdb->get_results($wpdb->prepare(
    "SELECT p.*, t.display_name as trainer_name, t.profile_photo as trainer_photo 
     FROM {$wpdb->prefix}ptp_lesson_packs p
     LEFT JOIN {$wpdb->prefix}ptp_trainers t ON p.trainer_id = t.id
     WHERE p.customer_id = %d AND p.status = 'active'
     ORDER BY p.created_at DESC",
    $user_id
)) ?: [];

// Get upcoming sessions
$upcoming_sessions = $wpdb->get_results($wpdb->prepare(
    "SELECT s.*, t.display_name as trainer_name, t.profile_photo as trainer_photo
     FROM {$wpdb->prefix}ptp_sessions s
     LEFT JOIN {$wpdb->prefix}ptp_trainers t ON s.trainer_id = t.id
     WHERE s.customer_id = %d 
     AND s.session_date >= CURDATE()
     AND s.session_status IN ('confirmed', 'scheduled')
     ORDER BY s.session_date ASC, s.start_time ASC
     LIMIT 5",
    $user_id
)) ?: [];

// Get completed sessions
$completed_sessions = $wpdb->get_results($wpdb->prepare(
    "SELECT s.*, t.display_name as trainer_name, t.profile_photo as trainer_photo
     FROM {$wpdb->prefix}ptp_sessions s
     LEFT JOIN {$wpdb->prefix}ptp_trainers t ON s.trainer_id = t.id
     WHERE s.customer_id = %d AND s.session_status = 'completed'
     ORDER BY s.session_date DESC
     LIMIT 5",
    $user_id
)) ?: [];

$completed_count = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_sessions WHERE customer_id = %d AND session_status = 'completed'",
    $user_id
)) ?: 0;

// Calculate total credits
$credits = 0;
foreach ($packs as $pack) {
    $credits += $pack->sessions_remaining;
}

// Check for booking success message
$booking_success = isset($_GET['booking']) && $_GET['booking'] === 'success';

// PTP Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
?>

<style id="ptp-critical-fullwidth">
.ptp-page-wrap, .ptp-dashboard-wrap, .ptp-my-training-wrap { 
    width: 100vw !important; 
    max-width: 100vw !important; 
    margin-left: calc(50% - 50vw) !important; 
    margin-right: calc(50% - 50vw) !important; 
    position: relative !important; 
    background: #fff !important;
    display: block !important;
    padding: 0 !important;
}
.entry-content, .post-content, .page-content, .site-content, .content-area, article, main, #main, #content, .container, .site-main { 
    max-width: 100% !important; 
    width: 100% !important; 
    padding-left: 0 !important; 
    padding-right: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
}
body { overflow-x: hidden !important; }
</style>

<div class="ptp-dashboard-wrap ptp-page-wrap">
    
    <?php 
    // Include unified header
    $ptp_active_page = 'my-training';
    include PTP_TRAINING_PATH . 'templates/frontend/header-component.php';
    ?>
    
    <!-- Welcome Hero -->
    <section class="ptp-dashboard-hero">
        <div class="ptp-dashboard-hero-inner">
            <h1 class="ptp-dashboard-welcome">Welcome back, <?php echo esc_html($first_name); ?>!</h1>
            <p class="ptp-dashboard-subtitle">Track your training progress and schedule sessions</p>
        </div>
    </section>
    
    <?php if ($booking_success): ?>
    <!-- Success Message -->
    <div style="max-width: 1400px; margin: 24px auto 0; padding: 0 24px;">
        <div style="background: #D1FAE5; border: 2px solid #10B981; border-radius: 16px; padding: 20px 24px; display: flex; align-items: center; gap: 16px;">
            <span style="width: 48px; height: 48px; background: #10B981; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
            </span>
            <div>
                <strong style="font-size: 18px; color: #065F46;">Booking Confirmed!</strong>
                <p style="color: #047857; margin: 4px 0 0 0; font-size: 14px;">Your training sessions have been booked. We'll send you confirmation details shortly.</p>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <!-- Dashboard Content -->
    <div class="ptp-dashboard-content" style="background: #F9FAFB; min-height: 60vh;">
        
        <!-- Stats Cards -->
        <div class="ptp-stats-cards">
            <div class="ptp-stat-card">
                <div class="ptp-stat-card-icon" style="background: #FCB900;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#0E0F11" stroke="none"><circle cx="12" cy="12" r="10"/></svg>
                </div>
                <div>
                    <div class="ptp-stat-card-value"><?php echo intval($completed_count); ?></div>
                    <div class="ptp-stat-card-label">Sessions Completed</div>
                </div>
            </div>
            
            <div class="ptp-stat-card">
                <div class="ptp-stat-card-icon" style="background: #0E0F11;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                </div>
                <div>
                    <div class="ptp-stat-card-value"><?php echo count($upcoming_sessions); ?></div>
                    <div class="ptp-stat-card-label">Upcoming Sessions</div>
                </div>
            </div>
            
            <div class="ptp-stat-card">
                <div class="ptp-stat-card-icon" style="background: #F3F4F6;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/></svg>
                </div>
                <div>
                    <div class="ptp-stat-card-value"><?php echo count($packs); ?></div>
                    <div class="ptp-stat-card-label">Active Packs</div>
                </div>
            </div>
            
            <div class="ptp-stat-card" style="border-color: #FCB900; background: #FFFBEB;">
                <div class="ptp-stat-card-icon" style="background: linear-gradient(135deg, #FCB900, #F59E0B);">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z"/></svg>
                </div>
                <div>
                    <div class="ptp-stat-card-value"><?php echo intval($credits); ?></div>
                    <div class="ptp-stat-card-label">Credits Available</div>
                </div>
            </div>
        </div>
        
        <!-- Main Grid -->
        <div class="ptp-dashboard-grid">
            <!-- Left Column: Sessions -->
            <div>
                <!-- Upcoming Sessions -->
                <div class="ptp-dash-card">
                    <h2 class="ptp-dash-card-title">Upcoming Sessions</h2>
                    
                    <?php if (!empty($upcoming_sessions)): ?>
                        <?php foreach ($upcoming_sessions as $session): ?>
                        <div style="display: flex; gap: 16px; padding: 20px; background: #F9FAFB; border-radius: 16px; margin-bottom: 12px;">
                            <img src="<?php echo esc_url($session->trainer_photo ?: 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg'); ?>" 
                                 alt="" 
                                 style="width: 64px; height: 64px; border-radius: 14px; object-fit: cover; border: 2px solid #FCB900;">
                            <div style="flex: 1;">
                                <h4 style="font-size: 16px; font-weight: 700; color: #0E0F11; margin: 0 0 4px 0;">
                                    with <?php echo esc_html($session->trainer_name); ?>
                                </h4>
                                <p style="font-size: 14px; color: #6B7280; margin: 0 0 8px 0;">
                                    <?php echo date('l, F j', strtotime($session->session_date)); ?>
                                    <?php if ($session->start_time): ?>
                                        at <?php echo date('g:i A', strtotime($session->start_time)); ?>
                                    <?php endif; ?>
                                </p>
                                <span style="display: inline-flex; align-items: center; gap: 4px; padding: 6px 12px; background: #DBEAFE; color: #1D4ED8; font-size: 12px; font-weight: 600; border-radius: 100px;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                    <?php echo ucfirst($session->session_status); ?>
                                </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align: center; padding: 48px 24px;">
                            <div style="width: 80px; height: 80px; background: #FEFCE8; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>
                            </div>
                            <h3 style="font-size: 20px; font-weight: 700; color: #0E0F11; margin: 0 0 8px 0;">No upcoming sessions</h3>
                            <p style="font-size: 15px; color: #6B7280; margin: 0 0 24px 0;">Book your next training session to get started!</p>
                            <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-btn-primary" style="display: inline-flex;">
                                Find Trainers
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Completed Sessions -->
                <?php if (!empty($completed_sessions)): ?>
                <div class="ptp-dash-card">
                    <h2 class="ptp-dash-card-title" style="color: #10B981;">
                        Recent Sessions
                    </h2>
                    
                    <?php foreach ($completed_sessions as $session): ?>
                    <div style="display: flex; gap: 16px; padding: 16px; background: #F9FAFB; border-radius: 12px; margin-bottom: 12px;">
                        <img src="<?php echo esc_url($session->trainer_photo ?: 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg'); ?>" 
                             alt="" 
                             style="width: 52px; height: 52px; border-radius: 10px; object-fit: cover;">
                        <div style="flex: 1;">
                            <h4 style="font-size: 15px; font-weight: 600; color: #0E0F11; margin: 0 0 4px 0;">
                                with <?php echo esc_html($session->trainer_name); ?>
                            </h4>
                            <p style="font-size: 13px; color: #6B7280; margin: 0;">
                                <?php echo date('M j, Y', strtotime($session->session_date)); ?>
                            </p>
                        </div>
                        <span style="display: inline-flex; align-items: center; gap: 4px; padding: 6px 12px; background: #D1FAE5; color: #065F46; font-size: 12px; font-weight: 600; border-radius: 100px; height: fit-content;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
                            Complete
                        </span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Right Column: Sidebar -->
            <div>
                <!-- Training Packs -->
                <div class="ptp-dash-card" style="background: #0E0F11; color: #fff;">
                    <h3 style="font-size: 18px; font-weight: 700; color: #fff; margin: 0 0 24px 0;">Training Packs</h3>
                    
                    <?php if (!empty($packs)): ?>
                        <?php foreach ($packs as $pack): 
                            $progress = ($pack->sessions_used / $pack->total_sessions) * 100;
                        ?>
                        <div style="margin-bottom: 24px;">
                            <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                                <img src="<?php echo esc_url($pack->trainer_photo ?: 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg'); ?>" 
                                     alt="" 
                                     style="width: 44px; height: 44px; border-radius: 10px; object-fit: cover; border: 2px solid #FCB900;">
                                <div style="flex: 1;">
                                    <div style="font-weight: 600; color: #fff; font-size: 14px;"><?php echo esc_html($pack->trainer_name); ?></div>
                                    <div style="font-size: 12px; color: #9CA3AF;"><?php echo esc_html($pack->athlete_name); ?></div>
                                </div>
                            </div>
                            <div style="height: 8px; background: #374151; border-radius: 100px; overflow: hidden; margin-bottom: 8px;">
                                <div style="width: <?php echo $progress; ?>%; height: 100%; background: linear-gradient(90deg, #FCB900, #F59E0B); border-radius: 100px;"></div>
                            </div>
                            <div style="display: flex; justify-content: space-between; font-size: 13px;">
                                <span style="color: #9CA3AF;"><?php echo intval($pack->sessions_used); ?>/<?php echo intval($pack->total_sessions); ?> used</span>
                                <span style="color: #FCB900; font-weight: 600;"><?php echo intval($pack->sessions_remaining); ?> remaining</span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="font-size: 14px; color: #9CA3AF; margin: 0 0 16px 0;">No active packs. Purchase a training pack to save!</p>
                    <?php endif; ?>
                    
                    <a href="<?php echo home_url('/find-trainers/'); ?>" 
                       style="display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; padding: 14px; background: #FCB900; color: #0E0F11; font-size: 14px; font-weight: 700; border-radius: 12px; text-decoration: none; margin-top: 16px;">
                        Buy More Sessions
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>
                </div>
                
                <!-- Quick Links -->
                <div class="ptp-dash-card">
                    <h3 style="font-size: 16px; font-weight: 700; color: #0E0F11; margin: 0 0 16px 0;">Quick Links</h3>
                    <nav style="display: flex; flex-direction: column; gap: 8px;">
                        <a href="<?php echo home_url('/find-trainers/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 14px; border-radius: 12px; text-decoration: none; color: #374151; font-size: 14px; font-weight: 600; background: #F9FAFB; transition: all 0.2s;">
                            <span style="width: 36px; height: 36px; background: #FEFCE8; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                            </span>
                            Find Trainers
                        </a>
                        <a href="<?php echo home_url('/ptp-shop-page/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 14px; border-radius: 12px; text-decoration: none; color: #374151; font-size: 14px; font-weight: 600; background: #F9FAFB; transition: all 0.2s;">
                            <span style="width: 36px; height: 36px; background: #FCB900; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="#0E0F11" stroke="none"><circle cx="12" cy="12" r="10"/></svg>
                            </span>
                            Summer Camps
                        </a>
                        <a href="<?php echo home_url('/my-account/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 14px; border-radius: 12px; text-decoration: none; color: #374151; font-size: 14px; font-weight: 600; background: #F9FAFB; transition: all 0.2s;">
                            <span style="width: 36px; height: 36px; background: #E5E7EB; border-radius: 10px; display: flex; align-items: center; justify-content: center;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#374151" stroke-width="2"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
                            </span>
                            Account Settings
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Camps/Clinics Upsell -->
    <?php 
    if (class_exists('PTP_WooCommerce')) {
        echo PTP_WooCommerce::render_upsell_section('Also From PTP', 4);
    }
    ?>
</div>
