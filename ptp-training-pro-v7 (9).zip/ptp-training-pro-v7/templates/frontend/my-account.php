<?php
/**
 * PTP My Account Template
 * Professional account management page matching PTP design
 */

defined('ABSPATH') || exit;

// Require login
if (!is_user_logged_in()) {
    // Show login form
    $ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
    ?>
    <style>
    body:has(.ptp-page-wrap) #starter-starter > header,
    body:has(.ptp-page-wrap) .starter-header,
    body:has(.ptp-page-wrap) header.site-header { display: none !important; }
    </style>
    <div class="ptp-account-wrap ptp-page-wrap" style="font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif; color: #0E0F11;">
        
        <?php 
        $ptp_active_page = '';
        include PTP_TRAINING_PATH . 'templates/frontend/header-component.php';
        ?>
        
        <div style="min-height: 80vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%); padding: 40px 20px;">
            <div style="background: #fff; border-radius: 24px; padding: 48px; max-width: 440px; width: 100%; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
                <div style="text-align: center; margin-bottom: 32px;">
                    <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP" style="height: 50px; margin-bottom: 24px;">
                    <h1 style="font-size: 28px; font-weight: 800; margin: 0 0 8px 0;">Welcome Back</h1>
                    <p style="color: #6B7280; margin: 0;">Sign in to your PTP account</p>
                </div>
                
                <?php 
                // Use WooCommerce login form if available, otherwise WordPress
                if (function_exists('woocommerce_login_form')) {
                    woocommerce_login_form(array('redirect' => get_permalink()));
                } else {
                    wp_login_form(array(
                        'redirect' => get_permalink(),
                        'form_id' => 'ptp-login-form',
                        'label_username' => 'Email Address',
                        'label_password' => 'Password',
                        'label_remember' => 'Remember me',
                        'label_log_in' => 'Sign In'
                    ));
                }
                ?>
                
                <div style="margin-top: 24px; padding-top: 24px; border-top: 1px solid #E5E7EB; text-align: center;">
                    <p style="color: #6B7280; font-size: 14px; margin: 0;">
                        Don't have an account? 
                        <a href="<?php echo home_url('/find-trainers/'); ?>" style="color: #FCB900; font-weight: 600; text-decoration: none;">Book a session</a> 
                        or 
                        <a href="<?php echo home_url('/coach-application/'); ?>" style="color: #FCB900; font-weight: 600; text-decoration: none;">become a trainer</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
    
    <style>
    /* Style the WordPress login form */
    #ptp-login-form label {
        display: block;
        font-weight: 600;
        font-size: 14px;
        color: #374151;
        margin-bottom: 6px;
    }
    #ptp-login-form input[type="text"],
    #ptp-login-form input[type="password"] {
        width: 100%;
        padding: 14px 16px;
        border: 2px solid #E5E7EB;
        border-radius: 12px;
        font-size: 16px;
        margin-bottom: 16px;
        transition: border-color 0.2s;
    }
    #ptp-login-form input[type="text"]:focus,
    #ptp-login-form input[type="password"]:focus {
        border-color: #FCB900;
        outline: none;
    }
    #ptp-login-form input[type="submit"] {
        width: 100%;
        padding: 16px;
        background: #FCB900;
        color: #0E0F11;
        font-size: 16px;
        font-weight: 700;
        border: none;
        border-radius: 12px;
        cursor: pointer;
        transition: background 0.2s;
    }
    #ptp-login-form input[type="submit"]:hover {
        background: #E5A800;
    }
    #ptp-login-form .login-remember {
        margin-bottom: 16px;
    }
    #ptp-login-form .login-remember label {
        display: flex;
        align-items: center;
        gap: 8px;
        font-weight: 500;
    }
    </style>
    <?php
    return;
}

// User is logged in
$current_user = wp_get_current_user();
$first_name = $current_user->first_name ?: $current_user->display_name;

// Check if user is a trainer
global $wpdb;
$trainer = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
    $current_user->ID
));
$is_trainer = !empty($trainer);

// Get WooCommerce orders if available
$orders = array();
if (function_exists('wc_get_orders')) {
    $orders = wc_get_orders(array(
        'customer' => $current_user->ID,
        'limit' => 10,
        'orderby' => 'date',
        'order' => 'DESC'
    ));
}

// PTP Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';

// Current tab
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'dashboard';
?>

<style>
body:has(.ptp-page-wrap) #starter-starter > header,
body:has(.ptp-page-wrap) .starter-header,
body:has(.ptp-page-wrap) header.site-header { display: none !important; }

.ptp-account-nav a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 14px 18px;
    color: #374151;
    text-decoration: none;
    font-size: 15px;
    font-weight: 500;
    border-radius: 12px;
    transition: all 0.15s;
}
.ptp-account-nav a:hover {
    background: #F3F4F6;
    color: #0E0F11;
}
.ptp-account-nav a.active {
    background: #FCB900;
    color: #0E0F11;
    font-weight: 700;
}
.ptp-account-nav a svg {
    width: 20px;
    height: 20px;
    opacity: 0.7;
}
.ptp-account-nav a.active svg,
.ptp-account-nav a:hover svg {
    opacity: 1;
}
.ptp-account-card {
    background: #fff;
    border-radius: 20px;
    padding: 28px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    margin-bottom: 24px;
}
.ptp-account-card h3 {
    font-size: 18px;
    font-weight: 700;
    margin: 0 0 20px 0;
    color: #0E0F11;
}

/* Responsive */
@media (max-width: 768px) {
    .ptp-account-grid {
        grid-template-columns: 1fr !important;
    }
    .ptp-account-sidebar {
        margin-bottom: 24px;
    }
}
</style>

<div class="ptp-account-wrap ptp-page-wrap" style="font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif; color: #0E0F11; background: #F9FAFB; min-height: 100vh;">
    
    <?php 
    $ptp_active_page = '';
    include PTP_TRAINING_PATH . 'templates/frontend/header-component.php';
    ?>
    
    <!-- Hero -->
    <section style="background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%); padding: 48px 24px;">
        <div style="max-width: 1200px; margin: 0 auto;">
            <h1 style="font-size: 36px; font-weight: 900; color: #fff; margin: 0 0 8px 0;">My Account</h1>
            <p style="font-size: 18px; color: rgba(255,255,255,0.7); margin: 0;">Manage your profile, orders, and settings</p>
        </div>
    </section>
    
    <!-- Main Content -->
    <div style="max-width: 1200px; margin: 0 auto; padding: 32px 24px;">
        <div class="ptp-account-grid" style="display: grid; grid-template-columns: 280px 1fr; gap: 32px; align-items: start;">
            
            <!-- Sidebar -->
            <div class="ptp-account-sidebar">
                <!-- User Card -->
                <div class="ptp-account-card" style="text-align: center;">
                    <div style="width: 80px; height: 80px; background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px; font-size: 32px; font-weight: 800; color: #0E0F11;">
                        <?php echo strtoupper(substr($first_name, 0, 1)); ?>
                    </div>
                    <h2 style="font-size: 20px; font-weight: 700; margin: 0 0 4px 0;"><?php echo esc_html($current_user->display_name); ?></h2>
                    <p style="color: #6B7280; font-size: 14px; margin: 0 0 16px 0;"><?php echo esc_html($current_user->user_email); ?></p>
                    <?php if ($is_trainer): ?>
                        <span style="display: inline-block; padding: 6px 14px; background: #D1FAE5; color: #065F46; font-size: 12px; font-weight: 700; border-radius: 100px;">PTP Trainer</span>
                    <?php endif; ?>
                </div>
                
                <!-- Navigation -->
                <div class="ptp-account-card">
                    <nav class="ptp-account-nav" style="display: flex; flex-direction: column; gap: 6px;">
                        <a href="?tab=dashboard" class="<?php echo $current_tab === 'dashboard' ? 'active' : ''; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                            Dashboard
                        </a>
                        <?php if ($is_trainer): ?>
                            <a href="<?php echo home_url('/trainer-dashboard/'); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                                Trainer Dashboard
                            </a>
                        <?php else: ?>
                            <a href="<?php echo home_url('/my-training/'); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                                My Training
                            </a>
                        <?php endif; ?>
                        <a href="?tab=orders" class="<?php echo $current_tab === 'orders' ? 'active' : ''; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                            Orders
                        </a>
                        <a href="?tab=details" class="<?php echo $current_tab === 'details' ? 'active' : ''; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                            Account Details
                        </a>
                        <a href="?tab=addresses" class="<?php echo $current_tab === 'addresses' ? 'active' : ''; ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            Addresses
                        </a>
                        <a href="<?php echo wp_logout_url(home_url()); ?>" style="color: #EF4444; margin-top: 8px; border-top: 1px solid #E5E7EB; padding-top: 14px;">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                            Log Out
                        </a>
                    </nav>
                </div>
            </div>
            
            <!-- Content -->
            <div class="ptp-account-content">
                <?php if ($current_tab === 'dashboard'): ?>
                    <!-- Dashboard -->
                    <div class="ptp-account-card">
                        <h3>👋 Welcome back, <?php echo esc_html($first_name); ?>!</h3>
                        <p style="color: #6B7280; margin: 0 0 24px 0;">From your account dashboard you can view your recent orders, manage your training sessions, and edit your account details.</p>
                        
                        <!-- Quick Links -->
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
                            <?php if ($is_trainer): ?>
                                <a href="<?php echo home_url('/trainer-dashboard/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 20px; background: #FEFCE8; border: 2px solid #FCB900; border-radius: 16px; text-decoration: none; color: #0E0F11; transition: transform 0.2s;">
                                    <span style="width: 48px; height: 48px; background: #FCB900; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                                    </span>
                                    <div>
                                        <strong style="display: block; font-size: 15px;">Trainer Dashboard</strong>
                                        <span style="font-size: 13px; color: #6B7280;">Manage bookings & profile</span>
                                    </div>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo home_url('/my-training/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 20px; background: #FEFCE8; border: 2px solid #FCB900; border-radius: 16px; text-decoration: none; color: #0E0F11; transition: transform 0.2s;">
                                    <span style="width: 48px; height: 48px; background: #FCB900; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                                    </span>
                                    <div>
                                        <strong style="display: block; font-size: 15px;">My Training</strong>
                                        <span style="font-size: 13px; color: #6B7280;">View sessions & progress</span>
                                    </div>
                                </a>
                            <?php endif; ?>
                            
                            <a href="<?php echo home_url('/find-trainers/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 20px; background: #F9FAFB; border: 2px solid #E5E7EB; border-radius: 16px; text-decoration: none; color: #0E0F11; transition: transform 0.2s;">
                                <span style="width: 48px; height: 48px; background: #E5E7EB; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                                </span>
                                <div>
                                    <strong style="display: block; font-size: 15px;">Find Trainers</strong>
                                    <span style="font-size: 13px; color: #6B7280;">Book your next session</span>
                                </div>
                            </a>
                            
                            <a href="<?php echo home_url('/ptp-shop-page/'); ?>" style="display: flex; align-items: center; gap: 14px; padding: 20px; background: #F9FAFB; border: 2px solid #E5E7EB; border-radius: 16px; text-decoration: none; color: #0E0F11; transition: transform 0.2s;">
                                <span style="width: 48px; height: 48px; background: #E5E7EB; border-radius: 12px; display: flex; align-items: center; justify-content: center;">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#FCB900" stroke="none"><circle cx="12" cy="12" r="10"/></svg>
                                </span>
                                <div>
                                    <strong style="display: block; font-size: 15px;">Summer Camps</strong>
                                    <span style="font-size: 13px; color: #6B7280;">Register for 2026</span>
                                </div>
                            </a>
                        </div>
                    </div>
                    
                    <!-- Recent Orders -->
                    <?php if (!empty($orders)): ?>
                    <div class="ptp-account-card">
                        <h3>Recent Orders</h3>
                        <div style="overflow-x: auto;">
                            <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                                <thead>
                                    <tr style="border-bottom: 2px solid #E5E7EB;">
                                        <th style="text-align: left; padding: 12px 8px; font-weight: 600; color: #6B7280;">Order</th>
                                        <th style="text-align: left; padding: 12px 8px; font-weight: 600; color: #6B7280;">Date</th>
                                        <th style="text-align: left; padding: 12px 8px; font-weight: 600; color: #6B7280;">Status</th>
                                        <th style="text-align: right; padding: 12px 8px; font-weight: 600; color: #6B7280;">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach (array_slice($orders, 0, 5) as $order): ?>
                                    <tr style="border-bottom: 1px solid #F3F4F6;">
                                        <td style="padding: 14px 8px; font-weight: 600;">#<?php echo $order->get_order_number(); ?></td>
                                        <td style="padding: 14px 8px; color: #6B7280;"><?php echo $order->get_date_created()->date('M j, Y'); ?></td>
                                        <td style="padding: 14px 8px;">
                                            <?php 
                                            $status = $order->get_status();
                                            $status_colors = array(
                                                'completed' => '#D1FAE5',
                                                'processing' => '#DBEAFE',
                                                'pending' => '#FEF3C7',
                                                'cancelled' => '#FEE2E2',
                                                'refunded' => '#F3F4F6'
                                            );
                                            $bg = $status_colors[$status] ?? '#F3F4F6';
                                            ?>
                                            <span style="display: inline-block; padding: 4px 12px; background: <?php echo $bg; ?>; border-radius: 100px; font-size: 12px; font-weight: 600; text-transform: capitalize;"><?php echo esc_html($status); ?></span>
                                        </td>
                                        <td style="padding: 14px 8px; text-align: right; font-weight: 600;"><?php echo $order->get_formatted_order_total(); ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                        <a href="?tab=orders" style="display: inline-block; margin-top: 16px; color: #FCB900; font-weight: 600; text-decoration: none;">View all orders →</a>
                    </div>
                    <?php endif; ?>
                    
                <?php elseif ($current_tab === 'orders'): ?>
                    <!-- Orders -->
                    <div class="ptp-account-card">
                        <h3>Order History</h3>
                        <?php if (!empty($orders)): ?>
                            <div style="overflow-x: auto;">
                                <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                                    <thead>
                                        <tr style="border-bottom: 2px solid #E5E7EB;">
                                            <th style="text-align: left; padding: 12px 8px; font-weight: 600; color: #6B7280;">Order</th>
                                            <th style="text-align: left; padding: 12px 8px; font-weight: 600; color: #6B7280;">Date</th>
                                            <th style="text-align: left; padding: 12px 8px; font-weight: 600; color: #6B7280;">Status</th>
                                            <th style="text-align: right; padding: 12px 8px; font-weight: 600; color: #6B7280;">Total</th>
                                            <th style="text-align: right; padding: 12px 8px; font-weight: 600; color: #6B7280;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orders as $order): ?>
                                        <tr style="border-bottom: 1px solid #F3F4F6;">
                                            <td style="padding: 14px 8px; font-weight: 600;">#<?php echo $order->get_order_number(); ?></td>
                                            <td style="padding: 14px 8px; color: #6B7280;"><?php echo $order->get_date_created()->date('M j, Y'); ?></td>
                                            <td style="padding: 14px 8px;">
                                                <?php 
                                                $status = $order->get_status();
                                                $status_colors = array(
                                                    'completed' => '#D1FAE5',
                                                    'processing' => '#DBEAFE',
                                                    'pending' => '#FEF3C7',
                                                    'cancelled' => '#FEE2E2',
                                                    'refunded' => '#F3F4F6'
                                                );
                                                $bg = $status_colors[$status] ?? '#F3F4F6';
                                                ?>
                                                <span style="display: inline-block; padding: 4px 12px; background: <?php echo $bg; ?>; border-radius: 100px; font-size: 12px; font-weight: 600; text-transform: capitalize;"><?php echo esc_html($status); ?></span>
                                            </td>
                                            <td style="padding: 14px 8px; text-align: right; font-weight: 600;"><?php echo $order->get_formatted_order_total(); ?></td>
                                            <td style="padding: 14px 8px; text-align: right;">
                                                <a href="<?php echo $order->get_view_order_url(); ?>" style="color: #FCB900; font-weight: 600; text-decoration: none;">View</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div style="text-align: center; padding: 48px 24px; color: #6B7280;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin: 0 auto 16px; opacity: 0.5;"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                                <p style="margin: 0;">No orders yet</p>
                                <a href="<?php echo home_url('/ptp-shop-page/'); ?>" style="display: inline-block; margin-top: 16px; padding: 12px 24px; background: #FCB900; color: #0E0F11; font-weight: 600; text-decoration: none; border-radius: 10px;">Browse Camps</a>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                <?php elseif ($current_tab === 'details'): ?>
                    <!-- Account Details -->
                    <div class="ptp-account-card">
                        <h3>Account Details</h3>
                        <?php if (function_exists('woocommerce_account_edit_account')): ?>
                            <?php woocommerce_account_edit_account(); ?>
                        <?php else: ?>
                            <form method="post" id="ptp-account-form">
                                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                                    <div>
                                        <label style="display: block; font-weight: 600; font-size: 14px; color: #374151; margin-bottom: 6px;">First Name</label>
                                        <input type="text" name="first_name" value="<?php echo esc_attr($current_user->first_name); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px;">
                                    </div>
                                    <div>
                                        <label style="display: block; font-weight: 600; font-size: 14px; color: #374151; margin-bottom: 6px;">Last Name</label>
                                        <input type="text" name="last_name" value="<?php echo esc_attr($current_user->last_name); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px;">
                                    </div>
                                </div>
                                <div style="margin-bottom: 20px;">
                                    <label style="display: block; font-weight: 600; font-size: 14px; color: #374151; margin-bottom: 6px;">Display Name</label>
                                    <input type="text" name="display_name" value="<?php echo esc_attr($current_user->display_name); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px;">
                                </div>
                                <div style="margin-bottom: 20px;">
                                    <label style="display: block; font-weight: 600; font-size: 14px; color: #374151; margin-bottom: 6px;">Email Address</label>
                                    <input type="email" name="email" value="<?php echo esc_attr($current_user->user_email); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 10px; font-size: 15px;">
                                </div>
                                <p style="color: #6B7280; font-size: 14px; margin: 0 0 20px 0;">To change your password, visit <a href="<?php echo wp_lostpassword_url(); ?>" style="color: #FCB900;">password reset</a>.</p>
                                <button type="submit" style="padding: 14px 28px; background: #FCB900; color: #0E0F11; font-size: 15px; font-weight: 700; border: none; border-radius: 10px; cursor: pointer;">Save Changes</button>
                            </form>
                        <?php endif; ?>
                    </div>
                    
                <?php elseif ($current_tab === 'addresses'): ?>
                    <!-- Addresses -->
                    <div class="ptp-account-card">
                        <h3>Addresses</h3>
                        <?php if (function_exists('woocommerce_account_edit_address')): ?>
                            <?php woocommerce_account_edit_address('billing'); ?>
                        <?php else: ?>
                            <p style="color: #6B7280;">Address management requires WooCommerce.</p>
                        <?php endif; ?>
                    </div>
                    
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
