<?php
/**
 * PTP Unified Header Component
 * Include this in all frontend templates for consistent navigation
 * 
 * Usage: 
 * $ptp_active_page = 'find-trainers'; // or 'private-training', 'my-training', etc.
 * include PTP_TRAINING_PATH . 'templates/frontend/header-component.php';
 */

defined('ABSPATH') || exit;

// Get current user info
$ptp_is_logged_in = is_user_logged_in();
$ptp_current_user = $ptp_is_logged_in ? wp_get_current_user() : null;
$ptp_is_trainer = false;
$ptp_trainer = null;

if ($ptp_is_logged_in) {
    global $wpdb;
    $ptp_trainer = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d AND status = 'approved'",
        $ptp_current_user->ID
    ));
    $ptp_is_trainer = !empty($ptp_trainer);
}

// Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';

// Active page (should be set before including this file)
$ptp_active_page = isset($ptp_active_page) ? $ptp_active_page : '';
?>

<!-- Unified Header -->
<header class="ptp-unified-header">
    <div class="ptp-header-inner">
        <a href="<?php echo home_url(); ?>" class="ptp-header-logo">
            <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP Soccer">
        </a>
        
        <nav class="ptp-header-nav">
            <a href="<?php echo home_url('/private-training/'); ?>" <?php echo $ptp_active_page === 'private-training' ? 'class="active"' : ''; ?>>Private Training</a>
            <a href="<?php echo home_url('/find-trainers/'); ?>" <?php echo $ptp_active_page === 'find-trainers' ? 'class="active"' : ''; ?>>Find Trainers</a>
            <a href="<?php echo home_url('/ptp-shop-page/'); ?>" <?php echo $ptp_active_page === 'camps' ? 'class="active"' : ''; ?>>Summer Camps</a>
            <a href="<?php echo home_url('/coach-application/'); ?>" <?php echo $ptp_active_page === 'apply' ? 'class="active"' : ''; ?>>Become a Coach</a>
        </nav>
        
        <div class="ptp-header-actions">
            <?php if ($ptp_is_logged_in): ?>
                <?php if ($ptp_is_trainer): ?>
                    <!-- Trainer: Show Dashboard -->
                    <a href="<?php echo home_url('/trainer-dashboard/'); ?>" class="ptp-header-cta desktop-only">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                        Dashboard
                    </a>
                <?php else: ?>
                    <!-- Parent/Customer: Show My Training -->
                    <a href="<?php echo home_url('/my-training/'); ?>" class="ptp-header-cta desktop-only">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                        My Training
                    </a>
                <?php endif; ?>
                
                <!-- User Menu Dropdown -->
                <div class="ptp-user-menu">
                    <button class="ptp-user-btn" onclick="this.parentElement.classList.toggle('open')">
                        <span class="ptp-user-avatar">
                            <?php echo substr($ptp_current_user->display_name, 0, 1); ?>
                        </span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                    </button>
                    <div class="ptp-user-dropdown">
                        <div class="ptp-user-info">
                            <strong><?php echo esc_html($ptp_current_user->display_name); ?></strong>
                            <span><?php echo esc_html($ptp_current_user->user_email); ?></span>
                        </div>
                        <div class="ptp-user-links">
                            <?php if ($ptp_is_trainer): ?>
                                <a href="<?php echo home_url('/trainer-dashboard/'); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                                    Trainer Dashboard
                                </a>
                                <a href="<?php echo home_url('/trainer/' . $ptp_trainer->slug . '/'); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                                    My Profile
                                </a>
                            <?php else: ?>
                                <a href="<?php echo home_url('/my-training/'); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                                    My Training
                                </a>
                            <?php endif; ?>
                            <a href="<?php echo wp_logout_url(home_url()); ?>" class="ptp-logout-link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                                Log Out
                            </a>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <!-- Not Logged In: Show Login -->
                <a href="<?php echo wp_login_url(get_permalink()); ?>" class="ptp-header-login desktop-only">
                    Log In
                </a>
                <a href="<?php echo home_url('/find-trainers/'); ?>" class="ptp-header-cta desktop-only">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                    Find Trainers
                </a>
            <?php endif; ?>
        </div>
        
        <button class="ptp-mobile-menu-btn" onclick="document.getElementById('mobileNav').classList.toggle('active')">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
        </button>
    </div>
    
    <!-- Mobile Navigation -->
    <nav id="mobileNav" class="ptp-mobile-nav">
        <a href="<?php echo home_url('/private-training/'); ?>" <?php echo $ptp_active_page === 'private-training' ? 'class="active"' : ''; ?>>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
            Private Training
        </a>
        <a href="<?php echo home_url('/find-trainers/'); ?>" <?php echo $ptp_active_page === 'find-trainers' ? 'class="active"' : ''; ?>>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            Find Trainers
        </a>
        <a href="<?php echo home_url('/ptp-shop-page/'); ?>" <?php echo $ptp_active_page === 'camps' ? 'class="active"' : ''; ?>>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="#FCB900" stroke="none"><circle cx="12" cy="12" r="10"/></svg>
            Summer Camps
        </a>
        
        <?php if ($ptp_is_logged_in): ?>
            <?php if ($ptp_is_trainer): ?>
                <a href="<?php echo home_url('/trainer-dashboard/'); ?>" <?php echo $ptp_active_page === 'trainer-dashboard' ? 'class="active"' : ''; ?>>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
                    Trainer Dashboard
                </a>
            <?php else: ?>
                <a href="<?php echo home_url('/my-training/'); ?>" <?php echo $ptp_active_page === 'my-training' ? 'class="active"' : ''; ?>>
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>
                    My Training
                </a>
            <?php endif; ?>
            <a href="<?php echo wp_logout_url(home_url()); ?>" class="mobile-logout">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                Log Out
            </a>
        <?php else: ?>
            <a href="<?php echo wp_login_url(get_permalink()); ?>" class="mobile-login">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                Log In
            </a>
        <?php endif; ?>
        
        <a href="<?php echo home_url('/coach-application/'); ?>" <?php echo $ptp_active_page === 'apply' ? 'class="active"' : ''; ?>>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
            Become a Coach
        </a>
    </nav>
</header>

<style>
/* User Menu Dropdown Styles */
.ptp-header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
}

.ptp-header-login {
    padding: 10px 20px;
    color: #fff;
    text-decoration: none;
    font-weight: 600;
    font-size: 14px;
    border: 2px solid rgba(255,255,255,0.3);
    border-radius: 8px;
    transition: all 0.2s;
}
.ptp-header-login:hover {
    background: rgba(255,255,255,0.1);
    border-color: rgba(255,255,255,0.5);
}

.ptp-user-menu {
    position: relative;
}

.ptp-user-btn {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 12px 6px 6px;
    background: rgba(255,255,255,0.1);
    border: 2px solid rgba(255,255,255,0.2);
    border-radius: 100px;
    cursor: pointer;
    transition: all 0.2s;
}
.ptp-user-btn:hover {
    background: rgba(255,255,255,0.15);
    border-color: rgba(255,255,255,0.3);
}

.ptp-user-avatar {
    width: 32px;
    height: 32px;
    background: #FCB900;
    color: #0E0F11;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 14px;
    text-transform: uppercase;
}

.ptp-user-btn svg {
    color: #fff;
    transition: transform 0.2s;
}
.ptp-user-menu.open .ptp-user-btn svg {
    transform: rotate(180deg);
}

.ptp-user-dropdown {
    position: absolute;
    top: calc(100% + 8px);
    right: 0;
    width: 260px;
    background: #fff;
    border-radius: 16px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.2);
    opacity: 0;
    visibility: hidden;
    transform: translateY(-10px);
    transition: all 0.2s;
    z-index: 1000;
    overflow: hidden;
}
.ptp-user-menu.open .ptp-user-dropdown {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
}

.ptp-user-info {
    padding: 16px 20px;
    border-bottom: 1px solid #E5E7EB;
    background: #F9FAFB;
}
.ptp-user-info strong {
    display: block;
    font-size: 15px;
    font-weight: 700;
    color: #0E0F11;
    margin-bottom: 2px;
}
.ptp-user-info span {
    font-size: 13px;
    color: #6B7280;
}

.ptp-user-links {
    padding: 8px;
}
.ptp-user-links a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    color: #374151;
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    border-radius: 10px;
    transition: all 0.15s;
}
.ptp-user-links a:hover {
    background: #F3F4F6;
    color: #0E0F11;
}
.ptp-user-links a svg {
    color: #9CA3AF;
}
.ptp-user-links a:hover svg {
    color: #FCB900;
}

.ptp-logout-link {
    border-top: 1px solid #E5E7EB;
    margin-top: 8px;
    padding-top: 8px;
}
.ptp-logout-link:hover {
    color: #EF4444 !important;
}
.ptp-logout-link:hover svg {
    color: #EF4444 !important;
}

.mobile-login, .mobile-logout {
    border-top: 1px solid rgba(255,255,255,0.1);
    margin-top: 8px;
    padding-top: 16px !important;
}

/* Close dropdown when clicking outside */
@media (min-width: 769px) {
    .ptp-user-menu:not(:focus-within) .ptp-user-dropdown {
        /* Handled by JS */
    }
}
</style>

<script>
// Close user dropdown when clicking outside
document.addEventListener('click', function(e) {
    const userMenu = document.querySelector('.ptp-user-menu');
    if (userMenu && !userMenu.contains(e.target)) {
        userMenu.classList.remove('open');
    }
});
</script>
