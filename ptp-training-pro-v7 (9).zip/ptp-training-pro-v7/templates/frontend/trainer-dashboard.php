<?php
/**
 * Trainer Dashboard - v7.0
 * For approved trainers to manage their profile and sessions
 * Full-width layout with unified styling
 */

defined('ABSPATH') || exit;

// Require login
if (!is_user_logged_in()) {
    wp_redirect(wp_login_url(get_permalink()));
    exit;
}

$current_user = wp_get_current_user();
$user_id = $current_user->ID;

// Get trainer profile
global $wpdb;
$trainer = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
    $user_id
));

// Output critical styles
echo '<style id="ptp-critical-fullwidth">
.ptp-page-wrap, .ptp-trainer-dashboard-wrap { 
    width: 100vw !important; 
    max-width: 100vw !important; 
    margin-left: calc(50% - 50vw) !important; 
    margin-right: calc(50% - 50vw) !important; 
    position: relative !important; 
    background: #fff !important;
    display: block !important;
    padding: 0 !important;
}
.entry-content, .post-content, .page-content, .site-content, .content-area, article, main, #main, #content, .container, .site-main { 
    max-width: 100% !important; 
    width: 100% !important; 
    padding-left: 0 !important; 
    padding-right: 0 !important;
    margin: 0 !important;
    overflow: visible !important;
}
body { overflow-x: hidden !important; }
</style>';

// If not a trainer, show message
if (!$trainer) {
    ?>
    <div class="ptp-trainer-dashboard-wrap ptp-page-wrap" style="min-height: 100vh; background: #F9FAFB; display: flex; align-items: center; justify-content: center; padding: 24px;">
        <div class="ptp-empty-state" style="padding: 60px 48px;">
            <div class="ptp-empty-icon" style="background: #FEF3C7;">
                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="#FCB900" stroke="none"><circle cx="12" cy="12" r="10"/></svg>
            </div>
            <h1 class="ptp-empty-title">Not a Trainer Yet</h1>
            <p class="ptp-empty-text">You need to be an approved PTP trainer to access this dashboard.</p>
            <a href="<?php echo home_url('/coach-application/'); ?>" class="ptp-btn-primary">
                Apply to Become a Trainer
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
            </a>
        </div>
    </div>
    <?php
    return;
}

$trainer_id = $trainer->id;
$first_name = explode(' ', $trainer->display_name)[0];

// Get stats
$upcoming_sessions = $wpdb->get_results($wpdb->prepare(
    "SELECT s.*, p.athlete_name, p.athlete_age
     FROM {$wpdb->prefix}ptp_sessions s
     LEFT JOIN {$wpdb->prefix}ptp_lesson_packs p ON s.pack_id = p.id
     WHERE s.trainer_id = %d 
     AND s.session_date >= CURDATE()
     AND s.session_status IN ('confirmed', 'scheduled')
     ORDER BY s.session_date ASC, s.start_time ASC
     LIMIT 10",
    $trainer_id
)) ?: [];

$pending_requests = $wpdb->get_results($wpdb->prepare(
    "SELECT s.*, p.athlete_name, p.athlete_age, u.display_name as parent_name, u.user_email as parent_email
     FROM {$wpdb->prefix}ptp_sessions s
     LEFT JOIN {$wpdb->prefix}ptp_lesson_packs p ON s.pack_id = p.id
     LEFT JOIN {$wpdb->users} u ON s.customer_id = u.ID
     WHERE s.trainer_id = %d AND s.session_status = 'requested'
     ORDER BY s.created_at DESC",
    $trainer_id
)) ?: [];

$completed_count = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_sessions WHERE trainer_id = %d AND session_status = 'completed'",
    $trainer_id
)) ?: 0;

$total_earnings = $wpdb->get_var($wpdb->prepare(
    "SELECT SUM(trainer_earnings) FROM {$wpdb->prefix}ptp_payouts WHERE trainer_id = %d AND status = 'paid'",
    $trainer_id
)) ?: 0;

$pending_earnings = $wpdb->get_var($wpdb->prepare(
    "SELECT SUM(trainer_earnings) FROM {$wpdb->prefix}ptp_payouts WHERE trainer_id = %d AND status = 'pending'",
    $trainer_id
)) ?: 0;

$review_count = $wpdb->get_var($wpdb->prepare(
    "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'published'",
    $trainer_id
)) ?: 0;

// PTP Logo
$ptp_logo = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
?>

<div class="ptp-trainer-dashboard" style="font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif; color: #0E0F11; background: #F9FAFB; min-height: 100vh;">
    
    <!-- Nav -->
    <nav style="background: #0E0F11; padding: 16px 24px;">
        <div style="max-width: 1400px; margin: 0 auto; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px;">
            <a href="<?php echo home_url(); ?>">
                <img src="<?php echo esc_url($ptp_logo); ?>" alt="PTP" style="height: 44px; width: auto;">
            </a>
            
            <div class="ptp-dashboard-nav-links" style="display: flex; align-items: center; gap: 24px;">
                <a href="<?php echo home_url('/trainer-dashboard/'); ?>" style="font-size: 14px; font-weight: 700; color: #FCB900; text-decoration: none;">Dashboard</a>
                <a href="<?php echo home_url('/trainer/' . $trainer->slug . '/'); ?>" style="font-size: 14px; font-weight: 500; color: #fff; text-decoration: none;">My Profile</a>
                <a href="<?php echo home_url('/find-trainers/'); ?>" style="font-size: 14px; font-weight: 500; color: #fff; text-decoration: none;" class="hide-mobile">Find Trainers</a>
            </div>
            
            <div class="ptp-dashboard-user" style="display: flex; align-items: center; gap: 16px;">
                <div style="display: flex; align-items: center; gap: 12px;">
                    <img src="<?php echo esc_url($trainer->profile_photo ?: 'https://via.placeholder.com/40'); ?>" alt="" style="width: 40px; height: 40px; border-radius: 10px; object-fit: cover; border: 2px solid #FCB900;">
                    <span class="hide-mobile" style="font-weight: 600; color: #fff; font-size: 14px;"><?php echo esc_html($trainer->display_name); ?></span>
                </div>
                <a href="<?php echo wp_logout_url(home_url()); ?>" style="font-size: 13px; color: #EF4444; text-decoration: none; font-weight: 500;">Log Out</a>
            </div>
        </div>
    </nav>
    
    <style>
    @media (max-width: 640px) {
        .ptp-dashboard-nav-links { gap: 16px !important; }
        .ptp-dashboard-user { gap: 10px !important; }
        .hide-mobile { display: none !important; }
    }
    </style>
    
    <!-- Welcome Section -->
    <section style="background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%); padding: 48px 24px;">
        <div style="max-width: 1400px; margin: 0 auto;">
            <h1 style="font-size: 36px; font-weight: 900; color: #fff; margin: 0 0 8px 0;">Welcome back, <?php echo esc_html($first_name); ?>!</h1>
            <p style="font-size: 18px; color: rgba(255,255,255,0.7); margin: 0;">Manage your training sessions and earnings</p>
        </div>
    </section>
    
    <!-- Stats Cards -->
    <div style="max-width: 1400px; margin: -24px auto 0; padding: 0 24px; position: relative; z-index: 1;">
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;" class="ptp-stats-grid">
            <div style="background: #fff; border-radius: 20px; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                <div style="display: flex; align-items: center; gap: 14px;">
                    <span style="width: 52px; height: 52px; background: #FEFCE8; border-radius: 14px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#FCB900" stroke="none"><circle cx="12" cy="12" r="10"/></svg></span>
                    <div>
                        <h3 style="font-size: 32px; font-weight: 900; color: #0E0F11; margin: 0; line-height: 1;"><?php echo $completed_count; ?></h3>
                        <p style="font-size: 13px; color: #6B7280; margin: 4px 0 0 0;">Sessions Completed</p>
                    </div>
                </div>
            </div>
            <div style="background: #fff; border-radius: 20px; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                <div style="display: flex; align-items: center; gap: 14px;">
                    <span style="width: 52px; height: 52px; background: #E0F2FE; border-radius: 14px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0EA5E9" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg></span>
                    <div>
                        <h3 style="font-size: 32px; font-weight: 900; color: #0E0F11; margin: 0; line-height: 1;"><?php echo count($upcoming_sessions); ?></h3>
                        <p style="font-size: 13px; color: #6B7280; margin: 4px 0 0 0;">Upcoming</p>
                    </div>
                </div>
            </div>
            <div style="background: #fff; border-radius: 20px; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                <div style="display: flex; align-items: center; gap: 14px;">
                    <span style="width: 52px; height: 52px; background: #F3E8FF; border-radius: 14px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#8B5CF6" stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg></span>
                    <div>
                        <h3 style="font-size: 32px; font-weight: 900; color: #0E0F11; margin: 0; line-height: 1;"><?php echo number_format($trainer->avg_rating ?: 5.0, 1); ?></h3>
                        <p style="font-size: 13px; color: #6B7280; margin: 4px 0 0 0;"><?php echo $review_count; ?> Reviews</p>
                    </div>
                </div>
            </div>
            <div style="background: #0E0F11; border-radius: 20px; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                <div style="display: flex; align-items: center; gap: 14px;">
                    <span style="width: 52px; height: 52px; background: #FCB900; border-radius: 14px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><line x1="12" x2="12" y1="2" y2="22"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg></span>
                    <div>
                        <h3 style="font-size: 32px; font-weight: 900; color: #FCB900; margin: 0; line-height: 1;">$<?php echo number_format($total_earnings); ?></h3>
                        <p style="font-size: 13px; color: #9CA3AF; margin: 4px 0 0 0;">Total Earned</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div style="max-width: 1400px; margin: 0 auto; padding: 48px 24px;">
        <div style="display: grid; grid-template-columns: 1fr 380px; gap: 32px;" class="ptp-main-grid">
            
            <!-- Left Column -->
            <div>
                <!-- Pending Requests -->
                <?php if (!empty($pending_requests)): ?>
                <div style="background: #FEF3C7; border: 2px solid #FCB900; border-radius: 24px; padding: 28px; margin-bottom: 24px;">
                    <h2 style="font-size: 20px; font-weight: 800; color: #0E0F11; margin: 0 0 20px 0; display: flex; align-items: center; gap: 10px;">
                        <span style="width: 32px; height: 32px; background: #FCB900; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 16px;">🔔</span>
                        Pending Requests (<?php echo count($pending_requests); ?>)
                    </h2>
                    
                    <?php foreach ($pending_requests as $request): ?>
                    <div style="background: #fff; border-radius: 16px; padding: 20px; margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
                        <div>
                            <h4 style="font-size: 16px; font-weight: 700; color: #0E0F11; margin: 0 0 4px 0;"><?php echo esc_html($request->athlete_name); ?> (Age <?php echo intval($request->athlete_age); ?>)</h4>
                            <p style="font-size: 14px; color: #6B7280; margin: 0;">Parent: <?php echo esc_html($request->parent_name); ?></p>
                        </div>
                        <div style="display: flex; gap: 10px;">
                            <button onclick="respondToRequest(<?php echo $request->id; ?>, 'confirm')" style="padding: 10px 20px; background: #10B981; color: #fff; font-size: 14px; font-weight: 700; border: none; border-radius: 8px; cursor: pointer;">Accept</button>
                            <button onclick="respondToRequest(<?php echo $request->id; ?>, 'decline')" style="padding: 10px 20px; background: #fff; color: #DC2626; font-size: 14px; font-weight: 700; border: 2px solid #DC2626; border-radius: 8px; cursor: pointer;">Decline</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                
                <!-- Upcoming Sessions -->
                <div style="background: #fff; border-radius: 24px; padding: 28px; box-shadow: 0 2px 12px rgba(0,0,0,0.06);">
                    <h2 style="font-size: 22px; font-weight: 800; color: #0E0F11; margin: 0 0 24px 0; display: flex; align-items: center; gap: 10px;">
                        <span style="width: 4px; height: 24px; background: #FCB900; border-radius: 2px;"></span>
                        Upcoming Sessions
                    </h2>
                    
                    <?php if (!empty($upcoming_sessions)): ?>
                        <?php foreach ($upcoming_sessions as $session): ?>
                        <div style="display: flex; gap: 16px; padding: 20px; background: #F9FAFB; border-radius: 16px; margin-bottom: 12px; border-left: 4px solid #FCB900;">
                            <div style="flex: 1;">
                                <h4 style="font-size: 17px; font-weight: 700; color: #0E0F11; margin: 0 0 6px 0;"><?php echo esc_html($session->athlete_name ?: $session->player_name); ?></h4>
                                <p style="font-size: 14px; color: #6B7280; margin: 0 0 10px 0;">Age <?php echo intval($session->athlete_age ?: $session->player_age); ?></p>
                                <div style="display: flex; gap: 16px; flex-wrap: wrap;">
                                    <span style="display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 600; color: #0E0F11;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                                        <?php echo date('D, M j', strtotime($session->session_date)); ?>
                                    </span>
                                    <span style="display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 600; color: #0E0F11;">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                                        <?php echo date('g:i A', strtotime($session->start_time)); ?>
                                    </span>
                                </div>
                            </div>
                            <span style="padding: 6px 12px; background: #D1FAE5; color: #065F46; font-size: 12px; font-weight: 600; border-radius: 100px; height: fit-content;">Confirmed</span>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div style="text-align: center; padding: 48px 24px;">
                            <div style="width: 64px; height: 64px; background: #F3F4F6; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg></div>
                            <h3 style="font-size: 18px; font-weight: 700; color: #0E0F11; margin: 0 0 8px 0;">No upcoming sessions</h3>
                            <p style="font-size: 14px; color: #6B7280; margin: 0;">Sessions will appear here when clients book with you.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Right Sidebar -->
            <div>
                <!-- Earnings Card -->
                <div style="background: #0E0F11; border-radius: 24px; padding: 28px; margin-bottom: 24px;">
                    <h3 style="font-size: 18px; font-weight: 700; color: #fff; margin: 0 0 24px 0;">Earnings</h3>
                    
                    <div style="margin-bottom: 24px;">
                        <div style="font-size: 12px; color: #9CA3AF; margin-bottom: 6px;">Pending Payout</div>
                        <div style="font-size: 36px; font-weight: 900; color: #FCB900;">$<?php echo number_format($pending_earnings, 2); ?></div>
                    </div>
                    
                    <div style="padding-top: 20px; border-top: 1px solid #374151;">
                        <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                            <span style="font-size: 14px; color: #9CA3AF;">Total Earned</span>
                            <span style="font-size: 14px; font-weight: 600; color: #fff;">$<?php echo number_format($total_earnings, 2); ?></span>
                        </div>
                        <div style="display: flex; justify-content: space-between;">
                            <span style="font-size: 14px; color: #9CA3AF;">Your Rate</span>
                            <span style="font-size: 14px; font-weight: 600; color: #fff;">$<?php echo number_format($trainer->hourly_rate ?? 75); ?>/hr</span>
                        </div>
                    </div>
                </div>
                
                <!-- Profile Card -->
                <div style="background: #fff; border: 1px solid #E5E7EB; border-radius: 24px; padding: 24px;">
                    <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 20px;">
                        <img src="<?php echo esc_url($trainer->profile_photo ?: 'https://via.placeholder.com/60'); ?>" alt="" style="width: 60px; height: 60px; border-radius: 14px; object-fit: cover; border: 2px solid #FCB900;">
                        <div>
                            <h4 style="font-size: 16px; font-weight: 700; color: #0E0F11; margin: 0 0 4px 0;"><?php echo esc_html($trainer->display_name); ?></h4>
                            <span style="display: inline-block; padding: 4px 10px; background: <?php echo $trainer->status === 'approved' ? '#D1FAE5' : '#FEF3C7'; ?>; color: <?php echo $trainer->status === 'approved' ? '#065F46' : '#92400E'; ?>; font-size: 11px; font-weight: 600; border-radius: 100px; text-transform: uppercase;"><?php echo esc_html($trainer->status); ?></span>
                        </div>
                    </div>
                    
                    <a href="<?php echo home_url('/trainer/'); ?>?id=<?php echo $trainer_id; ?>" style="display: flex; align-items: center; justify-content: center; gap: 8px; width: 100%; padding: 14px; background: #F9FAFB; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 14px; font-weight: 700; color: #374151; text-decoration: none;">
                        View Public Profile
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                    </a>
                </div>
                
                <!-- Quick Links -->
                <div style="background: #fff; border: 1px solid #E5E7EB; border-radius: 24px; padding: 24px; margin-top: 24px;">
                    <h3 style="font-size: 16px; font-weight: 700; color: #0E0F11; margin: 0 0 16px 0;">Quick Actions</h3>
                    <nav style="display: flex; flex-direction: column; gap: 8px;">
                        <a href="#" onclick="document.getElementById('editProfileModal').style.display='flex'; return false;" style="display: flex; align-items: center; gap: 14px; padding: 14px; border-radius: 12px; text-decoration: none; color: #374151; font-size: 14px; font-weight: 600; background: #F9FAFB;">
                            <span style="width: 36px; height: 36px; background: #E5E7EB; border-radius: 10px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#374151" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg></span>
                            Edit Profile
                        </a>
                        <a href="<?php echo home_url('/trainer/' . $trainer->slug . '/'); ?>" target="_blank" style="display: flex; align-items: center; gap: 14px; padding: 14px; border-radius: 12px; text-decoration: none; color: #374151; font-size: 14px; font-weight: 600; background: #F9FAFB;">
                            <span style="width: 36px; height: 36px; background: #FEFCE8; border-radius: 10px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg></span>
                            View Public Profile
                        </a>
                        <a href="<?php echo wp_logout_url(home_url()); ?>" style="display: flex; align-items: center; gap: 14px; padding: 14px; border-radius: 12px; text-decoration: none; color: #374151; font-size: 14px; font-weight: 600; background: #F9FAFB;">
                            <span style="width: 36px; height: 36px; background: #FEE2E2; border-radius: 10px; display: flex; align-items: center; justify-content: center;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#DC2626" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg></span>
                            Log Out
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Edit Profile Modal -->
<div id="editProfileModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 9999; align-items: center; justify-content: center; padding: 24px;">
    <div style="background: #fff; border-radius: 24px; max-width: 600px; width: 100%; max-height: 90vh; overflow-y: auto;">
        <div style="padding: 24px; border-bottom: 1px solid #E5E7EB; display: flex; justify-content: space-between; align-items: center;">
            <h2 style="font-size: 20px; font-weight: 700; margin: 0;">Edit Profile</h2>
            <button onclick="document.getElementById('editProfileModal').style.display='none';" style="background: none; border: none; cursor: pointer; padding: 8px;">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
        <form id="trainerProfileForm" style="padding: 24px;">
            <input type="hidden" name="action" value="ptp_update_trainer_profile">
            <input type="hidden" name="trainer_id" value="<?php echo $trainer_id; ?>">
            <?php wp_nonce_field('ptp_update_profile', 'profile_nonce'); ?>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">Display Name</label>
                <input type="text" name="display_name" value="<?php echo esc_attr($trainer->display_name); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">Profile Photo URL</label>
                <input type="url" name="profile_photo" value="<?php echo esc_attr($trainer->profile_photo); ?>" placeholder="https://..." style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
                <p style="font-size: 12px; color: #6B7280; margin-top: 6px;">Upload your photo to your preferred host and paste the URL here</p>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">Hourly Rate ($)</label>
                <input type="number" name="hourly_rate" value="<?php echo esc_attr($trainer->hourly_rate ?: 75); ?>" min="25" max="500" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">Bio / About Me</label>
                <textarea name="bio" rows="4" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px; resize: vertical;"><?php echo esc_textarea($trainer->bio); ?></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 20px;">
                <div>
                    <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">City</label>
                    <input type="text" name="primary_location_city" value="<?php echo esc_attr($trainer->primary_location_city); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
                </div>
                <div>
                    <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">State</label>
                    <input type="text" name="primary_location_state" value="<?php echo esc_attr($trainer->primary_location_state); ?>" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
                </div>
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">Specialties (comma-separated)</label>
                <input type="text" name="specialties" value="<?php echo esc_attr($trainer->specialties); ?>" placeholder="Ball Control, Shooting, Defense" style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
            </div>
            
            <div style="margin-bottom: 20px;">
                <label style="display: block; font-size: 14px; font-weight: 600; color: #374151; margin-bottom: 8px;">Intro Video URL (YouTube/Vimeo)</label>
                <input type="url" name="intro_video_url" value="<?php echo esc_attr($trainer->intro_video_url); ?>" placeholder="https://youtube.com/..." style="width: 100%; padding: 12px 16px; border: 2px solid #E5E7EB; border-radius: 12px; font-size: 15px;">
            </div>
            
            <div id="profileFormMessage" style="display: none; padding: 12px 16px; border-radius: 12px; margin-bottom: 20px;"></div>
            
            <button type="submit" style="width: 100%; padding: 16px; background: #FCB900; color: #0E0F11; border: none; border-radius: 12px; font-size: 16px; font-weight: 700; cursor: pointer;">
                Save Changes
            </button>
        </form>
    </div>
</div>

<script>
document.getElementById('trainerProfileForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const form = this;
    const btn = form.querySelector('button[type="submit"]');
    const msgEl = document.getElementById('profileFormMessage');
    
    btn.disabled = true;
    btn.textContent = 'Saving...';
    
    const formData = new FormData(form);
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        msgEl.style.display = 'block';
        if (data.success) {
            msgEl.style.background = '#D1FAE5';
            msgEl.style.color = '#065F46';
            msgEl.textContent = 'Profile updated successfully!';
            setTimeout(() => {
                document.getElementById('editProfileModal').style.display = 'none';
                location.reload();
            }, 1500);
        } else {
            msgEl.style.background = '#FEE2E2';
            msgEl.style.color = '#991B1B';
            msgEl.textContent = data.data?.message || 'Error saving profile';
            btn.disabled = false;
            btn.textContent = 'Save Changes';
        }
    })
    .catch(() => {
        msgEl.style.display = 'block';
        msgEl.style.background = '#FEE2E2';
        msgEl.style.color = '#991B1B';
        msgEl.textContent = 'Connection error';
        btn.disabled = false;
        btn.textContent = 'Save Changes';
    });
});
</script>
