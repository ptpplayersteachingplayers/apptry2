<?php
/**
 * WooCommerce Integration - v5.5
 * Full integration with WooCommerce for training products, camps/clinics upsells
 */

if (!defined('ABSPATH')) exit;

class PTP_WooCommerce {
    
    private static $instance = null;
    private static $product_id = null;
    
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('init', array($this, 'ensure_product_exists'));
        add_filter('woocommerce_is_purchasable', array($this, 'make_hidden_product_purchasable'), 10, 2);
        add_filter('woocommerce_product_is_visible', array($this, 'hide_training_product'), 10, 2);
        add_filter('woocommerce_get_item_data', array($this, 'display_cart_item_data'), 10, 2);
        add_action('woocommerce_checkout_create_order_line_item', array($this, 'save_order_item_data'), 10, 4);
        add_action('woocommerce_order_status_completed', array($this, 'process_completed_order'));
        add_action('woocommerce_order_status_processing', array($this, 'process_completed_order'));
        
        // Dynamic price filter
        add_filter('woocommerce_product_get_price', array($this, 'dynamic_price'), 10, 2);
        add_filter('woocommerce_product_get_regular_price', array($this, 'dynamic_price'), 10, 2);
    }
    
    /**
     * Ensure a hidden product exists for private training sessions
     */
    public function ensure_product_exists() {
        if (!function_exists('wc_get_product')) return;
        
        self::$product_id = get_option('ptp_training_product_id');
        
        if (self::$product_id) {
            $product = wc_get_product(self::$product_id);
            if ($product) {
                return;
            }
        }
        
        // Create hidden product
        $product = new WC_Product_Simple();
        $product->set_name('Private Training Session');
        $product->set_slug('ptp-private-training-session');
        $product->set_status('publish');
        $product->set_catalog_visibility('hidden');
        $product->set_price(0);
        $product->set_regular_price(0);
        $product->set_sold_individually(false);
        $product->set_virtual(true);
        $product->set_description('Private soccer training session with a PTP trainer.');
        $product->save();
        
        self::$product_id = $product->get_id();
        update_option('ptp_training_product_id', self::$product_id);
    }
    
    /**
     * Dynamic pricing based on cart data
     */
    public function dynamic_price($price, $product) {
        if ($product->get_id() != self::$product_id) {
            return $price;
        }
        
        if (!WC()->cart) return $price;
        
        foreach (WC()->cart->get_cart() as $cart_item) {
            if (isset($cart_item['ptp_training']) && isset($cart_item['custom_price'])) {
                return $cart_item['custom_price'];
            }
        }
        
        return $price;
    }
    
    /**
     * Make sure hidden product is still purchasable
     */
    public function make_hidden_product_purchasable($purchasable, $product) {
        if ($product->get_id() == self::$product_id) {
            return true;
        }
        return $purchasable;
    }
    
    /**
     * Hide training product from shop
     */
    public function hide_training_product($visible, $product_id) {
        if ($product_id == self::$product_id) {
            return false;
        }
        return $visible;
    }
    
    /**
     * Add training session to cart with dynamic pricing
     */
    public static function add_to_cart($data) {
        if (!function_exists('WC') || !WC()->cart) {
            return new WP_Error('wc_not_ready', 'WooCommerce not available');
        }
        
        if (!self::$product_id) {
            self::instance()->ensure_product_exists();
        }
        
        if (!self::$product_id) {
            return new WP_Error('no_product', 'Training product not configured');
        }
        
        WC()->cart->empty_cart();
        
        $cart_item_data = array(
            'ptp_training' => true,
            'trainer_id' => $data['trainer_id'],
            'trainer_name' => $data['trainer_name'],
            'pack_type' => $data['pack_type'],
            'sessions' => $data['sessions'],
            'athlete_name' => $data['athlete_name'],
            'athlete_age' => $data['athlete_age'],
            'athlete_skill' => $data['athlete_skill'] ?? '',
            'athlete_goals' => $data['athlete_goals'] ?? '',
            'custom_price' => $data['price']
        );
        
        $cart_key = WC()->cart->add_to_cart(self::$product_id, 1, 0, array(), $cart_item_data);
        
        if (!$cart_key) {
            return new WP_Error('cart_error', 'Could not add to cart');
        }
        
        return wc_get_checkout_url();
    }
    
    /**
     * Display custom data in cart
     */
    public function display_cart_item_data($item_data, $cart_item) {
        if (isset($cart_item['ptp_training'])) {
            $item_data[] = array(
                'key' => 'Trainer',
                'value' => $cart_item['trainer_name']
            );
            $item_data[] = array(
                'key' => 'Package',
                'value' => ucfirst($cart_item['pack_type']) . ' (' . $cart_item['sessions'] . ' sessions)'
            );
            $item_data[] = array(
                'key' => 'Athlete',
                'value' => $cart_item['athlete_name'] . ' (Age ' . $cart_item['athlete_age'] . ')'
            );
        }
        return $item_data;
    }
    
    /**
     * Save training data to order item
     */
    public function save_order_item_data($item, $cart_item_key, $values, $order) {
        if (isset($values['ptp_training'])) {
            $item->add_meta_data('_ptp_training', true);
            $item->add_meta_data('_ptp_trainer_id', $values['trainer_id']);
            $item->add_meta_data('_ptp_pack_type', $values['pack_type']);
            $item->add_meta_data('_ptp_sessions', $values['sessions']);
            $item->add_meta_data('_ptp_athlete_name', $values['athlete_name']);
            $item->add_meta_data('_ptp_athlete_age', $values['athlete_age']);
            $item->add_meta_data('_ptp_athlete_skill', $values['athlete_skill'] ?? '');
            $item->add_meta_data('_ptp_athlete_goals', $values['athlete_goals'] ?? '');
            $item->add_meta_data('_ptp_custom_price', $values['custom_price']);
        }
    }
    
    /**
     * Process completed order - create lesson pack and sessions
     */
    public function process_completed_order($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) return;
        
        foreach ($order->get_items() as $item) {
            if ($item->get_meta('_ptp_training')) {
                $this->create_lesson_pack($order, $item);
            }
        }
    }
    
    /**
     * Create lesson pack from WooCommerce order
     */
    private function create_lesson_pack($order, $item) {
        global $wpdb;
        
        $trainer_id = $item->get_meta('_ptp_trainer_id');
        $sessions = $item->get_meta('_ptp_sessions');
        $pack_type = $item->get_meta('_ptp_pack_type');
        $price = $item->get_meta('_ptp_custom_price') ?: $item->get_total();
        
        // Check if already processed
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_lesson_packs WHERE order_id = %d",
            $order->get_id()
        ));
        
        if ($existing) {
            return $existing;
        }
        
        // Get trainer info
        $trainer = PTP_Database::get_trainer($trainer_id);
        
        // Create pack
        $pack_data = array(
            'customer_id' => $order->get_customer_id(),
            'trainer_id' => $trainer_id,
            'order_id' => $order->get_id(),
            'pack_type' => $pack_type,
            'total_sessions' => $sessions,
            'sessions_used' => 0,
            'sessions_remaining' => $sessions,
            'price_paid' => $price,
            'price_per_session' => $sessions > 0 ? ($price / $sessions) : 0,
            'athlete_name' => $item->get_meta('_ptp_athlete_name'),
            'athlete_age' => $item->get_meta('_ptp_athlete_age'),
            'athlete_skill_level' => $item->get_meta('_ptp_athlete_skill'),
            'athlete_goals' => $item->get_meta('_ptp_athlete_goals'),
            'status' => 'active',
            'payment_status' => 'paid',
            'expires_at' => date('Y-m-d H:i:s', strtotime('+6 months')),
            'created_at' => current_time('mysql')
        );
        
        $wpdb->insert("{$wpdb->prefix}ptp_lesson_packs", $pack_data);
        $pack_id = $wpdb->insert_id;
        
        // Create placeholder sessions
        for ($i = 0; $i < $sessions; $i++) {
            $wpdb->insert("{$wpdb->prefix}ptp_sessions", array(
                'pack_id' => $pack_id,
                'trainer_id' => $trainer_id,
                'customer_id' => $order->get_customer_id(),
                'player_name' => $item->get_meta('_ptp_athlete_name'),
                'player_age' => $item->get_meta('_ptp_athlete_age'),
                'session_date' => '0000-00-00',
                'start_time' => '00:00:00',
                'end_time' => '00:00:00',
                'session_status' => 'unscheduled',
                'payment_status' => 'paid',
                'created_at' => current_time('mysql')
            ));
        }
        
        // Send notifications
        $this->send_purchase_confirmation($pack_id, $order, $trainer);
        
        return $pack_id;
    }
    
    /**
     * Send confirmation email
     */
    private function send_purchase_confirmation($pack_id, $order, $trainer) {
        $pack = PTP_Database::get_pack($pack_id);
        $trainer_name = $trainer ? $trainer->display_name : 'your trainer';
        
        $subject = 'Training Package Confirmed - ' . $trainer_name;
        $message = "Hi {$order->get_billing_first_name()},\n\n";
        $message .= "Your training package with {$trainer_name} has been confirmed!\n\n";
        $message .= "Package Details:\n";
        $message .= "- Sessions: {$pack->total_sessions}\n";
        $message .= "- Athlete: {$pack->athlete_name}\n";
        $message .= "- Order #: {$order->get_id()}\n\n";
        $message .= "Visit your dashboard to schedule your sessions: " . home_url('/my-training/') . "\n\n";
        $message .= "See you on the field!\nThe PTP Team";
        
        wp_mail($order->get_billing_email(), $subject, $message);
        
        // Notify trainer
        if ($trainer && $trainer->user_id) {
            $trainer_user = get_userdata($trainer->user_id);
            if ($trainer_user) {
                $trainer_subject = 'New Training Package Sold!';
                $trainer_message = "Congratulations!\n\n";
                $trainer_message .= "A new training package has been purchased:\n";
                $trainer_message .= "- Customer: {$order->get_billing_first_name()} {$order->get_billing_last_name()}\n";
                $trainer_message .= "- Athlete: {$pack->athlete_name}\n";
                $trainer_message .= "- Sessions: {$pack->total_sessions}\n\n";
                $trainer_message .= "Log in to your dashboard to view details: " . home_url('/trainer-dashboard/') . "\n";
                
                wp_mail($trainer_user->user_email, $trainer_subject, $trainer_message);
            }
        }
    }
    
    /**
     * Get product ID
     */
    public static function get_product_id() {
        return self::$product_id;
    }
    
    // ==========================================
    // CAMPS & CLINICS UPSELL METHODS
    // ==========================================
    
    /**
     * Get camps and clinics for upsell display
     * @param int $limit Number of products to return
     * @param string $type 'camp', 'clinic', or 'all'
     * @return array
     */
    public static function get_camps_clinics($limit = 4, $type = 'all') {
        if (!function_exists('wc_get_products')) {
            return array();
        }
        
        $args = array(
            'status' => 'publish',
            'limit' => $limit,
            'visibility' => 'visible',
            'orderby' => 'date',
            'order' => 'DESC',
        );
        
        // Try to get products from specific categories
        $category_slugs = array();
        if ($type === 'camp' || $type === 'all') {
            $category_slugs[] = 'camps';
            $category_slugs[] = 'summer-camps';
            $category_slugs[] = 'camp';
        }
        if ($type === 'clinic' || $type === 'all') {
            $category_slugs[] = 'clinics';
            $category_slugs[] = 'clinic';
            $category_slugs[] = 'holiday-clinics';
        }
        
        // Get category IDs
        $cat_ids = array();
        foreach ($category_slugs as $slug) {
            $term = get_term_by('slug', $slug, 'product_cat');
            if ($term) {
                $cat_ids[] = $term->term_id;
            }
        }
        
        if (!empty($cat_ids)) {
            $args['category'] = $cat_ids;
        }
        
        $products = wc_get_products($args);
        
        // If no products found in categories, get any recent products
        if (empty($products)) {
            unset($args['category']);
            $products = wc_get_products($args);
        }
        
        return $products;
    }
    
    /**
     * Get upcoming camps (products with future dates)
     */
    public static function get_upcoming_camps($limit = 3) {
        return self::get_camps_clinics($limit, 'camp');
    }
    
    /**
     * Get upcoming clinics
     */
    public static function get_upcoming_clinics($limit = 3) {
        return self::get_camps_clinics($limit, 'clinic');
    }
    
    /**
     * Render upsell section HTML
     */
    public static function render_upsell_section($title = 'Also From PTP', $limit = 4) {
        $products = self::get_camps_clinics($limit);
        
        if (empty($products)) {
            return '';
        }
        
        ob_start();
        ?>
        <div class="ptp-upsell-section" style="background: #0E0F11; padding: 48px 24px; margin-top: 48px;">
            <div style="max-width: 1400px; margin: 0 auto;">
                <div style="text-align: center; margin-bottom: 32px;">
                    <span style="display: inline-block; padding: 6px 14px; background: #FCB900; color: #0E0F11; font-size: 11px; font-weight: 800; border-radius: 100px; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px;">More Ways to Train</span>
                    <h2 style="font-size: 28px; font-weight: 800; color: #fff; margin: 0;"><?php echo esc_html($title); ?></h2>
                </div>
                
                <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;" class="ptp-upsell-grid">
                    <?php foreach ($products as $product): 
                        $image_id = $product->get_image_id();
                        $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium') : 'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1915.jpg';
                        $price = $product->get_price();
                        $regular_price = $product->get_regular_price();
                        $sale_price = $product->get_sale_price();
                    ?>
                    <a href="<?php echo esc_url($product->get_permalink()); ?>" style="display: block; background: #1F2937; border-radius: 16px; overflow: hidden; text-decoration: none; transition: transform 0.2s, box-shadow 0.2s;" class="ptp-upsell-card">
                        <div style="position: relative; padding-bottom: 60%; overflow: hidden;">
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; object-fit: cover;">
                            <?php if ($sale_price): ?>
                            <span style="position: absolute; top: 12px; left: 12px; background: #EF4444; color: #fff; font-size: 11px; font-weight: 700; padding: 4px 10px; border-radius: 100px;">SALE</span>
                            <?php endif; ?>
                        </div>
                        <div style="padding: 16px;">
                            <h3 style="font-size: 15px; font-weight: 700; color: #fff; margin: 0 0 8px 0; line-height: 1.3;"><?php echo esc_html($product->get_name()); ?></h3>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <?php if ($sale_price): ?>
                                <span style="font-size: 16px; font-weight: 800; color: #FCB900;">$<?php echo number_format($sale_price); ?></span>
                                <span style="font-size: 13px; color: #6B7280; text-decoration: line-through;">$<?php echo number_format($regular_price); ?></span>
                                <?php else: ?>
                                <span style="font-size: 16px; font-weight: 800; color: #FCB900;"><?php echo $product->get_price_html(); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
                
                <div style="text-align: center; margin-top: 28px;">
                    <a href="<?php echo esc_url(wc_get_page_permalink('shop')); ?>" style="display: inline-flex; align-items: center; gap: 8px; padding: 14px 28px; background: transparent; border: 2px solid #FCB900; color: #FCB900; font-size: 14px; font-weight: 700; border-radius: 10px; text-decoration: none;">
                        View All Programs
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </a>
                </div>
            </div>
        </div>
        <style>
        @media (max-width: 900px) {
            .ptp-upsell-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
        @media (max-width: 500px) {
            .ptp-upsell-grid { 
                grid-template-columns: 1fr !important;
                display: flex !important;
                overflow-x: auto !important;
                scroll-snap-type: x mandatory !important;
                -webkit-overflow-scrolling: touch !important;
                gap: 16px !important;
                padding-bottom: 16px !important;
            }
            .ptp-upsell-card {
                flex: 0 0 280px !important;
                scroll-snap-align: start !important;
            }
        }
        .ptp-upsell-card:hover { transform: translateY(-4px); box-shadow: 0 10px 30px rgba(0,0,0,0.3); }
        </style>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render compact upsell banner
     */
    public static function render_upsell_banner() {
        ob_start();
        ?>
        <div style="background: linear-gradient(135deg, #FCB900 0%, #F59E0B 100%); padding: 20px 24px; margin: 24px 0; border-radius: 16px;">
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 16px; max-width: 1400px; margin: 0 auto;">
                <div style="display: flex; align-items: center; gap: 16px;">
                    <span style="font-size: 32px;">⚽</span>
                    <div>
                        <h3 style="font-size: 18px; font-weight: 800; color: #0E0F11; margin: 0;">Summer Camps Now Open!</h3>
                        <p style="font-size: 14px; color: rgba(0,0,0,0.7); margin: 4px 0 0 0;">Train with MLS & D1 coaches all summer long.</p>
                    </div>
                </div>
                <a href="<?php echo home_url('/camps/'); ?>" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background: #0E0F11; color: #fff; font-size: 14px; font-weight: 700; border-radius: 10px; text-decoration: none; white-space: nowrap;">
                    View Camps
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                </a>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

// Initialize if WooCommerce is active
add_action('plugins_loaded', function() {
    if (class_exists('WooCommerce')) {
        PTP_WooCommerce::instance();
    }
}, 20);
