<?php
/**
 * PTP Lesson Coordinator - v5.5
 * Integration with PTP Communications Hub for automated workflows
 * Handles SMS notifications, Teams alerts, and automated scheduling
 */

if (!defined('ABSPATH')) exit;

class PTP_Lesson_Coordinator {
    
    private static $instance = null;
    
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        // Hook into PTP Communications Hub events
        add_action('ptp_comm_hub_event', array($this, 'handle_comm_hub_event'), 10, 2);
        add_action('ptp_new_trainer_application', array($this, 'on_new_application'), 10, 1);
        add_action('ptp_new_training_booking', array($this, 'on_new_booking'), 10, 1);
        add_action('ptp_session_scheduled', array($this, 'on_session_scheduled'), 10, 1);
        add_action('ptp_session_completed', array($this, 'on_session_completed'), 10, 1);
        add_action('ptp_review_submitted', array($this, 'on_review_submitted'), 10, 1);
        
        // Cron jobs for automated tasks
        add_action('ptp_lesson_coordinator_daily', array($this, 'daily_tasks'));
        add_action('ptp_session_reminder', array($this, 'send_session_reminders'));
        
        // Schedule daily tasks
        if (!wp_next_scheduled('ptp_lesson_coordinator_daily')) {
            wp_schedule_event(strtotime('09:00:00'), 'daily', 'ptp_lesson_coordinator_daily');
        }
        if (!wp_next_scheduled('ptp_session_reminder')) {
            wp_schedule_event(time(), 'hourly', 'ptp_session_reminder');
        }
    }
    
    /**
     * Handle events from PTP Communications Hub
     */
    public function handle_comm_hub_event($event_type, $data) {
        $this->log_event($event_type, $data);
        
        switch ($event_type) {
            case 'new_application':
                $this->process_new_application($data);
                break;
            case 'new_booking':
                $this->process_new_booking($data);
                break;
            case 'session_scheduled':
                $this->process_session_scheduled($data);
                break;
            case 'session_completed':
                $this->process_session_completed($data);
                break;
            case 'review_submitted':
                $this->process_review_submitted($data);
                break;
        }
    }
    
    /**
     * Process new trainer application
     */
    private function process_new_application($data) {
        // Send SMS to admin if Twilio configured
        $this->send_admin_sms(
            "New trainer application: {$data['name']} ({$data['role_type']}). Check admin panel."
        );
        
        // Post to Teams if configured
        $this->post_to_teams(array(
            'title' => 'New Trainer Application',
            'message' => "**{$data['name']}** applied as {$data['role_type']}",
            'color' => '#FCB900',
            'facts' => array(
                'Email' => $data['email'],
                'Phone' => $data['phone'],
                'Type' => $data['role_type']
            ),
            'action_url' => admin_url('admin.php?page=ptp-training-applications')
        ));
    }
    
    /**
     * Process new booking
     */
    private function process_new_booking($data) {
        // Send SMS to parent
        if (!empty($data['customer_phone'])) {
            $this->send_sms(
                $data['customer_phone'],
                "PTP Training: Your {$data['sessions']}-session pack with {$data['trainer_name']} is confirmed! Log in to schedule: " . home_url('/my-training/')
            );
        }
        
        // Send SMS to trainer
        $this->notify_trainer_sms(
            $data['trainer_id'],
            "New training package sold! {$data['sessions']} sessions with {$data['athlete_name']}. Check your dashboard."
        );
        
        // Post to Teams
        $this->post_to_teams(array(
            'title' => 'New Training Package Sold! 💰',
            'message' => "**{$data['customer_name']}** purchased {$data['sessions']} sessions with **{$data['trainer_name']}**",
            'color' => '#10B981',
            'facts' => array(
                'Athlete' => $data['athlete_name'],
                'Sessions' => $data['sessions'],
                'Total' => '$' . number_format($data['total'], 2)
            ),
            'action_url' => admin_url('admin.php?page=ptp-training-packs')
        ));
    }
    
    /**
     * Process session scheduled
     */
    private function process_session_scheduled($data) {
        global $wpdb;
        
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, t.display_name as trainer_name, p.athlete_name
             FROM {$wpdb->prefix}ptp_sessions s
             LEFT JOIN {$wpdb->prefix}ptp_trainers t ON s.trainer_id = t.id
             LEFT JOIN {$wpdb->prefix}ptp_lesson_packs p ON s.pack_id = p.id
             WHERE s.id = %d",
            $data['session_id']
        ));
        
        if (!$session) return;
        
        $date_formatted = date('l, F j', strtotime($data['date']));
        $time_formatted = date('g:i A', strtotime($data['time']));
        
        // Notify trainer via SMS
        $this->notify_trainer_sms(
            $data['trainer_id'],
            "Session request: {$session->athlete_name} on {$date_formatted} at {$time_formatted}. Confirm in dashboard."
        );
        
        // Post to Teams
        $this->post_to_teams(array(
            'title' => 'Session Scheduling Request',
            'message' => "**{$session->athlete_name}** requested a session with **{$session->trainer_name}**",
            'color' => '#3B82F6',
            'facts' => array(
                'Date' => $date_formatted,
                'Time' => $time_formatted,
                'Location' => $data['location'] ?: 'TBD'
            )
        ));
    }
    
    /**
     * Process session completed
     */
    private function process_session_completed($data) {
        global $wpdb;
        
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, t.display_name as trainer_name, p.athlete_name, p.customer_id
             FROM {$wpdb->prefix}ptp_sessions s
             LEFT JOIN {$wpdb->prefix}ptp_trainers t ON s.trainer_id = t.id
             LEFT JOIN {$wpdb->prefix}ptp_lesson_packs p ON s.pack_id = p.id
             WHERE s.id = %d",
            $data['session_id']
        ));
        
        if (!$session) return;
        
        // Update pack sessions
        $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}ptp_lesson_packs 
             SET sessions_used = sessions_used + 1, sessions_remaining = sessions_remaining - 1
             WHERE id = %d",
            $session->pack_id
        ));
        
        // Check if pack is low on sessions
        $pack = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_lesson_packs WHERE id = %d",
            $session->pack_id
        ));
        
        if ($pack && $pack->sessions_remaining <= 2 && $pack->sessions_remaining > 0) {
            // Send reminder to parent
            $customer = get_userdata($pack->customer_id);
            if ($customer) {
                $phone = get_user_meta($customer->ID, 'phone', true);
                if ($phone) {
                    $this->send_sms(
                        $phone,
                        "PTP Training: Only {$pack->sessions_remaining} session(s) left in {$session->athlete_name}'s pack. Book more: " . home_url('/find-trainers/')
                    );
                }
            }
        }
        
        // Request review after session
        $this->schedule_review_request($session);
    }
    
    /**
     * Process review submitted
     */
    private function process_review_submitted($data) {
        $stars = str_repeat('⭐', $data['rating']);
        
        $this->post_to_teams(array(
            'title' => 'New Review Submitted',
            'message' => "{$stars} from **{$data['reviewer_name']}**",
            'color' => '#FCB900'
        ));
    }
    
    /**
     * Daily automated tasks
     */
    public function daily_tasks() {
        $this->check_expiring_packs();
        $this->check_inactive_trainers();
        $this->cleanup_old_logs();
    }
    
    /**
     * Check for packs expiring soon
     */
    private function check_expiring_packs() {
        global $wpdb;
        
        // Get packs expiring in 7 days with remaining sessions
        $expiring = $wpdb->get_results(
            "SELECT p.*, u.user_email, u.display_name
             FROM {$wpdb->prefix}ptp_lesson_packs p
             JOIN {$wpdb->users} u ON p.customer_id = u.ID
             WHERE p.status = 'active' 
             AND p.sessions_remaining > 0
             AND p.expires_at BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 7 DAY)"
        );
        
        foreach ($expiring as $pack) {
            $phone = get_user_meta($pack->customer_id, 'phone', true);
            
            if ($phone) {
                $this->send_sms(
                    $phone,
                    "PTP Training: Your training pack expires in 7 days with {$pack->sessions_remaining} session(s) unused! Schedule now: " . home_url('/my-training/')
                );
            }
            
            // Email reminder
            $subject = 'Your Training Pack Expires Soon!';
            $message = "Hi {$pack->display_name},\n\n";
            $message .= "Your training pack for {$pack->athlete_name} expires in 7 days.\n";
            $message .= "You still have {$pack->sessions_remaining} session(s) remaining.\n\n";
            $message .= "Schedule your sessions now: " . home_url('/my-training/') . "\n\n";
            $message .= "The PTP Team";
            
            wp_mail($pack->user_email, $subject, $message);
        }
    }
    
    /**
     * Check for inactive trainers
     */
    private function check_inactive_trainers() {
        global $wpdb;
        
        // Get trainers with no sessions in 30 days
        $inactive = $wpdb->get_results(
            "SELECT t.*, 
                    (SELECT MAX(s.session_date) FROM {$wpdb->prefix}ptp_sessions s WHERE s.trainer_id = t.id) as last_session
             FROM {$wpdb->prefix}ptp_trainers t
             WHERE t.status = 'approved'
             HAVING last_session < DATE_SUB(NOW(), INTERVAL 30 DAY) OR last_session IS NULL"
        );
        
        foreach ($inactive as $trainer) {
            // Send re-engagement email
            $user = get_userdata($trainer->user_id);
            if ($user) {
                $subject = 'We miss you at PTP!';
                $message = "Hi {$trainer->display_name},\n\n";
                $message .= "It's been a while since your last training session.\n";
                $message .= "Update your availability to start receiving bookings again.\n\n";
                $message .= "Your Dashboard: " . home_url('/trainer-dashboard/') . "\n\n";
                $message .= "The PTP Team";
                
                wp_mail($user->user_email, $subject, $message);
            }
        }
    }
    
    /**
     * Send session reminders
     */
    public function send_session_reminders() {
        global $wpdb;
        
        // Get sessions in next 24 hours that haven't been reminded
        $sessions = $wpdb->get_results(
            "SELECT s.*, t.display_name as trainer_name, t.user_id as trainer_user_id,
                    p.athlete_name, p.customer_id
             FROM {$wpdb->prefix}ptp_sessions s
             JOIN {$wpdb->prefix}ptp_trainers t ON s.trainer_id = t.id
             LEFT JOIN {$wpdb->prefix}ptp_lesson_packs p ON s.pack_id = p.id
             WHERE s.session_status IN ('confirmed', 'scheduled')
             AND s.session_date = CURDATE() + INTERVAL 1 DAY
             AND (s.reminder_sent IS NULL OR s.reminder_sent = 0)"
        );
        
        foreach ($sessions as $session) {
            $date_formatted = date('l, F j', strtotime($session->session_date));
            $time_formatted = date('g:i A', strtotime($session->start_time));
            
            // Remind parent
            $customer = get_userdata($session->customer_id);
            if ($customer) {
                $phone = get_user_meta($customer->ID, 'phone', true);
                if ($phone) {
                    $this->send_sms(
                        $phone,
                        "PTP Reminder: {$session->athlete_name}'s training with {$session->trainer_name} is tomorrow at {$time_formatted}!"
                    );
                }
                
                // Email reminder
                $subject = "Training Session Tomorrow - {$session->athlete_name}";
                $message = "Hi {$customer->first_name},\n\n";
                $message .= "Reminder: {$session->athlete_name} has training tomorrow!\n\n";
                $message .= "Date: {$date_formatted}\n";
                $message .= "Time: {$time_formatted}\n";
                $message .= "Trainer: {$session->trainer_name}\n";
                if ($session->location_text) {
                    $message .= "Location: {$session->location_text}\n";
                }
                $message .= "\nSee you on the field!\nThe PTP Team";
                
                wp_mail($customer->user_email, $subject, $message);
            }
            
            // Remind trainer
            $trainer_user = get_userdata($session->trainer_user_id);
            if ($trainer_user) {
                $this->send_sms(
                    get_user_meta($trainer_user->ID, 'phone', true),
                    "PTP Reminder: Training with {$session->athlete_name} tomorrow at {$time_formatted}."
                );
            }
            
            // Mark as reminded
            $wpdb->update(
                "{$wpdb->prefix}ptp_sessions",
                array('reminder_sent' => 1),
                array('id' => $session->id)
            );
        }
    }
    
    /**
     * Schedule review request after session
     */
    private function schedule_review_request($session) {
        // Schedule email for 2 hours after session end
        $send_at = strtotime($session->session_date . ' ' . $session->end_time) + 7200;
        
        wp_schedule_single_event($send_at, 'ptp_send_review_request', array($session->id));
    }
    
    /**
     * Send SMS via Twilio (if configured)
     */
    private function send_sms($to, $message) {
        // Check if Twilio class exists
        if (class_exists('PTP_Twilio')) {
            return PTP_Twilio::send_sms($to, $message);
        }
        
        // Check if PTP Communications Hub Twilio is available
        if (function_exists('ptp_comm_send_sms')) {
            return ptp_comm_send_sms($to, $message);
        }
        
        // Log that SMS would have been sent
        $this->log_event('sms_queued', array('to' => $to, 'message' => $message));
        
        return false;
    }
    
    /**
     * Send SMS to admin
     */
    private function send_admin_sms($message) {
        $admin_phone = get_option('ptp_admin_phone', '');
        if ($admin_phone) {
            return $this->send_sms($admin_phone, $message);
        }
        return false;
    }
    
    /**
     * Send SMS to trainer
     */
    private function notify_trainer_sms($trainer_id, $message) {
        global $wpdb;
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT t.*, u.ID as wp_user_id
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.id = %d",
            $trainer_id
        ));
        
        if ($trainer) {
            $phone = get_user_meta($trainer->wp_user_id, 'phone', true);
            if ($phone) {
                return $this->send_sms($phone, $message);
            }
        }
        
        return false;
    }
    
    /**
     * Post to Microsoft Teams (if configured)
     */
    private function post_to_teams($data) {
        // Check if PTP Communications Hub Teams integration is available
        if (function_exists('ptp_comm_post_to_teams')) {
            return ptp_comm_post_to_teams($data);
        }
        
        $webhook_url = get_option('ptp_teams_webhook_url', '');
        
        if (empty($webhook_url)) {
            return false;
        }
        
        $card = array(
            '@type' => 'MessageCard',
            '@context' => 'http://schema.org/extensions',
            'themeColor' => ltrim($data['color'] ?? '#FCB900', '#'),
            'summary' => $data['title'],
            'sections' => array(
                array(
                    'activityTitle' => $data['title'],
                    'activitySubtitle' => 'PTP Private Training',
                    'activityImage' => 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png',
                    'text' => $data['message']
                )
            )
        );
        
        if (!empty($data['facts'])) {
            $facts = array();
            foreach ($data['facts'] as $name => $value) {
                $facts[] = array('name' => $name, 'value' => $value);
            }
            $card['sections'][0]['facts'] = $facts;
        }
        
        if (!empty($data['action_url'])) {
            $card['potentialAction'] = array(
                array(
                    '@type' => 'OpenUri',
                    'name' => 'View Details',
                    'targets' => array(
                        array('os' => 'default', 'uri' => $data['action_url'])
                    )
                )
            );
        }
        
        $response = wp_remote_post($webhook_url, array(
            'body' => json_encode($card),
            'headers' => array('Content-Type' => 'application/json'),
            'timeout' => 15
        ));
        
        return !is_wp_error($response);
    }
    
    /**
     * Log event to database
     */
    private function log_event($event_type, $data) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'ptp_event_log';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            return;
        }
        
        $wpdb->insert($table, array(
            'event_type' => $event_type,
            'event_data' => json_encode($data),
            'created_at' => current_time('mysql')
        ));
    }
    
    /**
     * Cleanup old logs
     */
    private function cleanup_old_logs() {
        global $wpdb;
        
        // Delete logs older than 90 days
        $wpdb->query(
            "DELETE FROM {$wpdb->prefix}ptp_event_log 
             WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)"
        );
    }
    
    // Event hooks
    public function on_new_application($data) { $this->process_new_application($data); }
    public function on_new_booking($data) { $this->process_new_booking($data); }
    public function on_session_scheduled($data) { $this->process_session_scheduled($data); }
    public function on_session_completed($data) { $this->process_session_completed($data); }
    public function on_review_submitted($data) { $this->process_review_submitted($data); }
}

// Initialize
add_action('init', function() {
    PTP_Lesson_Coordinator::instance();
});
