<?php
/**
 * Admin Dashboard & Settings - v4.1
 * Enhanced admin pages for PTP Private Training
 */

if (!defined('ABSPATH')) exit;

class PTP_Admin {

    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menus'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_ptp_update_session_status', array($this, 'ajax_update_session_status'));
        add_action('wp_ajax_ptp_approve_trainer', array($this, 'ajax_approve_trainer'));
        add_action('wp_ajax_ptp_reject_trainer', array($this, 'ajax_reject_trainer'));
        add_action('wp_ajax_ptp_process_payout', array($this, 'ajax_process_payout'));
        add_action('wp_ajax_ptp_save_trainer', array($this, 'ajax_save_trainer'));
        add_action('wp_ajax_ptp_save_review', array($this, 'ajax_save_review'));
        add_action('wp_ajax_ptp_delete_review', array($this, 'ajax_delete_review'));
        add_action('wp_ajax_ptp_add_trainer', array($this, 'ajax_add_trainer'));
        add_action('admin_post_ptp_save_trainer', array($this, 'handle_save_trainer'));
    }

    /**
     * Add admin menus
     */
    public function add_admin_menus() {
        // Main menu
        add_menu_page(
            'PTP Private Training',
            'PTP Training',
            'manage_options',
            'ptp-training',
            array($this, 'render_dashboard_page'),
            'dashicons-groups',
            30
        );

        // Dashboard (same as main)
        add_submenu_page(
            'ptp-training',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'ptp-training',
            array($this, 'render_dashboard_page')
        );

        // Sessions
        add_submenu_page(
            'ptp-training',
            'Sessions',
            'Sessions',
            'manage_options',
            'ptp-training-sessions',
            array($this, 'render_sessions_page')
        );

        // Trainers
        add_submenu_page(
            'ptp-training',
            'Trainers',
            'Trainers',
            'manage_options',
            'ptp-training-trainers',
            array($this, 'render_trainers_page')
        );

        // Applications
        add_submenu_page(
            'ptp-training',
            'Applications',
            'Applications',
            'manage_options',
            'ptp-training-applications',
            array($this, 'render_applications_page')
        );

        // Payouts
        add_submenu_page(
            'ptp-training',
            'Payouts',
            'Payouts',
            'manage_options',
            'ptp-training-payouts',
            array($this, 'render_payouts_page')
        );

        // Settings
        add_submenu_page(
            'ptp-training',
            'Settings',
            'Settings',
            'manage_options',
            'ptp-training-settings',
            array($this, 'render_settings_page')
        );

        // Reviews
        add_submenu_page(
            'ptp-training',
            'Reviews',
            'Reviews',
            'manage_options',
            'ptp-training-reviews',
            array($this, 'render_reviews_page')
        );

        // Edit Trainer (hidden - accessed via link)
        add_submenu_page(
            null,
            'Edit Trainer',
            'Edit Trainer',
            'manage_options',
            'ptp-training-edit-trainer',
            array($this, 'render_edit_trainer_page')
        );
    }

    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        // Only load on PTP admin pages
        if (strpos($hook, 'ptp-training') === false) {
            return;
        }

        // Enqueue Google Fonts
        wp_enqueue_style(
            'ptp-google-fonts',
            'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap',
            array(),
            null
        );

        wp_enqueue_style(
            'ptp-admin-css',
            PTP_TRAINING_URL . 'assets/css/admin.css',
            array('ptp-google-fonts'),
            PTP_TRAINING_VERSION
        );

        wp_enqueue_script(
            'ptp-admin-js',
            PTP_TRAINING_URL . 'assets/js/admin.js',
            array('jquery'),
            PTP_TRAINING_VERSION,
            true
        );

        wp_localize_script('ptp-admin-js', 'ptpAdmin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ptp_admin_nonce')
        ));
    }

    /**
     * Register settings
     */
    public function register_settings() {
        // Platform Settings
        register_setting('ptp_training_settings', 'ptp_platform_fee_percent');
        register_setting('ptp_training_settings', 'ptp_admin_email');
        register_setting('ptp_training_settings', 'ptp_auto_confirm_on_payment');
        register_setting('ptp_training_settings', 'ptp_default_session_duration');
        register_setting('ptp_training_settings', 'ptp_cancellation_window');
        register_setting('ptp_training_settings', 'ptp_require_payment_upfront');
        register_setting('ptp_training_settings', 'ptp_allow_guest_booking');

        // Page Settings
        register_setting('ptp_training_settings', 'ptp_page_marketplace');
        register_setting('ptp_training_settings', 'ptp_page_private_training');
        register_setting('ptp_training_settings', 'ptp_page_checkout');
        register_setting('ptp_training_settings', 'ptp_page_parent_dashboard');
        register_setting('ptp_training_settings', 'ptp_page_trainer_dashboard');
        register_setting('ptp_training_settings', 'ptp_page_application');
        register_setting('ptp_training_settings', 'ptp_trainer_slug');

        // Stripe Settings
        register_setting('ptp_training_settings', 'ptp_stripe_mode');
        register_setting('ptp_training_settings', 'ptp_stripe_publishable_key');
        register_setting('ptp_training_settings', 'ptp_stripe_secret_key');
        register_setting('ptp_training_settings', 'ptp_stripe_webhook_secret');
        register_setting('ptp_training_settings', 'ptp_stripe_connect_enabled');
        register_setting('ptp_training_settings', 'ptp_stripe_payout_delay');

        // Google Settings
        register_setting('ptp_training_settings', 'ptp_google_maps_key');
        register_setting('ptp_training_settings', 'ptp_google_client_id');
        register_setting('ptp_training_settings', 'ptp_google_client_secret');

        // SMS/Twilio Settings
        register_setting('ptp_training_settings', 'ptp_twilio_sid');
        register_setting('ptp_training_settings', 'ptp_twilio_token');
        register_setting('ptp_training_settings', 'ptp_twilio_phone');
        register_setting('ptp_training_settings', 'ptp_sms_enabled');
        register_setting('ptp_training_settings', 'ptp_sms_booking_confirmed');
        register_setting('ptp_training_settings', 'ptp_sms_reminder_24h');
        register_setting('ptp_training_settings', 'ptp_sms_reminder_1h');
        register_setting('ptp_training_settings', 'ptp_sms_cancellation');

        // HubSpot Settings
        register_setting('ptp_training_settings', 'ptp_hubspot_enabled');
        register_setting('ptp_training_settings', 'ptp_hubspot_api_key');

        // Notification Settings
        register_setting('ptp_training_settings', 'ptp_notification_admin_email');
        register_setting('ptp_training_settings', 'ptp_notification_from_name');
        register_setting('ptp_training_settings', 'ptp_notification_from_email');
        register_setting('ptp_training_settings', 'ptp_notification_reply_to');
        register_setting('ptp_training_settings', 'ptp_notify_parent_booking_request');
        register_setting('ptp_training_settings', 'ptp_notify_trainer_booking_request');
        register_setting('ptp_training_settings', 'ptp_notify_admin_booking_request');
        register_setting('ptp_training_settings', 'ptp_notify_parent_session_confirmed');
        register_setting('ptp_training_settings', 'ptp_notify_trainer_session_confirmed');
        register_setting('ptp_training_settings', 'ptp_notify_parent_session_cancelled');
        register_setting('ptp_training_settings', 'ptp_notify_trainer_session_cancelled');
        register_setting('ptp_training_settings', 'ptp_notify_parent_session_completed');
        register_setting('ptp_training_settings', 'ptp_notify_parent_payment_success');
        register_setting('ptp_training_settings', 'ptp_notify_admin_payment_success');

        // Email Templates
        register_setting('ptp_training_settings', 'ptp_email_booking_request_subject');
        register_setting('ptp_training_settings', 'ptp_email_booking_request_intro');
        register_setting('ptp_training_settings', 'ptp_email_session_confirmed_subject');
        register_setting('ptp_training_settings', 'ptp_email_session_confirmed_intro');

        // Branding Settings
        register_setting('ptp_training_settings', 'ptp_brand_primary_color');
        register_setting('ptp_training_settings', 'ptp_brand_secondary_color');
        register_setting('ptp_training_settings', 'ptp_social_instagram');
        register_setting('ptp_training_settings', 'ptp_social_facebook');
        register_setting('ptp_training_settings', 'ptp_social_twitter');
        register_setting('ptp_training_settings', 'ptp_social_youtube');
        register_setting('ptp_training_settings', 'ptp_social_tiktok');

        // Advanced Settings
        register_setting('ptp_training_settings', 'ptp_debug_mode');
        register_setting('ptp_training_settings', 'ptp_disable_css');
    }

    /**
     * Render Dashboard Page - with inline styles directly on elements
     */
    public function render_dashboard_page() {
        $stats = PTP_Database::get_admin_stats();
        ?>
        <div class="wrap" style="max-width: 1400px; margin: 20px 20px 40px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; box-sizing: border-box;">
            <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 32px; padding-bottom: 24px; border-bottom: 1px solid #E5E7EB;">
                <span style="background: linear-gradient(135deg, #FCB900 0%, #E5A800 100%); color: #0E0F11; padding: 10px 18px; border-radius: 8px; font-weight: 900; font-size: 16px; letter-spacing: -0.02em; box-shadow: 0 4px 14px rgba(252, 185, 0, 0.4);">PTP</span>
                <h1 style="font-size: 28px; font-weight: 700; margin: 0; color: #111827; padding: 0;">Private Training Dashboard</h1>
            </div>

            <!-- Stats Grid -->
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 32px;">
                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #FCB900;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #FEF3C7 0%, #FCB900 100%);">
                        <span class="dashicons dashicons-groups" style="font-size: 24px; width: 24px; height: 24px; color: #0E0F11;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;"><?php echo number_format($stats['total_trainers']); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Active Trainers</div>
                </div>

                <div style="background: <?php echo $stats['pending_applications'] > 0 ? 'linear-gradient(135deg, #FFFBEB 0%, #FEF3C7 100%)' : '#fff'; ?>; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid <?php echo $stats['pending_applications'] > 0 ? '#F59E0B' : '#FCB900'; ?>;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #FEF3C7 0%, #FCB900 100%);">
                        <span class="dashicons dashicons-clock" style="font-size: 24px; width: 24px; height: 24px; color: #0E0F11;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;"><?php echo number_format($stats['pending_applications']); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Pending Applications</div>
                    <?php if ($stats['pending_applications'] > 0): ?>
                        <a href="<?php echo admin_url('admin.php?page=ptp-training-applications'); ?>" style="display: inline-block; margin-top: 12px; padding: 6px 14px; background: #FCB900; color: #0E0F11; font-size: 12px; font-weight: 700; border-radius: 6px; text-decoration: none;">Review Now →</a>
                    <?php endif; ?>
                </div>

                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #FCB900;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #FEF3C7 0%, #FCB900 100%);">
                        <span class="dashicons dashicons-calendar-alt" style="font-size: 24px; width: 24px; height: 24px; color: #0E0F11;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;"><?php echo number_format($stats['upcoming_sessions']); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Upcoming Sessions</div>
                </div>

                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #10B981;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #D1FAE5 0%, #10B981 100%);">
                        <span class="dashicons dashicons-yes-alt" style="font-size: 24px; width: 24px; height: 24px; color: #fff;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;"><?php echo number_format($stats['completed_sessions']); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Completed Sessions</div>
                </div>

                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #FCB900;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #FEF3C7 0%, #FCB900 100%);">
                        <span class="dashicons dashicons-chart-bar" style="font-size: 24px; width: 24px; height: 24px; color: #0E0F11;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;">$<?php echo number_format($stats['total_revenue'], 0); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Total Revenue</div>
                </div>

                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #FCB900;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #FEF3C7 0%, #FCB900 100%);">
                        <span class="dashicons dashicons-money-alt" style="font-size: 24px; width: 24px; height: 24px; color: #0E0F11;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;">$<?php echo number_format($stats['platform_revenue'], 0); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Platform Revenue</div>
                </div>

                <?php if ($stats['requested_sessions'] > 0): ?>
                <div style="background: linear-gradient(135deg, #FEF2F2 0%, #FEE2E2 100%); border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #EF4444;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #FEE2E2 0%, #EF4444 100%);">
                        <span class="dashicons dashicons-warning" style="font-size: 24px; width: 24px; height: 24px; color: #fff;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;"><?php echo number_format($stats['requested_sessions']); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Pending Session Requests</div>
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-sessions&status=requested'); ?>" style="display: inline-block; margin-top: 12px; padding: 6px 14px; background: #EF4444; color: #fff; font-size: 12px; font-weight: 700; border-radius: 6px; text-decoration: none;">Review →</a>
                </div>
                <?php endif; ?>

                <?php if ($stats['pending_payouts'] > 0): ?>
                <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-top: 4px solid #3B82F6;">
                    <div style="width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; background: linear-gradient(135deg, #DBEAFE 0%, #3B82F6 100%);">
                        <span class="dashicons dashicons-update" style="font-size: 24px; width: 24px; height: 24px; color: #fff;"></span>
                    </div>
                    <div style="font-size: 32px; font-weight: 800; color: #111827; line-height: 1; margin-bottom: 4px;"><?php echo number_format($stats['pending_payouts']); ?></div>
                    <div style="font-size: 14px; color: #6B7280; font-weight: 500;">Pending Payouts ($<?php echo number_format($stats['pending_payout_amount'], 0); ?>)</div>
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-payouts'); ?>" style="display: inline-block; margin-top: 12px; padding: 6px 14px; background: #3B82F6; color: #fff; font-size: 12px; font-weight: 700; border-radius: 6px; text-decoration: none;">Process →</a>
                </div>
                <?php endif; ?>
            </div>

            <!-- Quick Actions -->
            <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px;">
                <h2 style="font-size: 18px; font-weight: 700; margin: 0 0 20px; color: #111827;">Quick Actions</h2>
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-sessions'); ?>" style="display: flex; align-items: center; gap: 10px; padding: 14px 20px; background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 10px; color: #374151; font-size: 14px; font-weight: 600; text-decoration: none;">
                        <span class="dashicons dashicons-calendar-alt" style="font-size: 18px; width: 18px; height: 18px;"></span>
                        View All Sessions
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-trainers'); ?>" style="display: flex; align-items: center; gap: 10px; padding: 14px 20px; background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 10px; color: #374151; font-size: 14px; font-weight: 600; text-decoration: none;">
                        <span class="dashicons dashicons-groups" style="font-size: 18px; width: 18px; height: 18px;"></span>
                        Manage Trainers
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-applications'); ?>" style="display: flex; align-items: center; gap: 10px; padding: 14px 20px; background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 10px; color: #374151; font-size: 14px; font-weight: 600; text-decoration: none;">
                        <span class="dashicons dashicons-welcome-write-blog" style="font-size: 18px; width: 18px; height: 18px;"></span>
                        Review Applications
                    </a>
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-settings'); ?>" style="display: flex; align-items: center; gap: 10px; padding: 14px 20px; background: #FCB900; border: 1px solid #FCB900; border-radius: 10px; color: #0E0F11; font-size: 14px; font-weight: 600; text-decoration: none;">
                        <span class="dashicons dashicons-admin-settings" style="font-size: 18px; width: 18px; height: 18px;"></span>
                        Plugin Settings
                    </a>
                </div>
            </div>

            <!-- Recent Activity -->
            <div style="background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px;">
                <h2 style="font-size: 18px; font-weight: 700; margin: 0 0 20px; color: #111827;">Recent Sessions</h2>
                <?php
                $recent_sessions = PTP_Database::get_sessions(array('limit' => 10));
                if ($recent_sessions):
                ?>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%);">
                        <tr>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Customer</th>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Trainer</th>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Player</th>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Date/Time</th>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Price</th>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Session</th>
                            <th style="padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px;">Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_sessions as $session): ?>
                        <tr style="border-bottom: 1px solid #F3F4F6;">
                            <td style="padding: 14px 16px; font-size: 14px; color: #374151;">
                                <strong style="color: #111827;"><?php echo esc_html($session->customer_name); ?></strong><br>
                                <small style="color: #9CA3AF; font-size: 12px;"><?php echo esc_html($session->customer_email); ?></small>
                            </td>
                            <td style="padding: 14px 16px; font-size: 14px; color: #374151;"><?php echo esc_html($session->trainer_name); ?></td>
                            <td style="padding: 14px 16px; font-size: 14px; color: #374151;">
                                <?php echo esc_html($session->player_name ?: 'N/A'); ?>
                                <?php if ($session->player_age): ?>
                                    <br><small style="color: #9CA3AF; font-size: 12px;">Age <?php echo esc_html($session->player_age); ?></small>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 14px 16px; font-size: 14px; color: #374151;">
                                <?php if ($session->session_date !== '0000-00-00'): ?>
                                    <?php echo date('M j, Y', strtotime($session->session_date)); ?><br>
                                    <small style="color: #9CA3AF; font-size: 12px;"><?php echo date('g:i A', strtotime($session->start_time)); ?></small>
                                <?php else: ?>
                                    <em style="color:#9CA3AF;">Not scheduled</em>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 14px 16px; font-size: 14px; color: #374151;">$<?php echo number_format($session->price, 2); ?></td>
                            <td style="padding: 14px 16px; font-size: 14px;">
                                <?php 
                                $status_colors = array(
                                    'requested' => array('bg' => '#FEF3C7', 'color' => '#92400E'),
                                    'pending' => array('bg' => '#FEF3C7', 'color' => '#92400E'),
                                    'confirmed' => array('bg' => '#DBEAFE', 'color' => '#1E40AF'),
                                    'scheduled' => array('bg' => '#DBEAFE', 'color' => '#1E40AF'),
                                    'completed' => array('bg' => '#D1FAE5', 'color' => '#065F46'),
                                    'cancelled' => array('bg' => '#FEE2E2', 'color' => '#991B1B'),
                                );
                                $sc = isset($status_colors[$session->session_status]) ? $status_colors[$session->session_status] : array('bg' => '#F3F4F6', 'color' => '#374151');
                                ?>
                                <span style="display: inline-block; padding: 4px 10px; border-radius: 100px; font-size: 11px; font-weight: 700; text-transform: uppercase; background: <?php echo $sc['bg']; ?>; color: <?php echo $sc['color']; ?>;">
                                    <?php echo esc_html(ucfirst($session->session_status)); ?>
                                </span>
                            </td>
                            <td style="padding: 14px 16px; font-size: 14px;">
                                <?php 
                                $payment_colors = array(
                                    'pending' => array('bg' => '#FEF3C7', 'color' => '#92400E'),
                                    'paid' => array('bg' => '#D1FAE5', 'color' => '#065F46'),
                                    'unpaid' => array('bg' => '#FEE2E2', 'color' => '#991B1B'),
                                    'refunded' => array('bg' => '#F3F4F6', 'color' => '#374151'),
                                );
                                $pc = isset($payment_colors[$session->payment_status]) ? $payment_colors[$session->payment_status] : array('bg' => '#F3F4F6', 'color' => '#374151');
                                ?>
                                <span style="display: inline-block; padding: 4px 10px; border-radius: 100px; font-size: 11px; font-weight: 700; text-transform: uppercase; background: <?php echo $pc['bg']; ?>; color: <?php echo $pc['color']; ?>;">
                                    <?php echo esc_html(ucfirst($session->payment_status)); ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <p style="text-align: center; padding: 40px; color: #9CA3AF; font-size: 15px;">No sessions yet. Once trainers are approved and parents book sessions, they'll appear here.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Render Sessions Page
     */
    public function render_sessions_page() {
        // Get filters
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $payment_filter = isset($_GET['payment']) ? sanitize_text_field($_GET['payment']) : '';
        $trainer_filter = isset($_GET['trainer']) ? intval($_GET['trainer']) : 0;
        $date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        $date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';

        $args = array(
            'session_status' => $status_filter,
            'payment_status' => $payment_filter,
            'trainer_id' => $trainer_filter,
            'date_from' => $date_from,
            'date_to' => $date_to,
            'limit' => 50
        );

        $sessions = PTP_Database::get_sessions($args);
        $trainers = PTP_Database::get_trainers(array('status' => 'approved', 'limit' => 100));
        ?>
        <div class="wrap ptp-admin">
            <h1 class="ptp-admin-title">Sessions</h1>

            <!-- Filters -->
            <div class="ptp-filters">
                <form method="get" class="ptp-filter-form">
                    <input type="hidden" name="page" value="ptp-training-sessions">

                    <div class="ptp-filter-group">
                        <label>Session Status</label>
                        <select name="status">
                            <option value="">All Statuses</option>
                            <option value="requested" <?php selected($status_filter, 'requested'); ?>>Requested</option>
                            <option value="confirmed" <?php selected($status_filter, 'confirmed'); ?>>Confirmed</option>
                            <option value="scheduled" <?php selected($status_filter, 'scheduled'); ?>>Scheduled</option>
                            <option value="completed" <?php selected($status_filter, 'completed'); ?>>Completed</option>
                            <option value="cancelled" <?php selected($status_filter, 'cancelled'); ?>>Cancelled</option>
                            <option value="no_show" <?php selected($status_filter, 'no_show'); ?>>No Show</option>
                        </select>
                    </div>

                    <div class="ptp-filter-group">
                        <label>Payment Status</label>
                        <select name="payment">
                            <option value="">All Payments</option>
                            <option value="unpaid" <?php selected($payment_filter, 'unpaid'); ?>>Unpaid</option>
                            <option value="pending" <?php selected($payment_filter, 'pending'); ?>>Pending</option>
                            <option value="paid" <?php selected($payment_filter, 'paid'); ?>>Paid</option>
                            <option value="refunded" <?php selected($payment_filter, 'refunded'); ?>>Refunded</option>
                        </select>
                    </div>

                    <div class="ptp-filter-group">
                        <label>Trainer</label>
                        <select name="trainer">
                            <option value="">All Trainers</option>
                            <?php foreach ($trainers as $trainer): ?>
                                <option value="<?php echo $trainer->id; ?>" <?php selected($trainer_filter, $trainer->id); ?>>
                                    <?php echo esc_html($trainer->display_name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="ptp-filter-group">
                        <label>Date From</label>
                        <input type="date" name="date_from" value="<?php echo esc_attr($date_from); ?>">
                    </div>

                    <div class="ptp-filter-group">
                        <label>Date To</label>
                        <input type="date" name="date_to" value="<?php echo esc_attr($date_to); ?>">
                    </div>

                    <button type="submit" class="button">Filter</button>
                    <a href="<?php echo admin_url('admin.php?page=ptp-training-sessions'); ?>" class="button">Reset</a>
                </form>
            </div>

            <!-- Sessions Table -->
            <?php if ($sessions): ?>
            <table class="ptp-admin-table widefat">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Parent/Customer</th>
                        <th>Trainer</th>
                        <th>Player</th>
                        <th>Date/Time</th>
                        <th>Price</th>
                        <th>Session Status</th>
                        <th>Payment Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($sessions as $session): ?>
                    <tr data-session-id="<?php echo $session->id; ?>">
                        <td>#<?php echo $session->id; ?></td>
                        <td>
                            <strong><?php echo esc_html($session->customer_name); ?></strong><br>
                            <small><?php echo esc_html($session->customer_email); ?></small>
                        </td>
                        <td><?php echo esc_html($session->trainer_name); ?></td>
                        <td>
                            <?php echo esc_html($session->player_name ?: 'N/A'); ?>
                            <?php if ($session->player_age): ?>
                                <br><small>Age <?php echo esc_html($session->player_age); ?></small>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($session->session_date !== '0000-00-00'): ?>
                                <?php echo date('M j, Y', strtotime($session->session_date)); ?><br>
                                <small><?php echo date('g:i A', strtotime($session->start_time)); ?></small>
                            <?php else: ?>
                                <em>Not scheduled</em>
                            <?php endif; ?>
                        </td>
                        <td>$<?php echo number_format($session->price, 2); ?></td>
                        <td>
                            <select class="ptp-session-status-select" data-session-id="<?php echo $session->id; ?>">
                                <option value="requested" <?php selected($session->session_status, 'requested'); ?>>Requested</option>
                                <option value="confirmed" <?php selected($session->session_status, 'confirmed'); ?>>Confirmed</option>
                                <option value="scheduled" <?php selected($session->session_status, 'scheduled'); ?>>Scheduled</option>
                                <option value="completed" <?php selected($session->session_status, 'completed'); ?>>Completed</option>
                                <option value="cancelled" <?php selected($session->session_status, 'cancelled'); ?>>Cancelled</option>
                                <option value="no_show" <?php selected($session->session_status, 'no_show'); ?>>No Show</option>
                            </select>
                        </td>
                        <td>
                            <span class="ptp-status ptp-status--payment-<?php echo esc_attr($session->payment_status); ?>">
                                <?php echo esc_html(ucfirst($session->payment_status)); ?>
                            </span>
                        </td>
                        <td>
                            <a href="#" class="ptp-view-session" data-session-id="<?php echo $session->id; ?>">View</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="ptp-empty">No sessions found matching your criteria.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render Trainers Page - with inline styles and Edit functionality
     */
    public function render_trainers_page() {
        $trainers = PTP_Database::get_trainers(array('status' => 'approved', 'limit' => 100));
        ?>
        <style>
            .ptp-trainers-wrap { max-width: 1400px; margin: 20px 20px 40px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
            .ptp-trainers-wrap * { box-sizing: border-box; }
            .ptp-trainers-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; padding-bottom: 20px; border-bottom: 1px solid #E5E7EB; }
            .ptp-trainers-header h1 { display: flex; align-items: center; gap: 12px; font-size: 26px; font-weight: 700; margin: 0; color: #111827; }
            .ptp-trainers-header h1 .badge { background: linear-gradient(135deg, #FCB900, #E5A800); color: #0E0F11; padding: 6px 14px; border-radius: 6px; font-size: 14px; font-weight: 800; }
            .ptp-add-btn { display: inline-flex; align-items: center; gap: 8px; padding: 10px 20px; background: #FCB900; color: #0E0F11; font-size: 14px; font-weight: 700; border-radius: 8px; text-decoration: none; border: none; cursor: pointer; }
            .ptp-add-btn:hover { background: #E5A800; color: #0E0F11; }
            
            .ptp-trainers-table { width: 100%; background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }
            .ptp-trainers-table thead { background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%); }
            .ptp-trainers-table th { padding: 14px 16px; text-align: left; font-size: 12px; font-weight: 700; color: #fff; text-transform: uppercase; letter-spacing: 0.5px; }
            .ptp-trainers-table tbody tr { border-bottom: 1px solid #F3F4F6; transition: background 0.15s; }
            .ptp-trainers-table tbody tr:hover { background: #FFFBEB; }
            .ptp-trainers-table td { padding: 14px 16px; font-size: 14px; color: #374151; vertical-align: middle; }
            
            .ptp-trainer-avatar { width: 48px; height: 48px; border-radius: 10px; object-fit: cover; }
            .ptp-trainer-avatar--placeholder { width: 48px; height: 48px; border-radius: 10px; background: linear-gradient(135deg, #FCB900, #E5A800); display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 800; color: #0E0F11; }
            
            .ptp-rating { display: flex; align-items: center; gap: 4px; }
            .ptp-rating svg { width: 14px; height: 14px; fill: #FCB900; }
            
            .ptp-badge { display: inline-block; padding: 4px 10px; border-radius: 100px; font-size: 11px; font-weight: 700; text-transform: uppercase; }
            .ptp-badge--featured { background: linear-gradient(135deg, #FCB900, #E5A800); color: #0E0F11; }
            .ptp-badge--connected { background: #D1FAE5; color: #065F46; }
            .ptp-badge--pending { background: #FEF3C7; color: #92400E; }
            .ptp-badge--notset { background: #FEE2E2; color: #991B1B; }
            
            .ptp-actions { display: flex; gap: 8px; flex-wrap: wrap; }
            .ptp-actions a, .ptp-actions button { padding: 6px 12px; font-size: 12px; font-weight: 600; border-radius: 6px; text-decoration: none; border: none; cursor: pointer; transition: all 0.15s; }
            .ptp-actions .edit { background: #FCB900; color: #0E0F11; }
            .ptp-actions .edit:hover { background: #E5A800; }
            .ptp-actions .view { background: #E5E7EB; color: #374151; }
            .ptp-actions .view:hover { background: #D1D5DB; }
            .ptp-actions .feature { background: #DBEAFE; color: #1E40AF; }
            .ptp-actions .feature:hover { background: #BFDBFE; }
            
            .ptp-empty { text-align: center; padding: 60px 20px; color: #9CA3AF; font-size: 15px; background: #fff; border-radius: 12px; }
        </style>
        
        <div class="ptp-trainers-wrap">
            <div class="ptp-trainers-header">
                <h1><span class="badge">PTP</span> Trainers</h1>
                <a href="<?php echo admin_url('admin.php?page=ptp-training-edit-trainer&action=new'); ?>" class="ptp-add-btn">
                    <span class="dashicons dashicons-plus-alt" style="font-size:16px;width:16px;height:16px;"></span>
                    Add Trainer
                </a>
            </div>

            <?php if ($trainers): ?>
            <table class="ptp-trainers-table">
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Rate</th>
                        <th>Rating</th>
                        <th>Sessions</th>
                        <th>Stripe</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($trainers as $trainer): ?>
                    <tr>
                        <td>
                            <?php if ($trainer->profile_photo): ?>
                                <img src="<?php echo esc_url($trainer->profile_photo); ?>" alt="" class="ptp-trainer-avatar">
                            <?php else: ?>
                                <div class="ptp-trainer-avatar--placeholder">
                                    <?php echo esc_html(strtoupper(substr($trainer->display_name, 0, 1))); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong style="color:#111827;"><?php echo esc_html($trainer->display_name); ?></strong>
                            <?php if ($trainer->credentials): ?>
                                <br><small style="color:#6B7280;"><?php echo esc_html($trainer->credentials); ?></small>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($trainer->primary_location_city . ', ' . $trainer->primary_location_state); ?></td>
                        <td><strong>$<?php echo number_format($trainer->hourly_rate, 0); ?></strong>/hr</td>
                        <td>
                            <?php if ($trainer->avg_rating > 0): ?>
                                <span class="ptp-rating">
                                    <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                    <?php echo number_format($trainer->avg_rating, 1); ?>
                                    <small style="color:#9CA3AF;">(<?php echo $trainer->total_reviews; ?>)</small>
                                </span>
                            <?php else: ?>
                                <em style="color:#9CA3AF;">No reviews</em>
                            <?php endif; ?>
                        </td>
                        <td><?php echo number_format($trainer->total_sessions); ?></td>
                        <td>
                            <?php if ($trainer->stripe_onboarding_complete): ?>
                                <span class="ptp-badge ptp-badge--connected">Connected</span>
                            <?php elseif ($trainer->stripe_account_id): ?>
                                <span class="ptp-badge ptp-badge--pending">Pending</span>
                            <?php else: ?>
                                <span class="ptp-badge ptp-badge--notset">Not Set</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($trainer->is_featured): ?>
                                <span class="ptp-badge ptp-badge--featured">⭐ Featured</span>
                            <?php else: ?>
                                <span style="color:#9CA3AF;">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="ptp-actions">
                                <a href="<?php echo admin_url('admin.php?page=ptp-training-edit-trainer&id=' . $trainer->id); ?>" class="edit">Edit</a>
                                <a href="<?php echo home_url('/trainer/' . $trainer->slug . '/'); ?>" target="_blank" class="view">View</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="ptp-empty">No approved trainers yet. Approve applications or add trainers manually.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render Applications Page
     */
    public function render_applications_page() {
        global $wpdb;
        
        // Get filter
        $status_filter = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        
        $where = "1=1";
        if ($status_filter) {
            $where .= $wpdb->prepare(" AND status = %s", $status_filter);
        }
        
        $applications = $wpdb->get_results(
            "SELECT * FROM {$wpdb->prefix}ptp_applications WHERE {$where} ORDER BY status = 'pending' DESC, created_at DESC LIMIT 100"
        );
        
        // Get counts
        $pending_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_applications WHERE status = 'pending'");
        $approved_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_applications WHERE status = 'approved'");
        $rejected_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_applications WHERE status = 'rejected'");
        ?>
        <style>
        .ptp-applications-page { max-width: 1400px; margin: 20px 20px 20px 0; }
        .ptp-applications-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
        .ptp-applications-header h1 { font-size: 28px; font-weight: 700; margin: 0; display: flex; align-items: center; gap: 12px; }
        .ptp-applications-header h1 .count { background: #FCB900; color: #0E0F11; padding: 4px 12px; border-radius: 100px; font-size: 14px; font-weight: 700; }
        
        .ptp-filter-tabs { display: flex; gap: 8px; margin-bottom: 24px; }
        .ptp-filter-tab { padding: 10px 20px; background: #fff; border: 1px solid #E5E7EB; border-radius: 8px; text-decoration: none; color: #4B5563; font-weight: 500; font-size: 14px; transition: all 0.15s; }
        .ptp-filter-tab:hover { background: #F9FAFB; color: #111827; }
        .ptp-filter-tab.active { background: #0E0F11; color: #fff; border-color: #0E0F11; }
        .ptp-filter-tab .count { background: rgba(0,0,0,0.1); padding: 2px 8px; border-radius: 100px; margin-left: 6px; font-size: 12px; }
        .ptp-filter-tab.active .count { background: rgba(255,255,255,0.2); }
        
        .ptp-applications-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(380px, 1fr)); gap: 20px; }
        
        .ptp-application-card { background: #fff; border-radius: 16px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; transition: all 0.2s; }
        .ptp-application-card:hover { box-shadow: 0 4px 12px rgba(0,0,0,0.15); }
        .ptp-application-card--pending { border-left: 4px solid #FCB900; }
        .ptp-application-card--approved { border-left: 4px solid #10B981; opacity: 0.7; }
        .ptp-application-card--rejected { border-left: 4px solid #EF4444; opacity: 0.6; }
        
        .ptp-application-header { padding: 20px 20px 16px; border-bottom: 1px solid #F3F4F6; display: flex; justify-content: space-between; align-items: flex-start; }
        .ptp-application-header h3 { font-size: 18px; font-weight: 700; margin: 0 0 4px; color: #111827; }
        .ptp-application-header .meta { font-size: 13px; color: #6B7280; }
        
        .ptp-status { padding: 4px 12px; border-radius: 100px; font-size: 12px; font-weight: 600; text-transform: uppercase; }
        .ptp-status--pending { background: #FEF3C7; color: #92400E; }
        .ptp-status--approved { background: #D1FAE5; color: #065F46; }
        .ptp-status--rejected { background: #FEE2E2; color: #991B1B; }
        
        .ptp-application-body { padding: 20px; }
        .ptp-application-body .field { margin-bottom: 12px; }
        .ptp-application-body .field-label { font-size: 11px; font-weight: 600; text-transform: uppercase; color: #9CA3AF; margin-bottom: 4px; }
        .ptp-application-body .field-value { font-size: 14px; color: #374151; }
        .ptp-application-body .field-value a { color: #FCB900; }
        
        .ptp-application-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
        
        .ptp-application-text { background: #F9FAFB; padding: 12px; border-radius: 8px; font-size: 13px; color: #4B5563; line-height: 1.5; max-height: 100px; overflow-y: auto; }
        
        .ptp-application-actions { padding: 16px 20px; background: #F9FAFB; border-top: 1px solid #F3F4F6; display: flex; gap: 12px; }
        .ptp-application-actions button { flex: 1; padding: 12px 20px; border-radius: 8px; font-weight: 600; font-size: 14px; cursor: pointer; transition: all 0.15s; }
        .ptp-application-actions .ptp-approve-application { background: #10B981; color: #fff; border: none; }
        .ptp-application-actions .ptp-approve-application:hover { background: #059669; }
        .ptp-application-actions .ptp-reject-application { background: #fff; color: #EF4444; border: 2px solid #EF4444; }
        .ptp-application-actions .ptp-reject-application:hover { background: #FEE2E2; }
        
        .ptp-approved-animation { background: #D1FAE5 !important; }
        
        .ptp-empty-state { text-align: center; padding: 60px 20px; background: #fff; border-radius: 16px; }
        .ptp-empty-state svg { margin-bottom: 16px; opacity: 0.5; }
        .ptp-empty-state h3 { font-size: 18px; font-weight: 600; color: #374151; margin: 0 0 8px; }
        .ptp-empty-state p { color: #6B7280; margin: 0; }
        </style>
        
        <div class="wrap ptp-applications-page">
            <div class="ptp-applications-header">
                <h1>
                    Trainer Applications
                    <?php if ($pending_count > 0): ?>
                    <span class="count"><?php echo $pending_count; ?> pending</span>
                    <?php endif; ?>
                </h1>
            </div>
            
            <div class="ptp-filter-tabs">
                <a href="<?php echo admin_url('admin.php?page=ptp-training-applications'); ?>" class="ptp-filter-tab <?php echo !$status_filter ? 'active' : ''; ?>">
                    All<span class="count"><?php echo count($applications); ?></span>
                </a>
                <a href="<?php echo admin_url('admin.php?page=ptp-training-applications&status=pending'); ?>" class="ptp-filter-tab <?php echo $status_filter === 'pending' ? 'active' : ''; ?>">
                    Pending<span class="count"><?php echo $pending_count; ?></span>
                </a>
                <a href="<?php echo admin_url('admin.php?page=ptp-training-applications&status=approved'); ?>" class="ptp-filter-tab <?php echo $status_filter === 'approved' ? 'active' : ''; ?>">
                    Approved<span class="count"><?php echo $approved_count; ?></span>
                </a>
                <a href="<?php echo admin_url('admin.php?page=ptp-training-applications&status=rejected'); ?>" class="ptp-filter-tab <?php echo $status_filter === 'rejected' ? 'active' : ''; ?>">
                    Rejected<span class="count"><?php echo $rejected_count; ?></span>
                </a>
            </div>

            <?php if ($applications): ?>
            <div class="ptp-applications-grid">
                <?php foreach ($applications as $app): ?>
                <div class="ptp-application-card ptp-application-card--<?php echo esc_attr($app->status); ?>">
                    <div class="ptp-application-header">
                        <div>
                            <h3><?php echo esc_html($app->first_name . ' ' . $app->last_name); ?></h3>
                            <div class="meta">Applied <?php echo date('M j, Y \a\t g:ia', strtotime($app->created_at)); ?></div>
                        </div>
                        <span class="ptp-status ptp-status--<?php echo esc_attr($app->status); ?>">
                            <?php echo esc_html(ucfirst($app->status)); ?>
                        </span>
                    </div>
                    
                    <div class="ptp-application-body">
                        <div class="ptp-application-grid">
                            <div class="field">
                                <div class="field-label">Email</div>
                                <div class="field-value"><a href="mailto:<?php echo esc_attr($app->email); ?>"><?php echo esc_html($app->email); ?></a></div>
                            </div>
                            <div class="field">
                                <div class="field-label">Phone</div>
                                <div class="field-value"><a href="tel:<?php echo esc_attr($app->phone); ?>"><?php echo esc_html($app->phone); ?></a></div>
                            </div>
                            <div class="field">
                                <div class="field-label">Location</div>
                                <div class="field-value"><?php echo esc_html(trim($app->location_city . ', ' . $app->location_state . ' ' . $app->location_zip, ', ')); ?></div>
                            </div>
                            <div class="field">
                                <div class="field-label">Type</div>
                                <div class="field-value"><?php echo esc_html(ucfirst($app->role_type ?: 'Trainer')); ?></div>
                            </div>
                        </div>
                        
                        <?php if (!empty($app->playing_background)): ?>
                        <div class="field">
                            <div class="field-label">Playing Background</div>
                            <div class="ptp-application-text"><?php echo esc_html($app->playing_background); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($app->coaching_experience)): ?>
                        <div class="field">
                            <div class="field-label">Coaching Experience</div>
                            <div class="ptp-application-text"><?php echo esc_html($app->coaching_experience); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($app->why_join)): ?>
                        <div class="field">
                            <div class="field-label">Why They Want to Join</div>
                            <div class="ptp-application-text"><?php echo esc_html($app->why_join); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($app->certifications)): ?>
                        <div class="field">
                            <div class="field-label">Certifications</div>
                            <div class="field-value"><?php echo esc_html($app->certifications); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($app->instagram_handle)): ?>
                        <div class="field">
                            <div class="field-label">Instagram</div>
                            <div class="field-value"><a href="https://instagram.com/<?php echo esc_attr(ltrim($app->instagram_handle, '@')); ?>" target="_blank">@<?php echo esc_html(ltrim($app->instagram_handle, '@')); ?></a></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($app->referral_source)): ?>
                        <div class="field">
                            <div class="field-label">How They Heard About Us</div>
                            <div class="field-value"><?php echo esc_html($app->referral_source); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($app->intro_video_url)): ?>
                        <div class="field">
                            <div class="field-label">Intro Video</div>
                            <div class="field-value"><a href="<?php echo esc_url($app->intro_video_url); ?>" target="_blank">Watch Video →</a></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if ($app->status !== 'pending' && !empty($app->admin_notes)): ?>
                        <div class="field">
                            <div class="field-label">Admin Notes</div>
                            <div class="ptp-application-text"><?php echo esc_html($app->admin_notes); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <?php if ($app->status === 'pending'): ?>
                    <div class="ptp-application-actions">
                        <button class="ptp-approve-application" data-app-id="<?php echo $app->id; ?>">
                            ✓ Approve & Create Account
                        </button>
                        <button class="ptp-reject-application" data-app-id="<?php echo $app->id; ?>">
                            ✕ Reject
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="ptp-empty-state">
                <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg>
                <h3>No applications yet</h3>
                <p>When trainers apply, they'll appear here for your review.</p>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render Payouts Page
     */
    public function render_payouts_page() {
        global $wpdb;
        $payouts = $wpdb->get_results(
            "SELECT p.*, t.display_name as trainer_name
             FROM {$wpdb->prefix}ptp_payouts p
             LEFT JOIN {$wpdb->prefix}ptp_trainers t ON p.trainer_id = t.id
             ORDER BY p.status = 'pending' DESC, p.created_at DESC
             LIMIT 100"
        );
        ?>
        <div class="wrap ptp-admin">
            <h1 class="ptp-admin-title">Trainer Payouts</h1>

            <?php if ($payouts): ?>
            <table class="ptp-admin-table widefat">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Trainer</th>
                        <th>Gross</th>
                        <th>Platform Fee</th>
                        <th>Trainer Payout</th>
                        <th>Status</th>
                        <th>Paid At</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payouts as $payout): ?>
                    <tr>
                        <td>#<?php echo $payout->id; ?></td>
                        <td><?php echo esc_html($payout->trainer_name); ?></td>
                        <td>$<?php echo number_format($payout->gross_amount, 2); ?></td>
                        <td>$<?php echo number_format($payout->platform_fee, 2); ?></td>
                        <td><strong>$<?php echo number_format($payout->trainer_payout, 2); ?></strong></td>
                        <td>
                            <span class="ptp-status ptp-status--<?php echo $payout->status === 'paid' ? 'confirmed' : 'pending'; ?>">
                                <?php echo esc_html(ucfirst($payout->status)); ?>
                            </span>
                        </td>
                        <td>
                            <?php echo $payout->paid_at ? date('M j, Y', strtotime($payout->paid_at)) : '-'; ?>
                        </td>
                        <td>
                            <?php if ($payout->status === 'pending'): ?>
                                <button class="button button-primary button-small ptp-process-payout" data-payout-id="<?php echo $payout->id; ?>">
                                    Process
                                </button>
                            <?php elseif ($payout->stripe_transfer_id): ?>
                                <small><?php echo esc_html($payout->stripe_transfer_id); ?></small>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php else: ?>
            <p class="ptp-empty">No payouts yet.</p>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Render Settings Page - Robust Version with Inline Styles
     */
    public function render_settings_page() {
        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
        $tabs = array(
            'general' => array('label' => 'General', 'icon' => '⚙️'),
            'pages' => array('label' => 'Pages & URLs', 'icon' => '📄'),
            'stripe' => array('label' => 'Payments', 'icon' => '💳'),
            'notifications' => array('label' => 'Notifications', 'icon' => '📧'),
            'sms' => array('label' => 'SMS', 'icon' => '📱'),
            'integrations' => array('label' => 'Integrations', 'icon' => '🔌'),
            'branding' => array('label' => 'Branding', 'icon' => '🎨'),
            'advanced' => array('label' => 'Advanced', 'icon' => '🔧'),
        );
        ?>
        <style>
            .ptp-settings-wrap { max-width: 1200px; margin: 20px 20px 20px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
            .ptp-settings-wrap * { box-sizing: border-box; }
            .ptp-settings-header { margin-bottom: 24px; }
            .ptp-settings-header h1 { display: flex; align-items: center; gap: 12px; font-size: 28px; font-weight: 700; margin: 0 0 8px; }
            .ptp-settings-header h1 .ptp-badge { background: linear-gradient(135deg, #FCB900, #E5A800); color: #0E0F11; padding: 6px 14px; border-radius: 6px; font-size: 14px; font-weight: 800; }
            .ptp-settings-header p { color: #6B7280; font-size: 15px; margin: 0; }
            
            .ptp-settings-layout { display: grid; grid-template-columns: 200px 1fr; gap: 24px; }
            @media (max-width: 900px) { .ptp-settings-layout { grid-template-columns: 1fr; } }
            
            .ptp-settings-nav { background: #fff; border-radius: 12px; padding: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); height: fit-content; position: sticky; top: 32px; }
            .ptp-settings-nav a { display: flex; align-items: center; gap: 10px; padding: 12px 14px; border-radius: 8px; color: #4B5563; text-decoration: none; font-size: 14px; font-weight: 500; transition: all 0.15s; }
            .ptp-settings-nav a:hover { background: #F3F4F6; color: #111827; }
            .ptp-settings-nav a.active { background: #FEF3C7; color: #0E0F11; font-weight: 600; }
            .ptp-settings-nav a span.icon { font-size: 16px; }
            
            .ptp-settings-content { min-width: 0; }
            
            .ptp-card { background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; overflow: hidden; }
            .ptp-card-header { padding: 20px 24px; border-bottom: 1px solid #F3F4F6; background: #FAFAFA; }
            .ptp-card-header h2 { font-size: 16px; font-weight: 700; margin: 0 0 4px; color: #111827; }
            .ptp-card-header p { font-size: 13px; color: #6B7280; margin: 0; }
            .ptp-card-body { padding: 24px; }
            
            .ptp-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
            @media (max-width: 700px) { .ptp-grid { grid-template-columns: 1fr; } }
            .ptp-grid .full { grid-column: 1 / -1; }
            
            .ptp-field { display: flex; flex-direction: column; gap: 6px; }
            .ptp-field label { font-size: 13px; font-weight: 600; color: #374151; }
            .ptp-field input[type="text"], .ptp-field input[type="email"], .ptp-field input[type="password"], 
            .ptp-field input[type="number"], .ptp-field input[type="url"], .ptp-field select, .ptp-field textarea {
                padding: 10px 14px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 14px; width: 100%; transition: all 0.15s;
            }
            .ptp-field input:focus, .ptp-field select:focus, .ptp-field textarea:focus { outline: none; border-color: #FCB900; box-shadow: 0 0 0 3px rgba(252,185,0,0.2); }
            .ptp-field .hint { font-size: 12px; color: #9CA3AF; }
            .ptp-field .hint code { background: #F3F4F6; padding: 2px 6px; border-radius: 4px; font-size: 11px; }
            
            .ptp-toggle-row { display: flex; align-items: center; gap: 12px; padding: 12px 0; border-bottom: 1px solid #F3F4F6; }
            .ptp-toggle-row:last-child { border-bottom: none; }
            .ptp-toggle-row input[type="checkbox"] { width: 44px; height: 24px; appearance: none; background: #D1D5DB; border-radius: 12px; position: relative; cursor: pointer; transition: all 0.2s; }
            .ptp-toggle-row input[type="checkbox"]::after { content: ''; width: 18px; height: 18px; background: #fff; border-radius: 50%; position: absolute; top: 3px; left: 3px; transition: all 0.2s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
            .ptp-toggle-row input[type="checkbox"]:checked { background: #FCB900; }
            .ptp-toggle-row input[type="checkbox"]:checked::after { transform: translateX(20px); }
            .ptp-toggle-row span { font-size: 14px; color: #374151; }
            
            .ptp-alert { display: flex; gap: 12px; padding: 14px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
            .ptp-alert-info { background: #DBEAFE; color: #1E40AF; }
            .ptp-alert a { color: inherit; font-weight: 600; }
            
            .ptp-input-group { display: flex; }
            .ptp-input-group .prefix { padding: 10px 12px; background: #F3F4F6; border: 1px solid #D1D5DB; border-right: none; border-radius: 8px 0 0 8px; font-size: 13px; color: #6B7280; white-space: nowrap; }
            .ptp-input-group input { border-radius: 0 8px 8px 0; flex: 1; }
            
            .ptp-radio-row { display: flex; gap: 24px; margin-bottom: 16px; }
            .ptp-radio-row label { display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 14px; }
            .ptp-radio-row input[type="radio"] { width: 18px; height: 18px; accent-color: #FCB900; }
            
            .ptp-notify-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; }
            @media (max-width: 700px) { .ptp-notify-grid { grid-template-columns: 1fr; } }
            .ptp-notify-section h4 { font-size: 12px; font-weight: 600; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.5px; margin: 0 0 12px; padding-bottom: 8px; border-bottom: 1px solid #F3F4F6; }
            
            .ptp-system-table { width: 100%; font-size: 13px; }
            .ptp-system-table td { padding: 10px 0; border-bottom: 1px solid #F3F4F6; }
            .ptp-system-table td:first-child { font-weight: 600; color: #6B7280; width: 150px; }
            .ptp-system-table code { background: #F3F4F6; padding: 4px 8px; border-radius: 4px; font-size: 11px; }
            
            .ptp-settings-footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #E5E7EB; }
            .ptp-settings-footer .button-primary { background: #FCB900 !important; border-color: #FCB900 !important; color: #0E0F11 !important; padding: 10px 24px !important; height: auto !important; font-weight: 600 !important; }
            .ptp-settings-footer .button-primary:hover { background: #E5A800 !important; border-color: #E5A800 !important; }
        </style>
        
        <div class="ptp-settings-wrap">
            <div class="ptp-settings-header">
                <h1><span class="ptp-badge">PTP</span> Settings</h1>
                <p>Configure your private training platform</p>
            </div>

            <div class="ptp-settings-layout">
                <!-- Sidebar Navigation -->
                <nav class="ptp-settings-nav">
                    <?php foreach ($tabs as $tab_id => $tab): ?>
                    <a href="?page=ptp-training-settings&tab=<?php echo $tab_id; ?>" class="<?php echo $current_tab === $tab_id ? 'active' : ''; ?>">
                        <span class="icon"><?php echo $tab['icon']; ?></span>
                        <?php echo $tab['label']; ?>
                    </a>
                    <?php endforeach; ?>
                </nav>

                <!-- Settings Content -->
                <div class="ptp-settings-content">
                    <form method="post" action="options.php">
                        <?php settings_fields('ptp_training_settings'); ?>

                        <?php if ($current_tab === 'general'): ?>
                        <!-- GENERAL TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Platform Settings</h2>
                                <p>Core configuration for your training marketplace</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Platform Fee (%)</label>
                                        <input type="number" name="ptp_platform_fee_percent" value="<?php echo esc_attr(get_option('ptp_platform_fee_percent', 20)); ?>" min="0" max="50" step="0.5">
                                        <span class="hint">Percentage kept from each transaction</span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Admin Email</label>
                                        <input type="email" name="ptp_admin_email" value="<?php echo esc_attr(get_option('ptp_admin_email', get_option('admin_email'))); ?>">
                                        <span class="hint">Primary email for notifications</span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Default Session Duration</label>
                                        <select name="ptp_default_session_duration">
                                            <option value="30" <?php selected(get_option('ptp_default_session_duration', 60), 30); ?>>30 minutes</option>
                                            <option value="45" <?php selected(get_option('ptp_default_session_duration', 60), 45); ?>>45 minutes</option>
                                            <option value="60" <?php selected(get_option('ptp_default_session_duration', 60), 60); ?>>1 hour</option>
                                            <option value="90" <?php selected(get_option('ptp_default_session_duration', 60), 90); ?>>1.5 hours</option>
                                            <option value="120" <?php selected(get_option('ptp_default_session_duration', 60), 120); ?>>2 hours</option>
                                        </select>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Cancellation Window (hours)</label>
                                        <input type="number" name="ptp_cancellation_window" value="<?php echo esc_attr(get_option('ptp_cancellation_window', 24)); ?>" min="0" max="168">
                                        <span class="hint">Hours before session when free cancellation ends</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Booking Settings</h2>
                                <p>Control how bookings are processed</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-toggle-row">
                                    <input type="checkbox" name="ptp_auto_confirm_on_payment" value="1" <?php checked(get_option('ptp_auto_confirm_on_payment'), 1); ?>>
                                    <span>Auto-confirm sessions when payment succeeds</span>
                                </div>
                                <div class="ptp-toggle-row">
                                    <input type="checkbox" name="ptp_require_payment_upfront" value="1" <?php checked(get_option('ptp_require_payment_upfront'), 1); ?>>
                                    <span>Require payment before session is confirmed</span>
                                </div>
                                <div class="ptp-toggle-row">
                                    <input type="checkbox" name="ptp_allow_guest_booking" value="1" <?php checked(get_option('ptp_allow_guest_booking', 1), 1); ?>>
                                    <span>Allow booking without account (creates account automatically)</span>
                                </div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'pages'): ?>
                        <!-- PAGES TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Page Configuration</h2>
                                <p>Assign pages for each part of your training platform</p>
                            </div>
                            <div class="ptp-card-body">
                                <?php $pages = get_pages(); ?>
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Trainer Directory Page</label>
                                        <select name="ptp_page_marketplace">
                                            <option value="">— Select —</option>
                                            <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo $page->ID; ?>" <?php selected(get_option('ptp_page_marketplace'), $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <span class="hint">Shortcode: <code>[ptp_training_directory]</code></span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Private Training Landing</label>
                                        <select name="ptp_page_private_training">
                                            <option value="">— Select —</option>
                                            <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo $page->ID; ?>" <?php selected(get_option('ptp_page_private_training'), $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <span class="hint">Shortcode: <code>[ptp_private_training]</code></span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Checkout Page</label>
                                        <select name="ptp_page_checkout">
                                            <option value="">— Select —</option>
                                            <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo $page->ID; ?>" <?php selected(get_option('ptp_page_checkout'), $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <span class="hint">Shortcode: <code>[ptp_training_checkout]</code></span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Parent Dashboard</label>
                                        <select name="ptp_page_parent_dashboard">
                                            <option value="">— Select —</option>
                                            <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo $page->ID; ?>" <?php selected(get_option('ptp_page_parent_dashboard'), $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <span class="hint">Shortcode: <code>[ptp_parent_dashboard]</code></span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Trainer Dashboard</label>
                                        <select name="ptp_page_trainer_dashboard">
                                            <option value="">— Select —</option>
                                            <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo $page->ID; ?>" <?php selected(get_option('ptp_page_trainer_dashboard'), $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <span class="hint">Shortcode: <code>[ptp_trainer_dashboard]</code></span>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Trainer Application</label>
                                        <select name="ptp_page_application">
                                            <option value="">— Select —</option>
                                            <?php foreach ($pages as $page): ?>
                                            <option value="<?php echo $page->ID; ?>" <?php selected(get_option('ptp_page_application'), $page->ID); ?>><?php echo esc_html($page->post_title); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <span class="hint">Shortcode: <code>[ptp_application_form]</code></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>URL Structure</h2>
                                <p>Configure trainer profile URLs</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-field">
                                    <label>Trainer Profile Base</label>
                                    <div class="ptp-input-group">
                                        <span class="prefix"><?php echo home_url('/'); ?></span>
                                        <input type="text" name="ptp_trainer_slug" value="<?php echo esc_attr(get_option('ptp_trainer_slug', 'trainer')); ?>">
                                    </div>
                                    <span class="hint">Flush permalinks after changing</span>
                                </div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'stripe'): ?>
                        <!-- PAYMENTS TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Stripe Configuration</h2>
                                <p>Connect your Stripe account to accept payments</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-alert ptp-alert-info">
                                    ℹ️ Get your API keys from <a href="https://dashboard.stripe.com/apikeys" target="_blank">Stripe Dashboard → Developers → API keys</a>
                                </div>
                                
                                <div class="ptp-radio-row">
                                    <label><input type="radio" name="ptp_stripe_mode" value="test" <?php checked(get_option('ptp_stripe_mode', 'test'), 'test'); ?>> Test Mode</label>
                                    <label><input type="radio" name="ptp_stripe_mode" value="live" <?php checked(get_option('ptp_stripe_mode', 'test'), 'live'); ?>> Live Mode</label>
                                </div>
                                
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Publishable Key</label>
                                        <input type="text" name="ptp_stripe_publishable_key" value="<?php echo esc_attr(get_option('ptp_stripe_publishable_key')); ?>" placeholder="pk_test_... or pk_live_...">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Secret Key</label>
                                        <input type="password" name="ptp_stripe_secret_key" value="<?php echo esc_attr(get_option('ptp_stripe_secret_key')); ?>" placeholder="sk_test_... or sk_live_...">
                                    </div>
                                    <div class="ptp-field full">
                                        <label>Webhook Secret</label>
                                        <input type="password" name="ptp_stripe_webhook_secret" value="<?php echo esc_attr(get_option('ptp_stripe_webhook_secret')); ?>" placeholder="whsec_...">
                                        <span class="hint">Webhook URL: <code><?php echo rest_url('ptp-training/v1/stripe-webhook'); ?></code></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Stripe Connect</h2>
                                <p>Allow trainers to receive direct payments</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-toggle-row">
                                    <input type="checkbox" name="ptp_stripe_connect_enabled" value="1" <?php checked(get_option('ptp_stripe_connect_enabled'), 1); ?>>
                                    <span>Enable Stripe Connect for trainer payouts</span>
                                </div>
                                <div class="ptp-field" style="margin-top: 16px;">
                                    <label>Payout Delay (days)</label>
                                    <input type="number" name="ptp_stripe_payout_delay" value="<?php echo esc_attr(get_option('ptp_stripe_payout_delay', 7)); ?>" min="0" max="30" style="max-width: 100px;">
                                    <span class="hint">Days after session before trainer payout</span>
                                </div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'notifications'): ?>
                        <!-- NOTIFICATIONS TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Email Settings</h2>
                                <p>Configure email sender information</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>From Name</label>
                                        <input type="text" name="ptp_notification_from_name" value="<?php echo esc_attr(get_option('ptp_notification_from_name', 'Players Teaching Players')); ?>">
                                    </div>
                                    <div class="ptp-field">
                                        <label>From Email</label>
                                        <input type="email" name="ptp_notification_from_email" value="<?php echo esc_attr(get_option('ptp_notification_from_email', get_option('admin_email'))); ?>">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Admin Notification Email</label>
                                        <input type="email" name="ptp_notification_admin_email" value="<?php echo esc_attr(get_option('ptp_notification_admin_email', get_option('admin_email'))); ?>">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Reply-To Email</label>
                                        <input type="email" name="ptp_notification_reply_to" value="<?php echo esc_attr(get_option('ptp_notification_reply_to')); ?>" placeholder="Optional">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Notification Triggers</h2>
                                <p>Choose which events send emails</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-notify-grid">
                                    <div class="ptp-notify-section">
                                        <h4>Booking Requests</h4>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_parent_booking_request" value="1" <?php checked(get_option('ptp_notify_parent_booking_request', 1), 1); ?>><span>Email parent</span></div>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_trainer_booking_request" value="1" <?php checked(get_option('ptp_notify_trainer_booking_request', 1), 1); ?>><span>Email trainer</span></div>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_admin_booking_request" value="1" <?php checked(get_option('ptp_notify_admin_booking_request', 1), 1); ?>><span>Email admin</span></div>
                                    </div>
                                    <div class="ptp-notify-section">
                                        <h4>Session Confirmed</h4>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_parent_session_confirmed" value="1" <?php checked(get_option('ptp_notify_parent_session_confirmed', 1), 1); ?>><span>Email parent</span></div>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_trainer_session_confirmed" value="1" <?php checked(get_option('ptp_notify_trainer_session_confirmed', 1), 1); ?>><span>Email trainer</span></div>
                                    </div>
                                    <div class="ptp-notify-section">
                                        <h4>Cancellations</h4>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_parent_session_cancelled" value="1" <?php checked(get_option('ptp_notify_parent_session_cancelled', 1), 1); ?>><span>Email parent</span></div>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_trainer_session_cancelled" value="1" <?php checked(get_option('ptp_notify_trainer_session_cancelled', 1), 1); ?>><span>Email trainer</span></div>
                                    </div>
                                    <div class="ptp-notify-section">
                                        <h4>Completion & Payment</h4>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_parent_session_completed" value="1" <?php checked(get_option('ptp_notify_parent_session_completed', 1), 1); ?>><span>Email after session</span></div>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_parent_payment_success" value="1" <?php checked(get_option('ptp_notify_parent_payment_success', 1), 1); ?>><span>Send receipt</span></div>
                                        <div class="ptp-toggle-row"><input type="checkbox" name="ptp_notify_admin_payment_success" value="1" <?php checked(get_option('ptp_notify_admin_payment_success', 1), 1); ?>><span>Notify admin</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Email Templates</h2>
                                <p>Customize subject lines and content</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-grid">
                                    <div class="ptp-field full">
                                        <label>Booking Request - Subject</label>
                                        <input type="text" name="ptp_email_booking_request_subject" value="<?php echo esc_attr(get_option('ptp_email_booking_request_subject', 'We received your PTP private training request')); ?>">
                                    </div>
                                    <div class="ptp-field full">
                                        <label>Booking Request - Intro</label>
                                        <textarea name="ptp_email_booking_request_intro" rows="2"><?php echo esc_textarea(get_option('ptp_email_booking_request_intro', 'Thank you for submitting your training request!')); ?></textarea>
                                    </div>
                                    <div class="ptp-field full">
                                        <label>Session Confirmed - Subject</label>
                                        <input type="text" name="ptp_email_session_confirmed_subject" value="<?php echo esc_attr(get_option('ptp_email_session_confirmed_subject', 'Your training session is confirmed!')); ?>">
                                    </div>
                                    <div class="ptp-field full">
                                        <label>Session Confirmed - Intro</label>
                                        <textarea name="ptp_email_session_confirmed_intro" rows="2"><?php echo esc_textarea(get_option('ptp_email_session_confirmed_intro', 'Great news! Your training session has been confirmed.')); ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'sms'): ?>
                        <!-- SMS TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Twilio SMS</h2>
                                <p>Send text message notifications</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-toggle-row" style="margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #E5E7EB;">
                                    <input type="checkbox" name="ptp_sms_enabled" value="1" <?php checked(get_option('ptp_sms_enabled'), 1); ?>>
                                    <span><strong>Enable SMS Notifications</strong></span>
                                </div>
                                
                                <div class="ptp-alert ptp-alert-info">
                                    ℹ️ Sign up at <a href="https://www.twilio.com/console" target="_blank">twilio.com/console</a> to get your credentials
                                </div>
                                
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Account SID</label>
                                        <input type="text" name="ptp_twilio_sid" value="<?php echo esc_attr(get_option('ptp_twilio_sid')); ?>" placeholder="ACxxxxxxxx">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Auth Token</label>
                                        <input type="password" name="ptp_twilio_token" value="<?php echo esc_attr(get_option('ptp_twilio_token')); ?>">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Phone Number</label>
                                        <input type="text" name="ptp_twilio_phone" value="<?php echo esc_attr(get_option('ptp_twilio_phone')); ?>" placeholder="+15551234567">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>SMS Triggers</h2>
                                <p>Choose when to send texts</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-toggle-row"><input type="checkbox" name="ptp_sms_booking_confirmed" value="1" <?php checked(get_option('ptp_sms_booking_confirmed', 1), 1); ?>><span>Booking confirmed</span></div>
                                <div class="ptp-toggle-row"><input type="checkbox" name="ptp_sms_reminder_24h" value="1" <?php checked(get_option('ptp_sms_reminder_24h', 1), 1); ?>><span>24 hour reminder</span></div>
                                <div class="ptp-toggle-row"><input type="checkbox" name="ptp_sms_reminder_1h" value="1" <?php checked(get_option('ptp_sms_reminder_1h'), 1); ?>><span>1 hour reminder</span></div>
                                <div class="ptp-toggle-row"><input type="checkbox" name="ptp_sms_cancellation" value="1" <?php checked(get_option('ptp_sms_cancellation', 1), 1); ?>><span>Cancellation notice</span></div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'integrations'): ?>
                        <!-- INTEGRATIONS TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Google Maps</h2>
                                <p>Display trainer locations on maps</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-field">
                                    <label>API Key</label>
                                    <input type="text" name="ptp_google_maps_key" value="<?php echo esc_attr(get_option('ptp_google_maps_key')); ?>" placeholder="AIzaSy...">
                                    <span class="hint">Get from <a href="https://console.cloud.google.com/google/maps-apis" target="_blank">Google Cloud Console</a></span>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Google Calendar</h2>
                                <p>Sync sessions to trainer calendars</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-alert ptp-alert-info">
                                    ℹ️ Create OAuth credentials at <a href="https://console.cloud.google.com/apis/credentials" target="_blank">Google Cloud Console</a><br>
                                    Redirect URI: <code><?php echo admin_url('admin.php?page=ptp-training-google-callback'); ?></code>
                                </div>
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Client ID</label>
                                        <input type="text" name="ptp_google_client_id" value="<?php echo esc_attr(get_option('ptp_google_client_id')); ?>" placeholder="xxxxx.apps.googleusercontent.com">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Client Secret</label>
                                        <input type="password" name="ptp_google_client_secret" value="<?php echo esc_attr(get_option('ptp_google_client_secret')); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>HubSpot CRM</h2>
                                <p>Sync customers and sessions</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-toggle-row" style="margin-bottom: 16px;">
                                    <input type="checkbox" name="ptp_hubspot_enabled" value="1" <?php checked(get_option('ptp_hubspot_enabled'), 1); ?>>
                                    <span>Enable HubSpot Integration</span>
                                </div>
                                <div class="ptp-field">
                                    <label>Private App Token</label>
                                    <input type="password" name="ptp_hubspot_api_key" value="<?php echo esc_attr(get_option('ptp_hubspot_api_key')); ?>" placeholder="pat-na1-xxxxx">
                                </div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'branding'): ?>
                        <!-- BRANDING TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Brand Colors</h2>
                                <p>Customize your platform's look</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Primary Color</label>
                                        <input type="color" name="ptp_brand_primary_color" value="<?php echo esc_attr(get_option('ptp_brand_primary_color', '#FCB900')); ?>" style="width: 60px; height: 40px; padding: 4px;">
                                    </div>
                                    <div class="ptp-field">
                                        <label>Secondary Color</label>
                                        <input type="color" name="ptp_brand_secondary_color" value="<?php echo esc_attr(get_option('ptp_brand_secondary_color', '#0E0F11')); ?>" style="width: 60px; height: 40px; padding: 4px;">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Social Media</h2>
                                <p>Your organization's social links</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-grid">
                                    <div class="ptp-field">
                                        <label>Instagram</label>
                                        <div class="ptp-input-group">
                                            <span class="prefix">instagram.com/</span>
                                            <input type="text" name="ptp_social_instagram" value="<?php echo esc_attr(get_option('ptp_social_instagram')); ?>" placeholder="ptpsoccercamps">
                                        </div>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Facebook</label>
                                        <div class="ptp-input-group">
                                            <span class="prefix">facebook.com/</span>
                                            <input type="text" name="ptp_social_facebook" value="<?php echo esc_attr(get_option('ptp_social_facebook')); ?>">
                                        </div>
                                    </div>
                                    <div class="ptp-field">
                                        <label>Twitter / X</label>
                                        <div class="ptp-input-group">
                                            <span class="prefix">x.com/</span>
                                            <input type="text" name="ptp_social_twitter" value="<?php echo esc_attr(get_option('ptp_social_twitter')); ?>">
                                        </div>
                                    </div>
                                    <div class="ptp-field">
                                        <label>YouTube</label>
                                        <input type="url" name="ptp_social_youtube" value="<?php echo esc_attr(get_option('ptp_social_youtube')); ?>" placeholder="https://youtube.com/@channel">
                                    </div>
                                    <div class="ptp-field">
                                        <label>TikTok</label>
                                        <div class="ptp-input-group">
                                            <span class="prefix">tiktok.com/@</span>
                                            <input type="text" name="ptp_social_tiktok" value="<?php echo esc_attr(get_option('ptp_social_tiktok')); ?>">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <?php elseif ($current_tab === 'advanced'): ?>
                        <!-- ADVANCED TAB -->
                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>Developer Settings</h2>
                                <p>Advanced options</p>
                            </div>
                            <div class="ptp-card-body">
                                <div class="ptp-toggle-row"><input type="checkbox" name="ptp_debug_mode" value="1" <?php checked(get_option('ptp_debug_mode'), 1); ?>><span>Enable Debug Mode (logs to wp-content/ptp-debug.log)</span></div>
                                <div class="ptp-toggle-row"><input type="checkbox" name="ptp_disable_css" value="1" <?php checked(get_option('ptp_disable_css'), 1); ?>><span>Disable plugin CSS (use your own styles)</span></div>
                            </div>
                        </div>

                        <div class="ptp-card">
                            <div class="ptp-card-header">
                                <h2>System Information</h2>
                                <p>Useful for debugging</p>
                            </div>
                            <div class="ptp-card-body">
                                <table class="ptp-system-table">
                                    <tr><td>Plugin Version</td><td><?php echo PTP_TRAINING_VERSION; ?></td></tr>
                                    <tr><td>WordPress</td><td><?php echo get_bloginfo('version'); ?></td></tr>
                                    <tr><td>PHP</td><td><?php echo phpversion(); ?></td></tr>
                                    <tr><td>REST API</td><td><code><?php echo rest_url('ptp-training/v1/'); ?></code></td></tr>
                                </table>
                            </div>
                        </div>

                        <?php endif; ?>

                        <div class="ptp-settings-footer">
                            <?php submit_button('Save Settings', 'primary', 'submit', false); ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    // ==========================================
    // AJAX HANDLERS
    // ==========================================

    /**
     * Update session status via AJAX
     */
    public function ajax_update_session_status() {
        check_ajax_referer('ptp_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }

        $session_id = intval($_POST['session_id']);
        $new_status = sanitize_text_field($_POST['status']);

        $valid_statuses = array('requested', 'confirmed', 'scheduled', 'completed', 'cancelled', 'no_show');
        if (!in_array($new_status, $valid_statuses)) {
            wp_send_json_error(array('message' => 'Invalid status'));
        }

        $result = PTP_Database::update_session_status($session_id, $new_status);

        if ($result !== false) {
            wp_send_json_success(array('message' => 'Status updated'));
        } else {
            wp_send_json_error(array('message' => 'Failed to update status'));
        }
    }

    /**
     * Approve trainer application via AJAX
     */
    public function ajax_approve_trainer() {
        check_ajax_referer('ptp_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }

        global $wpdb;
        $app_id = intval($_POST['app_id']);

        $app = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_applications WHERE id = %d",
            $app_id
        ));

        if (!$app) {
            wp_send_json_error(array('message' => 'Application not found'));
        }
        
        // PREVENT DOUBLE APPROVAL - Check if already approved
        if ($app->status === 'approved') {
            wp_send_json_error(array('message' => 'This application has already been approved.'));
        }
        
        // Check if trainer profile already exists for this email
        $existing_trainer = $wpdb->get_var($wpdb->prepare(
            "SELECT t.id FROM {$wpdb->prefix}ptp_trainers t 
             INNER JOIN {$wpdb->users} u ON t.user_id = u.ID 
             WHERE u.user_email = %s",
            $app->email
        ));
        
        if ($existing_trainer) {
            // Just update the application status and return success
            $wpdb->update(
                "{$wpdb->prefix}ptp_applications",
                array('status' => 'approved', 'reviewed_by' => get_current_user_id(), 'reviewed_at' => current_time('mysql')),
                array('id' => $app_id)
            );
            wp_send_json_success(array('message' => 'Trainer already exists. Application marked as approved.'));
        }

        // Check if user already exists
        $existing_user = get_user_by('email', $app->email);
        
        if ($existing_user) {
            $user_id = $existing_user->ID;
            // Just update their role
            $user = new WP_User($user_id);
            $user->add_role('ptp_trainer');
        } else {
            // Create new user account
            $username = sanitize_user(strtolower($app->first_name . '.' . $app->last_name));
            
            // Make username unique if needed
            $base_username = $username;
            $counter = 1;
            while (username_exists($username)) {
                $username = $base_username . $counter;
                $counter++;
            }
            
            // Generate random password (user will reset it)
            $password = wp_generate_password(12, true, true);
            
            $user_id = wp_create_user($username, $password, $app->email);

            if (is_wp_error($user_id)) {
                wp_send_json_error(array('message' => 'Error creating account: ' . $user_id->get_error_message()));
            }

            // Set role and user meta
            $user = new WP_User($user_id);
            $user->set_role('ptp_trainer');
            
            wp_update_user(array(
                'ID' => $user_id,
                'first_name' => $app->first_name,
                'last_name' => $app->last_name,
                'display_name' => $app->first_name . ' ' . $app->last_name
            ));
            
            // Store phone number
            update_user_meta($user_id, 'phone', $app->phone);
        }

        // Create trainer profile in ptp_trainers table
        $slug = sanitize_title($app->first_name . '-' . $app->last_name);
        
        // Make slug unique if needed
        $base_slug = $slug;
        $counter = 1;
        while ($wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE slug = %s", $slug))) {
            $slug = $base_slug . '-' . $counter;
            $counter++;
        }
        
        // Build bio from application data
        $bio_parts = array();
        if (!empty($app->playing_background)) {
            $bio_parts[] = $app->playing_background;
        }
        if (!empty($app->coaching_experience)) {
            $bio_parts[] = $app->coaching_experience;
        }
        $bio = implode("\n\n", $bio_parts);
        
        $wpdb->insert(
            "{$wpdb->prefix}ptp_trainers",
            array(
                'user_id' => $user_id,
                'status' => 'approved',
                'display_name' => $app->first_name . ' ' . $app->last_name,
                'slug' => $slug,
                'bio' => $bio,
                'primary_location_city' => $app->location_city,
                'primary_location_state' => $app->location_state,
                'primary_location_zip' => $app->location_zip,
                'intro_video_url' => $app->intro_video_url ?? '',
                'certifications' => $app->certifications ?? '',
                'hourly_rate' => 75,
                'created_at' => current_time('mysql')
            )
        );
        
        $trainer_id = $wpdb->insert_id;

        // Update application status IMMEDIATELY to prevent double processing
        $wpdb->update(
            "{$wpdb->prefix}ptp_applications",
            array(
                'status' => 'approved',
                'reviewed_by' => get_current_user_id(),
                'reviewed_at' => current_time('mysql')
            ),
            array('id' => $app_id)
        );

        // Generate password reset link
        $user = get_user_by('id', $user_id);
        $reset_key = get_password_reset_key($user);
        if (is_wp_error($reset_key)) {
            $reset_url = home_url('/login/');
        } else {
            $reset_url = home_url("/login/?action=rp&key=$reset_key&login=" . rawurlencode($app->email));
        }
        
        $dashboard_url = home_url('/trainer-dashboard/');
        $profile_url = home_url('/trainer/' . $slug . '/');
        $login_url = home_url('/login/');

        // Send HTML approval email
        $subject = 'Welcome to PTP! Your trainer application is approved 🎉';
        
        $html_message = $this->get_trainer_welcome_email_html(
            $app->first_name,
            $reset_url,
            $dashboard_url,
            $profile_url,
            $login_url
        );

        $headers = array(
            'Content-Type: text/html; charset=UTF-8',
            'From: PTP Soccer <noreply@ptpsummercamps.com>'
        );
        
        wp_mail($app->email, $subject, $html_message, $headers);
        
        // Notify admin (plain text is fine)
        $admin_email = get_option('admin_email');
        $admin_subject = "Trainer Approved: {$app->first_name} {$app->last_name}";
        $admin_message = "Trainer application approved.\n\n";
        $admin_message .= "Name: {$app->first_name} {$app->last_name}\n";
        $admin_message .= "Email: {$app->email}\n";
        $admin_message .= "Profile: {$profile_url}\n";
        wp_mail($admin_email, $admin_subject, $admin_message);

        wp_send_json_success(array(
            'message' => "Trainer approved! Account created and welcome email sent to {$app->email}",
            'trainer_id' => $trainer_id,
            'user_id' => $user_id
        ));
    }
    
    /**
     * Generate HTML email for trainer welcome
     */
    private function get_trainer_welcome_email_html($first_name, $reset_url, $dashboard_url, $profile_url, $login_url) {
        $logo_url = 'https://ptpsummercamps.com/wp-content/uploads/2025/11/PTP-LOGO-2.png';
        
        return '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; background-color: #F9FAFB; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #F9FAFB; padding: 40px 20px;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="max-width: 600px; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
                    
                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #0E0F11 0%, #1F2937 100%); padding: 40px 40px 30px; text-align: center;">
                            <img src="' . esc_url($logo_url) . '" alt="PTP Soccer" style="height: 50px; margin-bottom: 20px;">
                            <h1 style="color: #FCB900; font-size: 28px; font-weight: 800; margin: 0 0 8px 0;">Welcome to the Team! 🎉</h1>
                            <p style="color: rgba(255,255,255,0.8); font-size: 16px; margin: 0;">Your trainer application has been approved</p>
                        </td>
                    </tr>
                    
                    <!-- Body -->
                    <tr>
                        <td style="padding: 40px;">
                            <p style="font-size: 16px; color: #374151; margin: 0 0 24px 0; line-height: 1.6;">
                                Hi ' . esc_html($first_name) . ',
                            </p>
                            <p style="font-size: 16px; color: #374151; margin: 0 0 32px 0; line-height: 1.6;">
                                Great news! You\'re now officially a PTP trainer. Let\'s get you set up so you can start helping young athletes reach their potential.
                            </p>
                            
                            <!-- Step 1 -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="background: #FEFCE8; border-radius: 12px; margin-bottom: 20px;">
                                <tr>
                                    <td style="padding: 24px;">
                                        <table cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="vertical-align: top; padding-right: 16px;">
                                                    <div style="width: 36px; height: 36px; background: #FCB900; border-radius: 50%; text-align: center; line-height: 36px; font-weight: 800; color: #0E0F11; font-size: 16px;">1</div>
                                                </td>
                                                <td>
                                                    <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 700; color: #0E0F11;">Set Your Password</h3>
                                                    <p style="margin: 0 0 16px 0; font-size: 14px; color: #6B7280; line-height: 1.5;">Click the button below to create a secure password for your account.</p>
                                                    <a href="' . esc_url($reset_url) . '" style="display: inline-block; background: #FCB900; color: #0E0F11; text-decoration: none; padding: 14px 28px; border-radius: 8px; font-weight: 700; font-size: 14px;">Create Password →</a>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- Step 2 -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="background: #F3F4F6; border-radius: 12px; margin-bottom: 20px;">
                                <tr>
                                    <td style="padding: 24px;">
                                        <table cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="vertical-align: top; padding-right: 16px;">
                                                    <div style="width: 36px; height: 36px; background: #0E0F11; border-radius: 50%; text-align: center; line-height: 36px; font-weight: 800; color: #fff; font-size: 16px;">2</div>
                                                </td>
                                                <td>
                                                    <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 700; color: #0E0F11;">Complete Your Profile</h3>
                                                    <p style="margin: 0; font-size: 14px; color: #6B7280; line-height: 1.5;">After setting your password, log in to add:</p>
                                                    <ul style="margin: 12px 0 0 0; padding-left: 20px; font-size: 14px; color: #6B7280; line-height: 1.8;">
                                                        <li>Profile photo</li>
                                                        <li>Your hourly rate</li>
                                                        <li>Training specialties</li>
                                                        <li>Intro video (optional)</li>
                                                    </ul>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- Step 3 -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="background: #F3F4F6; border-radius: 12px; margin-bottom: 32px;">
                                <tr>
                                    <td style="padding: 24px;">
                                        <table cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="vertical-align: top; padding-right: 16px;">
                                                    <div style="width: 36px; height: 36px; background: #0E0F11; border-radius: 50%; text-align: center; line-height: 36px; font-weight: 800; color: #fff; font-size: 16px;">3</div>
                                                </td>
                                                <td>
                                                    <h3 style="margin: 0 0 8px 0; font-size: 18px; font-weight: 700; color: #0E0F11;">Start Training!</h3>
                                                    <p style="margin: 0; font-size: 14px; color: #6B7280; line-height: 1.5;">Parents will find you in our trainer directory and book sessions directly. You\'ll receive notifications when someone books.</p>
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- Quick Links -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="border-top: 1px solid #E5E7EB; padding-top: 24px;">
                                <tr>
                                    <td>
                                        <p style="font-size: 14px; color: #6B7280; margin: 0 0 12px 0; font-weight: 600;">Quick Links:</p>
                                        <p style="font-size: 14px; margin: 0; line-height: 2;">
                                            <a href="' . esc_url($dashboard_url) . '" style="color: #FCB900; text-decoration: none;">Your Dashboard</a> · 
                                            <a href="' . esc_url($profile_url) . '" style="color: #FCB900; text-decoration: none;">Your Public Profile</a> · 
                                            <a href="' . esc_url($login_url) . '" style="color: #FCB900; text-decoration: none;">Login Page</a>
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background: #0E0F11; padding: 30px 40px; text-align: center;">
                            <p style="color: rgba(255,255,255,0.6); font-size: 13px; margin: 0 0 8px 0;">Questions? Just reply to this email.</p>
                            <p style="color: rgba(255,255,255,0.4); font-size: 12px; margin: 0;">
                                PTP Soccer · Teaching What Team Coaches Don\'t<br>
                                <a href="https://ptpsummercamps.com" style="color: #FCB900; text-decoration: none;">ptpsummercamps.com</a>
                            </p>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';
    }

    /**
     * Reject trainer application via AJAX
     */
    public function ajax_reject_trainer() {
        check_ajax_referer('ptp_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }

        global $wpdb;
        $app_id = intval($_POST['app_id']);
        $reason = sanitize_textarea_field($_POST['reason'] ?? '');

        $app = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_applications WHERE id = %d",
            $app_id
        ));

        if (!$app) {
            wp_send_json_error(array('message' => 'Application not found'));
        }

        $wpdb->update(
            "{$wpdb->prefix}ptp_applications",
            array(
                'status' => 'rejected',
                'admin_notes' => $reason,
                'reviewed_by' => get_current_user_id(),
                'reviewed_at' => current_time('mysql')
            ),
            array('id' => $app_id)
        );

        // Send rejection email
        $subject = 'Update on your PTP trainer application';
        $message = "Hi {$app->first_name},\n\n";
        $message .= "Thank you for your interest in becoming a PTP trainer.\n\n";
        $message .= "After careful review, we've decided not to move forward with your application at this time.\n";
        if ($reason) {
            $message .= "\nFeedback: {$reason}\n";
        }
        $message .= "\nWe encourage you to reapply in the future if circumstances change.\n\n";
        $message .= "Best regards,\nThe PTP Team";

        wp_mail($app->email, $subject, $message);

        wp_send_json_success(array('message' => 'Application rejected'));
    }

    /**
     * Process payout via AJAX
     */
    public function ajax_process_payout() {
        check_ajax_referer('ptp_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Permission denied'));
        }

        $payout_id = intval($_POST['payout_id']);

        $result = PTP_Stripe::process_payout($payout_id);

        if (is_wp_error($result)) {
            wp_send_json_error(array('message' => $result->get_error_message()));
        }

        wp_send_json_success(array('message' => 'Payout processed', 'transfer_id' => $result));
    }

    /**
     * Render Edit Trainer Page
     */
    public function render_edit_trainer_page() {
        global $wpdb;
        
        $trainer_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        $is_new = isset($_GET['action']) && $_GET['action'] === 'new';
        
        $trainer = null;
        if ($trainer_id) {
            $trainer = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
                $trainer_id
            ));
        }
        
        // Handle form submission
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_save_trainer_nonce'])) {
            if (wp_verify_nonce($_POST['ptp_save_trainer_nonce'], 'ptp_save_trainer')) {
                $data = array(
                    'display_name' => sanitize_text_field($_POST['display_name']),
                    'slug' => sanitize_title($_POST['slug'] ?: $_POST['display_name']),
                    'bio' => sanitize_textarea_field($_POST['bio']),
                    'tagline' => sanitize_text_field($_POST['tagline']),
                    'credentials' => sanitize_text_field($_POST['credentials']),
                    'hourly_rate' => floatval($_POST['hourly_rate']),
                    'primary_location_city' => sanitize_text_field($_POST['primary_location_city']),
                    'primary_location_state' => sanitize_text_field($_POST['primary_location_state']),
                    'primary_location_zip' => sanitize_text_field($_POST['primary_location_zip']),
                    'profile_photo' => esc_url_raw($_POST['profile_photo']),
                    'intro_video' => esc_url_raw($_POST['intro_video']),
                    'specialties' => sanitize_text_field($_POST['specialties']),
                    'is_featured' => isset($_POST['is_featured']) ? 1 : 0,
                    'avg_rating' => floatval($_POST['avg_rating']),
                    'total_reviews' => intval($_POST['total_reviews']),
                );
                
                if ($trainer_id) {
                    $wpdb->update("{$wpdb->prefix}ptp_trainers", $data, array('id' => $trainer_id));
                    $message = 'Trainer updated successfully!';
                } else {
                    $data['status'] = 'approved';
                    $data['created_at'] = current_time('mysql');
                    $wpdb->insert("{$wpdb->prefix}ptp_trainers", $data);
                    $trainer_id = $wpdb->insert_id;
                    $message = 'Trainer created successfully!';
                }
                
                // Reload trainer data
                $trainer = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
                    $trainer_id
                ));
                
                echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
            }
        }
        
        // Sample images for easy selection
        $sample_images = array(
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1787.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1915.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1899.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1874.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1847.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1797.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1790.jpg',
            'https://ptpsummercamps.com/wp-content/uploads/2025/12/BG7A1595.jpg',
        );
        ?>
        <style>
            .ptp-edit-wrap { max-width: 900px; margin: 20px 20px 40px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
            .ptp-edit-wrap * { box-sizing: border-box; }
            .ptp-edit-header { display: flex; align-items: center; gap: 16px; margin-bottom: 24px; }
            .ptp-edit-header h1 { font-size: 24px; font-weight: 700; margin: 0; }
            .ptp-back-btn { display: inline-flex; align-items: center; gap: 6px; padding: 8px 16px; background: #F3F4F6; color: #374151; font-size: 13px; font-weight: 600; border-radius: 6px; text-decoration: none; }
            .ptp-back-btn:hover { background: #E5E7EB; color: #111827; }
            
            .ptp-form-card { background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 24px; overflow: hidden; }
            .ptp-form-card-header { padding: 20px 24px; border-bottom: 1px solid #F3F4F6; background: #FAFAFA; }
            .ptp-form-card-header h2 { font-size: 16px; font-weight: 700; margin: 0; }
            .ptp-form-card-body { padding: 24px; }
            
            .ptp-form-row { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 20px; }
            .ptp-form-row.full { grid-template-columns: 1fr; }
            .ptp-form-field { display: flex; flex-direction: column; gap: 6px; }
            .ptp-form-field label { font-size: 13px; font-weight: 600; color: #374151; }
            .ptp-form-field input, .ptp-form-field select, .ptp-form-field textarea { padding: 10px 14px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 14px; width: 100%; }
            .ptp-form-field input:focus, .ptp-form-field textarea:focus { outline: none; border-color: #FCB900; box-shadow: 0 0 0 3px rgba(252,185,0,0.2); }
            .ptp-form-field .hint { font-size: 12px; color: #9CA3AF; }
            
            .ptp-photo-preview { width: 120px; height: 120px; border-radius: 12px; object-fit: cover; border: 2px solid #E5E7EB; }
            .ptp-photo-preview--placeholder { width: 120px; height: 120px; border-radius: 12px; background: #F3F4F6; display: flex; align-items: center; justify-content: center; color: #9CA3AF; font-size: 14px; }
            
            .ptp-image-grid { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 12px; }
            .ptp-image-thumb { width: 60px; height: 60px; border-radius: 8px; object-fit: cover; cursor: pointer; border: 2px solid transparent; transition: all 0.15s; }
            .ptp-image-thumb:hover { border-color: #FCB900; transform: scale(1.05); }
            
            .ptp-toggle-row { display: flex; align-items: center; gap: 12px; }
            .ptp-toggle { width: 44px; height: 24px; appearance: none; background: #D1D5DB; border-radius: 12px; position: relative; cursor: pointer; transition: all 0.2s; border: none; }
            .ptp-toggle::after { content: ''; width: 18px; height: 18px; background: #fff; border-radius: 50%; position: absolute; top: 3px; left: 3px; transition: all 0.2s; box-shadow: 0 1px 3px rgba(0,0,0,0.2); }
            .ptp-toggle:checked { background: #FCB900; }
            .ptp-toggle:checked::after { transform: translateX(20px); }
            
            .ptp-submit-row { display: flex; gap: 12px; padding-top: 20px; border-top: 1px solid #E5E7EB; margin-top: 20px; }
            .ptp-submit-btn { padding: 12px 28px; background: #FCB900; color: #0E0F11; font-size: 14px; font-weight: 700; border: none; border-radius: 8px; cursor: pointer; }
            .ptp-submit-btn:hover { background: #E5A800; }
            .ptp-cancel-btn { padding: 12px 28px; background: #F3F4F6; color: #374151; font-size: 14px; font-weight: 600; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; display: inline-block; }
            .ptp-cancel-btn:hover { background: #E5E7EB; color: #111827; }
        </style>
        
        <div class="ptp-edit-wrap">
            <div class="ptp-edit-header">
                <a href="<?php echo admin_url('admin.php?page=ptp-training-trainers'); ?>" class="ptp-back-btn">← Back to Trainers</a>
                <h1><?php echo $is_new || !$trainer ? 'Add New Trainer' : 'Edit Trainer: ' . esc_html($trainer->display_name); ?></h1>
            </div>
            
            <form method="post">
                <?php wp_nonce_field('ptp_save_trainer', 'ptp_save_trainer_nonce'); ?>
                
                <div class="ptp-form-card">
                    <div class="ptp-form-card-header">
                        <h2>Basic Information</h2>
                    </div>
                    <div class="ptp-form-card-body">
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <label>Display Name *</label>
                                <input type="text" name="display_name" value="<?php echo esc_attr($trainer->display_name ?? ''); ?>" required>
                            </div>
                            <div class="ptp-form-field">
                                <label>URL Slug</label>
                                <input type="text" name="slug" value="<?php echo esc_attr($trainer->slug ?? ''); ?>" placeholder="auto-generated">
                                <span class="hint">Leave blank to auto-generate from name</span>
                            </div>
                        </div>
                        
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <label>Credentials</label>
                                <select name="credentials">
                                    <option value="">Select...</option>
                                    <option value="MLS Pro" <?php selected($trainer->credentials ?? '', 'MLS Pro'); ?>>MLS Pro</option>
                                    <option value="NCAA D1" <?php selected($trainer->credentials ?? '', 'NCAA D1'); ?>>NCAA D1</option>
                                    <option value="NCAA D2" <?php selected($trainer->credentials ?? '', 'NCAA D2'); ?>>NCAA D2</option>
                                    <option value="NCAA D3" <?php selected($trainer->credentials ?? '', 'NCAA D3'); ?>>NCAA D3</option>
                                    <option value="USSF Licensed" <?php selected($trainer->credentials ?? '', 'USSF Licensed'); ?>>USSF Licensed</option>
                                    <option value="Pro Experience" <?php selected($trainer->credentials ?? '', 'Pro Experience'); ?>>Pro Experience</option>
                                </select>
                            </div>
                            <div class="ptp-form-field">
                                <label>Hourly Rate ($)</label>
                                <input type="number" name="hourly_rate" value="<?php echo esc_attr($trainer->hourly_rate ?? 75); ?>" min="25" max="500" step="5">
                            </div>
                        </div>
                        
                        <div class="ptp-form-row full">
                            <div class="ptp-form-field">
                                <label>Tagline</label>
                                <input type="text" name="tagline" value="<?php echo esc_attr($trainer->tagline ?? ''); ?>" placeholder="e.g., Former MLS player specializing in finishing">
                            </div>
                        </div>
                        
                        <div class="ptp-form-row full">
                            <div class="ptp-form-field">
                                <label>Bio</label>
                                <textarea name="bio" rows="4" placeholder="Trainer's background and experience..."><?php echo esc_textarea($trainer->bio ?? ''); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="ptp-form-row full">
                            <div class="ptp-form-field">
                                <label>Specialties (comma-separated)</label>
                                <input type="text" name="specialties" value="<?php echo esc_attr($trainer->specialties ?? ''); ?>" placeholder="Ball Mastery, Finishing, 1v1 Skills, First Touch">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="ptp-form-card">
                    <div class="ptp-form-card-header">
                        <h2>Location</h2>
                    </div>
                    <div class="ptp-form-card-body">
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <label>City</label>
                                <input type="text" name="primary_location_city" value="<?php echo esc_attr($trainer->primary_location_city ?? ''); ?>">
                            </div>
                            <div class="ptp-form-field">
                                <label>State</label>
                                <input type="text" name="primary_location_state" value="<?php echo esc_attr($trainer->primary_location_state ?? 'PA'); ?>" maxlength="2" placeholder="PA">
                            </div>
                        </div>
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <label>ZIP Code</label>
                                <input type="text" name="primary_location_zip" value="<?php echo esc_attr($trainer->primary_location_zip ?? ''); ?>" maxlength="10">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="ptp-form-card">
                    <div class="ptp-form-card-header">
                        <h2>Media</h2>
                    </div>
                    <div class="ptp-form-card-body">
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <label>Profile Photo URL</label>
                                <?php if ($trainer && $trainer->profile_photo): ?>
                                    <img src="<?php echo esc_url($trainer->profile_photo); ?>" class="ptp-photo-preview" id="photo-preview">
                                <?php else: ?>
                                    <div class="ptp-photo-preview--placeholder" id="photo-preview">No photo</div>
                                <?php endif; ?>
                                <input type="text" name="profile_photo" id="profile_photo" value="<?php echo esc_url($trainer->profile_photo ?? ''); ?>" placeholder="https://...">
                                <span class="hint">Quick select from PTP library:</span>
                                <div class="ptp-image-grid">
                                    <?php foreach ($sample_images as $img): ?>
                                    <img src="<?php echo esc_url($img); ?>" class="ptp-image-thumb" onclick="document.getElementById('profile_photo').value='<?php echo esc_url($img); ?>';document.getElementById('photo-preview').src='<?php echo esc_url($img); ?>';document.getElementById('photo-preview').className='ptp-photo-preview';">
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="ptp-form-field">
                                <label>Intro Video URL</label>
                                <input type="text" name="intro_video" value="<?php echo esc_url($trainer->intro_video ?? ''); ?>" placeholder="YouTube or Vimeo URL">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="ptp-form-card">
                    <div class="ptp-form-card-header">
                        <h2>Rating & Status</h2>
                    </div>
                    <div class="ptp-form-card-body">
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <label>Average Rating (0-5)</label>
                                <input type="number" name="avg_rating" value="<?php echo esc_attr($trainer->avg_rating ?? '5.0'); ?>" min="0" max="5" step="0.1">
                            </div>
                            <div class="ptp-form-field">
                                <label>Total Reviews</label>
                                <input type="number" name="total_reviews" value="<?php echo esc_attr($trainer->total_reviews ?? '0'); ?>" min="0">
                            </div>
                        </div>
                        <div class="ptp-form-row">
                            <div class="ptp-form-field">
                                <div class="ptp-toggle-row">
                                    <input type="checkbox" name="is_featured" class="ptp-toggle" <?php checked($trainer->is_featured ?? false); ?>>
                                    <span>Featured Trainer (shown prominently on marketplace)</span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="ptp-submit-row">
                            <button type="submit" class="ptp-submit-btn"><?php echo $is_new || !$trainer ? 'Create Trainer' : 'Save Changes'; ?></button>
                            <a href="<?php echo admin_url('admin.php?page=ptp-training-trainers'); ?>" class="ptp-cancel-btn">Cancel</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <?php
    }

    /**
     * Render Reviews Management Page
     */
    public function render_reviews_page() {
        global $wpdb;
        
        // Handle add/edit review
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_review_nonce'])) {
            if (wp_verify_nonce($_POST['ptp_review_nonce'], 'ptp_save_review')) {
                $review_id = isset($_POST['review_id']) ? intval($_POST['review_id']) : 0;
                $data = array(
                    'trainer_id' => intval($_POST['trainer_id']),
                    'reviewer_name' => sanitize_text_field($_POST['reviewer_name']),
                    'reviewer_relation' => sanitize_text_field($_POST['reviewer_relation']),
                    'rating' => floatval($_POST['rating']),
                    'review_text' => sanitize_textarea_field($_POST['review_text']),
                    'status' => sanitize_text_field($_POST['status']),
                );
                
                if ($review_id) {
                    $wpdb->update("{$wpdb->prefix}ptp_reviews", $data, array('id' => $review_id));
                } else {
                    $data['created_at'] = current_time('mysql');
                    $wpdb->insert("{$wpdb->prefix}ptp_reviews", $data);
                }
                
                // Update trainer's avg rating
                $trainer_id = $data['trainer_id'];
                $avg = $wpdb->get_var($wpdb->prepare(
                    "SELECT AVG(rating) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'published'",
                    $trainer_id
                ));
                $count = $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'published'",
                    $trainer_id
                ));
                $wpdb->update(
                    "{$wpdb->prefix}ptp_trainers",
                    array('avg_rating' => round($avg, 1), 'total_reviews' => $count),
                    array('id' => $trainer_id)
                );
                
                echo '<div class="notice notice-success is-dismissible"><p>Review saved!</p></div>';
            }
        }
        
        // Handle delete
        if (isset($_GET['delete_review']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_review_' . $_GET['delete_review'])) {
                $review = $wpdb->get_row($wpdb->prepare(
                    "SELECT trainer_id FROM {$wpdb->prefix}ptp_reviews WHERE id = %d",
                    intval($_GET['delete_review'])
                ));
                $wpdb->delete("{$wpdb->prefix}ptp_reviews", array('id' => intval($_GET['delete_review'])));
                
                // Update trainer stats
                if ($review) {
                    $avg = $wpdb->get_var($wpdb->prepare(
                        "SELECT AVG(rating) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'published'",
                        $review->trainer_id
                    ));
                    $count = $wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'published'",
                        $review->trainer_id
                    ));
                    $wpdb->update(
                        "{$wpdb->prefix}ptp_trainers",
                        array('avg_rating' => round($avg ?: 0, 1), 'total_reviews' => $count ?: 0),
                        array('id' => $review->trainer_id)
                    );
                }
                
                echo '<div class="notice notice-success is-dismissible"><p>Review deleted.</p></div>';
            }
        }
        
        // Get trainers for dropdown
        $trainers = $wpdb->get_results("SELECT id, display_name FROM {$wpdb->prefix}ptp_trainers WHERE status = 'approved' ORDER BY display_name");
        
        // Get reviews
        $filter_trainer = isset($_GET['trainer']) ? intval($_GET['trainer']) : 0;
        $where = $filter_trainer ? $wpdb->prepare("WHERE r.trainer_id = %d", $filter_trainer) : "";
        $reviews = $wpdb->get_results(
            "SELECT r.*, t.display_name as trainer_name 
             FROM {$wpdb->prefix}ptp_reviews r
             LEFT JOIN {$wpdb->prefix}ptp_trainers t ON r.trainer_id = t.id
             {$where}
             ORDER BY r.created_at DESC
             LIMIT 100"
        );
        
        // Edit mode
        $editing = isset($_GET['edit']) ? $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_reviews WHERE id = %d",
            intval($_GET['edit'])
        )) : null;
        ?>
        <style>
            .ptp-reviews-wrap { max-width: 1200px; margin: 20px 20px 40px 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
            .ptp-reviews-wrap * { box-sizing: border-box; }
            .ptp-reviews-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; }
            .ptp-reviews-header h1 { display: flex; align-items: center; gap: 12px; font-size: 26px; font-weight: 700; margin: 0; }
            .ptp-reviews-header h1 .badge { background: linear-gradient(135deg, #FCB900, #E5A800); color: #0E0F11; padding: 6px 14px; border-radius: 6px; font-size: 14px; }
            
            .ptp-reviews-layout { display: grid; grid-template-columns: 350px 1fr; gap: 24px; }
            @media (max-width: 900px) { .ptp-reviews-layout { grid-template-columns: 1fr; } }
            
            .ptp-add-form { background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); padding: 24px; height: fit-content; }
            .ptp-add-form h3 { font-size: 16px; font-weight: 700; margin: 0 0 20px; }
            .ptp-add-form .field { margin-bottom: 16px; }
            .ptp-add-form label { display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 6px; }
            .ptp-add-form input, .ptp-add-form select, .ptp-add-form textarea { width: 100%; padding: 10px 12px; border: 1px solid #D1D5DB; border-radius: 8px; font-size: 14px; }
            .ptp-add-form input:focus, .ptp-add-form textarea:focus { outline: none; border-color: #FCB900; box-shadow: 0 0 0 3px rgba(252,185,0,0.2); }
            .ptp-add-form button { width: 100%; padding: 12px; background: #FCB900; color: #0E0F11; font-size: 14px; font-weight: 700; border: none; border-radius: 8px; cursor: pointer; }
            .ptp-add-form button:hover { background: #E5A800; }
            
            .ptp-reviews-list { background: #fff; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); overflow: hidden; }
            .ptp-reviews-filter { padding: 16px 20px; border-bottom: 1px solid #F3F4F6; display: flex; align-items: center; gap: 12px; }
            .ptp-reviews-filter label { font-size: 13px; font-weight: 600; color: #6B7280; }
            .ptp-reviews-filter select { padding: 8px 12px; border: 1px solid #D1D5DB; border-radius: 6px; font-size: 13px; }
            
            .ptp-review-item { padding: 20px; border-bottom: 1px solid #F3F4F6; }
            .ptp-review-item:last-child { border-bottom: none; }
            .ptp-review-item:hover { background: #FFFBEB; }
            .ptp-review-header { display: flex; align-items: flex-start; justify-content: space-between; margin-bottom: 12px; }
            .ptp-review-meta { display: flex; flex-direction: column; gap: 4px; }
            .ptp-review-name { font-weight: 700; color: #111827; }
            .ptp-review-relation { font-size: 13px; color: #6B7280; }
            .ptp-review-trainer { font-size: 12px; color: #9CA3AF; }
            .ptp-review-rating { display: flex; align-items: center; gap: 4px; }
            .ptp-review-rating svg { width: 16px; height: 16px; fill: #FCB900; }
            .ptp-review-text { font-size: 14px; color: #374151; line-height: 1.6; margin-bottom: 12px; }
            .ptp-review-actions { display: flex; gap: 8px; }
            .ptp-review-actions a { padding: 4px 10px; font-size: 12px; font-weight: 600; border-radius: 4px; text-decoration: none; }
            .ptp-review-actions .edit { background: #DBEAFE; color: #1E40AF; }
            .ptp-review-actions .delete { background: #FEE2E2; color: #991B1B; }
            
            .ptp-badge { display: inline-block; padding: 3px 8px; border-radius: 100px; font-size: 11px; font-weight: 600; }
            .ptp-badge--published { background: #D1FAE5; color: #065F46; }
            .ptp-badge--pending { background: #FEF3C7; color: #92400E; }
            
            .ptp-empty { text-align: center; padding: 60px 20px; color: #9CA3AF; }
        </style>
        
        <div class="ptp-reviews-wrap">
            <div class="ptp-reviews-header">
                <h1><span class="badge">PTP</span> Reviews</h1>
            </div>
            
            <div class="ptp-reviews-layout">
                <!-- Add/Edit Form -->
                <div class="ptp-add-form">
                    <h3><?php echo $editing ? 'Edit Review' : 'Add New Review'; ?></h3>
                    <form method="post">
                        <?php wp_nonce_field('ptp_save_review', 'ptp_review_nonce'); ?>
                        <?php if ($editing): ?>
                        <input type="hidden" name="review_id" value="<?php echo $editing->id; ?>">
                        <?php endif; ?>
                        
                        <div class="field">
                            <label>Trainer *</label>
                            <select name="trainer_id" required>
                                <option value="">Select trainer...</option>
                                <?php foreach ($trainers as $t): ?>
                                <option value="<?php echo $t->id; ?>" <?php selected($editing->trainer_id ?? '', $t->id); ?>><?php echo esc_html($t->display_name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="field">
                            <label>Reviewer Name *</label>
                            <input type="text" name="reviewer_name" value="<?php echo esc_attr($editing->reviewer_name ?? ''); ?>" placeholder="e.g., Michael K." required>
                        </div>
                        
                        <div class="field">
                            <label>Relation</label>
                            <input type="text" name="reviewer_relation" value="<?php echo esc_attr($editing->reviewer_relation ?? ''); ?>" placeholder="e.g., Parent of Jake (12)">
                        </div>
                        
                        <div class="field">
                            <label>Rating *</label>
                            <select name="rating" required>
                                <option value="5" <?php selected($editing->rating ?? 5, 5); ?>>⭐⭐⭐⭐⭐ 5.0</option>
                                <option value="4.5" <?php selected($editing->rating ?? '', 4.5); ?>>⭐⭐⭐⭐½ 4.5</option>
                                <option value="4" <?php selected($editing->rating ?? '', 4); ?>>⭐⭐⭐⭐ 4.0</option>
                                <option value="3.5" <?php selected($editing->rating ?? '', 3.5); ?>>⭐⭐⭐½ 3.5</option>
                                <option value="3" <?php selected($editing->rating ?? '', 3); ?>>⭐⭐⭐ 3.0</option>
                            </select>
                        </div>
                        
                        <div class="field">
                            <label>Review Text *</label>
                            <textarea name="review_text" rows="4" required placeholder="Write the review..."><?php echo esc_textarea($editing->review_text ?? ''); ?></textarea>
                        </div>
                        
                        <div class="field">
                            <label>Status</label>
                            <select name="status">
                                <option value="published" <?php selected($editing->status ?? 'published', 'published'); ?>>Published</option>
                                <option value="pending" <?php selected($editing->status ?? '', 'pending'); ?>>Pending</option>
                            </select>
                        </div>
                        
                        <button type="submit"><?php echo $editing ? 'Update Review' : 'Add Review'; ?></button>
                        
                        <?php if ($editing): ?>
                        <a href="<?php echo admin_url('admin.php?page=ptp-training-reviews'); ?>" style="display: block; text-align: center; margin-top: 12px; color: #6B7280; font-size: 13px;">Cancel editing</a>
                        <?php endif; ?>
                    </form>
                </div>
                
                <!-- Reviews List -->
                <div class="ptp-reviews-list">
                    <div class="ptp-reviews-filter">
                        <label>Filter by trainer:</label>
                        <form method="get">
                            <input type="hidden" name="page" value="ptp-training-reviews">
                            <select name="trainer" onchange="this.form.submit()">
                                <option value="">All trainers</option>
                                <?php foreach ($trainers as $t): ?>
                                <option value="<?php echo $t->id; ?>" <?php selected($filter_trainer, $t->id); ?>><?php echo esc_html($t->display_name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </div>
                    
                    <?php if ($reviews): ?>
                        <?php foreach ($reviews as $review): ?>
                        <div class="ptp-review-item">
                            <div class="ptp-review-header">
                                <div class="ptp-review-meta">
                                    <span class="ptp-review-name"><?php echo esc_html($review->reviewer_name); ?></span>
                                    <?php if ($review->reviewer_relation): ?>
                                    <span class="ptp-review-relation"><?php echo esc_html($review->reviewer_relation); ?></span>
                                    <?php endif; ?>
                                    <span class="ptp-review-trainer">For: <?php echo esc_html($review->trainer_name); ?></span>
                                </div>
                                <div style="text-align: right;">
                                    <span class="ptp-review-rating">
                                        <svg viewBox="0 0 24 24"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
                                        <?php echo number_format($review->rating, 1); ?>
                                    </span>
                                    <span class="ptp-badge ptp-badge--<?php echo $review->status; ?>" style="margin-left: 8px;">
                                        <?php echo ucfirst($review->status); ?>
                                    </span>
                                </div>
                            </div>
                            <div class="ptp-review-text"><?php echo esc_html($review->review_text); ?></div>
                            <div class="ptp-review-actions">
                                <a href="<?php echo admin_url('admin.php?page=ptp-training-reviews&edit=' . $review->id); ?>" class="edit">Edit</a>
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=ptp-training-reviews&delete_review=' . $review->id), 'delete_review_' . $review->id); ?>" class="delete" onclick="return confirm('Delete this review?');">Delete</a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="ptp-empty">No reviews yet. Add some reviews to display on trainer profiles.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }
}

PTP_Admin::instance();
