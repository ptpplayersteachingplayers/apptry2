<?php
/**
 * Plugin Name: PTP Private Training
 * Plugin URI: https://ptpsummercamps.com
 * Description: Professional private training marketplace with TeachMe.to-style UX, map-based discovery, trainer videos, lesson packs, Google Calendar sync, and mobile-first design. Integrated with PTP Communications Hub.
 * Version: 7.0.0
 * Author: PTP Soccer Camps
 * Text Domain: ptp-training-pro
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 */

if (!defined('ABSPATH')) exit;

define('PTP_TRAINING_VERSION', '7.0.0');
define('PTP_TRAINING_PATH', plugin_dir_path(__FILE__));
define('PTP_TRAINING_URL', plugin_dir_url(__FILE__));
define('PTP_TRAINING_BASENAME', plugin_basename(__FILE__));

class PTP_Training_Pro {
    
    private static $instance = null;
    private $woocommerce_active = false;
    
    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->check_woocommerce();
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    private function check_woocommerce() {
        $this->woocommerce_active = class_exists('WooCommerce') || in_array(
            'woocommerce/woocommerce.php', 
            apply_filters('active_plugins', get_option('active_plugins'))
        );
    }
    
    public function is_woocommerce_active() {
        return $this->woocommerce_active;
    }
    
    private function load_dependencies() {
        // Core
        require_once PTP_TRAINING_PATH . 'includes/class-ptp-database.php';
        require_once PTP_TRAINING_PATH . 'includes/class-ptp-roles.php';
        require_once PTP_TRAINING_PATH . 'includes/class-ptp-post-types.php';
        
        // Features
        if (file_exists(PTP_TRAINING_PATH . 'includes/api/class-ptp-rest-api.php')) {
            require_once PTP_TRAINING_PATH . 'includes/api/class-ptp-rest-api.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/stripe/class-ptp-stripe.php')) {
            require_once PTP_TRAINING_PATH . 'includes/stripe/class-ptp-stripe.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/calendar/class-ptp-google-calendar.php')) {
            require_once PTP_TRAINING_PATH . 'includes/calendar/class-ptp-google-calendar.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/maps/class-ptp-maps.php')) {
            require_once PTP_TRAINING_PATH . 'includes/maps/class-ptp-maps.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/video/class-ptp-video.php')) {
            require_once PTP_TRAINING_PATH . 'includes/video/class-ptp-video.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/reviews/class-ptp-reviews.php')) {
            require_once PTP_TRAINING_PATH . 'includes/reviews/class-ptp-reviews.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/sms/class-ptp-twilio.php')) {
            require_once PTP_TRAINING_PATH . 'includes/sms/class-ptp-twilio.php';
        }
        if (file_exists(PTP_TRAINING_PATH . 'includes/class-ptp-notifications.php')) {
            require_once PTP_TRAINING_PATH . 'includes/class-ptp-notifications.php';
        }
        
        // Lesson Coordinator (PTP Comm Hub integration)
        if (file_exists(PTP_TRAINING_PATH . 'includes/class-ptp-lesson-coordinator.php')) {
            require_once PTP_TRAINING_PATH . 'includes/class-ptp-lesson-coordinator.php';
        }
        
        // WooCommerce integration
        if ($this->woocommerce_active && file_exists(PTP_TRAINING_PATH . 'includes/class-ptp-woocommerce.php')) {
            require_once PTP_TRAINING_PATH . 'includes/class-ptp-woocommerce.php';
        }
        
        // Admin
        if (is_admin()) {
            require_once PTP_TRAINING_PATH . 'includes/class-ptp-admin.php';
        }
    }
    
    private function init_hooks() {
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend'), 999);
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin'));
        add_action('admin_notices', array($this, 'admin_notices'));
        
        // AJAX handlers
        add_action('wp_ajax_ptp_submit_application', array($this, 'handle_application_submission'));
        add_action('wp_ajax_nopriv_ptp_submit_application', array($this, 'handle_application_submission'));
        add_action('wp_ajax_ptp_quick_booking_request', array($this, 'handle_quick_booking_request'));
        add_action('wp_ajax_nopriv_ptp_quick_booking_request', array($this, 'handle_quick_booking_request'));
        add_action('wp_ajax_ptp_process_checkout', array($this, 'handle_checkout'));
        add_action('wp_ajax_nopriv_ptp_process_checkout', array($this, 'handle_checkout'));
        add_action('wp_ajax_ptp_respond_session', array($this, 'handle_session_response'));
        add_action('wp_ajax_ptp_add_review', array($this, 'handle_add_review'));
        add_action('wp_ajax_ptp_schedule_session', array($this, 'handle_schedule_session'));
        add_action('wp_ajax_ptp_update_trainer_profile', array($this, 'handle_update_trainer_profile'));
        
        // Shortcodes
        add_shortcode('ptp_training_directory', array($this, 'render_marketplace'));
        add_shortcode('ptp_trainer_profile', array($this, 'render_trainer_profile'));
        add_shortcode('ptp_training_checkout', array($this, 'render_checkout'));
        add_shortcode('ptp_parent_dashboard', array($this, 'render_my_training'));
        add_shortcode('ptp_trainer_dashboard', array($this, 'render_trainer_dashboard'));
        add_shortcode('ptp_application_form', array($this, 'render_application'));
        add_shortcode('ptp_private_training', array($this, 'render_private_training'));
        add_shortcode('ptp_my_account', array($this, 'render_my_account'));
        add_shortcode('ptp_login', array($this, 'render_login'));
        
        // Alias shortcodes
        add_shortcode('ptp_trainer_marketplace', array($this, 'render_marketplace'));
        add_shortcode('ptp_trainer_application', array($this, 'render_application'));
        add_shortcode('ptp_my_training', array($this, 'render_my_training'));
        add_shortcode('ptp_checkout', array($this, 'render_checkout'));
        add_shortcode('ptp_account', array($this, 'render_my_account'));
        
        // Intercept WordPress login page and redirect to custom
        add_action('login_init', array($this, 'redirect_login_page'));
    }
    
    public function admin_notices() {
        if (!$this->woocommerce_active && current_user_can('manage_options')) {
            $screen = get_current_screen();
            if ($screen && strpos($screen->id, 'ptp-training') !== false) {
                echo '<div class="notice notice-info is-dismissible">';
                echo '<p><strong>PTP Private Training:</strong> WooCommerce is not active. The plugin will use Stripe direct checkout. Install WooCommerce for additional cart/order features.</p>';
                echo '</div>';
            }
        }
    }
    
    /**
     * Handle application form submission - wired to database
     */
    public function handle_application_submission() {
        if (!isset($_POST['ptp_application_nonce']) || !wp_verify_nonce($_POST['ptp_application_nonce'], 'ptp_application_submit')) {
            wp_send_json_error(array('message' => 'Security check failed. Please refresh the page and try again.'));
        }
        
        $required = array('first_name', 'last_name', 'email', 'phone');
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                wp_send_json_error(array('message' => 'Please fill in all required fields: ' . $field));
            }
        }
        
        $email = sanitize_email($_POST['email']);
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
        }
        
        global $wpdb;
        
        // Ensure table exists
        $table_name = $wpdb->prefix . 'ptp_applications';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
        
        if (!$table_exists) {
            // Try to create table
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                email varchar(255) NOT NULL,
                first_name varchar(100) NOT NULL,
                last_name varchar(100) NOT NULL,
                phone varchar(50),
                role_type varchar(50) DEFAULT 'trainer',
                experience_summary text,
                playing_background text,
                coaching_experience text,
                certifications text,
                location_city varchar(100),
                location_state varchar(50),
                location_zip varchar(20),
                intro_video_url varchar(500),
                resume_url varchar(500),
                instagram_handle varchar(100),
                referral_source varchar(255),
                why_join text,
                availability_notes text,
                status varchar(20) DEFAULT 'pending',
                admin_notes text,
                reviewed_by bigint(20) UNSIGNED,
                reviewed_at datetime,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY email (email),
                KEY status (status)
            ) $charset_collate;";
            dbDelta($sql);
        }
        
        // Prepare data for database
        $data = array(
            'first_name' => sanitize_text_field($_POST['first_name']),
            'last_name' => sanitize_text_field($_POST['last_name']),
            'email' => $email,
            'phone' => sanitize_text_field($_POST['phone']),
            'role_type' => sanitize_text_field($_POST['role_type'] ?? 'trainer'),
            'location_city' => sanitize_text_field($_POST['location_city'] ?? ''),
            'location_state' => sanitize_text_field($_POST['location_state'] ?? ''),
            'location_zip' => sanitize_text_field($_POST['location_zip'] ?? ''),
            'playing_background' => sanitize_textarea_field($_POST['playing_background'] ?? ''),
            'coaching_experience' => sanitize_textarea_field($_POST['coaching_experience'] ?? ''),
            'certifications' => sanitize_text_field($_POST['certifications'] ?? ''),
            'instagram_handle' => sanitize_text_field($_POST['instagram_handle'] ?? ''),
            'referral_source' => sanitize_text_field($_POST['referral_source'] ?? ''),
            'why_join' => sanitize_textarea_field($_POST['why_join'] ?? ''),
            'status' => 'pending',
            'created_at' => current_time('mysql')
        );
        
        $result = $wpdb->insert($table_name, $data);
        
        if ($result === false) {
            // Log the actual error for debugging
            error_log('PTP Application Insert Error: ' . $wpdb->last_error);
            wp_send_json_error(array('message' => 'Database error. Please contact support. Error: ' . $wpdb->last_error));
        }
        
        $application_id = $wpdb->insert_id;
        
        // Send notification emails
        $this->send_application_emails($data, $application_id);
        
        // Notify via PTP Communications Hub if available
        $this->notify_comm_hub('new_application', array(
            'application_id' => $application_id,
            'name' => $data['first_name'] . ' ' . $data['last_name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'role_type' => $data['role_type']
        ));
        
        wp_send_json_success(array(
            'message' => 'Thank you for your application! We\'ll review it and get back to you within 2-3 business days.',
            'application_id' => $application_id
        ));
    }
    
    private function send_application_emails($data, $application_id) {
        $admin_email = get_option('ptp_admin_email', get_option('admin_email'));
        $subject = 'New Trainer Application: ' . $data['first_name'] . ' ' . $data['last_name'];
        $message = "A new trainer application has been submitted.\n\n";
        $message .= "Application ID: #{$application_id}\n";
        $message .= "Name: {$data['first_name']} {$data['last_name']}\n";
        $message .= "Email: {$data['email']}\n";
        $message .= "Phone: {$data['phone']}\n";
        $message .= "Role: {$data['role_type']}\n";
        $message .= "Location: {$data['location_city']}, {$data['location_state']}\n\n";
        $message .= "Playing Background:\n{$data['playing_background']}\n\n";
        $message .= "Coaching Experience:\n{$data['coaching_experience']}\n\n";
        $message .= "Review in admin: " . admin_url('admin.php?page=ptp-training-applications');
        
        wp_mail($admin_email, $subject, $message);
        
        // Applicant confirmation
        $subject = 'PTP Training Application Received';
        $message = "Hi {$data['first_name']},\n\n";
        $message .= "Thank you for applying to become a PTP trainer! We've received your application and will review it within 2-3 business days.\n\n";
        $message .= "Application Reference: #{$application_id}\n\n";
        $message .= "What happens next:\n";
        $message .= "1. Our team reviews your application\n";
        $message .= "2. If approved, you'll receive onboarding instructions\n";
        $message .= "3. Set up your profile and start accepting bookings\n\n";
        $message .= "Questions? Reply to this email.\n\n";
        $message .= "Best,\nThe PTP Team";
        
        wp_mail($data['email'], $subject, $message);
    }
    
    /**
     * Notify PTP Communications Hub (Lesson Coordinator)
     */
    private function notify_comm_hub($event_type, $data) {
        // Check if PTP Communications Hub is active
        if (!function_exists('ptp_comm_hub') && !class_exists('PTP_Communications_Hub')) {
            return false;
        }
        
        // Log to PTP Comm Hub
        global $wpdb;
        $log_table = $wpdb->prefix . 'ptp_comm_log';
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$log_table'") === $log_table) {
            $wpdb->insert($log_table, array(
                'event_type' => $event_type,
                'event_data' => json_encode($data),
                'status' => 'pending',
                'created_at' => current_time('mysql')
            ));
        }
        
        // Trigger action for PTP Comm Hub to handle
        do_action('ptp_comm_hub_event', $event_type, $data);
        
        // Specific events for lesson coordinator
        switch ($event_type) {
            case 'new_application':
                do_action('ptp_new_trainer_application', $data);
                break;
            case 'new_booking':
                do_action('ptp_new_training_booking', $data);
                break;
            case 'session_scheduled':
                do_action('ptp_session_scheduled', $data);
                break;
            case 'session_completed':
                do_action('ptp_session_completed', $data);
                break;
            case 'review_submitted':
                do_action('ptp_review_submitted', $data);
                break;
        }
        
        return true;
    }
    
    public function activate() {
        PTP_Database::create_tables();
        if (class_exists('PTP_Roles')) {
            PTP_Roles::create_roles();
        }
        $this->create_pages();
        flush_rewrite_rules();
    }
    
    public function deactivate() {
        flush_rewrite_rules();
    }
    
    public function init() {
        load_plugin_textdomain('ptp-training-pro', false, dirname(PTP_TRAINING_BASENAME) . '/languages');
    }
    
    private function create_pages() {
        $pages = array(
            'find-trainers' => array(
                'title' => 'Find Trainers',
                'content' => '[ptp_training_directory]'
            ),
            'trainer' => array(
                'title' => 'Trainer Profile',
                'content' => '[ptp_trainer_profile]'
            ),
            'training-checkout' => array(
                'title' => 'Training Checkout',
                'content' => '[ptp_training_checkout]'
            ),
            'my-training' => array(
                'title' => 'My Training',
                'content' => '[ptp_parent_dashboard]'
            ),
            'trainer-dashboard' => array(
                'title' => 'Trainer Dashboard',
                'content' => '[ptp_trainer_dashboard]'
            ),
            'coach-application' => array(
                'title' => 'Apply to Coach',
                'content' => '[ptp_application_form]'
            ),
            'private-training' => array(
                'title' => 'Private Training',
                'content' => '[ptp_private_training]'
            )
        );
        
        foreach ($pages as $slug => $page) {
            if (!get_page_by_path($slug)) {
                wp_insert_post(array(
                    'post_title' => $page['title'],
                    'post_name' => $slug,
                    'post_content' => $page['content'],
                    'post_status' => 'publish',
                    'post_type' => 'page'
                ));
            }
        }
    }
    
    public function enqueue_frontend() {
        if (!is_admin()) {
            // Google Fonts
            wp_enqueue_style('ptp-google-fonts', 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700;800;900&display=swap', array(), null);
            
            // Plugin styles
            if (file_exists(PTP_TRAINING_PATH . 'assets/css/frontend.css')) {
                wp_enqueue_style('ptp-training-frontend', PTP_TRAINING_URL . 'assets/css/frontend.css', array(), PTP_TRAINING_VERSION);
            }
            
            // Plugin scripts
            if (file_exists(PTP_TRAINING_PATH . 'assets/js/frontend.js')) {
                wp_enqueue_script('ptp-training-frontend', PTP_TRAINING_URL . 'assets/js/frontend.js', array('jquery'), PTP_TRAINING_VERSION, true);
                wp_localize_script('ptp-training-frontend', 'ptpTraining', array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('ptp_training_nonce'),
                    'home_url' => home_url()
                ));
            }
            
            // Hide theme header/footer on PTP pages
            $this->maybe_hide_theme_elements();
        }
    }
    
    /**
     * Hide theme header and footer on PTP custom pages
     * This prevents double headers/footers
     */
    private function maybe_hide_theme_elements() {
        // Add inline CSS to hide theme elements on PTP pages
        $hide_css = '
            /* Hide theme header/footer on PTP pages */
            body.ptp-full-width-page #starter-starter header,
            body.ptp-full-width-page .starter-starter header,
            body.ptp-full-width-page #starter-header,
            body.ptp-full-width-page .starter-header,
            body.ptp-full-width-page .site-header,
            body.ptp-full-width-page #site-header,
            body.ptp-full-width-page #masthead,
            body.ptp-full-width-page .ast-header,
            body.ptp-full-width-page header.elementor-location-header,
            body:has(.ptp-page-wrap) #starter-starter > header:first-child,
            body:has(.ptp-page-wrap) .starter-starter > header:first-child,
            body:has(.ptp-page-wrap) header.site-header,
            body:has(.ptp-page-wrap) header#masthead,
            body:has(.ptp-page-wrap) .starter-header,
            body:has(.ptp-page-wrap) #starter-header {
                display: none !important;
            }
            
            /* Also hide theme footer if we have our own */
            body.ptp-full-width-page .starter-footer,
            body.ptp-full-width-page #starter-footer,
            body.ptp-full-width-page footer.site-footer:not(.ptp-footer),
            body:has(.ptp-page-wrap) .starter-footer,
            body:has(.ptp-page-wrap) #starter-footer {
                /* Keep footer visible for now */
            }
            
            /* Remove any top margin/padding from main content on PTP pages */
            body.ptp-full-width-page .site-content,
            body.ptp-full-width-page main#main,
            body.ptp-full-width-page .starter-starter main,
            body:has(.ptp-page-wrap) .site-content,
            body:has(.ptp-page-wrap) main#main {
                margin-top: 0 !important;
                padding-top: 0 !important;
            }
        ';
        wp_add_inline_style('ptp-training-frontend', $hide_css);
        
        // Also add JS as backup to hide theme header
        $hide_js = "
            document.addEventListener('DOMContentLoaded', function() {
                if (document.querySelector('.ptp-page-wrap')) {
                    document.body.classList.add('ptp-full-width-page');
                    
                    // Find and hide theme headers (not our PTP header)
                    var themeHeaders = document.querySelectorAll('header:not(.ptp-unified-header)');
                    themeHeaders.forEach(function(header) {
                        // Check if it's inside our PTP wrapper - if so, skip
                        if (!header.closest('.ptp-page-wrap')) {
                            header.style.display = 'none';
                        }
                    });
                    
                    // Also target common theme header classes/IDs
                    var commonHeaders = document.querySelectorAll('#starter-starter > header:first-child, .starter-header, #masthead, .site-header');
                    commonHeaders.forEach(function(h) {
                        if (!h.classList.contains('ptp-unified-header')) {
                            h.style.display = 'none';
                        }
                    });
                }
            });
        ";
        wp_add_inline_script('ptp-training-frontend', $hide_js);
    }
    
    public function enqueue_admin($hook) {
        if (strpos($hook, 'ptp-training') !== false) {
            wp_enqueue_style('ptp-training-admin', PTP_TRAINING_URL . 'assets/css/admin.css', array(), PTP_TRAINING_VERSION);
            
            if (file_exists(PTP_TRAINING_PATH . 'assets/js/admin.js')) {
                wp_enqueue_script('ptp-training-admin', PTP_TRAINING_URL . 'assets/js/admin.js', array('jquery'), PTP_TRAINING_VERSION, true);
            }
        }
    }
    
    // Template Rendering Methods
    public function render_marketplace() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/marketplace.php';
        return ob_get_clean();
    }
    
    public function render_trainer_profile() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/trainer-profile.php';
        return ob_get_clean();
    }
    
    public function render_checkout() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/checkout.php';
        return ob_get_clean();
    }
    
    public function render_my_training() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/my-training.php';
        return ob_get_clean();
    }
    
    public function render_trainer_dashboard() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/trainer-dashboard.php';
        return ob_get_clean();
    }
    
    public function render_application() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/application.php';
        return ob_get_clean();
    }
    
    public function render_private_training() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/private-training.php';
        return ob_get_clean();
    }
    
    public function render_my_account() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/my-account.php';
        return ob_get_clean();
    }
    
    public function render_login() {
        ob_start();
        include PTP_TRAINING_PATH . 'templates/frontend/login.php';
        return ob_get_clean();
    }
    
    /**
     * Redirect WordPress login page to custom PTP login
     * Only for frontend login requests, not admin
     */
    public function redirect_login_page() {
        // Don't redirect if accessing wp-admin
        if (isset($_GET['action']) && in_array($_GET['action'], array('logout', 'postpass', 'confirmaction'))) {
            return;
        }
        
        // Don't redirect admins
        if (current_user_can('manage_options')) {
            return;
        }
        
        // Check if a login page exists
        $login_page = get_page_by_path('login');
        if (!$login_page) {
            return; // No custom login page created yet
        }
        
        $login_url = home_url('/login/');
        
        // Handle different actions
        $action = isset($_GET['action']) ? $_GET['action'] : 'login';
        
        if ($action === 'lostpassword') {
            wp_redirect($login_url . '?action=lostpassword');
            exit;
        }
        
        if ($action === 'rp' && isset($_GET['key']) && isset($_GET['login'])) {
            wp_redirect($login_url . '?action=rp&key=' . urlencode($_GET['key']) . '&login=' . urlencode($_GET['login']));
            exit;
        }
        
        // Default login redirect
        $redirect_to = isset($_GET['redirect_to']) ? '&redirect_to=' . urlencode($_GET['redirect_to']) : '';
        wp_redirect($login_url . $redirect_to);
        exit;
    }
    
    /**
     * Handle quick booking request
     */
    public function handle_quick_booking_request() {
        if (!isset($_POST['ptp_booking_nonce']) || !wp_verify_nonce($_POST['ptp_booking_nonce'], 'ptp_booking_request')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }

        $required = array('parent_name', 'parent_email', 'parent_phone', 'player_name', 'player_age');
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                wp_send_json_error(array('message' => 'Please fill in all required fields.'));
            }
        }

        $email = sanitize_email($_POST['parent_email']);
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
        }

        // Get or create customer
        $user = get_user_by('email', $email);
        if (!$user) {
            $user_id = wp_create_user($email, wp_generate_password(), $email);
            if (!is_wp_error($user_id)) {
                wp_update_user(array(
                    'ID' => $user_id,
                    'display_name' => sanitize_text_field($_POST['parent_name']),
                    'first_name' => sanitize_text_field($_POST['parent_name'])
                ));
                update_user_meta($user_id, 'phone', sanitize_text_field($_POST['parent_phone']));
            } else {
                $user_id = 0;
            }
        } else {
            $user_id = $user->ID;
        }

        $session_date = !empty($_POST['preferred_date']) ? sanitize_text_field($_POST['preferred_date']) : '0000-00-00';
        $start_time = '09:00:00';
        if (!empty($_POST['preferred_time'])) {
            switch ($_POST['preferred_time']) {
                case 'morning': $start_time = '09:00:00'; break;
                case 'afternoon': $start_time = '14:00:00'; break;
                case 'evening': $start_time = '17:00:00'; break;
            }
        }

        global $wpdb;
        $session_data = array(
            'trainer_id' => 0,
            'customer_id' => $user_id ?: 0,
            'player_name' => sanitize_text_field($_POST['player_name']),
            'player_age' => intval($_POST['player_age']),
            'session_date' => $session_date,
            'start_time' => $start_time,
            'end_time' => date('H:i:s', strtotime($start_time) + 3600),
            'location_text' => sanitize_text_field($_POST['location'] ?? ''),
            'session_type' => sanitize_text_field($_POST['session_type'] ?? '1on1'),
            'customer_notes' => sanitize_textarea_field($_POST['notes'] ?? ''),
            'session_status' => 'requested',
            'payment_status' => 'unpaid',
            'created_at' => current_time('mysql')
        );

        $wpdb->insert("{$wpdb->prefix}ptp_sessions", $session_data);
        $session_id = $wpdb->insert_id;

        if (!$session_id) {
            wp_send_json_error(array('message' => 'Error submitting request.'));
        }

        // Notify via PTP Communications Hub
        $this->notify_comm_hub('new_booking', array(
            'session_id' => $session_id,
            'parent_name' => sanitize_text_field($_POST['parent_name']),
            'parent_email' => $email,
            'parent_phone' => sanitize_text_field($_POST['parent_phone']),
            'player_name' => sanitize_text_field($_POST['player_name']),
            'player_age' => intval($_POST['player_age'])
        ));

        // Send admin notification
        $admin_email = get_option('ptp_admin_email', get_option('admin_email'));
        $subject = 'New Quick Booking Request - ' . sanitize_text_field($_POST['player_name']);
        $message = "A new training request has been submitted.\n\n";
        $message .= "Parent: " . sanitize_text_field($_POST['parent_name']) . "\n";
        $message .= "Email: " . $email . "\n";
        $message .= "Phone: " . sanitize_text_field($_POST['parent_phone']) . "\n";
        $message .= "Player: " . sanitize_text_field($_POST['player_name']) . " (Age " . intval($_POST['player_age']) . ")\n\n";
        $message .= "View in admin: " . admin_url('admin.php?page=ptp-training-sessions');

        wp_mail($admin_email, $subject, $message);

        wp_send_json_success(array(
            'message' => 'Thank you! Your request has been submitted. We\'ll contact you within 24 hours.',
            'session_id' => $session_id
        ));
    }
    
    /**
     * Handle checkout form submission
     */
    public function handle_checkout() {
        if (!isset($_POST['ptp_checkout_nonce']) || !wp_verify_nonce($_POST['ptp_checkout_nonce'], 'ptp_checkout')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        $required = array('athlete_name', 'athlete_age', 'first_name', 'last_name', 'email', 'phone', 'trainer_id', 'package_type');
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                wp_send_json_error(array('message' => 'Please fill in all required fields.'));
            }
        }
        
        $email = sanitize_email($_POST['email']);
        if (!is_email($email)) {
            wp_send_json_error(array('message' => 'Please enter a valid email address.'));
        }
        
        global $wpdb;
        $trainer_id = intval($_POST['trainer_id']);
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d AND status = 'approved'",
            $trainer_id
        ));
        
        if (!$trainer) {
            wp_send_json_error(array('message' => 'Invalid trainer selected.'));
        }
        
        $hourly_rate = $trainer->hourly_rate ?: 75;
        $package_type = sanitize_text_field($_POST['package_type']);
        
        switch ($package_type) {
            case '5pack':
                $sessions = 5;
                $discount = 0.10;
                break;
            case '10pack':
                $sessions = 10;
                $discount = 0.20;
                break;
            default:
                $sessions = 1;
                $discount = 0;
        }
        
        $total = $hourly_rate * $sessions * (1 - $discount);
        
        // Get or create user
        $user = get_user_by('email', $email);
        if (!$user) {
            $user_id = wp_create_user($email, wp_generate_password(), $email);
            if (!is_wp_error($user_id)) {
                wp_update_user(array(
                    'ID' => $user_id,
                    'first_name' => sanitize_text_field($_POST['first_name']),
                    'last_name' => sanitize_text_field($_POST['last_name']),
                    'display_name' => sanitize_text_field($_POST['first_name'] . ' ' . $_POST['last_name'])
                ));
                update_user_meta($user_id, 'phone', sanitize_text_field($_POST['phone']));
            } else {
                $user_id = 0;
            }
        } else {
            $user_id = $user->ID;
        }
        
        // Process Stripe payment if token provided
        $stripe_token = isset($_POST['stripe_token']) ? sanitize_text_field($_POST['stripe_token']) : '';
        $payment_intent_id = '';
        
        if ($stripe_token && class_exists('PTP_Stripe')) {
            $stripe_result = PTP_Stripe::charge($stripe_token, $total, array(
                'trainer_id' => $trainer_id,
                'customer_email' => $email,
                'package_type' => $package_type
            ));
            
            if (is_wp_error($stripe_result)) {
                wp_send_json_error(array('message' => $stripe_result->get_error_message()));
            }
            
            $payment_intent_id = $stripe_result['id'] ?? '';
        }
        
        // Create lesson pack
        $pack_data = array(
            'customer_id' => $user_id,
            'trainer_id' => $trainer_id,
            'pack_type' => $package_type,
            'total_sessions' => $sessions,
            'sessions_used' => 0,
            'sessions_remaining' => $sessions,
            'price_paid' => $total,
            'price_per_session' => $total / $sessions,
            'athlete_name' => sanitize_text_field($_POST['athlete_name']),
            'athlete_age' => intval($_POST['athlete_age']),
            'athlete_skill_level' => sanitize_text_field($_POST['skill_level'] ?? 'beginner'),
            'athlete_goals' => sanitize_textarea_field($_POST['goals'] ?? ''),
            'status' => 'active',
            'payment_status' => $stripe_token ? 'paid' : 'pending',
            'stripe_payment_intent_id' => $payment_intent_id,
            'expires_at' => date('Y-m-d H:i:s', strtotime('+6 months')),
            'created_at' => current_time('mysql')
        );
        
        $wpdb->insert("{$wpdb->prefix}ptp_lesson_packs", $pack_data);
        $pack_id = $wpdb->insert_id;
        
        if (!$pack_id) {
            wp_send_json_error(array('message' => 'Error creating booking.'));
        }
        
        // Create placeholder sessions
        for ($i = 0; $i < $sessions; $i++) {
            $wpdb->insert("{$wpdb->prefix}ptp_sessions", array(
                'pack_id' => $pack_id,
                'trainer_id' => $trainer_id,
                'customer_id' => $user_id,
                'player_name' => sanitize_text_field($_POST['athlete_name']),
                'player_age' => intval($_POST['athlete_age']),
                'session_date' => '0000-00-00',
                'start_time' => '00:00:00',
                'end_time' => '00:00:00',
                'session_status' => 'unscheduled',
                'payment_status' => $stripe_token ? 'paid' : 'pending',
                'created_at' => current_time('mysql')
            ));
        }
        
        // Notify via PTP Communications Hub
        $this->notify_comm_hub('new_booking', array(
            'pack_id' => $pack_id,
            'trainer_id' => $trainer_id,
            'trainer_name' => $trainer->display_name,
            'customer_name' => sanitize_text_field($_POST['first_name'] . ' ' . $_POST['last_name']),
            'customer_email' => $email,
            'customer_phone' => sanitize_text_field($_POST['phone']),
            'athlete_name' => sanitize_text_field($_POST['athlete_name']),
            'sessions' => $sessions,
            'total' => $total
        ));
        
        // Send confirmation email
        $subject = 'Training Package Confirmed - ' . $trainer->display_name;
        $message = "Hi " . sanitize_text_field($_POST['first_name']) . ",\n\n";
        $message .= "Your training package with " . $trainer->display_name . " has been confirmed!\n\n";
        $message .= "Package Details:\n";
        $message .= "- Sessions: " . $sessions . "\n";
        $message .= "- Athlete: " . sanitize_text_field($_POST['athlete_name']) . "\n";
        $message .= "- Total: $" . number_format($total, 2) . "\n\n";
        $message .= "Visit your dashboard to schedule: " . home_url('/my-training/') . "\n\n";
        $message .= "See you on the field!\nThe PTP Team";
        
        wp_mail($email, $subject, $message);
        
        // Notify admin
        $admin_email = get_option('ptp_admin_email', get_option('admin_email'));
        $admin_subject = 'New Training Package - ' . sanitize_text_field($_POST['athlete_name']);
        $admin_message = "A new training package has been purchased.\n\n";
        $admin_message .= "Customer: " . sanitize_text_field($_POST['first_name'] . ' ' . $_POST['last_name']) . "\n";
        $admin_message .= "Trainer: " . $trainer->display_name . "\n";
        $admin_message .= "Package: " . $package_type . " (" . $sessions . " sessions)\n";
        $admin_message .= "Total: $" . number_format($total, 2) . "\n\n";
        $admin_message .= "View in admin: " . admin_url('admin.php?page=ptp-training-packs');
        
        wp_mail($admin_email, $admin_subject, $admin_message);
        
        // Notify trainer
        if ($trainer->user_id) {
            $trainer_user = get_userdata($trainer->user_id);
            if ($trainer_user) {
                $trainer_subject = 'New Training Package Sold!';
                $trainer_message = "Congratulations!\n\n";
                $trainer_message .= "A new training package has been purchased:\n";
                $trainer_message .= "- Athlete: " . sanitize_text_field($_POST['athlete_name']) . "\n";
                $trainer_message .= "- Sessions: " . $sessions . "\n\n";
                $trainer_message .= "Log in to your dashboard: " . home_url('/trainer-dashboard/');
                
                wp_mail($trainer_user->user_email, $trainer_subject, $trainer_message);
            }
        }
        
        wp_send_json_success(array(
            'message' => 'Booking confirmed!',
            'pack_id' => $pack_id,
            'redirect' => home_url('/my-training/?booking=success')
        ));
    }
    
    /**
     * Handle trainer response to session request
     */
    public function handle_session_response() {
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ptp_session_response')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in to continue.'));
        }
        
        $session_id = intval($_POST['session_id'] ?? 0);
        $response = sanitize_text_field($_POST['response'] ?? '');
        
        if (!$session_id || !in_array($response, array('confirm', 'decline'))) {
            wp_send_json_error(array('message' => 'Invalid request.'));
        }
        
        global $wpdb;
        $current_user = wp_get_current_user();
        
        // Verify trainer owns this session
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT s.*, t.user_id as trainer_user_id 
             FROM {$wpdb->prefix}ptp_sessions s
             JOIN {$wpdb->prefix}ptp_trainers t ON s.trainer_id = t.id
             WHERE s.id = %d",
            $session_id
        ));
        
        if (!$session || $session->trainer_user_id != $current_user->ID) {
            wp_send_json_error(array('message' => 'You do not have permission to manage this session.'));
        }
        
        $new_status = ($response === 'confirm') ? 'confirmed' : 'cancelled';
        
        $wpdb->update(
            "{$wpdb->prefix}ptp_sessions",
            array(
                'session_status' => $new_status,
                'updated_at' => current_time('mysql')
            ),
            array('id' => $session_id)
        );
        
        // Notify customer
        if ($session->customer_id) {
            $customer = get_userdata($session->customer_id);
            if ($customer) {
                $subject = ($response === 'confirm') ? 'Training Session Confirmed!' : 'Training Session Update';
                $message = "Hi,\n\n";
                if ($response === 'confirm') {
                    $message .= "Great news! Your training session request has been confirmed.\n\n";
                    $message .= "View your dashboard for details: " . home_url('/my-training/');
                } else {
                    $message .= "Unfortunately, the trainer was unable to accommodate your session request.\n\n";
                    $message .= "Please select a different time or trainer: " . home_url('/find-trainers/');
                }
                wp_mail($customer->user_email, $subject, $message);
            }
        }
        
        // Notify via PTP Communications Hub
        $this->notify_comm_hub('session_response', array(
            'session_id' => $session_id,
            'response' => $response,
            'trainer_id' => $session->trainer_id
        ));
        
        wp_send_json_success(array(
            'message' => ($response === 'confirm') ? 'Session confirmed!' : 'Session declined.'
        ));
    }
    
    /**
     * Handle review submission
     */
    public function handle_add_review() {
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ptp_add_review')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in to leave a review.'));
        }
        
        $trainer_id = intval($_POST['trainer_id'] ?? 0);
        $rating = intval($_POST['rating'] ?? 5);
        $review_text = sanitize_textarea_field($_POST['review_text'] ?? '');
        
        if (!$trainer_id || $rating < 1 || $rating > 5 || empty($review_text)) {
            wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        }
        
        $current_user = wp_get_current_user();
        
        global $wpdb;
        
        // Check if user has had a session with this trainer
        $has_session = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_sessions 
             WHERE trainer_id = %d AND customer_id = %d AND session_status = 'completed'",
            $trainer_id, $current_user->ID
        ));
        
        // Insert review
        $wpdb->insert("{$wpdb->prefix}ptp_reviews", array(
            'trainer_id' => $trainer_id,
            'customer_id' => $current_user->ID,
            'reviewer_name' => $current_user->display_name,
            'rating' => $rating,
            'review_text' => $review_text,
            'status' => $has_session ? 'published' : 'pending',
            'created_at' => current_time('mysql')
        ));
        
        $review_id = $wpdb->insert_id;
        
        // Update trainer's average rating
        $this->update_trainer_rating($trainer_id);
        
        // Notify via PTP Communications Hub
        $this->notify_comm_hub('review_submitted', array(
            'review_id' => $review_id,
            'trainer_id' => $trainer_id,
            'rating' => $rating,
            'reviewer_name' => $current_user->display_name
        ));
        
        wp_send_json_success(array(
            'message' => $has_session ? 'Thank you for your review!' : 'Thank you! Your review will be published after verification.',
            'review_id' => $review_id
        ));
    }
    
    /**
     * Update trainer's average rating
     */
    private function update_trainer_rating($trainer_id) {
        global $wpdb;
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT AVG(rating) as avg_rating, COUNT(*) as total_reviews 
             FROM {$wpdb->prefix}ptp_reviews 
             WHERE trainer_id = %d AND status = 'published'",
            $trainer_id
        ));
        
        $wpdb->update(
            "{$wpdb->prefix}ptp_trainers",
            array(
                'avg_rating' => round($stats->avg_rating, 2),
                'total_reviews' => $stats->total_reviews
            ),
            array('id' => $trainer_id)
        );
    }
    
    /**
     * Handle session scheduling
     */
    public function handle_schedule_session() {
        if (!wp_verify_nonce($_POST['_wpnonce'] ?? '', 'ptp_schedule_session')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in to continue.'));
        }
        
        $session_id = intval($_POST['session_id'] ?? 0);
        $session_date = sanitize_text_field($_POST['session_date'] ?? '');
        $start_time = sanitize_text_field($_POST['start_time'] ?? '');
        $location = sanitize_text_field($_POST['location'] ?? '');
        
        if (!$session_id || empty($session_date) || empty($start_time)) {
            wp_send_json_error(array('message' => 'Please fill in all required fields.'));
        }
        
        global $wpdb;
        $current_user = wp_get_current_user();
        
        // Verify user owns this session
        $session = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_sessions WHERE id = %d AND customer_id = %d",
            $session_id, $current_user->ID
        ));
        
        if (!$session) {
            wp_send_json_error(array('message' => 'You do not have permission to schedule this session.'));
        }
        
        $end_time = date('H:i:s', strtotime($start_time) + 3600);
        
        $wpdb->update(
            "{$wpdb->prefix}ptp_sessions",
            array(
                'session_date' => $session_date,
                'start_time' => $start_time,
                'end_time' => $end_time,
                'location_text' => $location,
                'session_status' => 'requested',
                'updated_at' => current_time('mysql')
            ),
            array('id' => $session_id)
        );
        
        // Notify trainer
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT t.*, u.user_email 
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.id = %d",
            $session->trainer_id
        ));
        
        if ($trainer && $trainer->user_email) {
            $subject = 'New Session Scheduling Request';
            $message = "A customer has requested to schedule a training session.\n\n";
            $message .= "Date: " . date('l, F j, Y', strtotime($session_date)) . "\n";
            $message .= "Time: " . date('g:i A', strtotime($start_time)) . "\n";
            $message .= "Location: " . $location . "\n\n";
            $message .= "View in your dashboard: " . home_url('/trainer-dashboard/');
            
            wp_mail($trainer->user_email, $subject, $message);
        }
        
        // Notify via PTP Communications Hub
        $this->notify_comm_hub('session_scheduled', array(
            'session_id' => $session_id,
            'trainer_id' => $session->trainer_id,
            'date' => $session_date,
            'time' => $start_time,
            'location' => $location
        ));
        
        wp_send_json_success(array(
            'message' => 'Session request submitted! The trainer will confirm shortly.'
        ));
    }
    
    /**
     * Handle trainer profile update
     */
    public function handle_update_trainer_profile() {
        if (!wp_verify_nonce($_POST['profile_nonce'] ?? '', 'ptp_update_profile')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
        }
        
        if (!is_user_logged_in()) {
            wp_send_json_error(array('message' => 'Please log in to continue.'));
        }
        
        $trainer_id = intval($_POST['trainer_id'] ?? 0);
        
        global $wpdb;
        $current_user = wp_get_current_user();
        
        // Verify this trainer belongs to current user
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d AND user_id = %d",
            $trainer_id, $current_user->ID
        ));
        
        if (!$trainer) {
            wp_send_json_error(array('message' => 'You do not have permission to edit this profile.'));
        }
        
        // Sanitize inputs
        $update_data = array(
            'display_name' => sanitize_text_field($_POST['display_name'] ?? $trainer->display_name),
            'profile_photo' => esc_url_raw($_POST['profile_photo'] ?? ''),
            'bio' => sanitize_textarea_field($_POST['bio'] ?? ''),
            'hourly_rate' => max(25, min(500, floatval($_POST['hourly_rate'] ?? 75))),
            'primary_location_city' => sanitize_text_field($_POST['primary_location_city'] ?? ''),
            'primary_location_state' => sanitize_text_field($_POST['primary_location_state'] ?? ''),
            'specialties' => sanitize_text_field($_POST['specialties'] ?? ''),
            'intro_video_url' => esc_url_raw($_POST['intro_video_url'] ?? ''),
            'updated_at' => current_time('mysql')
        );
        
        $result = $wpdb->update(
            "{$wpdb->prefix}ptp_trainers",
            $update_data,
            array('id' => $trainer_id)
        );
        
        if ($result === false) {
            wp_send_json_error(array('message' => 'Error updating profile. Please try again.'));
        }
        
        // Also update WP user display name
        wp_update_user(array(
            'ID' => $current_user->ID,
            'display_name' => $update_data['display_name']
        ));
        
        wp_send_json_success(array(
            'message' => 'Profile updated successfully!'
        ));
    }
}

function ptp_training_pro() {
    return PTP_Training_Pro::instance();
}

add_action('plugins_loaded', 'ptp_training_pro');
