<?php
/**
 * PTP Camps Cross-Sell Component v1.0.0
 * 
 * Reusable component to display camps & clinics cross-selling
 * Used on trainer profiles, checkout, and thank you pages
 * 
 * Mobile-optimized with horizontal scroll on small screens
 */

defined('ABSPATH') || exit;

/**
 * Render the camps cross-sell section
 * 
 * @param array $options Configuration options
 *   - 'limit' => Number of camps to show (default: 6)
 *   - 'title' => Section title (default: 'Camps & Clinics')
 *   - 'subtitle' => Section subtitle
 *   - 'style' => 'grid' or 'carousel' (default: 'grid')
 *   - 'show_view_all' => true/false (default: true)
 *   - 'context' => 'profile', 'checkout', 'thankyou' for analytics
 *   - 'exclude_ids' => Array of product IDs to exclude
 */
function ptp_render_camps_crosssell($options = array()) {
    // Check WooCommerce
    if (!function_exists('wc_get_products')) {
        return;
    }
    
    $defaults = array(
        'limit' => 6,
        'title' => 'Camps & Clinics',
        'subtitle' => 'Level up with our group training programs',
        'style' => 'grid',
        'show_view_all' => true,
        'context' => 'general',
        'exclude_ids' => array(),
    );
    $opts = array_merge($defaults, $options);
    
    // Get camps & clinics
    $camps = ptp_get_camps_clinics($opts['limit'], $opts['exclude_ids']);
    
    if (empty($camps)) {
        return;
    }
    
    $shop_url = wc_get_page_permalink('shop');
    ?>
    
    <style>
    /* Camps Cross-Sell Component */
    .ptp-camps-crosssell {
        background: #0A0A0A;
        padding: 32px 12px;
        font-family: 'Inter', -apple-system, sans-serif;
    }
    
    .ptp-camps-inner {
        max-width: 1200px;
        margin: 0 auto;
    }
    
    .ptp-camps-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-end;
        margin-bottom: 16px;
        gap: 12px;
    }
    
    .ptp-camps-title {
        font-family: 'Oswald', sans-serif;
        font-size: 22px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        color: #fff;
        margin: 0 0 2px;
        line-height: 1.1;
    }
    
    .ptp-camps-subtitle {
        font-size: 13px;
        color: #9CA3AF;
        margin: 0;
    }
    
    .ptp-camps-viewall {
        display: flex;
        align-items: center;
        gap: 4px;
        font-family: 'Oswald', sans-serif;
        font-size: 13px;
        font-weight: 700;
        color: #FCB900;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        white-space: nowrap;
        transition: all 0.2s;
    }
    
    .ptp-camps-viewall:hover {
        color: #fff;
    }
    
    .ptp-camps-viewall svg {
        transition: transform 0.2s;
        width: 14px;
        height: 14px;
    }
    
    .ptp-camps-viewall:hover svg {
        transform: translateX(3px);
    }
    
    /* Grid Layout */
    .ptp-camps-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
        gap: 12px;
    }
    
    /* Carousel Layout (Mobile) */
    .ptp-camps-carousel {
        display: flex;
        gap: 12px;
        overflow-x: auto;
        scroll-snap-type: x mandatory;
        -webkit-overflow-scrolling: touch;
        scrollbar-width: none;
        -ms-overflow-style: none;
        padding-bottom: 6px;
        margin: 0 -12px;
        padding-left: 12px;
        padding-right: 12px;
    }
    
    .ptp-camps-carousel::-webkit-scrollbar {
        display: none;
    }
    
    .ptp-camps-carousel .ptp-camp-card {
        flex: 0 0 220px;
        scroll-snap-align: start;
    }
    
    /* Camp Card */
    .ptp-camp-card {
        background: #fff;
        border-radius: 10px;
        overflow: hidden;
        text-decoration: none;
        color: inherit;
        display: flex;
        flex-direction: column;
        transition: all 0.15s;
        position: relative;
    }
    
    .ptp-camp-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
    }
    
    .ptp-camp-card:active {
        transform: translateY(-1px);
    }
    
    /* Card Image */
    .ptp-camp-image {
        position: relative;
        width: 100%;
        height: 120px;
        overflow: hidden;
    }
    
    .ptp-camp-image img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.3s;
    }
    
    .ptp-camp-card:hover .ptp-camp-image img {
        transform: scale(1.05);
    }
    
    /* Sale Badge */
    .ptp-camp-badge {
        position: absolute;
        top: 12px;
        right: 8px;
        background: #DC2626;
        color: #fff;
        font-family: 'Oswald', sans-serif;
        font-size: 10px;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 3px;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }
    
    .ptp-camp-badge.new {
        background: #10B981;
    }
    
    .ptp-camp-badge.sold-out {
        background: #6B7280;
    }
    
    /* Sold Out Card */
    .ptp-camp-card.sold-out {
        opacity: 0.7;
    }
    .ptp-camp-card.sold-out .ptp-camp-image img {
        filter: grayscale(50%);
    }
    
    /* Waitlist Button */
    .ptp-camp-waitlist {
        background: #0A0A0A;
        color: #FCB900;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 700;
        cursor: pointer;
        text-transform: uppercase;
    }
    .ptp-camp-waitlist:hover {
        background: #FCB900;
        color: #0A0A0A;
    }
    
    /* Waitlist Modal */
    .ptp-waitlist-modal {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.8);
        z-index: 99999;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .ptp-waitlist-content {
        background: #fff;
        border-radius: 16px;
        padding: 32px;
        max-width: 400px;
        width: 90%;
        position: relative;
        text-align: center;
    }
    .ptp-waitlist-close {
        position: absolute;
        top: 12px;
        right: 16px;
        background: none;
        border: none;
        font-size: 24px;
        color: #9CA3AF;
        cursor: pointer;
    }
    .ptp-waitlist-content h3 {
        margin: 0 0 8px;
        font-size: 22px;
    }
    .ptp-waitlist-content p {
        margin: 0 0 20px;
        color: #6B7280;
    }
    #waitlist-form {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }
    #waitlist-form input {
        padding: 14px;
        border: 2px solid #E5E7EB;
        border-radius: 8px;
        font-size: 16px;
    }
    #waitlist-form button {
        padding: 14px;
        background: #FCB900;
        color: #0A0A0A;
        border: none;
        border-radius: 8px;
        font-weight: 700;
        font-size: 16px;
        cursor: pointer;
    }
    .ptp-waitlist-note {
        font-size: 13px !important;
        margin-top: 16px !important;
    }
    
    /* Trainer Badge */
    .ptp-camp-trainer-badge {
        position: absolute;
        bottom: 8px;
        left: 8px;
        display: flex;
        align-items: center;
        gap: 6px;
        background: rgba(0, 0, 0, 0.8);
        backdrop-filter: blur(4px);
        -webkit-backdrop-filter: blur(4px);
        padding: 4px 8px;
        border-radius: 16px;
    }
    
    .ptp-camp-trainer-badge img {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: 2px solid #FCB900;
        object-fit: cover;
    }
    
    .ptp-camp-trainer-badge span {
        font-size: 11px;
        font-weight: 600;
        color: #fff;
    }
    
    /* Card Body */
    .ptp-camp-body {
        padding: 10px 12px 12px;
        flex: 1;
        display: flex;
        flex-direction: column;
    }
    
    .ptp-camp-name {
        font-family: 'Oswald', sans-serif;
        font-size: 13px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        color: #0A0A0A;
        margin: 0 0 6px;
        line-height: 1.2;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    
    .ptp-camp-meta {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        margin-bottom: 8px;
        font-size: 11px;
        color: #6B7280;
    }
    
    .ptp-camp-meta-item {
        display: flex;
        align-items: center;
        gap: 3px;
    }
    
    .ptp-camp-meta-item svg {
        width: 12px;
        height: 12px;
        flex-shrink: 0;
    }
    
    /* Price Row */
    .ptp-camp-price-row {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-top: auto;
    }
    
    .ptp-camp-price {
        font-family: 'Oswald', sans-serif;
        font-size: 18px;
        font-weight: 900;
        color: #0A0A0A;
    }
    
    .ptp-camp-price-old {
        font-size: 12px;
        color: #9CA3AF;
        text-decoration: line-through;
    }
    
    .ptp-camp-spots {
        margin-left: auto;
        font-size: 10px;
        font-weight: 600;
        color: #DC2626;
        background: #FEE2E2;
        padding: 3px 6px;
        border-radius: 3px;
    }
    
    /* Mobile Responsive */
    @media (max-width: 768px) {
        .ptp-camps-crosssell {
            padding: 28px 0;
        }
        
        .ptp-camps-header {
            padding: 0 12px;
            flex-direction: column;
            align-items: flex-start;
        }
        
        .ptp-camps-title {
            font-size: 20px;
        }
        
        /* Force carousel on mobile */
        .ptp-camps-grid {
            display: flex;
            gap: 10px;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: none;
            padding: 0 12px;
        }
        
        .ptp-camps-grid::-webkit-scrollbar {
            display: none;
        }
        
        .ptp-camps-grid .ptp-camp-card {
            flex: 0 0 200px;
            scroll-snap-align: start;
        }
        
        .ptp-camp-image {
            height: 100px;
        }
        
        .ptp-camp-body {
            padding: 10px;
        }
        
        .ptp-camp-name {
            font-size: 12px;
        }
    }
    
    @media (max-width: 480px) {
        .ptp-camps-grid .ptp-camp-card {
            flex: 0 0 180px;
        }
    }
    
    /* Scroll Indicator (Mobile) */
    .ptp-camps-scroll-hint {
        display: none;
        justify-content: center;
        gap: 5px;
        margin-top: 12px;
        padding: 0 12px;
    }
    
    .ptp-camps-scroll-hint span {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: rgba(255, 255, 255, 0.3);
        transition: all 0.2s;
    }
    
    .ptp-camps-scroll-hint span.active {
        background: #FCB900;
        width: 18px;
        border-radius: 3px;
    }
    
    @media (max-width: 768px) {
        .ptp-camps-scroll-hint {
            display: flex;
        }
    }
    </style>
    
    <div class="ptp-camps-crosssell" data-context="<?php echo esc_attr($opts['context']); ?>">
        <div class="ptp-camps-inner">
            <div class="ptp-camps-header">
                <div>
                    <h2 class="ptp-camps-title"><?php echo esc_html($opts['title']); ?></h2>
                    <?php if ($opts['subtitle']): ?>
                    <p class="ptp-camps-subtitle"><?php echo esc_html($opts['subtitle']); ?></p>
                    <?php endif; ?>
                </div>
                
                <?php if ($opts['show_view_all'] && $shop_url): ?>
                <a href="<?php echo esc_url($shop_url); ?>" class="ptp-camps-viewall">
                    View All
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                        <polyline points="9 18 15 12 9 6"/>
                    </svg>
                </a>
                <?php endif; ?>
            </div>
            
            <div class="ptp-camps-<?php echo esc_attr($opts['style']); ?>">
                <?php foreach ($camps as $product): 
                    $image_id = $product->get_image_id();
                    $image_url = $image_id ? wp_get_attachment_image_url($image_id, 'medium_large') : wc_placeholder_img_src('medium_large');
                    $price = $product->get_price();
                    $regular_price = $product->get_regular_price();
                    $on_sale = $product->is_on_sale();
                    
                    // Extract date from title, short description, or meta
                    $camp_date = ptp_extract_camp_date($product);
                    
                    // Extract location
                    $camp_location = ptp_extract_camp_location($product);
                    
                    // Get trainer info if available
                    $trainer_name = get_post_meta($product->get_id(), '_ptp_trainer_name', true);
                    $trainer_photo = get_post_meta($product->get_id(), '_ptp_trainer_photo', true);
                    
                    // Check if product is recent (within 14 days)
                    $post_date = get_post_time('U', false, $product->get_id());
                    $is_new = (time() - $post_date) < (14 * 24 * 60 * 60);
                    
                    // Stock status
                    $stock_status = $product->get_stock_status();
                    $stock_qty = $product->get_stock_quantity();
                    $low_stock = $stock_qty !== null && $stock_qty > 0 && $stock_qty <= 5;
                    $sold_out = $stock_status === 'outofstock' || ($stock_qty !== null && $stock_qty <= 0);
                ?>
                <a href="<?php echo esc_url($product->get_permalink()); ?>" class="ptp-camp-card <?php echo $sold_out ? 'sold-out' : ''; ?>" data-product-id="<?php echo $product->get_id(); ?>">
                    <div class="ptp-camp-image">
                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($product->get_name()); ?>" loading="lazy">
                        
                        <?php if ($on_sale): ?>
                        <span class="ptp-camp-badge">Sale</span>
                        <?php elseif ($sold_out): ?>
                        <span class="ptp-camp-badge sold-out">Sold Out</span>
                        <?php elseif ($is_new): ?>
                        <span class="ptp-camp-badge new">New</span>
                        <?php endif; ?>
                        
                        <?php if ($trainer_name && $trainer_photo): ?>
                        <div class="ptp-camp-trainer-badge">
                            <img src="<?php echo esc_url($trainer_photo); ?>" alt="">
                            <span><?php echo esc_html($trainer_name); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="ptp-camp-body">
                        <h3 class="ptp-camp-name"><?php echo esc_html($product->get_name()); ?></h3>
                        
                        <div class="ptp-camp-meta">
                            <?php if ($camp_date): ?>
                            <span class="ptp-camp-meta-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
                                    <line x1="16" y1="2" x2="16" y2="6"/>
                                    <line x1="8" y1="2" x2="8" y2="6"/>
                                    <line x1="3" y1="10" x2="21" y2="10"/>
                                </svg>
                                <?php echo esc_html($camp_date); ?>
                            </span>
                            <?php endif; ?>
                            
                            <?php if ($camp_location): ?>
                            <span class="ptp-camp-meta-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
                                    <circle cx="12" cy="10" r="3"/>
                                </svg>
                                <?php echo esc_html($camp_location); ?>
                            </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="ptp-camp-price-row">
                            <span class="ptp-camp-price">$<?php echo number_format($price, 0); ?></span>
                            <?php if ($on_sale && $regular_price): ?>
                            <span class="ptp-camp-price-old">$<?php echo number_format($regular_price, 0); ?></span>
                            <?php endif; ?>
                            
                            <?php if ($low_stock): ?>
                            <span class="ptp-camp-spots"><?php echo $stock_qty; ?> spots left</span>
                            <?php elseif ($sold_out): ?>
                            <button type="button" class="ptp-camp-waitlist" onclick="event.preventDefault();openWaitlist(<?php echo $product->get_id(); ?>,'<?php echo esc_js($product->get_name()); ?>')">Join Waitlist</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
            
            <!-- Waitlist Modal -->
            <div class="ptp-waitlist-modal" id="waitlist-modal" style="display:none">
                <div class="ptp-waitlist-content">
                    <button class="ptp-waitlist-close" onclick="closeWaitlist()">&times;</button>
                    <h3>🔔 Join the Waitlist</h3>
                    <p id="waitlist-camp-name"></p>
                    <form id="waitlist-form" onsubmit="submitWaitlist(event)">
                        <input type="hidden" id="waitlist-product-id" value="">
                        <input type="email" id="waitlist-email" placeholder="Your email" required>
                        <input type="tel" id="waitlist-phone" placeholder="Phone (optional)">
                        <button type="submit">Notify Me</button>
                    </form>
                    <p class="ptp-waitlist-note">We'll email you when a spot opens up!</p>
                </div>
            </div>
            
            <!-- Scroll Indicator -->
            <div class="ptp-camps-scroll-hint" id="camps-scroll-hint">
                <?php for ($i = 0; $i < min(count($camps), 6); $i++): ?>
                <span <?php echo $i === 0 ? 'class="active"' : ''; ?>></span>
                <?php endfor; ?>
            </div>
        </div>
    </div>
    
    <script>
    (function() {
        // Scroll indicator
        var container = document.querySelector('.ptp-camps-grid, .ptp-camps-carousel');
        var hints = document.querySelectorAll('#camps-scroll-hint span');
        
        if (container && hints.length > 1) {
            container.addEventListener('scroll', function() {
                var scrollLeft = container.scrollLeft;
                var cardWidth = container.querySelector('.ptp-camp-card')?.offsetWidth || 260;
                var gap = 16;
                var index = Math.round(scrollLeft / (cardWidth + gap));
                
                hints.forEach(function(hint, i) {
                    hint.classList.toggle('active', i === index);
                });
            });
        }
        
        // Track clicks for analytics
        document.querySelectorAll('.ptp-camp-card').forEach(function(card) {
            card.addEventListener('click', function() {
                var context = card.closest('.ptp-camps-crosssell')?.dataset.context || 'unknown';
                var productId = card.dataset.productId;
                
                // Track with Google Analytics if available
                if (typeof gtag === 'function') {
                    gtag('event', 'view_item', {
                        currency: 'USD',
                        items: [{
                            item_id: productId,
                            item_category: 'camp_crosssell',
                            item_list_name: context
                        }]
                    });
                }
            });
        });
        
        // Waitlist functions
        window.openWaitlist = function(productId, productName) {
            document.getElementById('waitlist-product-id').value = productId;
            document.getElementById('waitlist-camp-name').textContent = productName;
            document.getElementById('waitlist-modal').style.display = 'flex';
        };
        
        window.closeWaitlist = function() {
            document.getElementById('waitlist-modal').style.display = 'none';
        };
        
        window.submitWaitlist = function(e) {
            e.preventDefault();
            var productId = document.getElementById('waitlist-product-id').value;
            var email = document.getElementById('waitlist-email').value;
            var phone = document.getElementById('waitlist-phone').value;
            
            fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=ptp_add_to_waitlist&product_id=' + productId + '&email=' + encodeURIComponent(email) + '&phone=' + encodeURIComponent(phone)
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                if (data.success) {
                    document.getElementById('waitlist-form').innerHTML = '<p style="color:#10B981;font-weight:600">✓ ' + data.data.message + '</p>';
                    setTimeout(closeWaitlist, 2000);
                } else {
                    alert(data.data || 'Error joining waitlist');
                }
            });
        };
        
        // Close modal on backdrop click
        document.getElementById('waitlist-modal')?.addEventListener('click', function(e) {
            if (e.target === this) closeWaitlist();
        });
    })();
    </script>
    <?php
}

/**
 * Get camps and clinics products
 */
function ptp_get_camps_clinics($limit = 6, $exclude_ids = array()) {
    $camps = array();
    
    // Try category-based query first
    $args = array(
        'status' => 'publish',
        'limit' => $limit,
        'category' => array('camps', 'clinics', 'camp', 'clinic', 'winter-clinics', 'summer-camps'),
        'orderby' => 'date',
        'order' => 'DESC',
        'exclude' => $exclude_ids,
    );
    
    $camps = wc_get_products($args);
    
    // If no category results, try title-based search
    if (empty($camps)) {
        $all_products = wc_get_products(array(
            'status' => 'publish',
            'limit' => 30,
            'orderby' => 'date',
            'order' => 'DESC',
            'exclude' => $exclude_ids,
        ));
        
        foreach ($all_products as $product) {
            $title_lower = strtolower($product->get_name());
            $cats = wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'slugs'));
            
            $is_camp = strpos($title_lower, 'camp') !== false 
                    || strpos($title_lower, 'clinic') !== false
                    || array_intersect($cats, array('camps', 'clinics', 'camp', 'clinic'));
            
            if ($is_camp) {
                $camps[] = $product;
            }
            
            if (count($camps) >= $limit) break;
        }
    }
    
    return $camps;
}

/**
 * Extract date from product
 */
function ptp_extract_camp_date($product) {
    // Check custom meta field first
    $date = get_post_meta($product->get_id(), '_event_date', true);
    if ($date) {
        return date('M j', strtotime($date));
    }
    
    // Check product attributes
    $attributes = $product->get_attributes();
    if (isset($attributes['date']) || isset($attributes['pa_date'])) {
        $attr = $attributes['date'] ?? $attributes['pa_date'];
        if (is_object($attr) && method_exists($attr, 'get_options')) {
            $options = $attr->get_options();
            if (!empty($options)) {
                return is_array($options) ? reset($options) : $options;
            }
        }
    }
    
    // Try to extract from title
    $title = $product->get_name();
    if (preg_match('/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s*\d{1,2}(?:st|nd|rd|th)?/i', $title, $match)) {
        return $match[0];
    }
    
    // Try short description
    $desc = $product->get_short_description();
    if (preg_match('/\b(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s*\d{1,2}(?:st|nd|rd|th)?/i', $desc, $match)) {
        return $match[0];
    }
    
    return '';
}

/**
 * Extract location from product
 */
function ptp_extract_camp_location($product) {
    // Check custom meta field
    $location = get_post_meta($product->get_id(), '_event_location', true);
    if ($location) {
        // Shorten long locations
        if (strlen($location) > 25) {
            $parts = explode(',', $location);
            return trim($parts[0]);
        }
        return $location;
    }
    
    // Check product attributes
    $attributes = $product->get_attributes();
    if (isset($attributes['location']) || isset($attributes['pa_location'])) {
        $attr = $attributes['location'] ?? $attributes['pa_location'];
        if (is_object($attr) && method_exists($attr, 'get_options')) {
            $options = $attr->get_options();
            if (!empty($options)) {
                $loc = is_array($options) ? reset($options) : $options;
                if (strlen($loc) > 25) {
                    $parts = explode(',', $loc);
                    return trim($parts[0]);
                }
                return $loc;
            }
        }
    }
    
    // Try to extract from title (common patterns)
    $title = $product->get_name();
    if (preg_match('/(?:at|@)\s+([^-|]+)/i', $title, $match)) {
        return trim($match[1]);
    }
    
    // Extract city/state patterns
    if (preg_match('/\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?),?\s*(?:PA|NJ|NY|MD|DE)\b/', $title, $match)) {
        return $match[0];
    }
    
    return '';
}

/**
 * Shortcode for displaying camps cross-sell
 */
add_shortcode('ptp_camps_crosssell', function($atts) {
    $atts = shortcode_atts(array(
        'limit' => 6,
        'title' => 'Camps & Clinics',
        'subtitle' => 'Level up with our group training programs',
        'style' => 'grid',
    ), $atts);
    
    ob_start();
    ptp_render_camps_crosssell($atts);
    return ob_get_clean();
});
