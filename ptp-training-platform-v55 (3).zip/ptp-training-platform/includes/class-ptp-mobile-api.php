<?php
/**
 * PTP Mobile API - Enterprise Grade
 * Complete REST API for iOS/Android mobile applications
 * 
 * @version 2.0.0
 * @package PTP_Training_Platform
 */

defined('ABSPATH') || exit;

class PTP_Mobile_API {
    
    const API_VERSION = '2.0.0';
    const NAMESPACE = 'ptp/v2';
    
    private static $instance = null;
    
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_filter('rest_pre_dispatch', array($this, 'add_cors_headers'), 10, 3);
    }
    
    /**
     * Add CORS headers for mobile apps
     */
    public function add_cors_headers($result, $server, $request) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type, X-PTP-App-Version, X-PTP-Device-ID, X-PTP-Platform');
        header('X-PTP-API-Version: ' . self::API_VERSION);
        return $result;
    }
    
    /**
     * Register all API routes
     */
    public function register_routes() {
        
        // ================================================================
        // HEALTH & CONFIG
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'health_check'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/config', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_config'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/config/bootstrap', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_bootstrap'),
            'permission_callback' => '__return_true',
        ));
        
        // ================================================================
        // AUTHENTICATION
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/auth/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'login'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/google', array(
            'methods' => 'POST',
            'callback' => array($this, 'google_login'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/apple', array(
            'methods' => 'POST',
            'callback' => array($this, 'apple_login'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/refresh', array(
            'methods' => 'POST',
            'callback' => array($this, 'refresh_token'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/forgot-password', array(
            'methods' => 'POST',
            'callback' => array($this, 'forgot_password'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/logout', array(
            'methods' => 'POST',
            'callback' => array($this, 'logout'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // USER / PROFILE
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/me', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_current_user'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_profile'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/avatar', array(
            'methods' => 'POST',
            'callback' => array($this, 'upload_avatar'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/password', array(
            'methods' => 'PUT',
            'callback' => array($this, 'change_password'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/notifications', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_notifications'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/notifications/(?P<id>\d+)/read', array(
            'methods' => 'POST',
            'callback' => array($this, 'mark_notification_read'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/device', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_device'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/device', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'unregister_device'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // PLAYERS (for parents)
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/players', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_players'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)/progress', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_player_progress'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // TRAINERS
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/trainers', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/nearby', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_nearby_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)/availability', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_availability'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)/reviews', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_reviews'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)/gallery', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_gallery'),
            'permission_callback' => '__return_true',
        ));
        
        // ================================================================
        // TRAINER PROFILE (for trainers)
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/trainer/profile', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_profile'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/profile', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_trainer_profile'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/availability', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_my_availability'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/availability', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_availability'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/earnings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_earnings'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_stats'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/stripe/connect', array(
            'methods' => 'POST',
            'callback' => array($this, 'connect_stripe'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/stripe/dashboard', array(
            'methods' => 'GET',
            'callback' => array($this, 'stripe_dashboard_link'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        // ================================================================
        // BOOKINGS
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/bookings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_bookings'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_booking'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_booking'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/confirm', array(
            'methods' => 'POST',
            'callback' => array($this, 'confirm_booking'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/cancel', array(
            'methods' => 'POST',
            'callback' => array($this, 'cancel_booking'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/complete', array(
            'methods' => 'POST',
            'callback' => array($this, 'complete_booking'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/notes', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_session_notes'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/review', array(
            'methods' => 'POST',
            'callback' => array($this, 'submit_review'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // CAMPS & PROGRAMS (WooCommerce Products)
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/camps', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/programs', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_programs'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/programs/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_programs'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/upcoming', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_upcoming_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/programs/upcoming', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_upcoming_programs'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/nearby', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_nearby_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/by-location', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camps_by_location'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camp_categories'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/programs/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_program_categories'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/programs/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_programs'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camp'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/programs/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_program'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/(?P<id>\d+)/availability', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camp_availability'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/(?P<id>\d+)/schedule', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camp_schedule'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/(?P<id>\d+)/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_for_camp'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/my-registrations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_my_camp_registrations'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // MESSAGING
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/conversations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_conversations'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/conversations/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_conversation'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/conversations/(?P<id>\d+)/messages', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_messages'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/conversations/(?P<id>\d+)/messages', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_message'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/messages/start', array(
            'methods' => 'POST',
            'callback' => array($this, 'start_conversation'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // PAYMENTS
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/payments/methods', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_payment_methods'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/payments/setup-intent', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_setup_intent'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/payments/methods', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_payment_method'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/payments/methods/(?P<id>[a-zA-Z0-9_]+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'remove_payment_method'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // FAVORITES
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/favorites', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_favorites'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/favorites/(?P<trainer_id>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_favorite'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/favorites/(?P<trainer_id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'remove_favorite'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // STATIC CONTENT
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/content/faq', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_faq'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/content/specialties', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_specialties'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/content/locations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_locations'),
            'permission_callback' => '__return_true',
        ));
    }
    
    // ================================================================
    // AUTH HELPERS
    // ================================================================
    
    public function check_auth($request) {
        $user = $this->get_user_from_token($request);
        return $user !== false;
    }
    
    public function check_trainer($request) {
        $user = $this->get_user_from_token($request);
        if (!$user) return false;
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d AND status = 'active'",
            $user->ID
        ));
        
        return !empty($trainer);
    }
    
    private function get_user_from_token($request) {
        $auth_header = $request->get_header('Authorization');
        
        if (empty($auth_header) || strpos($auth_header, 'Bearer ') !== 0) {
            return false;
        }
        
        $token = substr($auth_header, 7);
        
        // Use existing JWT validation from PTP_REST_API
        if (class_exists('PTP_REST_API')) {
            $api = new PTP_REST_API();
            if (method_exists($api, 'validate_token')) {
                return $api->validate_token($token);
            }
        }
        
        // Fallback: simple token validation
        global $wpdb;
        $user_id = $wpdb->get_var($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'ptp_auth_token' AND meta_value = %s",
            hash('sha256', $token)
        ));
        
        if ($user_id) {
            return get_user_by('ID', $user_id);
        }
        
        return false;
    }
    
    private function generate_token($user_id) {
        $token = bin2hex(random_bytes(32));
        $expires = time() + (30 * DAY_IN_SECONDS);
        
        update_user_meta($user_id, 'ptp_auth_token', hash('sha256', $token));
        update_user_meta($user_id, 'ptp_token_expires', $expires);
        
        return array(
            'access_token' => $token,
            'token_type' => 'Bearer',
            'expires_in' => 30 * DAY_IN_SECONDS,
            'expires_at' => date('c', $expires),
        );
    }
    
    // ================================================================
    // HEALTH & CONFIG ENDPOINTS
    // ================================================================
    
    public function health_check($request) {
        return rest_ensure_response(array(
            'status' => 'ok',
            'api_version' => self::API_VERSION,
            'wordpress_version' => get_bloginfo('version'),
            'plugin_version' => PTP_VERSION,
            'timestamp' => current_time('c'),
            'timezone' => wp_timezone_string(),
        ));
    }
    
    public function get_config($request) {
        $config = array(
            'api_version' => self::API_VERSION,
            'app' => array(
                'name' => get_option('ptp_app_name', 'PTP Training'),
                'tagline' => get_option('ptp_tagline', 'Players Teaching Players'),
                'min_version' => get_option('ptp_min_app_version', '1.0.0'),
                'current_version' => get_option('ptp_current_app_version', '1.0.0'),
                'force_update' => (bool) get_option('ptp_force_update', false),
                'update_message' => get_option('ptp_update_message', ''),
                'maintenance_mode' => (bool) get_option('ptp_maintenance_mode', false),
                'maintenance_message' => get_option('ptp_maintenance_message', ''),
            ),
            'theme' => array(
                'primary_color' => get_option('ptp_color_primary', '#FCB900'),
                'secondary_color' => get_option('ptp_color_secondary', '#0A0A0A'),
                'font_heading' => 'Oswald',
                'font_body' => 'Inter',
            ),
            'branding' => array(
                'logo' => get_option('ptp_logo_url', PTP_Images::LOGO),
                'logo_dark' => get_option('ptp_logo_dark_url', PTP_Images::LOGO),
                'app_icon' => get_option('ptp_app_icon_url', ''),
            ),
            'features' => array(
                'private_training' => true,
                'group_sessions' => (bool) get_option('ptp_feature_groups', true),
                'training_plans' => (bool) get_option('ptp_feature_training_plans', true),
                'camps_clinics' => (bool) get_option('ptp_feature_camps', true),
                'messaging' => true,
                'reviews' => true,
                'push_notifications' => (bool) get_option('ptp_push_enabled', false),
                'calendar_sync' => (bool) get_option('ptp_feature_calendar_sync', false),
                'google_login' => !empty(get_option('ptp_google_client_id')),
                'apple_login' => !empty(get_option('ptp_apple_client_id')),
            ),
            'social' => array(
                'instagram' => get_option('ptp_instagram', ''),
                'facebook' => get_option('ptp_facebook', ''),
                'twitter' => get_option('ptp_twitter', ''),
                'youtube' => get_option('ptp_youtube', ''),
                'tiktok' => get_option('ptp_tiktok', ''),
            ),
            'contact' => array(
                'email' => get_option('ptp_contact_email', 'info@ptptraining.com'),
                'support_email' => get_option('ptp_support_email', 'support@ptptraining.com'),
                'phone' => get_option('ptp_contact_phone', ''),
            ),
            'legal' => array(
                'terms_url' => get_option('ptp_terms_url', site_url('/terms')),
                'privacy_url' => get_option('ptp_privacy_url', site_url('/privacy')),
                'refund_url' => get_option('ptp_refund_url', ''),
            ),
            'payment' => array(
                'stripe_publishable_key' => get_option('ptp_stripe_publishable_key', ''),
                'platform_fee_percent' => floatval(get_option('ptp_platform_fee', 15)),
                'currency' => 'USD',
            ),
        );
        
        return rest_ensure_response($config);
    }
    
    public function get_bootstrap($request) {
        // Get everything needed to initialize the app in one call
        $user = $this->get_user_from_token($request);
        
        $bootstrap = array(
            'config' => $this->get_config($request)->get_data(),
            'onboarding' => get_option('ptp_onboarding_screens', array()),
            'specialties' => $this->get_specialties_list(),
            'locations' => $this->get_locations_list(),
            'featured_trainers' => $this->get_featured_trainers_data(6),
            'featured_camps' => $this->get_featured_camps_data(6),
        );
        
        if ($user) {
            $bootstrap['user'] = $this->format_user($user);
            $bootstrap['unread_notifications'] = PTP_Push_Notifications::get_unread_count($user->ID);
        }
        
        return rest_ensure_response($bootstrap);
    }
    
    // ================================================================
    // CAMPS ENDPOINTS - ALL WOOCOMMERCE PRODUCTS
    // ================================================================
    
    public function get_camps($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => intval($request->get_param('limit') ?: 50),
            'paged' => intval($request->get_param('page') ?: 1),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        // Filter by type
        $type = $request->get_param('type');
        if ($type) {
            $args['meta_query'][] = array(
                'key' => '_ptp_camp_type',
                'value' => $type,
            );
        }
        
        // Filter by state
        $state = $request->get_param('state');
        if ($state) {
            $args['meta_query'][] = array(
                'key' => '_ptp_state',
                'value' => $state,
            );
        }
        
        // Filter by age group
        $age_group = $request->get_param('age_group');
        if ($age_group) {
            $args['meta_query'][] = array(
                'key' => '_ptp_age_groups',
                'value' => $age_group,
                'compare' => 'LIKE',
            );
        }
        
        // Upcoming only
        if ($request->get_param('upcoming')) {
            $args['meta_query'][] = array(
                'key' => '_ptp_start_date',
                'value' => date('Y-m-d'),
                'compare' => '>=',
                'type' => 'DATE',
            );
        }
        
        // Category filter
        $category = $request->get_param('category');
        if ($category) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $category,
                ),
            );
        }
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camps[] = $this->format_camp($post->ID);
        }
        
        return rest_ensure_response(array(
            'camps' => $camps,
            'pagination' => array(
                'total' => $query->found_posts,
                'pages' => $query->max_num_pages,
                'page' => intval($request->get_param('page') ?: 1),
                'per_page' => intval($request->get_param('limit') ?: 50),
            ),
        ));
    }
    
    public function get_featured_camps($request) {
        $camps = wc_get_featured_product_ids();
        $result = array();
        
        foreach (array_slice($camps, 0, 10) as $id) {
            $result[] = $this->format_camp($id);
        }
        
        return rest_ensure_response($result);
    }
    
    public function get_upcoming_camps($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            'meta_query' => array(
                array(
                    'key' => '_ptp_start_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE',
                ),
            ),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camps[] = $this->format_camp($post->ID);
        }
        
        return rest_ensure_response($camps);
    }
    
    public function get_camp($request) {
        $id = intval($request->get_param('id'));
        $product = wc_get_product($id);
        
        if (!$product) {
            return new WP_Error('not_found', 'Camp not found', array('status' => 404));
        }
        
        return rest_ensure_response($this->format_camp($id, true));
    }
    
    private function format_camp($product_id, $full = false) {
        $product = wc_get_product($product_id);
        if (!$product) return null;
        
        $start_date = get_post_meta($product_id, '_ptp_start_date', true);
        $end_date = get_post_meta($product_id, '_ptp_end_date', true);
        $max_capacity = intval(get_post_meta($product_id, '_ptp_max_capacity', true));
        $sold_count = intval(get_post_meta($product_id, '_ptp_sold_count', true));
        
        // Get camp type - default to 'camp' if not set
        $camp_type = get_post_meta($product_id, '_ptp_camp_type', true);
        if (empty($camp_type)) {
            // Guess type from title
            $title_lower = strtolower($product->get_name());
            if (strpos($title_lower, 'clinic') !== false) {
                $camp_type = 'clinic';
            } elseif (strpos($title_lower, 'academy') !== false) {
                $camp_type = 'academy';
            } else {
                $camp_type = 'camp';
            }
        }
        
        $age_groups = get_post_meta($product_id, '_ptp_age_groups', true) ?: array();
        if (is_string($age_groups)) {
            $age_groups = json_decode($age_groups, true) ?: array();
        }
        
        $camp = array(
            'id' => $product_id,
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'type' => $camp_type,
            'price' => floatval($product->get_price()),
            'regular_price' => floatval($product->get_regular_price()),
            'sale_price' => $product->get_sale_price() ? floatval($product->get_sale_price()) : null,
            'on_sale' => $product->is_on_sale(),
            'currency' => 'USD',
            'start_date' => $start_date,
            'end_date' => $end_date ?: $start_date,
            'location' => array(
                'name' => get_post_meta($product_id, '_ptp_location_name', true) ?: '',
                'address' => get_post_meta($product_id, '_ptp_address', true) ?: '',
                'city' => get_post_meta($product_id, '_ptp_city', true) ?: '',
                'state' => get_post_meta($product_id, '_ptp_state', true) ?: '',
                'zip' => get_post_meta($product_id, '_ptp_zip', true) ?: '',
                'latitude' => floatval(get_post_meta($product_id, '_ptp_latitude', true)),
                'longitude' => floatval(get_post_meta($product_id, '_ptp_longitude', true)),
            ),
            'age_groups' => $age_groups,
            'capacity' => array(
                'max' => $max_capacity,
                'sold' => $sold_count,
                'available' => max(0, $max_capacity - $sold_count),
                'is_sold_out' => $max_capacity > 0 && $sold_count >= $max_capacity,
            ),
            'featured_image' => wp_get_attachment_url($product->get_image_id()) ?: PTP_Images::get_camp_photo($product_id),
            'is_featured' => $product->is_featured(),
            'status' => $product->get_status(),
            'url' => get_permalink($product_id),
        );
        
        // Add full details
        if ($full) {
            $skill_levels = get_post_meta($product_id, '_ptp_skill_levels', true) ?: array();
            if (is_string($skill_levels)) {
                $skill_levels = json_decode($skill_levels, true) ?: array();
            }
            
            $daily_times = get_post_meta($product_id, '_ptp_daily_times', true) ?: array();
            
            $camp['description'] = $product->get_description();
            $camp['short_description'] = $product->get_short_description();
            $camp['skill_levels'] = $skill_levels;
            $camp['daily_times'] = array(
                'start' => $daily_times['start'] ?? '09:00',
                'end' => $daily_times['end'] ?? '15:00',
            );
            $camp['what_to_bring'] = get_post_meta($product_id, '_ptp_what_to_bring', true) ?: '';
            $camp['included'] = get_post_meta($product_id, '_ptp_included', true) ?: '';
            $camp['contact'] = array(
                'email' => get_post_meta($product_id, '_ptp_contact_email', true) ?: '',
                'phone' => get_post_meta($product_id, '_ptp_contact_phone', true) ?: '',
            );
            
            // Gallery images
            $gallery_ids = $product->get_gallery_image_ids();
            $camp['gallery'] = array_map('wp_get_attachment_url', $gallery_ids);
            
            // Categories
            $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
            $camp['categories'] = is_array($categories) ? $categories : array();
            
            // Schedule
            if ($start_date && $end_date) {
                $camp['schedule'] = $this->generate_camp_schedule($start_date, $end_date, $daily_times);
            }
        }
        
        return $camp;
    }
    
    private function generate_camp_schedule($start, $end, $times) {
        $schedule = array();
        $current = strtotime($start);
        $end_ts = strtotime($end);
        $day = 1;
        
        while ($current <= $end_ts) {
            $schedule[] = array(
                'day' => $day,
                'date' => date('Y-m-d', $current),
                'day_name' => date('l', $current),
                'start_time' => $times['start'] ?? '09:00',
                'end_time' => $times['end'] ?? '15:00',
            );
            $current = strtotime('+1 day', $current);
            $day++;
        }
        
        return $schedule;
    }
    
    // ================================================================
    // PROGRAMS ENDPOINTS (Training Programs, Clinics)
    // ================================================================
    
    public function get_programs($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => intval($request->get_param('limit') ?: 50),
            'paged' => intval($request->get_param('page') ?: 1),
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => array('programs', 'clinics', 'training-programs', 'skills-clinics'),
                    'operator' => 'IN',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $programs = array();
        
        foreach ($query->posts as $post) {
            $programs[] = $this->format_program($post->ID);
        }
        
        return rest_ensure_response(array(
            'programs' => $programs,
            'pagination' => array(
                'total' => $query->found_posts,
                'pages' => $query->max_num_pages,
                'page' => intval($request->get_param('page') ?: 1),
                'per_page' => intval($request->get_param('limit') ?: 50),
            ),
        ));
    }
    
    public function get_featured_programs($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 10,
            'meta_query' => array(
                array(
                    'key' => '_featured',
                    'value' => 'yes',
                ),
            ),
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => array('programs', 'clinics', 'training-programs'),
                    'operator' => 'IN',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $programs = array();
        
        foreach ($query->posts as $post) {
            $programs[] = $this->format_program($post->ID);
        }
        
        return rest_ensure_response($programs);
    }
    
    public function get_upcoming_programs($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            'meta_query' => array(
                array(
                    'key' => '_ptp_start_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE',
                ),
            ),
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => array('programs', 'clinics'),
                    'operator' => 'IN',
                ),
            ),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        $query = new WP_Query($args);
        $programs = array();
        
        foreach ($query->posts as $post) {
            $programs[] = $this->format_program($post->ID);
        }
        
        return rest_ensure_response($programs);
    }
    
    public function get_program($request) {
        $id = intval($request->get_param('id'));
        $product = wc_get_product($id);
        
        if (!$product) {
            return new WP_Error('not_found', 'Program not found', array('status' => 404));
        }
        
        return rest_ensure_response($this->format_program($id, true));
    }
    
    public function search_programs($request) {
        $search = sanitize_text_field($request->get_param('q') ?: $request->get_param('search') ?: '');
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            's' => $search,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => array('programs', 'clinics'),
                    'operator' => 'IN',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $programs = array();
        
        foreach ($query->posts as $post) {
            $programs[] = $this->format_program($post->ID);
        }
        
        return rest_ensure_response(array(
            'programs' => $programs,
            'total' => $query->found_posts,
        ));
    }
    
    public function get_program_categories($request) {
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => true,
            'parent' => 0,
        ));
        
        $program_cats = array();
        foreach ($categories as $cat) {
            if (in_array($cat->slug, array('programs', 'clinics', 'training-programs', 'skills-clinics'))) {
                $program_cats[] = array(
                    'id' => $cat->term_id,
                    'name' => $cat->name,
                    'slug' => $cat->slug,
                    'count' => $cat->count,
                    'description' => $cat->description,
                );
                
                // Get subcategories
                $children = get_terms(array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => true,
                    'parent' => $cat->term_id,
                ));
                
                foreach ($children as $child) {
                    $program_cats[] = array(
                        'id' => $child->term_id,
                        'name' => $child->name,
                        'slug' => $child->slug,
                        'count' => $child->count,
                        'parent_id' => $cat->term_id,
                    );
                }
            }
        }
        
        return rest_ensure_response($program_cats);
    }
    
    private function format_program($product_id, $full = false) {
        $product = wc_get_product($product_id);
        if (!$product) return null;
        
        $start_date = get_post_meta($product_id, '_ptp_start_date', true);
        $end_date = get_post_meta($product_id, '_ptp_end_date', true);
        
        $program = array(
            'id' => $product_id,
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'type' => 'program',
            'price' => floatval($product->get_price()),
            'regular_price' => floatval($product->get_regular_price()),
            'sale_price' => $product->get_sale_price() ? floatval($product->get_sale_price()) : null,
            'on_sale' => $product->is_on_sale(),
            'currency' => 'USD',
            'start_date' => $start_date ?: null,
            'end_date' => $end_date ?: null,
            'location' => array(
                'name' => get_post_meta($product_id, '_ptp_location_name', true) ?: '',
                'city' => get_post_meta($product_id, '_ptp_city', true) ?: '',
                'state' => get_post_meta($product_id, '_ptp_state', true) ?: '',
            ),
            'featured_image' => wp_get_attachment_url($product->get_image_id()) ?: '',
            'is_featured' => $product->is_featured(),
            'url' => get_permalink($product_id),
        );
        
        if ($full) {
            $program['description'] = $product->get_description();
            $program['short_description'] = $product->get_short_description();
            $program['gallery'] = array_map('wp_get_attachment_url', $product->get_gallery_image_ids());
            $program['categories'] = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
        }
        
        return $program;
    }
    
    // ================================================================
    // ADDITIONAL CAMPS ENDPOINTS
    // ================================================================
    
    public function get_nearby_camps($request) {
        $lat = floatval($request->get_param('lat'));
        $lng = floatval($request->get_param('lng'));
        $radius = intval($request->get_param('radius') ?: 50);
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 50,
            'meta_query' => array(
                'relation' => 'AND',
                array(
                    'key' => '_ptp_latitude',
                    'compare' => 'EXISTS',
                ),
                array(
                    'key' => '_ptp_start_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE',
                ),
            ),
        );
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camp_lat = floatval(get_post_meta($post->ID, '_ptp_latitude', true));
            $camp_lng = floatval(get_post_meta($post->ID, '_ptp_longitude', true));
            
            if ($camp_lat && $camp_lng && $lat && $lng) {
                // Haversine formula
                $distance = 3959 * acos(
                    cos(deg2rad($lat)) * cos(deg2rad($camp_lat)) *
                    cos(deg2rad($camp_lng) - deg2rad($lng)) +
                    sin(deg2rad($lat)) * sin(deg2rad($camp_lat))
                );
                
                if ($distance <= $radius) {
                    $camp = $this->format_camp($post->ID);
                    $camp['distance'] = round($distance, 1);
                    $camps[] = $camp;
                }
            }
        }
        
        // Sort by distance
        usort($camps, function($a, $b) {
            return ($a['distance'] ?? 999) <=> ($b['distance'] ?? 999);
        });
        
        return rest_ensure_response($camps);
    }
    
    public function get_camps_by_location($request) {
        $state = sanitize_text_field($request->get_param('state'));
        $city = sanitize_text_field($request->get_param('city'));
        
        $meta_query = array(
            array(
                'key' => '_ptp_start_date',
                'value' => date('Y-m-d'),
                'compare' => '>=',
                'type' => 'DATE',
            ),
        );
        
        if ($state) {
            $meta_query[] = array(
                'key' => '_ptp_state',
                'value' => $state,
            );
        }
        
        if ($city) {
            $meta_query[] = array(
                'key' => '_ptp_city',
                'value' => $city,
                'compare' => 'LIKE',
            );
        }
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 50,
            'meta_query' => $meta_query,
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camps[] = $this->format_camp($post->ID);
        }
        
        return rest_ensure_response($camps);
    }
    
    public function get_camp_categories($request) {
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => true,
        ));
        
        $camp_cats = array();
        $camp_slugs = array('camps', 'summer-camps', 'winter-camps', 'spring-camps', 'holiday-camps');
        
        foreach ($categories as $cat) {
            if (in_array($cat->slug, $camp_slugs) || $cat->parent > 0) {
                $parent_cat = $cat->parent > 0 ? get_term($cat->parent) : null;
                if (!$parent_cat || in_array($parent_cat->slug, $camp_slugs)) {
                    $camp_cats[] = array(
                        'id' => $cat->term_id,
                        'name' => $cat->name,
                        'slug' => $cat->slug,
                        'count' => $cat->count,
                        'description' => $cat->description ?: '',
                        'parent_id' => $cat->parent ?: null,
                    );
                }
            }
        }
        
        return rest_ensure_response($camp_cats);
    }
    
    public function search_camps($request) {
        $search = sanitize_text_field($request->get_param('q') ?: $request->get_param('search') ?: '');
        $state = sanitize_text_field($request->get_param('state'));
        $age_group = sanitize_text_field($request->get_param('age_group'));
        
        $meta_query = array();
        
        if ($state) {
            $meta_query[] = array(
                'key' => '_ptp_state',
                'value' => $state,
            );
        }
        
        if ($age_group) {
            $meta_query[] = array(
                'key' => '_ptp_age_groups',
                'value' => $age_group,
                'compare' => 'LIKE',
            );
        }
        
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 50,
            's' => $search,
        );
        
        if (!empty($meta_query)) {
            $args['meta_query'] = $meta_query;
        }
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camps[] = $this->format_camp($post->ID);
        }
        
        return rest_ensure_response(array(
            'camps' => $camps,
            'total' => $query->found_posts,
        ));
    }
    
    public function get_camp_availability($request) {
        $camp_id = intval($request->get_param('id'));
        $product = wc_get_product($camp_id);
        
        if (!$product) {
            return new WP_Error('not_found', 'Camp not found', array('status' => 404));
        }
        
        $max_capacity = intval(get_post_meta($camp_id, '_ptp_max_capacity', true));
        $sold_count = intval(get_post_meta($camp_id, '_ptp_sold_count', true));
        $start_date = get_post_meta($camp_id, '_ptp_start_date', true);
        
        // Check if registration is still open
        $registration_deadline = get_post_meta($camp_id, '_ptp_registration_deadline', true);
        $is_registration_open = true;
        if ($registration_deadline && strtotime($registration_deadline) < time()) {
            $is_registration_open = false;
        }
        
        return rest_ensure_response(array(
            'camp_id' => $camp_id,
            'max_capacity' => $max_capacity,
            'spots_sold' => $sold_count,
            'spots_available' => max(0, $max_capacity - $sold_count),
            'is_sold_out' => $max_capacity > 0 && $sold_count >= $max_capacity,
            'is_registration_open' => $is_registration_open,
            'registration_deadline' => $registration_deadline ?: null,
            'start_date' => $start_date,
            'in_stock' => $product->is_in_stock(),
        ));
    }
    
    public function get_camp_schedule($request) {
        $camp_id = intval($request->get_param('id'));
        
        $start_date = get_post_meta($camp_id, '_ptp_start_date', true);
        $end_date = get_post_meta($camp_id, '_ptp_end_date', true);
        $daily_times = get_post_meta($camp_id, '_ptp_daily_times', true) ?: array();
        
        if (!$start_date) {
            return new WP_Error('no_schedule', 'No schedule available', array('status' => 404));
        }
        
        $schedule = $this->generate_camp_schedule(
            $start_date,
            $end_date ?: $start_date,
            $daily_times
        );
        
        return rest_ensure_response(array(
            'camp_id' => $camp_id,
            'start_date' => $start_date,
            'end_date' => $end_date ?: $start_date,
            'daily_start_time' => $daily_times['start'] ?? '09:00',
            'daily_end_time' => $daily_times['end'] ?? '15:00',
            'schedule' => $schedule,
        ));
    }
    
    // ================================================================
    // TRAINERS ENDPOINTS
    // ================================================================
    
    public function get_trainers($request) {
        global $wpdb;
        
        $limit = intval($request->get_param('limit') ?: 20);
        $offset = (intval($request->get_param('page') ?: 1) - 1) * $limit;
        
        $where = "WHERE t.status = 'active'";
        $params = array();
        
        // Filter by specialty
        if ($specialty = $request->get_param('specialty')) {
            $where .= " AND t.specialties LIKE %s";
            $params[] = '%' . $specialty . '%';
        }
        
        // Filter by state
        if ($state = $request->get_param('state')) {
            $where .= " AND t.location LIKE %s";
            $params[] = '%' . $state . '%';
        }
        
        $sql = "SELECT t.*, u.display_name as wp_name, u.user_email
                FROM {$wpdb->prefix}ptp_trainers t
                JOIN {$wpdb->users} u ON t.user_id = u.ID
                $where
                ORDER BY t.is_featured DESC, t.rating DESC
                LIMIT %d OFFSET %d";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $trainers = $wpdb->get_results($wpdb->prepare($sql, $params));
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_trainers t $where");
        
        $result = array();
        foreach ($trainers as $trainer) {
            $result[] = $this->format_trainer($trainer);
        }
        
        return rest_ensure_response(array(
            'trainers' => $result,
            'pagination' => array(
                'total' => intval($total),
                'pages' => ceil($total / $limit),
                'page' => intval($request->get_param('page') ?: 1),
                'per_page' => $limit,
            ),
        ));
    }
    
    public function get_featured_trainers($request) {
        $trainers = $this->get_featured_trainers_data(10);
        return rest_ensure_response($trainers);
    }
    
    private function get_featured_trainers_data($limit = 6) {
        global $wpdb;
        
        $trainers = $wpdb->get_results($wpdb->prepare(
            "SELECT t.*, u.display_name as wp_name
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.status = 'active' AND t.is_featured = 1
             ORDER BY t.rating DESC
             LIMIT %d",
            $limit
        ));
        
        return array_map(array($this, 'format_trainer'), $trainers);
    }
    
    private function get_featured_camps_data($limit = 6) {
        $featured_ids = wc_get_featured_product_ids();
        $camps = array();
        
        foreach (array_slice($featured_ids, 0, $limit) as $id) {
            $camps[] = $this->format_camp($id);
        }
        
        return $camps;
    }
    
    public function get_trainer($request) {
        global $wpdb;
        
        $id = intval($request->get_param('id'));
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT t.*, u.display_name as wp_name, u.user_email
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.id = %d",
            $id
        ));
        
        if (!$trainer) {
            return new WP_Error('not_found', 'Trainer not found', array('status' => 404));
        }
        
        return rest_ensure_response($this->format_trainer($trainer, true));
    }
    
    private function format_trainer($trainer, $full = false) {
        $specialties = $trainer->specialties;
        if (is_string($specialties)) {
            $decoded = json_decode($specialties, true);
            $specialties = is_array($decoded) ? $decoded : array_filter(array_map('trim', explode(',', $specialties)));
        }
        
        // Generate photo URLs at different sizes for mobile app
        $photo_url = $trainer->photo_url;
        $has_photo = !empty($photo_url);
        
        // If no photo, generate avatar
        if (!$has_photo) {
            $name = $trainer->display_name ?: 'Trainer';
            $photo_url = 'https://ui-avatars.com/api/?name=' . urlencode($name) . '&size=400&background=FCB900&color=0A0A0A&bold=true&format=png';
        }
        
        $data = array(
            'id' => intval($trainer->id),
            'name' => $trainer->display_name ?: $trainer->wp_name,
            'slug' => $trainer->slug,
            'photo' => $photo_url,
            'photo_thumb' => $has_photo ? $photo_url : str_replace('size=400', 'size=200', $photo_url),
            'photo_large' => $has_photo ? $photo_url : str_replace('size=400', 'size=800', $photo_url),
            'has_photo' => $has_photo,
            'headline' => $trainer->headline ?: '',
            'location' => $trainer->location ?: '',
            'hourly_rate' => floatval($trainer->hourly_rate),
            'rating' => floatval($trainer->rating ?: 5.0),
            'review_count' => intval($trainer->review_count ?: 0),
            'session_count' => intval($trainer->session_count ?: 0),
            'specialties' => $specialties ?: array(),
            'playing_level' => $trainer->playing_level ?: '',
            'is_featured' => (bool) $trainer->is_featured,
            'is_verified' => (bool) $trainer->is_verified,
            'response_time' => $trainer->response_time ?: 'within 24 hours',
            'happy_student_score' => intval($trainer->happy_student_score ?? 97),
        );
        
        if ($full) {
            $data['bio'] = $trainer->bio ?: '';
            $data['experience_years'] = intval($trainer->experience_years);
            $data['college'] = $trainer->college ?: '';
            $data['team'] = $trainer->team ?: '';
            $data['position'] = $trainer->position ?: '';
            $data['travel_radius'] = intval($trainer->travel_radius ?: 15);
            $data['accepts_groups'] = (bool) $trainer->accepts_groups;
            $data['group_rate'] = floatval($trainer->group_rate ?: 0);
            $data['instagram'] = $trainer->instagram ?: '';
            
            // Training locations
            $locations = $trainer->training_locations;
            if (is_string($locations)) {
                $locations = json_decode($locations, true) ?: array();
            }
            $data['training_locations'] = $locations;
            
            // Video intro
            $data['video_intro'] = $trainer->video_intro_url ?: '';
        }
        
        return $data;
    }
    
    // ================================================================
    // HELPER METHODS
    // ================================================================
    
    private function format_user($user) {
        global $wpdb;
        
        $data = array(
            'id' => $user->ID,
            'email' => $user->user_email,
            'name' => $user->display_name,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'avatar' => get_avatar_url($user->ID, array('size' => 200)),
            'phone' => get_user_meta($user->ID, 'phone', true),
        );
        
        // Check if trainer
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if ($trainer) {
            $data['type'] = 'trainer';
            $data['trainer_id'] = intval($trainer->id);
            $data['trainer_status'] = $trainer->status;
        } else {
            // Check if parent
            $parent = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_parents WHERE user_id = %d",
                $user->ID
            ));
            
            if ($parent) {
                $data['type'] = 'parent';
                $data['parent_id'] = intval($parent->id);
                
                // Get players
                $players = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}ptp_players WHERE parent_id = %d",
                    $parent->id
                ));
                
                $data['players'] = array_map(function($p) {
                    return array(
                        'id' => intval($p->id),
                        'name' => $p->name,
                        'age' => intval($p->age),
                        'position' => $p->position ?: '',
                    );
                }, $players);
            } else {
                $data['type'] = 'user';
            }
        }
        
        return $data;
    }
    
    private function get_specialties_list() {
        return array(
            array('id' => 'ball_control', 'name' => 'Ball Control', 'icon' => '⚽'),
            array('id' => 'dribbling', 'name' => 'Dribbling', 'icon' => '🏃'),
            array('id' => 'shooting', 'name' => 'Shooting', 'icon' => '🎯'),
            array('id' => 'passing', 'name' => 'Passing', 'icon' => '➡️'),
            array('id' => 'first_touch', 'name' => 'First Touch', 'icon' => '✋'),
            array('id' => 'heading', 'name' => 'Heading', 'icon' => '🤕'),
            array('id' => 'defending', 'name' => 'Defending', 'icon' => '🛡️'),
            array('id' => 'positioning', 'name' => 'Positioning', 'icon' => '📍'),
            array('id' => 'speed_agility', 'name' => 'Speed & Agility', 'icon' => '⚡'),
            array('id' => 'goalkeeping', 'name' => 'Goalkeeping', 'icon' => '🧤'),
            array('id' => 'game_iq', 'name' => 'Game IQ', 'icon' => '🧠'),
            array('id' => 'confidence', 'name' => 'Confidence Building', 'icon' => '💪'),
        );
    }
    
    private function get_locations_list() {
        return array(
            array('id' => 'PA', 'name' => 'Pennsylvania', 'cities' => array('Philadelphia', 'Pittsburgh', 'Allentown')),
            array('id' => 'NJ', 'name' => 'New Jersey', 'cities' => array('Newark', 'Jersey City', 'Princeton')),
            array('id' => 'DE', 'name' => 'Delaware', 'cities' => array('Wilmington', 'Dover', 'Newark')),
            array('id' => 'MD', 'name' => 'Maryland', 'cities' => array('Baltimore', 'Annapolis', 'Rockville')),
            array('id' => 'NY', 'name' => 'New York', 'cities' => array('New York City', 'Buffalo', 'Albany')),
        );
    }
    
    // ================================================================
    // STUB METHODS (implement as needed)
    // ================================================================
    
    public function login($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        
        $user = wp_authenticate($email, $password);
        
        if (is_wp_error($user)) {
            return new WP_Error('invalid_credentials', 'Invalid email or password', array('status' => 401));
        }
        
        $token = $this->generate_token($user->ID);
        
        return rest_ensure_response(array(
            'user' => $this->format_user($user),
            'auth' => $token,
        ));
    }
    
    public function register($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        $name = sanitize_text_field($request->get_param('name'));
        $type = sanitize_text_field($request->get_param('type') ?: 'parent');
        
        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Email already registered', array('status' => 400));
        }
        
        $user_id = wp_create_user($email, $password, $email);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $name,
        ));
        
        // Create parent record
        if ($type === 'parent') {
            global $wpdb;
            $wpdb->insert($wpdb->prefix . 'ptp_parents', array(
                'user_id' => $user_id,
                'display_name' => $name,
                'email' => $email,
                'status' => 'active',
                'created_at' => current_time('mysql'),
            ));
        }
        
        $user = get_user_by('ID', $user_id);
        $token = $this->generate_token($user_id);
        
        return rest_ensure_response(array(
            'user' => $this->format_user($user),
            'auth' => $token,
        ));
    }
    
    public function google_login($request) {
        if (class_exists('PTP_Social_Login')) {
            return PTP_Social_Login::google_auth($request);
        }
        return new WP_Error('not_configured', 'Google login not configured', array('status' => 501));
    }
    
    public function apple_login($request) {
        if (class_exists('PTP_Social_Login')) {
            return PTP_Social_Login::apple_auth($request);
        }
        return new WP_Error('not_configured', 'Apple login not configured', array('status' => 501));
    }
    
    public function refresh_token($request) {
        $user = $this->get_user_from_token($request);
        if (!$user) {
            return new WP_Error('invalid_token', 'Invalid or expired token', array('status' => 401));
        }
        
        $token = $this->generate_token($user->ID);
        return rest_ensure_response($token);
    }
    
    public function forgot_password($request) {
        $email = sanitize_email($request->get_param('email'));
        $user = get_user_by('email', $email);
        
        if ($user) {
            retrieve_password($email);
        }
        
        // Always return success to prevent email enumeration
        return rest_ensure_response(array(
            'message' => 'If an account exists, a password reset link has been sent.',
        ));
    }
    
    public function logout($request) {
        $user = $this->get_user_from_token($request);
        if ($user) {
            delete_user_meta($user->ID, 'ptp_auth_token');
            delete_user_meta($user->ID, 'ptp_token_expires');
        }
        return rest_ensure_response(array('message' => 'Logged out'));
    }
    
    public function get_current_user($request) {
        $user = $this->get_user_from_token($request);
        return rest_ensure_response($this->format_user($user));
    }
    
    public function register_device($request) {
        $user = $this->get_user_from_token($request);
        $token = sanitize_text_field($request->get_param('fcm_token'));
        $device_type = sanitize_text_field($request->get_param('device_type') ?: 'unknown');
        $device_name = sanitize_text_field($request->get_param('device_name') ?: '');
        $app_version = sanitize_text_field($request->get_param('app_version') ?: '');
        
        global $wpdb;
        
        // Check if token exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_fcm_tokens WHERE token = %s",
            $token
        ));
        
        if ($existing) {
            $wpdb->update(
                $wpdb->prefix . 'ptp_fcm_tokens',
                array(
                    'user_id' => $user->ID,
                    'device_type' => $device_type,
                    'device_name' => $device_name,
                    'app_version' => $app_version,
                    'is_active' => 1,
                    'updated_at' => current_time('mysql'),
                ),
                array('id' => $existing)
            );
        } else {
            $wpdb->insert($wpdb->prefix . 'ptp_fcm_tokens', array(
                'user_id' => $user->ID,
                'token' => $token,
                'device_type' => $device_type,
                'device_name' => $device_name,
                'app_version' => $app_version,
                'is_active' => 1,
                'created_at' => current_time('mysql'),
            ));
        }
        
        return rest_ensure_response(array('registered' => true));
    }
    
    public function unregister_device($request) {
        $token = sanitize_text_field($request->get_param('fcm_token'));
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'ptp_fcm_tokens',
            array('is_active' => 0),
            array('token' => $token)
        );
        
        return rest_ensure_response(array('unregistered' => true));
    }
    
    // ================================================================
    // PROFILE METHODS
    // ================================================================
    
    public function update_profile($request) {
        $user = $this->get_user_from_token($request);
        
        $update_data = array('ID' => $user->ID);
        
        if ($request->has_param('name')) {
            $update_data['display_name'] = sanitize_text_field($request->get_param('name'));
        }
        if ($request->has_param('first_name')) {
            $update_data['first_name'] = sanitize_text_field($request->get_param('first_name'));
        }
        if ($request->has_param('last_name')) {
            $update_data['last_name'] = sanitize_text_field($request->get_param('last_name'));
        }
        
        wp_update_user($update_data);
        
        if ($request->has_param('phone')) {
            update_user_meta($user->ID, 'phone', sanitize_text_field($request->get_param('phone')));
        }
        
        return rest_ensure_response(array(
            'updated' => true,
            'user' => $this->format_user(get_user_by('ID', $user->ID)),
        ));
    }
    
    public function upload_avatar($request) {
        $user = $this->get_user_from_token($request);
        $files = $request->get_file_params();
        
        if (empty($files['avatar'])) {
            return new WP_Error('no_file', 'No avatar file provided', array('status' => 400));
        }
        
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        
        $attachment_id = media_handle_upload('avatar', 0);
        
        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }
        
        update_user_meta($user->ID, 'ptp_avatar', $attachment_id);
        
        return rest_ensure_response(array(
            'uploaded' => true,
            'avatar_url' => wp_get_attachment_url($attachment_id),
        ));
    }
    
    public function change_password($request) {
        $user = $this->get_user_from_token($request);
        $current = $request->get_param('current_password');
        $new = $request->get_param('new_password');
        
        if (!wp_check_password($current, $user->user_pass, $user->ID)) {
            return new WP_Error('wrong_password', 'Current password is incorrect', array('status' => 400));
        }
        
        if (strlen($new) < 8) {
            return new WP_Error('weak_password', 'Password must be at least 8 characters', array('status' => 400));
        }
        
        wp_set_password($new, $user->ID);
        
        // Generate new token after password change
        $token = $this->generate_token($user->ID);
        
        return rest_ensure_response(array(
            'changed' => true,
            'auth' => $token,
        ));
    }
    
    // ================================================================
    // NOTIFICATIONS
    // ================================================================
    
    public function get_notifications($request) {
        $user = $this->get_user_from_token($request);
        global $wpdb;
        
        $limit = intval($request->get_param('limit') ?: 50);
        $offset = intval($request->get_param('offset') ?: 0);
        
        $notifications = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_notifications 
             WHERE user_id = %d 
             ORDER BY created_at DESC 
             LIMIT %d OFFSET %d",
            $user->ID, $limit, $offset
        ));
        
        $result = array();
        foreach ($notifications as $n) {
            $result[] = array(
                'id' => intval($n->id),
                'type' => $n->type,
                'title' => $n->title,
                'message' => $n->message,
                'data' => json_decode($n->data, true) ?: array(),
                'is_read' => (bool) $n->is_read,
                'created_at' => $n->created_at,
            );
        }
        
        $unread = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_notifications WHERE user_id = %d AND is_read = 0",
            $user->ID
        ));
        
        return rest_ensure_response(array(
            'notifications' => $result,
            'unread_count' => intval($unread),
        ));
    }
    
    public function mark_notification_read($request) {
        $user = $this->get_user_from_token($request);
        $id = intval($request->get_param('id'));
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'ptp_notifications',
            array('is_read' => 1, 'read_at' => current_time('mysql')),
            array('id' => $id, 'user_id' => $user->ID)
        );
        
        return rest_ensure_response(array('read' => true));
    }
    
    // ================================================================
    // PLAYERS (for parents)
    // ================================================================
    
    public function get_players($request) {
        $user = $this->get_user_from_token($request);
        global $wpdb;
        
        $parent = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_parents WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$parent) {
            return rest_ensure_response(array('players' => array()));
        }
        
        $players = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_players WHERE parent_id = %d ORDER BY name ASC",
            $parent->id
        ));
        
        $result = array();
        foreach ($players as $p) {
            $result[] = $this->format_player($p);
        }
        
        return rest_ensure_response(array('players' => $result));
    }
    
    public function add_player($request) {
        $user = $this->get_user_from_token($request);
        global $wpdb;
        
        $parent = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_parents WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$parent) {
            // Create parent record
            $wpdb->insert($wpdb->prefix . 'ptp_parents', array(
                'user_id' => $user->ID,
                'display_name' => $user->display_name,
                'email' => $user->user_email,
                'status' => 'active',
                'created_at' => current_time('mysql'),
            ));
            $parent_id = $wpdb->insert_id;
        } else {
            $parent_id = $parent->id;
        }
        
        $wpdb->insert($wpdb->prefix . 'ptp_players', array(
            'parent_id' => $parent_id,
            'name' => sanitize_text_field($request->get_param('name')),
            'age' => intval($request->get_param('age')),
            'birthdate' => sanitize_text_field($request->get_param('birthdate') ?: ''),
            'gender' => sanitize_text_field($request->get_param('gender') ?: ''),
            'position' => sanitize_text_field($request->get_param('position') ?: ''),
            'skill_level' => sanitize_text_field($request->get_param('skill_level') ?: 'beginner'),
            'team' => sanitize_text_field($request->get_param('team') ?: ''),
            'notes' => sanitize_textarea_field($request->get_param('notes') ?: ''),
            'created_at' => current_time('mysql'),
        ));
        
        $player_id = $wpdb->insert_id;
        $player = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_players WHERE id = %d",
            $player_id
        ));
        
        return rest_ensure_response(array(
            'created' => true,
            'player' => $this->format_player($player),
        ));
    }
    
    public function get_player($request) {
        $user = $this->get_user_from_token($request);
        $player_id = intval($request->get_param('id'));
        
        global $wpdb;
        $player = $wpdb->get_row($wpdb->prepare(
            "SELECT p.* FROM {$wpdb->prefix}ptp_players p
             JOIN {$wpdb->prefix}ptp_parents pa ON p.parent_id = pa.id
             WHERE p.id = %d AND pa.user_id = %d",
            $player_id, $user->ID
        ));
        
        if (!$player) {
            return new WP_Error('not_found', 'Player not found', array('status' => 404));
        }
        
        return rest_ensure_response($this->format_player($player, true));
    }
    
    public function update_player($request) {
        $user = $this->get_user_from_token($request);
        $player_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        // Verify ownership
        $player = $wpdb->get_row($wpdb->prepare(
            "SELECT p.* FROM {$wpdb->prefix}ptp_players p
             JOIN {$wpdb->prefix}ptp_parents pa ON p.parent_id = pa.id
             WHERE p.id = %d AND pa.user_id = %d",
            $player_id, $user->ID
        ));
        
        if (!$player) {
            return new WP_Error('not_found', 'Player not found', array('status' => 404));
        }
        
        $update = array('updated_at' => current_time('mysql'));
        
        $fields = array('name', 'age', 'birthdate', 'gender', 'position', 'skill_level', 'team', 'notes');
        foreach ($fields as $field) {
            if ($request->has_param($field)) {
                $update[$field] = sanitize_text_field($request->get_param($field));
            }
        }
        
        $wpdb->update($wpdb->prefix . 'ptp_players', $update, array('id' => $player_id));
        
        $updated_player = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_players WHERE id = %d",
            $player_id
        ));
        
        return rest_ensure_response(array(
            'updated' => true,
            'player' => $this->format_player($updated_player),
        ));
    }
    
    public function delete_player($request) {
        $user = $this->get_user_from_token($request);
        $player_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE p FROM {$wpdb->prefix}ptp_players p
             JOIN {$wpdb->prefix}ptp_parents pa ON p.parent_id = pa.id
             WHERE p.id = %d AND pa.user_id = %d",
            $player_id, $user->ID
        ));
        
        return rest_ensure_response(array('deleted' => $deleted > 0));
    }
    
    public function get_player_progress($request) {
        $user = $this->get_user_from_token($request);
        $player_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        // Get session history
        $sessions = $wpdb->get_results($wpdb->prepare(
            "SELECT b.*, t.display_name as trainer_name
             FROM {$wpdb->prefix}ptp_bookings b
             JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
             WHERE b.player_id = %d AND b.status = 'completed'
             ORDER BY b.session_date DESC
             LIMIT 20",
            $player_id
        ));
        
        // Get skill progress notes
        $notes = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_session_notes
             WHERE player_id = %d
             ORDER BY created_at DESC
             LIMIT 10",
            $player_id
        ));
        
        return rest_ensure_response(array(
            'total_sessions' => count($sessions),
            'sessions' => array_map(function($s) {
                return array(
                    'id' => intval($s->id),
                    'date' => $s->session_date,
                    'trainer' => $s->trainer_name,
                    'focus_area' => $s->focus_area ?: '',
                );
            }, $sessions),
            'notes' => array_map(function($n) {
                return array(
                    'date' => $n->created_at,
                    'content' => $n->notes,
                    'skills_covered' => json_decode($n->skills_covered, true) ?: array(),
                );
            }, $notes),
        ));
    }
    
    private function format_player($player, $full = false) {
        $data = array(
            'id' => intval($player->id),
            'name' => $player->name,
            'age' => intval($player->age),
            'position' => $player->position ?: '',
            'skill_level' => $player->skill_level ?: 'beginner',
        );
        
        if ($full) {
            $data['birthdate'] = $player->birthdate ?: '';
            $data['gender'] = $player->gender ?: '';
            $data['team'] = $player->team ?: '';
            $data['notes'] = $player->notes ?: '';
            $data['created_at'] = $player->created_at;
        }
        
        return $data;
    }
    
    // ================================================================
    // TRAINER ENDPOINTS
    // ================================================================
    
    public function search_trainers($request) {
        return $this->get_trainers($request);
    }
    
    public function get_nearby_trainers($request) {
        $lat = floatval($request->get_param('lat'));
        $lng = floatval($request->get_param('lng'));
        $radius = intval($request->get_param('radius') ?: 25);
        
        if (!$lat || !$lng) {
            return $this->get_trainers($request);
        }
        
        global $wpdb;
        
        // Haversine formula for distance
        $sql = $wpdb->prepare(
            "SELECT t.*, u.display_name as wp_name,
                    (3959 * acos(cos(radians(%f)) * cos(radians(t.latitude)) 
                    * cos(radians(t.longitude) - radians(%f)) 
                    + sin(radians(%f)) * sin(radians(t.latitude)))) AS distance
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.status = 'active'
             AND t.latitude IS NOT NULL AND t.longitude IS NOT NULL
             HAVING distance < %d
             ORDER BY distance ASC
             LIMIT 50",
            $lat, $lng, $lat, $radius
        );
        
        $trainers = $wpdb->get_results($sql);
        
        return rest_ensure_response(array(
            'trainers' => array_map(function($t) {
                $data = $this->format_trainer($t);
                $data['distance'] = round($t->distance, 1);
                return $data;
            }, $trainers),
        ));
    }
    
    public function get_trainer_availability($request) {
        $trainer_id = intval($request->get_param('id'));
        $date = sanitize_text_field($request->get_param('date') ?: date('Y-m-d'));
        $days = intval($request->get_param('days') ?: 7);
        
        global $wpdb;
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
            $trainer_id
        ));
        
        if (!$trainer) {
            return new WP_Error('not_found', 'Trainer not found', array('status' => 404));
        }
        
        // Get weekly schedule
        $schedule = json_decode($trainer->weekly_schedule, true) ?: array();
        
        // Get booked slots
        $end_date = date('Y-m-d', strtotime("+{$days} days", strtotime($date)));
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT session_date, session_time FROM {$wpdb->prefix}ptp_bookings
             WHERE trainer_id = %d AND session_date BETWEEN %s AND %s
             AND status IN ('pending', 'confirmed')",
            $trainer_id, $date, $end_date
        ));
        
        $booked_slots = array();
        foreach ($bookings as $b) {
            $key = $b->session_date . '_' . $b->session_time;
            $booked_slots[$key] = true;
        }
        
        // Generate availability
        $availability = array();
        $current = strtotime($date);
        $end = strtotime($end_date);
        
        while ($current <= $end) {
            $day_name = strtolower(date('l', $current));
            $date_str = date('Y-m-d', $current);
            $day_schedule = $schedule[$day_name] ?? array();
            
            $slots = array();
            if (!empty($day_schedule['enabled'])) {
                $start_hour = intval($day_schedule['start'] ?? 9);
                $end_hour = intval($day_schedule['end'] ?? 17);
                
                for ($hour = $start_hour; $hour < $end_hour; $hour++) {
                    $time = sprintf('%02d:00', $hour);
                    $key = $date_str . '_' . $time;
                    
                    $slots[] = array(
                        'time' => $time,
                        'display' => date('g:i A', strtotime($time)),
                        'available' => !isset($booked_slots[$key]),
                    );
                }
            }
            
            $availability[] = array(
                'date' => $date_str,
                'day' => date('l', $current),
                'slots' => $slots,
            );
            
            $current = strtotime('+1 day', $current);
        }
        
        return rest_ensure_response(array('availability' => $availability));
    }
    
    public function get_trainer_reviews($request) {
        $trainer_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        $reviews = $wpdb->get_results($wpdb->prepare(
            "SELECT r.*, u.display_name as reviewer_name
             FROM {$wpdb->prefix}ptp_reviews r
             JOIN {$wpdb->users} u ON r.user_id = u.ID
             WHERE r.trainer_id = %d AND r.status = 'approved'
             ORDER BY r.created_at DESC
             LIMIT 50",
            $trainer_id
        ));
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT AVG(rating) as avg_rating, COUNT(*) as total
             FROM {$wpdb->prefix}ptp_reviews
             WHERE trainer_id = %d AND status = 'approved'",
            $trainer_id
        ));
        
        return rest_ensure_response(array(
            'average_rating' => round(floatval($stats->avg_rating ?: 5), 1),
            'total_reviews' => intval($stats->total),
            'reviews' => array_map(function($r) {
                return array(
                    'id' => intval($r->id),
                    'rating' => intval($r->rating),
                    'comment' => $r->comment,
                    'reviewer' => $r->reviewer_name,
                    'created_at' => $r->created_at,
                );
            }, $reviews),
        ));
    }
    
    public function get_trainer_gallery($request) {
        $trainer_id = intval($request->get_param('id'));
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT gallery FROM {$wpdb->prefix}ptp_trainers WHERE id = %d",
            $trainer_id
        ));
        
        if (!$trainer) {
            return new WP_Error('not_found', 'Trainer not found', array('status' => 404));
        }
        
        $gallery = json_decode($trainer->gallery, true) ?: array();
        
        return rest_ensure_response(array(
            'images' => array_map(function($img) {
                if (is_array($img)) {
                    return array(
                        'url' => $img['url'] ?? '',
                        'caption' => $img['caption'] ?? '',
                    );
                }
                return array('url' => $img, 'caption' => '');
            }, $gallery),
        ));
    }
    
    public function get_trainer_profile($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer) {
            return new WP_Error('not_trainer', 'User is not a trainer', array('status' => 403));
        }
        
        return rest_ensure_response($this->format_trainer($trainer, true));
    }
    
    public function update_trainer_profile($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer) {
            return new WP_Error('not_trainer', 'User is not a trainer', array('status' => 403));
        }
        
        $update = array('updated_at' => current_time('mysql'));
        
        $text_fields = array('bio', 'headline', 'college', 'team', 'position', 'instagram', 'location');
        $int_fields = array('hourly_rate', 'group_rate', 'travel_radius', 'experience_years');
        $bool_fields = array('accepts_groups');
        $json_fields = array('specialties', 'training_locations', 'weekly_schedule');
        
        foreach ($text_fields as $field) {
            if ($request->has_param($field)) {
                $update[$field] = sanitize_text_field($request->get_param($field));
            }
        }
        
        foreach ($int_fields as $field) {
            if ($request->has_param($field)) {
                $update[$field] = intval($request->get_param($field));
            }
        }
        
        foreach ($bool_fields as $field) {
            if ($request->has_param($field)) {
                $update[$field] = $request->get_param($field) ? 1 : 0;
            }
        }
        
        foreach ($json_fields as $field) {
            if ($request->has_param($field)) {
                $value = $request->get_param($field);
                $update[$field] = is_array($value) ? json_encode($value) : $value;
            }
        }
        
        $wpdb->update($wpdb->prefix . 'ptp_trainers', $update, array('id' => $trainer->id));
        
        return rest_ensure_response(array('updated' => true));
    }
    
    public function get_my_availability($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT weekly_schedule FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer) {
            return new WP_Error('not_trainer', 'User is not a trainer', array('status' => 403));
        }
        
        return rest_ensure_response(array(
            'schedule' => json_decode($trainer->weekly_schedule, true) ?: array(),
        ));
    }
    
    public function update_availability($request) {
        $user = $this->get_user_from_token($request);
        $schedule = $request->get_param('schedule');
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'ptp_trainers',
            array('weekly_schedule' => json_encode($schedule)),
            array('user_id' => $user->ID)
        );
        
        return rest_ensure_response(array('updated' => true));
    }
    
    public function get_earnings($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer) {
            return new WP_Error('not_trainer', 'User is not a trainer', array('status' => 403));
        }
        
        // Get earnings summary
        $totals = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                SUM(CASE WHEN status = 'completed' THEN trainer_payout ELSE 0 END) as total_earned,
                SUM(CASE WHEN status = 'completed' AND payout_status = 'pending' THEN trainer_payout ELSE 0 END) as pending_payout,
                SUM(CASE WHEN status = 'completed' AND payout_status = 'paid' THEN trainer_payout ELSE 0 END) as total_paid
             FROM {$wpdb->prefix}ptp_bookings WHERE trainer_id = %d",
            $trainer->id
        ));
        
        // Recent transactions
        $transactions = $wpdb->get_results($wpdb->prepare(
            "SELECT id, session_date, trainer_payout, payout_status, created_at
             FROM {$wpdb->prefix}ptp_bookings
             WHERE trainer_id = %d AND status = 'completed'
             ORDER BY session_date DESC LIMIT 20",
            $trainer->id
        ));
        
        return rest_ensure_response(array(
            'total_earned' => floatval($totals->total_earned ?: 0),
            'pending_payout' => floatval($totals->pending_payout ?: 0),
            'total_paid' => floatval($totals->total_paid ?: 0),
            'transactions' => array_map(function($t) {
                return array(
                    'id' => intval($t->id),
                    'date' => $t->session_date,
                    'amount' => floatval($t->trainer_payout),
                    'status' => $t->payout_status,
                );
            }, $transactions),
        ));
    }
    
    public function get_trainer_stats($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer) {
            return new WP_Error('not_trainer', 'User is not a trainer', array('status' => 403));
        }
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as total_sessions,
                COUNT(DISTINCT parent_id) as unique_clients,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_sessions,
                SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) as cancelled_sessions
             FROM {$wpdb->prefix}ptp_bookings WHERE trainer_id = %d",
            $trainer->id
        ));
        
        return rest_ensure_response(array(
            'rating' => floatval($trainer->rating ?: 5.0),
            'review_count' => intval($trainer->review_count),
            'total_sessions' => intval($stats->total_sessions),
            'completed_sessions' => intval($stats->completed_sessions),
            'unique_clients' => intval($stats->unique_clients),
            'response_rate' => $trainer->response_rate ?: 100,
            'profile_views' => intval($trainer->profile_views ?: 0),
        ));
    }
    
    public function connect_stripe($request) {
        $user = $this->get_user_from_token($request);
        
        if (!class_exists('PTP_Stripe')) {
            return new WP_Error('not_configured', 'Stripe not configured', array('status' => 501));
        }
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer) {
            return new WP_Error('not_trainer', 'User is not a trainer', array('status' => 403));
        }
        
        $return_url = $request->get_param('return_url') ?: home_url('/trainer-dashboard/');
        $link = PTP_Stripe::create_connect_account_link($trainer->id, $return_url);
        
        return rest_ensure_response(array('url' => $link));
    }
    
    public function stripe_dashboard_link($request) {
        $user = $this->get_user_from_token($request);
        
        if (!class_exists('PTP_Stripe')) {
            return new WP_Error('not_configured', 'Stripe not configured', array('status' => 501));
        }
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT stripe_account_id FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$trainer || empty($trainer->stripe_account_id)) {
            return new WP_Error('not_connected', 'Stripe not connected', array('status' => 400));
        }
        
        $link = PTP_Stripe::create_dashboard_link($trainer->stripe_account_id);
        
        return rest_ensure_response(array('url' => $link));
    }
    
    // ================================================================
    // BOOKINGS
    // ================================================================
    
    public function get_bookings($request) {
        $user = $this->get_user_from_token($request);
        $status = $request->get_param('status');
        $role = $request->get_param('role'); // 'parent' or 'trainer'
        
        global $wpdb;
        
        $where = "WHERE 1=1";
        $params = array();
        
        // Determine if user is parent or trainer
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        $parent = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_parents WHERE user_id = %d",
            $user->ID
        ));
        
        if ($role === 'trainer' && $trainer) {
            $where .= " AND b.trainer_id = %d";
            $params[] = $trainer->id;
        } elseif ($parent) {
            $where .= " AND b.parent_id = %d";
            $params[] = $parent->id;
        } else {
            return rest_ensure_response(array('bookings' => array()));
        }
        
        if ($status) {
            $where .= " AND b.status = %s";
            $params[] = $status;
        }
        
        $sql = "SELECT b.*, t.display_name as trainer_name, t.photo_url as trainer_photo,
                       p.name as player_name
                FROM {$wpdb->prefix}ptp_bookings b
                JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
                LEFT JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
                $where
                ORDER BY b.session_date DESC, b.session_time DESC
                LIMIT 100";
        
        $bookings = $wpdb->get_results($wpdb->prepare($sql, $params));
        
        return rest_ensure_response(array(
            'bookings' => array_map(function($b) {
                return array(
                    'id' => intval($b->id),
                    'trainer_id' => intval($b->trainer_id),
                    'trainer_name' => $b->trainer_name,
                    'trainer_photo' => $b->trainer_photo ?: '',
                    'player_name' => $b->player_name ?: '',
                    'session_date' => $b->session_date,
                    'session_time' => $b->session_time,
                    'duration' => intval($b->duration ?: 60),
                    'location' => $b->location ?: '',
                    'status' => $b->status,
                    'total_amount' => floatval($b->total_amount),
                    'created_at' => $b->created_at,
                );
            }, $bookings),
        ));
    }
    
    public function create_booking($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        
        $parent = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_parents WHERE user_id = %d",
            $user->ID
        ));
        
        if (!$parent) {
            return new WP_Error('not_parent', 'Must be registered as parent to book', array('status' => 403));
        }
        
        $trainer_id = intval($request->get_param('trainer_id'));
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE id = %d AND status = 'active'",
            $trainer_id
        ));
        
        if (!$trainer) {
            return new WP_Error('invalid_trainer', 'Trainer not found or inactive', array('status' => 400));
        }
        
        $session_date = sanitize_text_field($request->get_param('date'));
        $session_time = sanitize_text_field($request->get_param('time'));
        
        // Check availability
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_bookings
             WHERE trainer_id = %d AND session_date = %s AND session_time = %s
             AND status IN ('pending', 'confirmed')",
            $trainer_id, $session_date, $session_time
        ));
        
        if ($existing) {
            return new WP_Error('not_available', 'This time slot is no longer available', array('status' => 400));
        }
        
        $rate = floatval($trainer->hourly_rate);
        $platform_fee = $rate * 0.15;
        $trainer_payout = $rate - $platform_fee;
        
        $wpdb->insert($wpdb->prefix . 'ptp_bookings', array(
            'parent_id' => $parent->id,
            'trainer_id' => $trainer_id,
            'player_id' => intval($request->get_param('player_id')),
            'session_date' => $session_date,
            'session_time' => $session_time,
            'duration' => intval($request->get_param('duration') ?: 60),
            'location' => sanitize_text_field($request->get_param('location')),
            'total_amount' => $rate,
            'platform_fee' => $platform_fee,
            'trainer_payout' => $trainer_payout,
            'status' => 'pending',
            'created_at' => current_time('mysql'),
        ));
        
        $booking_id = $wpdb->insert_id;
        
        return rest_ensure_response(array(
            'created' => true,
            'booking_id' => $booking_id,
            'requires_payment' => true,
            'amount' => $rate,
        ));
    }
    
    public function get_booking($request) {
        $user = $this->get_user_from_token($request);
        $booking_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT b.*, t.display_name as trainer_name, t.photo_url as trainer_photo,
                    t.phone as trainer_phone, p.name as player_name
             FROM {$wpdb->prefix}ptp_bookings b
             JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id
             LEFT JOIN {$wpdb->prefix}ptp_players p ON b.player_id = p.id
             WHERE b.id = %d",
            $booking_id
        ));
        
        if (!$booking) {
            return new WP_Error('not_found', 'Booking not found', array('status' => 404));
        }
        
        return rest_ensure_response(array(
            'id' => intval($booking->id),
            'trainer' => array(
                'id' => intval($booking->trainer_id),
                'name' => $booking->trainer_name,
                'photo' => $booking->trainer_photo ?: '',
                'phone' => $booking->trainer_phone ?: '',
            ),
            'player_name' => $booking->player_name ?: '',
            'session_date' => $booking->session_date,
            'session_time' => $booking->session_time,
            'duration' => intval($booking->duration),
            'location' => $booking->location ?: '',
            'status' => $booking->status,
            'total_amount' => floatval($booking->total_amount),
            'notes' => $booking->notes ?: '',
            'created_at' => $booking->created_at,
        ));
    }
    
    public function confirm_booking($request) {
        $user = $this->get_user_from_token($request);
        $booking_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        $wpdb->update(
            $wpdb->prefix . 'ptp_bookings',
            array('status' => 'confirmed', 'confirmed_at' => current_time('mysql')),
            array('id' => $booking_id)
        );
        
        return rest_ensure_response(array('confirmed' => true));
    }
    
    public function cancel_booking($request) {
        $booking_id = intval($request->get_param('id'));
        $reason = sanitize_text_field($request->get_param('reason') ?: '');
        
        global $wpdb;
        
        $wpdb->update(
            $wpdb->prefix . 'ptp_bookings',
            array(
                'status' => 'cancelled',
                'cancellation_reason' => $reason,
                'cancelled_at' => current_time('mysql'),
            ),
            array('id' => $booking_id)
        );
        
        return rest_ensure_response(array('cancelled' => true));
    }
    
    public function complete_booking($request) {
        $booking_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        $wpdb->update(
            $wpdb->prefix . 'ptp_bookings',
            array('status' => 'completed', 'completed_at' => current_time('mysql')),
            array('id' => $booking_id)
        );
        
        return rest_ensure_response(array('completed' => true));
    }
    
    public function add_session_notes($request) {
        $booking_id = intval($request->get_param('id'));
        $notes = sanitize_textarea_field($request->get_param('notes'));
        $skills = $request->get_param('skills_covered') ?: array();
        
        global $wpdb;
        
        // Get booking info
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT player_id, trainer_id FROM {$wpdb->prefix}ptp_bookings WHERE id = %d",
            $booking_id
        ));
        
        $wpdb->insert($wpdb->prefix . 'ptp_session_notes', array(
            'booking_id' => $booking_id,
            'player_id' => $booking->player_id,
            'trainer_id' => $booking->trainer_id,
            'notes' => $notes,
            'skills_covered' => json_encode($skills),
            'created_at' => current_time('mysql'),
        ));
        
        // Update booking
        $wpdb->update(
            $wpdb->prefix . 'ptp_bookings',
            array('notes' => $notes),
            array('id' => $booking_id)
        );
        
        return rest_ensure_response(array('saved' => true));
    }
    
    public function submit_review($request) {
        $user = $this->get_user_from_token($request);
        $booking_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        $booking = $wpdb->get_row($wpdb->prepare(
            "SELECT trainer_id FROM {$wpdb->prefix}ptp_bookings WHERE id = %d",
            $booking_id
        ));
        
        if (!$booking) {
            return new WP_Error('not_found', 'Booking not found', array('status' => 404));
        }
        
        $wpdb->insert($wpdb->prefix . 'ptp_reviews', array(
            'trainer_id' => $booking->trainer_id,
            'user_id' => $user->ID,
            'booking_id' => $booking_id,
            'rating' => intval($request->get_param('rating')),
            'comment' => sanitize_textarea_field($request->get_param('comment')),
            'status' => 'approved',
            'created_at' => current_time('mysql'),
        ));
        
        // Update trainer rating
        $avg = $wpdb->get_var($wpdb->prepare(
            "SELECT AVG(rating) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'approved'",
            $booking->trainer_id
        ));
        
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}ptp_reviews WHERE trainer_id = %d AND status = 'approved'",
            $booking->trainer_id
        ));
        
        $wpdb->update(
            $wpdb->prefix . 'ptp_trainers',
            array('rating' => round($avg, 2), 'review_count' => $count),
            array('id' => $booking->trainer_id)
        );
        
        return rest_ensure_response(array('submitted' => true));
    }
    
    // ================================================================
    // CAMPS REGISTRATION
    // ================================================================
    
    public function register_for_camp($request) {
        $user = $this->get_user_from_token($request);
        $camp_id = intval($request->get_param('id'));
        
        if (!class_exists('WooCommerce')) {
            return new WP_Error('not_available', 'Camp registration not available', array('status' => 501));
        }
        
        $product = wc_get_product($camp_id);
        if (!$product) {
            return new WP_Error('not_found', 'Camp not found', array('status' => 404));
        }
        
        // Add to cart and return checkout URL
        WC()->cart->empty_cart();
        WC()->cart->add_to_cart($camp_id);
        
        return rest_ensure_response(array(
            'added' => true,
            'checkout_url' => wc_get_checkout_url(),
        ));
    }
    
    public function get_my_camp_registrations($request) {
        $user = $this->get_user_from_token($request);
        
        $orders = wc_get_orders(array(
            'customer_id' => $user->ID,
            'status' => array('completed', 'processing'),
            'limit' => 50,
        ));
        
        $registrations = array();
        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                $product_id = $item->get_product_id();
                $registrations[] = array(
                    'order_id' => $order->get_id(),
                    'camp' => $this->format_camp($product_id),
                    'status' => $order->get_status(),
                    'date_purchased' => $order->get_date_created()->date('Y-m-d'),
                );
            }
        }
        
        return rest_ensure_response(array('registrations' => $registrations));
    }
    
    // ================================================================
    // MESSAGING
    // ================================================================
    
    public function get_conversations($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        
        $conversations = $wpdb->get_results($wpdb->prepare(
            "SELECT c.*, 
                    CASE WHEN c.user1_id = %d THEN u2.display_name ELSE u1.display_name END as other_name,
                    CASE WHEN c.user1_id = %d THEN c.user2_id ELSE c.user1_id END as other_id,
                    (SELECT message FROM {$wpdb->prefix}ptp_messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message,
                    (SELECT created_at FROM {$wpdb->prefix}ptp_messages WHERE conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message_at,
                    (SELECT COUNT(*) FROM {$wpdb->prefix}ptp_messages WHERE conversation_id = c.id AND sender_id != %d AND is_read = 0) as unread_count
             FROM {$wpdb->prefix}ptp_conversations c
             JOIN {$wpdb->users} u1 ON c.user1_id = u1.ID
             JOIN {$wpdb->users} u2 ON c.user2_id = u2.ID
             WHERE c.user1_id = %d OR c.user2_id = %d
             ORDER BY last_message_at DESC",
            $user->ID, $user->ID, $user->ID, $user->ID, $user->ID
        ));
        
        return rest_ensure_response(array(
            'conversations' => array_map(function($c) {
                return array(
                    'id' => intval($c->id),
                    'other_user' => array(
                        'id' => intval($c->other_id),
                        'name' => $c->other_name,
                    ),
                    'last_message' => $c->last_message ?: '',
                    'last_message_at' => $c->last_message_at,
                    'unread_count' => intval($c->unread_count),
                );
            }, $conversations),
        ));
    }
    
    public function get_conversation($request) {
        return $this->get_messages($request);
    }
    
    public function get_messages($request) {
        $user = $this->get_user_from_token($request);
        $conversation_id = intval($request->get_param('id'));
        
        global $wpdb;
        
        // Mark as read
        $wpdb->update(
            $wpdb->prefix . 'ptp_messages',
            array('is_read' => 1, 'read_at' => current_time('mysql')),
            array('conversation_id' => $conversation_id, 'is_read' => 0)
        );
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT m.*, u.display_name as sender_name
             FROM {$wpdb->prefix}ptp_messages m
             JOIN {$wpdb->users} u ON m.sender_id = u.ID
             WHERE m.conversation_id = %d
             ORDER BY m.created_at ASC",
            $conversation_id
        ));
        
        return rest_ensure_response(array(
            'messages' => array_map(function($m) use ($user) {
                return array(
                    'id' => intval($m->id),
                    'message' => $m->message,
                    'sender_id' => intval($m->sender_id),
                    'sender_name' => $m->sender_name,
                    'is_mine' => intval($m->sender_id) === $user->ID,
                    'created_at' => $m->created_at,
                );
            }, $messages),
        ));
    }
    
    public function send_message($request) {
        $user = $this->get_user_from_token($request);
        $conversation_id = intval($request->get_param('id'));
        $message = sanitize_textarea_field($request->get_param('message'));
        
        global $wpdb;
        
        $wpdb->insert($wpdb->prefix . 'ptp_messages', array(
            'conversation_id' => $conversation_id,
            'sender_id' => $user->ID,
            'message' => $message,
            'is_read' => 0,
            'created_at' => current_time('mysql'),
        ));
        
        $message_id = $wpdb->insert_id;
        
        return rest_ensure_response(array(
            'sent' => true,
            'message_id' => $message_id,
        ));
    }
    
    public function start_conversation($request) {
        $user = $this->get_user_from_token($request);
        $recipient_id = intval($request->get_param('recipient_id'));
        $message = sanitize_textarea_field($request->get_param('message'));
        
        global $wpdb;
        
        // Check for existing conversation
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_conversations
             WHERE (user1_id = %d AND user2_id = %d) OR (user1_id = %d AND user2_id = %d)",
            $user->ID, $recipient_id, $recipient_id, $user->ID
        ));
        
        if ($existing) {
            $conversation_id = $existing;
        } else {
            $wpdb->insert($wpdb->prefix . 'ptp_conversations', array(
                'user1_id' => $user->ID,
                'user2_id' => $recipient_id,
                'created_at' => current_time('mysql'),
            ));
            $conversation_id = $wpdb->insert_id;
        }
        
        // Send first message
        $wpdb->insert($wpdb->prefix . 'ptp_messages', array(
            'conversation_id' => $conversation_id,
            'sender_id' => $user->ID,
            'message' => $message,
            'is_read' => 0,
            'created_at' => current_time('mysql'),
        ));
        
        return rest_ensure_response(array(
            'conversation_id' => $conversation_id,
            'created' => !$existing,
        ));
    }
    
    // ================================================================
    // PAYMENTS
    // ================================================================
    
    public function get_payment_methods($request) {
        $user = $this->get_user_from_token($request);
        
        if (!class_exists('PTP_Stripe')) {
            return rest_ensure_response(array('methods' => array()));
        }
        
        $customer_id = get_user_meta($user->ID, 'ptp_stripe_customer_id', true);
        if (!$customer_id) {
            return rest_ensure_response(array('methods' => array()));
        }
        
        $methods = PTP_Stripe::get_payment_methods($customer_id);
        
        return rest_ensure_response(array('methods' => $methods ?: array()));
    }
    
    public function create_setup_intent($request) {
        $user = $this->get_user_from_token($request);
        
        if (!class_exists('PTP_Stripe')) {
            return new WP_Error('not_configured', 'Stripe not configured', array('status' => 501));
        }
        
        $intent = PTP_Stripe::create_setup_intent($user->ID);
        
        return rest_ensure_response(array(
            'client_secret' => $intent->client_secret,
        ));
    }
    
    public function add_payment_method($request) {
        $user = $this->get_user_from_token($request);
        $payment_method_id = sanitize_text_field($request->get_param('payment_method_id'));
        
        if (!class_exists('PTP_Stripe')) {
            return new WP_Error('not_configured', 'Stripe not configured', array('status' => 501));
        }
        
        $result = PTP_Stripe::attach_payment_method($user->ID, $payment_method_id);
        
        return rest_ensure_response(array('added' => $result));
    }
    
    public function remove_payment_method($request) {
        $payment_method_id = sanitize_text_field($request->get_param('id'));
        
        if (!class_exists('PTP_Stripe')) {
            return new WP_Error('not_configured', 'Stripe not configured', array('status' => 501));
        }
        
        PTP_Stripe::detach_payment_method($payment_method_id);
        
        return rest_ensure_response(array('removed' => true));
    }
    
    // ================================================================
    // FAVORITES
    // ================================================================
    
    public function get_favorites($request) {
        $user = $this->get_user_from_token($request);
        
        global $wpdb;
        
        $favorites = $wpdb->get_results($wpdb->prepare(
            "SELECT t.* FROM {$wpdb->prefix}ptp_favorites f
             JOIN {$wpdb->prefix}ptp_trainers t ON f.trainer_id = t.id
             WHERE f.user_id = %d AND t.status = 'active'
             ORDER BY f.created_at DESC",
            $user->ID
        ));
        
        return rest_ensure_response(array(
            'favorites' => array_map(array($this, 'format_trainer'), $favorites),
        ));
    }
    
    public function add_favorite($request) {
        $user = $this->get_user_from_token($request);
        $trainer_id = intval($request->get_param('trainer_id'));
        
        global $wpdb;
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_favorites WHERE user_id = %d AND trainer_id = %d",
            $user->ID, $trainer_id
        ));
        
        if (!$existing) {
            $wpdb->insert($wpdb->prefix . 'ptp_favorites', array(
                'user_id' => $user->ID,
                'trainer_id' => $trainer_id,
                'created_at' => current_time('mysql'),
            ));
        }
        
        return rest_ensure_response(array('added' => true));
    }
    
    public function remove_favorite($request) {
        $user = $this->get_user_from_token($request);
        $trainer_id = intval($request->get_param('trainer_id'));
        
        global $wpdb;
        $wpdb->delete($wpdb->prefix . 'ptp_favorites', array(
            'user_id' => $user->ID,
            'trainer_id' => $trainer_id,
        ));
        
        return rest_ensure_response(array('removed' => true));
    }
    
    // ================================================================
    // STATIC CONTENT
    // ================================================================
    
    public function get_faq($request) {
        $faqs = array();
        
        if (class_exists('PTP_FAQ')) {
            $faqs = PTP_FAQ::get_admin_faqs();
        }
        
        return rest_ensure_response(array('faqs' => $faqs));
    }
    
    public function get_specialties($request) {
        return rest_ensure_response($this->get_specialties_list());
    }
    
    public function get_locations($request) {
        return rest_ensure_response($this->get_locations_list());
    }
}

// Initialize
PTP_Mobile_API::instance();
