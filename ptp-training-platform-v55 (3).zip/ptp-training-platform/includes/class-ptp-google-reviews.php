<?php
/**
 * PTP Google Reviews Integration v1.0.0
 * 
 * Displays Google Business reviews on the platform
 * - Fetches reviews from Google Places API
 * - Caches reviews to reduce API calls
 * - Widget for displaying on pages
 */

defined('ABSPATH') || exit;

class PTP_Google_Reviews {
    
    const CACHE_KEY = 'ptp_google_reviews';
    const CACHE_DURATION = 86400; // 24 hours
    
    /**
     * Fetch reviews from Google Places API
     */
    public static function fetch_reviews() {
        $place_id = get_option('ptp_google_place_id');
        $api_key = get_option('ptp_google_maps_key');
        
        if (empty($place_id) || empty($api_key)) {
            return array();
        }
        
        // Check cache first
        $cached = get_transient(self::CACHE_KEY);
        if ($cached !== false) {
            return $cached;
        }
        
        $url = add_query_arg(array(
            'place_id' => $place_id,
            'fields' => 'reviews,rating,user_ratings_total',
            'key' => $api_key,
        ), 'https://maps.googleapis.com/maps/api/place/details/json');
        
        $response = wp_remote_get($url, array('timeout' => 10));
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        
        if (empty($data['result']['reviews'])) {
            return array();
        }
        
        $reviews = array(
            'overall_rating' => $data['result']['rating'] ?? 0,
            'total_reviews' => $data['result']['user_ratings_total'] ?? 0,
            'reviews' => array_slice($data['result']['reviews'], 0, 5), // Top 5
        );
        
        // Cache the results
        set_transient(self::CACHE_KEY, $reviews, self::CACHE_DURATION);
        
        return $reviews;
    }
    
    /**
     * Render reviews widget
     */
    public static function render_widget($args = array()) {
        $defaults = array(
            'title' => 'What Parents Say',
            'show_google_badge' => true,
            'max_reviews' => 3,
            'min_rating' => 4,
        );
        $opts = array_merge($defaults, $args);
        
        $reviews_data = self::fetch_reviews();
        
        // If no Google reviews, show platform reviews
        if (empty($reviews_data['reviews'])) {
            self::render_platform_reviews($opts);
            return;
        }
        
        $reviews = $reviews_data['reviews'];
        $overall = $reviews_data['overall_rating'];
        $total = $reviews_data['total_reviews'];
        
        // Filter by min rating
        $reviews = array_filter($reviews, function($r) use ($opts) {
            return $r['rating'] >= $opts['min_rating'];
        });
        
        $reviews = array_slice($reviews, 0, $opts['max_reviews']);
        
        if (empty($reviews)) return;
        ?>
        <div class="ptp-google-reviews">
            <div class="ptp-gr-header">
                <h3 class="ptp-gr-title"><?php echo esc_html($opts['title']); ?></h3>
                <?php if ($opts['show_google_badge']): ?>
                <div class="ptp-gr-badge">
                    <svg width="16" height="16" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                    <span><?php echo number_format($overall, 1); ?> ★ (<?php echo $total; ?> reviews)</span>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="ptp-gr-list">
                <?php foreach ($reviews as $review): ?>
                <div class="ptp-gr-review">
                    <div class="ptp-gr-author">
                        <img src="<?php echo esc_url($review['profile_photo_url'] ?? 'https://ui-avatars.com/api/?name=' . urlencode($review['author_name'])); ?>" alt="" class="ptp-gr-avatar">
                        <div class="ptp-gr-author-info">
                            <span class="ptp-gr-author-name"><?php echo esc_html($review['author_name']); ?></span>
                            <span class="ptp-gr-author-time"><?php echo esc_html($review['relative_time_description']); ?></span>
                        </div>
                        <div class="ptp-gr-rating">
                            <?php for ($i = 0; $i < 5; $i++): ?>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="<?php echo $i < $review['rating'] ? '#FCB900' : '#E5E7EB'; ?>"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <p class="ptp-gr-text"><?php echo esc_html(wp_trim_words($review['text'], 30)); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
            
            <?php 
            $place_id = get_option('ptp_google_place_id');
            if ($place_id): 
            ?>
            <a href="https://search.google.com/local/reviews?placeid=<?php echo esc_attr($place_id); ?>" target="_blank" rel="noopener" class="ptp-gr-more">
                View all reviews on Google →
            </a>
            <?php endif; ?>
        </div>
        
        <style>
        .ptp-google-reviews {
            background: #fff;
            border-radius: 12px;
            padding: 24px;
            margin: 24px 0;
        }
        .ptp-gr-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .ptp-gr-title {
            font-family: 'Oswald', sans-serif;
            font-size: 20px;
            font-weight: 700;
            margin: 0;
            color: #111;
        }
        .ptp-gr-badge {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            color: #6B7280;
        }
        .ptp-gr-list {
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        .ptp-gr-review {
            padding-bottom: 16px;
            border-bottom: 1px solid #F3F4F6;
        }
        .ptp-gr-review:last-child {
            border-bottom: none;
            padding-bottom: 0;
        }
        .ptp-gr-author {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 10px;
        }
        .ptp-gr-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
        }
        .ptp-gr-author-info {
            flex: 1;
        }
        .ptp-gr-author-name {
            display: block;
            font-weight: 600;
            font-size: 14px;
            color: #111;
        }
        .ptp-gr-author-time {
            font-size: 12px;
            color: #9CA3AF;
        }
        .ptp-gr-rating {
            display: flex;
            gap: 2px;
        }
        .ptp-gr-text {
            margin: 0;
            font-size: 14px;
            color: #374151;
            line-height: 1.5;
        }
        .ptp-gr-more {
            display: inline-block;
            margin-top: 16px;
            font-size: 14px;
            font-weight: 600;
            color: #4285F4;
            text-decoration: none;
        }
        .ptp-gr-more:hover {
            text-decoration: underline;
        }
        </style>
        <?php
    }
    
    /**
     * Fallback: Show platform reviews
     */
    private static function render_platform_reviews($opts) {
        global $wpdb;
        
        $reviews = $wpdb->get_results($wpdb->prepare("
            SELECT r.*, p.display_name as parent_name, t.display_name as trainer_name
            FROM {$wpdb->prefix}ptp_reviews r
            JOIN {$wpdb->prefix}ptp_parents p ON r.parent_id = p.id
            JOIN {$wpdb->prefix}ptp_trainers t ON r.trainer_id = t.id
            WHERE r.is_published = 1 AND r.rating >= %d
            ORDER BY r.created_at DESC
            LIMIT %d
        ", $opts['min_rating'], $opts['max_reviews']));
        
        if (empty($reviews)) return;
        
        // Get overall stats
        $stats = $wpdb->get_row("
            SELECT AVG(rating) as avg_rating, COUNT(*) as total
            FROM {$wpdb->prefix}ptp_reviews
            WHERE is_published = 1
        ");
        ?>
        <div class="ptp-google-reviews">
            <div class="ptp-gr-header">
                <h3 class="ptp-gr-title"><?php echo esc_html($opts['title']); ?></h3>
                <div class="ptp-gr-badge">
                    <span><?php echo number_format($stats->avg_rating, 1); ?> ★ (<?php echo $stats->total; ?> reviews)</span>
                </div>
            </div>
            
            <div class="ptp-gr-list">
                <?php foreach ($reviews as $review): ?>
                <div class="ptp-gr-review">
                    <div class="ptp-gr-author">
                        <div class="ptp-gr-avatar" style="background:#F3F4F6;display:flex;align-items:center;justify-content:center;font-weight:600;color:#6B7280">
                            <?php echo strtoupper(substr($review->parent_name, 0, 1)); ?>
                        </div>
                        <div class="ptp-gr-author-info">
                            <span class="ptp-gr-author-name"><?php echo esc_html($review->parent_name); ?></span>
                            <span class="ptp-gr-author-time">trained with <?php echo esc_html($review->trainer_name); ?></span>
                        </div>
                        <div class="ptp-gr-rating">
                            <?php for ($i = 0; $i < 5; $i++): ?>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="<?php echo $i < $review->rating ? '#FCB900' : '#E5E7EB'; ?>"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <?php if ($review->review): ?>
                    <p class="ptp-gr-text"><?php echo esc_html(wp_trim_words($review->review, 30)); ?></p>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Register settings
     */
    public static function register_settings() {
        register_setting('ptp_general', 'ptp_google_place_id');
    }
}

add_action('admin_init', array('PTP_Google_Reviews', 'register_settings'));

/**
 * Shortcode for reviews
 */
add_shortcode('ptp_reviews', function($atts) {
    $atts = shortcode_atts(array(
        'title' => 'What Parents Say',
        'max' => 3,
        'min_rating' => 4,
    ), $atts);
    
    ob_start();
    PTP_Google_Reviews::render_widget(array(
        'title' => $atts['title'],
        'max_reviews' => intval($atts['max']),
        'min_rating' => intval($atts['min_rating']),
    ));
    return ob_get_clean();
});
