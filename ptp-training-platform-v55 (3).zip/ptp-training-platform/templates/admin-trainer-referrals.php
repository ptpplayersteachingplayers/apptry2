<?php
/**
 * Admin Template: Trainer Referrals Dashboard
 */

defined('ABSPATH') || exit;

global $wpdb;

// Get stats
$stats = $wpdb->get_row("
    SELECT 
        COUNT(CASE WHEN status = 'invited' THEN 1 END) as invited,
        COUNT(CASE WHEN status = 'applied' THEN 1 END) as applied,
        COUNT(CASE WHEN status = 'approved' THEN 1 END) as approved,
        COUNT(CASE WHEN status IN ('completed', 'paid') THEN 1 END) as completed,
        SUM(CASE WHEN status IN ('completed', 'paid') THEN referrer_bonus ELSE 0 END) as total_paid
    FROM {$wpdb->prefix}ptp_trainer_referrals
    WHERE referred_email IS NOT NULL
");

// Get recent referrals
$referrals = $wpdb->get_results("
    SELECT tr.*, 
           t1.display_name as referrer_name, t1.photo_url as referrer_photo,
           t2.display_name as referred_name, t2.photo_url as referred_photo
    FROM {$wpdb->prefix}ptp_trainer_referrals tr
    LEFT JOIN {$wpdb->prefix}ptp_trainers t1 ON tr.referrer_trainer_id = t1.id
    LEFT JOIN {$wpdb->prefix}ptp_trainers t2 ON tr.referred_trainer_id = t2.id
    WHERE tr.referred_email IS NOT NULL
    ORDER BY tr.created_at DESC
    LIMIT 50
");

// Top referrers
$top_referrers = $wpdb->get_results("
    SELECT t.id, t.display_name, t.photo_url,
           COUNT(DISTINCT tr.referred_email) as total_referrals,
           COUNT(CASE WHEN tr.status IN ('completed', 'paid') THEN 1 END) as successful,
           SUM(CASE WHEN tr.status IN ('completed', 'paid') THEN tr.referrer_bonus ELSE 0 END) as earned
    FROM {$wpdb->prefix}ptp_trainers t
    JOIN {$wpdb->prefix}ptp_trainer_referrals tr ON t.id = tr.referrer_trainer_id
    WHERE tr.referred_email IS NOT NULL
    GROUP BY t.id
    HAVING total_referrals > 0
    ORDER BY successful DESC, total_referrals DESC
    LIMIT 10
");
?>

<style>
.ptp-referrals-wrap {
    padding: 20px;
    max-width: 1400px;
}
.ptp-referrals-header {
    margin-bottom: 24px;
}
.ptp-referrals-header h1 {
    margin: 0 0 8px;
    font-size: 28px;
}
.ptp-referrals-header p {
    margin: 0;
    color: #6B7280;
}
.ptp-ref-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
    gap: 16px;
    margin-bottom: 32px;
}
.ptp-ref-stat {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.ptp-ref-stat-value {
    font-size: 32px;
    font-weight: 700;
    color: #111;
    margin-bottom: 4px;
}
.ptp-ref-stat-label {
    font-size: 14px;
    color: #6B7280;
}
.ptp-ref-stat.highlight {
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
}
.ptp-ref-stat.highlight .ptp-ref-stat-value,
.ptp-ref-stat.highlight .ptp-ref-stat-label {
    color: #fff;
}
.ptp-ref-grid {
    display: grid;
    grid-template-columns: 1fr 350px;
    gap: 24px;
}
@media (max-width: 1200px) {
    .ptp-ref-grid { grid-template-columns: 1fr; }
}
.ptp-ref-card {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    overflow: hidden;
}
.ptp-ref-card-header {
    padding: 16px 20px;
    border-bottom: 1px solid #E5E7EB;
    font-weight: 600;
    font-size: 16px;
}
.ptp-ref-table {
    width: 100%;
    border-collapse: collapse;
}
.ptp-ref-table th,
.ptp-ref-table td {
    padding: 12px 16px;
    text-align: left;
    border-bottom: 1px solid #F3F4F6;
}
.ptp-ref-table th {
    background: #F9FAFB;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    color: #6B7280;
}
.ptp-ref-table tr:hover {
    background: #F9FAFB;
}
.ptp-ref-user {
    display: flex;
    align-items: center;
    gap: 10px;
}
.ptp-ref-user img {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
}
.ptp-ref-status {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}
.ptp-ref-status.invited { background: #F3F4F6; color: #6B7280; }
.ptp-ref-status.applied { background: #FEF3C7; color: #92400E; }
.ptp-ref-status.approved { background: #DBEAFE; color: #1E40AF; }
.ptp-ref-status.completed { background: #D1FAE5; color: #065F46; }
.ptp-ref-status.paid { background: #10B981; color: #fff; }
.ptp-leaderboard-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-bottom: 1px solid #F3F4F6;
}
.ptp-leaderboard-item:last-child {
    border-bottom: none;
}
.ptp-leaderboard-rank {
    width: 24px;
    height: 24px;
    background: #F3F4F6;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    font-size: 12px;
    color: #6B7280;
}
.ptp-leaderboard-item:nth-child(1) .ptp-leaderboard-rank { background: #FEF3C7; color: #92400E; }
.ptp-leaderboard-item:nth-child(2) .ptp-leaderboard-rank { background: #E5E7EB; color: #374151; }
.ptp-leaderboard-item:nth-child(3) .ptp-leaderboard-rank { background: #FED7AA; color: #9A3412; }
.ptp-leaderboard-photo {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}
.ptp-leaderboard-info {
    flex: 1;
}
.ptp-leaderboard-name {
    font-weight: 600;
    color: #111;
    margin-bottom: 2px;
}
.ptp-leaderboard-stats {
    font-size: 12px;
    color: #6B7280;
}
.ptp-leaderboard-earned {
    font-weight: 700;
    color: #059669;
}
</style>

<div class="ptp-referrals-wrap">
    <div class="ptp-referrals-header">
        <h1>🤝 Trainer Referrals</h1>
        <p>Track trainer-to-trainer referrals. Trainers earn $50 when their referral completes their first session.</p>
    </div>
    
    <div class="ptp-ref-stats">
        <div class="ptp-ref-stat">
            <div class="ptp-ref-stat-value"><?php echo intval($stats->invited ?? 0); ?></div>
            <div class="ptp-ref-stat-label">Invited</div>
        </div>
        <div class="ptp-ref-stat">
            <div class="ptp-ref-stat-value"><?php echo intval($stats->applied ?? 0); ?></div>
            <div class="ptp-ref-stat-label">Applied</div>
        </div>
        <div class="ptp-ref-stat">
            <div class="ptp-ref-stat-value"><?php echo intval($stats->approved ?? 0); ?></div>
            <div class="ptp-ref-stat-label">Approved</div>
        </div>
        <div class="ptp-ref-stat">
            <div class="ptp-ref-stat-value"><?php echo intval($stats->completed ?? 0); ?></div>
            <div class="ptp-ref-stat-label">Completed</div>
        </div>
        <div class="ptp-ref-stat highlight">
            <div class="ptp-ref-stat-value">$<?php echo number_format($stats->total_paid ?? 0); ?></div>
            <div class="ptp-ref-stat-label">Bonuses Paid</div>
        </div>
    </div>
    
    <div class="ptp-ref-grid">
        <div class="ptp-ref-card">
            <div class="ptp-ref-card-header">Recent Referrals</div>
            <table class="ptp-ref-table">
                <thead>
                    <tr>
                        <th>Referrer</th>
                        <th>Referred</th>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Bonus</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($referrals)): ?>
                    <tr><td colspan="5" style="text-align:center;padding:32px;color:#6B7280">No referrals yet</td></tr>
                    <?php else: ?>
                    <?php foreach ($referrals as $ref): ?>
                    <tr>
                        <td>
                            <div class="ptp-ref-user">
                                <img src="<?php echo esc_url($ref->referrer_photo ?: 'https://ui-avatars.com/api/?name=' . urlencode($ref->referrer_name)); ?>" alt="">
                                <span><?php echo esc_html($ref->referrer_name); ?></span>
                            </div>
                        </td>
                        <td>
                            <?php if ($ref->referred_name): ?>
                            <div class="ptp-ref-user">
                                <img src="<?php echo esc_url($ref->referred_photo ?: 'https://ui-avatars.com/api/?name=' . urlencode($ref->referred_name)); ?>" alt="">
                                <span><?php echo esc_html($ref->referred_name); ?></span>
                            </div>
                            <?php else: ?>
                            <span style="color:#6B7280"><?php echo esc_html($ref->referred_email); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><span class="ptp-ref-status <?php echo esc_attr($ref->status); ?>"><?php echo ucfirst($ref->status); ?></span></td>
                        <td style="color:#6B7280;font-size:13px"><?php echo date('M j, Y', strtotime($ref->created_at)); ?></td>
                        <td>
                            <?php if (in_array($ref->status, array('completed', 'paid'))): ?>
                            <strong style="color:#059669">$<?php echo number_format($ref->referrer_bonus); ?></strong>
                            <?php else: ?>
                            <span style="color:#9CA3AF">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="ptp-ref-card">
            <div class="ptp-ref-card-header">🏆 Top Referrers</div>
            <?php if (empty($top_referrers)): ?>
            <div style="padding:32px;text-align:center;color:#6B7280">No referrers yet</div>
            <?php else: ?>
            <?php foreach ($top_referrers as $i => $trainer): ?>
            <div class="ptp-leaderboard-item">
                <div class="ptp-leaderboard-rank"><?php echo $i + 1; ?></div>
                <img src="<?php echo esc_url($trainer->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($trainer->display_name)); ?>" class="ptp-leaderboard-photo" alt="">
                <div class="ptp-leaderboard-info">
                    <div class="ptp-leaderboard-name"><?php echo esc_html($trainer->display_name); ?></div>
                    <div class="ptp-leaderboard-stats"><?php echo $trainer->total_referrals; ?> invited • <?php echo $trainer->successful; ?> successful</div>
                </div>
                <div class="ptp-leaderboard-earned">$<?php echo number_format($trainer->earned); ?></div>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
