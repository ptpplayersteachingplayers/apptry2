<?php
/**
 * Template: Trainer Profile v50.0.0
 * MOBILE-FIRST REDESIGN
 * - Sticky quick-action header on mobile
 * - Collapsible sections to reduce scroll
 * - Improved touch targets (48px minimum)
 * - Better visual hierarchy with clear sections
 * - Optimized spacing for small screens
 * - Quick-book sticky CTA
 */
defined('ABSPATH') || exit;

$logo_url = PTP_Images::logo();

// Get trainer
global $ptp_current_trainer;
if (!empty($ptp_current_trainer)) {
    $trainer = $ptp_current_trainer;
} else {
    $slug = get_query_var('trainer_slug');
    if (empty($slug)) $slug = isset($_GET['trainer']) ? sanitize_text_field($_GET['trainer']) : '';
    if (empty($slug)) {
        $path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
        if (preg_match('#trainer/([^/]+)/?$#', $path, $m)) $slug = sanitize_text_field($m[1]);
    }
    $trainer = $slug ? PTP_Trainer::get_by_slug($slug) : null;
}

if (!$trainer || $trainer->status !== 'active') {
    get_header();
    echo '<div style="min-height:60vh;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Inter,-apple-system,sans-serif;background:#FFFFFF">
        <div style="background:#FFFFFF;border:2px solid #E5E5E5;padding:48px 40px;text-align:center;max-width:420px;border-radius:16px">
            <img src="' . esc_url($logo_url) . '" alt="PTP Training" style="height:40px;max-width:160px;width:auto;object-fit:contain;margin-bottom:24px">
            <h2 style="font-family:Oswald,sans-serif;font-size:24px;font-weight:700;margin:0 0 12px;color:#0A0A0A;text-transform:uppercase">Trainer Not Found</h2>
            <p style="color:#6B7280;margin:0 0 28px">This trainer profile isn\'t available.</p>
            <a href="' . esc_url(home_url('/find-trainers/')) . '" style="display:inline-flex;background:#FCB900;color:#0A0A0A;padding:14px 32px;font-family:Oswald,sans-serif;font-weight:700;text-decoration:none;text-transform:uppercase;border-radius:8px">Find Trainers</a>
        </div>
    </div>';
    get_footer();
    return;
}

// Profile data
$photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 500);
$rate = (int)($trainer->hourly_rate ?: 80);
$rate_5pack = round($rate * 0.90 * 5);
$rate_10pack = round($rate * 0.85 * 10);
$location = $trainer->city && $trainer->state ? $trainer->city . ', ' . $trainer->state : ($trainer->location ?: 'Philadelphia Area');
$reviews = class_exists('PTP_Reviews') ? PTP_Reviews::get_trainer_reviews($trainer->id) : array();
$review_count = is_array($reviews) ? count($reviews) : 0;
$has_reviews = $review_count > 0;
$rating = ($has_reviews && $trainer->average_rating > 0) ? number_format((float)$trainer->average_rating, 1) : '5.0';
$bio = $trainer->bio ?: '';
$headline = $trainer->headline ?: ($trainer->college ?: '');
$first_name = explode(' ', $trainer->display_name)[0];

// Social links
$instagram = !empty($trainer->instagram) ? trim($trainer->instagram) : '';
$facebook = !empty($trainer->facebook) ? trim($trainer->facebook) : '';

// Specialties
$specialties = array();
if (!empty($trainer->specialties)) {
    $decoded = json_decode($trainer->specialties, true);
    if (is_array($decoded)) $specialties = $decoded;
    else $specialties = array_filter(array_map('trim', explode(',', $trainer->specialties)));
}
$specialty_labels = array(
    'shooting'=>'Shooting','dribbling'=>'Dribbling','passing'=>'Passing','defense'=>'Defending',
    'defending'=>'Defending','goalkeeping'=>'Goalkeeping','speed'=>'Speed & Agility',
    'speed_agility'=>'Speed & Agility','fitness'=>'Fitness','tactics'=>'Tactics',
    'first_touch'=>'First Touch','ball_control'=>'Ball Control','finishing'=>'Finishing','1v1'=>'1v1'
);

$level_labels = array('pro'=>'Pro','college_d1'=>'D1','college_d2'=>'D2','college_d3'=>'D3','academy'=>'Academy','semi_pro'=>'Semi-Pro');
$playing_level = $trainer->playing_level ?? '';
$level_label = isset($level_labels[$playing_level]) ? $level_labels[$playing_level] : '';

// Training locations
$training_locations = array();
if (!empty($trainer->training_locations)) {
    $decoded = json_decode($trainer->training_locations, true);
    if (is_array($decoded)) {
        foreach ($decoded as $loc) {
            if (is_array($loc) && !empty($loc['name'])) {
                // Clean up location name and address - remove leading/trailing slashes and clean formatting
                $loc['name'] = trim(str_replace(array('/', '\\'), '', $loc['name']));
                if (!empty($loc['address'])) {
                    $loc['address'] = trim(preg_replace('/^[\/\\\\]+|[\/\\\\]+$/', '', $loc['address']));
                    // Also remove any double spaces
                    $loc['address'] = preg_replace('/\s+/', ' ', $loc['address']);
                }
                $training_locations[] = $loc;
            }
        }
    }
}
if (empty($training_locations)) {
    $clean_location = trim(str_replace(array('/', '\\'), '', $location));
    $training_locations[] = array('id' => 'default', 'name' => $clean_location, 'address' => $clean_location);
}

// Gallery images
$gallery = array();
if (!empty($trainer->gallery)) {
    $decoded = json_decode($trainer->gallery, true);
    if (is_array($decoded)) $gallery = $decoded;
}

// Get FAQs
$admin_faqs = class_exists('PTP_FAQ') ? PTP_FAQ::get_admin_faqs() : array();
$trainer_faqs = class_exists('PTP_FAQ') ? PTP_FAQ::get_trainer_faqs($trainer->id) : array();

// Current user for messaging
$current_user_id = get_current_user_id();
$is_logged_in = is_user_logged_in();

// Happy Score
$happy_score = intval($trainer->happy_student_score ?? 0);
$is_supercoach = !empty($trainer->is_supercoach);

get_header();
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800;900&display=swap');
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{overflow-x:hidden!important;max-width:100vw;scroll-behavior:smooth}

.tp2{font-family:'Inter',-apple-system,sans-serif;-webkit-font-smoothing:antialiased;background:#F8FAFC;color:#0A0A0A;line-height:1.5}
.tp2 *{box-sizing:border-box}.tp2 h1,.tp2 h2,.tp2 h3,.tp2 p{margin:0}.tp2 img{max-width:100%;height:auto}
.tp2-heading{font-family:'Oswald',sans-serif;text-transform:uppercase;letter-spacing:0.02em;font-weight:700}

/* ============================================
   MOBILE-FIRST HERO (Compact & Scannable)
   ============================================ */
.tp2-hero{
    background:linear-gradient(135deg,#0A0A0A 0%,#1F2937 100%);
    padding:20px 16px 24px;
    position:relative;
}
.tp2-hero-inner{
    max-width:1100px;
    margin:0 auto;
}

/* Mobile: Horizontal card layout */
.tp2-hero-card{
    display:flex;
    gap:16px;
    align-items:flex-start;
}
.tp2-hero-photo{
    width:100px;
    height:130px;
    flex-shrink:0;
    border-radius:12px;
    overflow:hidden;
    border:3px solid #FCB900;
    background:#1a1a1a;
}
.tp2-hero-photo img{
    width:100%;height:100%;
    object-fit:cover;
    object-position:center top;
}
.tp2-hero-info{flex:1;color:#fff;min-width:0}

.tp2-hero-badges{
    display:flex;
    gap:8px;
    flex-wrap:wrap;
    margin-bottom:8px;
}
.tp2-badge{
    display:inline-flex;
    align-items:center;
    gap:4px;
    padding:4px 10px;
    font-size:11px;
    font-weight:700;
    font-family:'Oswald',sans-serif;
    text-transform:uppercase;
    border-radius:4px;
}
.tp2-badge-level{background:rgba(252,185,0,0.2);border:1px solid rgba(252,185,0,0.5);color:#FCB900}
.tp2-badge-new{background:#10B981;color:#fff}
.tp2-badge-score{background:#22C55E;color:#fff;padding:4px 8px}

.tp2-hero-name{
    font-family:'Oswald',sans-serif;
    font-size:22px;
    font-weight:700;
    color:#fff;
    margin-bottom:4px;
    text-transform:uppercase;
    line-height:1.1;
}
.tp2-hero-headline{
    font-size:14px;
    color:#9CA3AF;
    margin-bottom:8px;
    display:-webkit-box;
    -webkit-line-clamp:2;
    -webkit-box-orient:vertical;
    overflow:hidden;
}
.tp2-hero-meta{
    display:flex;
    gap:12px;
    flex-wrap:wrap;
    align-items:center;
    font-size:13px;
    color:#9CA3AF;
}
.tp2-hero-meta svg{flex-shrink:0}

/* Price & CTA row */
.tp2-hero-actions{
    display:flex;
    align-items:center;
    justify-content:space-between;
    margin-top:16px;
    padding-top:16px;
    border-top:1px solid rgba(255,255,255,0.1);
}
.tp2-price{
    display:flex;
    align-items:baseline;
    gap:4px;
}
.tp2-price-amount{
    font-family:'Oswald',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#FCB900;
}
.tp2-price-unit{font-size:14px;color:#9CA3AF}
.tp2-hero-cta{
    display:flex;
    align-items:center;
    gap:8px;
    padding:12px 20px;
    background:#FCB900;
    color:#0A0A0A;
    font-family:'Oswald',sans-serif;
    font-weight:700;
    font-size:14px;
    text-transform:uppercase;
    border-radius:8px;
    text-decoration:none;
    border:none;
    cursor:pointer;
}
.tp2-hero-cta:hover{background:#E5A800}

/* Social icons */
.tp2-social{
    display:flex;
    gap:10px;
    margin-top:12px;
}
.tp2-social a{
    width:36px;height:36px;
    background:rgba(255,255,255,0.1);
    border-radius:50%;
    display:flex;align-items:center;justify-content:center;
    color:#fff;text-decoration:none;
    transition:all 0.2s;
}
.tp2-social a:hover{background:#FCB900;color:#0A0A0A}

/* ============================================
   QUICK STATS BAR (Trust Signals)
   ============================================ */
.tp2-trust{
    background:#fff;
    border-bottom:1px solid #E5E7EB;
    padding:12px 16px;
    overflow-x:auto;
    -webkit-overflow-scrolling:touch;
}
.tp2-trust-inner{
    display:flex;
    gap:16px;
    max-width:1100px;
    margin:0 auto;
    min-width:max-content;
}
.tp2-trust-item{
    display:flex;
    align-items:center;
    gap:6px;
    font-size:12px;
    font-weight:600;
    color:#059669;
    white-space:nowrap;
}
.tp2-trust-item svg{flex-shrink:0}

/* ============================================
   MAIN CONTENT - MOBILE OPTIMIZED
   ============================================ */
.tp2-main{
    max-width:1100px;
    margin:0 auto;
    padding:16px;
    padding-bottom:100px; /* Space for sticky bar */
}
.tp2-grid{
    display:grid;
    gap:16px;
}
/* Mobile: Booking appears first, then info cards */
.tp2-info-column{
    order:1;
    display:flex;
    flex-direction:column;
    gap:16px;
}

/* Cards with collapsible sections */
.tp2-card{
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    border:1px solid #E5E7EB;
}
.tp2-card-header{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:16px;
    cursor:pointer;
    user-select:none;
    -webkit-user-select:none;
    min-height:56px;
}
.tp2-card-header:active{background:#F9FAFB}
.tp2-card-title{
    font-family:'Oswald',sans-serif;
    font-size:15px;
    font-weight:700;
    text-transform:uppercase;
    letter-spacing:0.02em;
    display:flex;
    align-items:center;
    gap:8px;
}
.tp2-card-toggle{
    width:28px;height:28px;
    display:flex;align-items:center;justify-content:center;
    background:#F3F4F6;
    border-radius:50%;
    transition:transform 0.2s;
}
.tp2-card.collapsed .tp2-card-toggle{transform:rotate(-90deg)}
.tp2-card-body{padding:0 16px 16px}
.tp2-card.collapsed .tp2-card-body{display:none}

/* Always expanded on desktop */
@media(min-width:768px){
    .tp2-card-toggle{display:none}
    .tp2-card.collapsed .tp2-card-body{display:block}
    .tp2-card-header{cursor:default}
    .tp2-card-header:active{background:transparent}
}

/* ============================================
   SPECIALTIES - Compact Pills
   ============================================ */
.tp2-specs{
    display:flex;
    flex-wrap:wrap;
    gap:8px;
}
.tp2-spec{
    padding:8px 14px;
    background:#F8FAFC;
    border:1px solid #E5E7EB;
    border-radius:20px;
    font-size:13px;
    font-weight:600;
    color:#374151;
}

/* ============================================
   LOCATIONS - Touch-Friendly List
   ============================================ */
.tp2-location{
    display:flex;
    align-items:center;
    gap:12px;
    padding:14px;
    background:#F8FAFC;
    border-radius:10px;
    margin-bottom:8px;
}
.tp2-location:last-child{margin-bottom:0}
.tp2-location-icon{
    width:44px;height:44px;
    background:#FCB900;
    border-radius:10px;
    display:flex;align-items:center;justify-content:center;
    flex-shrink:0;
}
.tp2-location-name{font-weight:700;font-size:15px;color:#0A0A0A}
.tp2-location-addr{font-size:13px;color:#6B7280}

/* ============================================
   FAQ ACCORDION
   ============================================ */
.tp2-faq{
    border:1px solid #E5E7EB;
    border-radius:10px;
    margin-bottom:8px;
    overflow:hidden;
}
.tp2-faq:last-child{margin-bottom:0}
.tp2-faq-q{
    display:flex;
    align-items:center;
    justify-content:space-between;
    padding:16px;
    font-weight:600;
    font-size:14px;
    cursor:pointer;
    min-height:56px;
    gap:12px;
}
.tp2-faq-q:active{background:#F9FAFB}
.tp2-faq-icon{transition:transform 0.2s;flex-shrink:0}
.tp2-faq.open .tp2-faq-icon{transform:rotate(180deg)}
.tp2-faq-a{
    display:none;
    padding:0 16px 16px;
    font-size:14px;
    color:#4B5563;
    line-height:1.7;
}
.tp2-faq.open .tp2-faq-a{display:block}

/* ============================================
   GALLERY - 2 Column on Mobile
   ============================================ */
.tp2-gallery{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:8px;
}
.tp2-gallery-item{
    aspect-ratio:1;
    border-radius:10px;
    overflow:hidden;
    cursor:pointer;
    border:2px solid #E5E7EB;
}
.tp2-gallery-item img{
    width:100%;height:100%;
    object-fit:cover;
    transition:transform 0.3s;
}
.tp2-gallery-item:active img{transform:scale(1.05)}

/* ============================================
   MESSAGE FORM
   ============================================ */
.tp2-msg-input{
    width:100%;
    padding:14px;
    border:2px solid #E5E7EB;
    border-radius:10px;
    font-size:15px;
    font-family:inherit;
    resize:none;
    min-height:100px;
}
.tp2-msg-input:focus{
    outline:none;
    border-color:#FCB900;
}
.tp2-msg-btn{
    width:100%;
    padding:16px;
    margin-top:12px;
    background:#0A0A0A;
    color:#fff;
    border:none;
    border-radius:10px;
    font-family:'Oswald',sans-serif;
    font-size:15px;
    font-weight:700;
    text-transform:uppercase;
    cursor:pointer;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    min-height:52px;
}
.tp2-msg-btn:active{background:#1a1a1a}

/* Schedule Call Button */
.tp2-schedule-btn{
    width:100%;
    padding:16px;
    background:#FCB900;
    color:#0A0A0A;
    border:2px solid #0A0A0A;
    border-radius:10px;
    font-family:'Oswald',sans-serif;
    font-size:15px;
    font-weight:700;
    text-transform:uppercase;
    cursor:pointer;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    min-height:52px;
    transition:all 0.2s;
}
.tp2-schedule-btn:hover{background:#e5a800}
.tp2-schedule-btn:active{transform:scale(0.98)}

/* Contact Modal */
.tp2-contact-modal{
    display:none;
    position:fixed;
    top:0;left:0;right:0;bottom:0;
    background:rgba(0,0,0,0.7);
    z-index:9999;
    align-items:center;
    justify-content:center;
    padding:20px;
    backdrop-filter:blur(4px);
    -webkit-backdrop-filter:blur(4px);
}
.tp2-contact-modal.show{display:flex}
.tp2-contact-content{
    background:#fff;
    border-radius:20px;
    max-width:400px;
    width:100%;
    padding:32px 24px;
    text-align:center;
    position:relative;
    animation:modalSlide 0.3s ease;
}
@keyframes modalSlide{
    from{opacity:0;transform:translateY(20px)}
    to{opacity:1;transform:translateY(0)}
}
.tp2-contact-close{
    position:absolute;
    top:16px;right:16px;
    width:32px;height:32px;
    border:none;
    background:#F3F4F6;
    border-radius:50%;
    cursor:pointer;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:20px;
    color:#6B7280;
}
.tp2-contact-close:hover{background:#E5E7EB}
.tp2-contact-icon{
    width:64px;height:64px;
    background:#FCB900;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    margin:0 auto 20px;
}
.tp2-contact-title{
    font-family:'Oswald',sans-serif;
    font-size:24px;
    font-weight:700;
    text-transform:uppercase;
    margin:0 0 8px;
    color:#0A0A0A;
}
.tp2-contact-subtitle{
    font-size:14px;
    color:#6B7280;
    margin:0 0 24px;
    line-height:1.5;
}
.tp2-contact-phone{
    font-family:'Oswald',sans-serif;
    font-size:28px;
    font-weight:700;
    color:#0A0A0A;
    margin:0 0 24px;
    letter-spacing:0.02em;
}
.tp2-contact-actions{
    display:flex;
    gap:12px;
}
.tp2-contact-btn{
    flex:1;
    padding:14px;
    border-radius:10px;
    font-family:'Oswald',sans-serif;
    font-size:14px;
    font-weight:700;
    text-transform:uppercase;
    cursor:pointer;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:6px;
    text-decoration:none;
    transition:all 0.2s;
}
.tp2-contact-btn.text.primary{
    background:#FCB900;
    color:#0A0A0A;
    border:2px solid #0A0A0A;
    padding:16px 24px;
}
.tp2-contact-btn.text.primary:hover{background:#e5a800}
.tp2-contact-btn.text.primary:active{transform:scale(0.98)}
.tp2-contact-btn.call{
    background:#0A0A0A;
    color:#fff;
    border:2px solid #0A0A0A;
}
.tp2-contact-btn.call:hover{background:#1a1a1a}
.tp2-contact-btn.text{
    background:#fff;
    color:#0A0A0A;
    border:2px solid #0A0A0A;
}
.tp2-contact-btn.text:hover{background:#F3F4F6}
.tp2-contact-hours{
    margin-top:20px;
    padding-top:20px;
    border-top:1px solid #E5E7EB;
    font-size:13px;
    color:#6B7280;
}

/* ============================================
   REVIEWS
   ============================================ */
.tp2-review{
    padding:16px 0;
    border-bottom:1px solid #E5E7EB;
}
.tp2-review:last-child{border-bottom:none}
.tp2-review-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:8px;
}
.tp2-review-name{font-weight:700;font-size:15px}
.tp2-review-stars{display:flex;gap:2px}
.tp2-review-text{font-size:14px;color:#4B5563;line-height:1.6}

.tp2-no-reviews{
    text-align:center;
    padding:32px 20px;
    background:#F8FAFC;
    border-radius:12px;
}
.tp2-no-reviews-icon{
    width:56px;height:56px;
    margin:0 auto 12px;
    background:#FEF3C7;
    border-radius:50%;
    display:flex;align-items:center;justify-content:center;
}

/* ============================================
   BOOKING SIDEBAR - MOBILE FIRST
   ============================================ */
.tp2-booking{
    display:block; /* Show on mobile */
    order:-1; /* Appear first on mobile */
}
.tp2-booking .tp2-book-card{
    border-radius:12px;
    padding:16px;
    border:2px solid #E5E7EB;
    background:#fff;
}

/* ============================================
   STICKY BOOKING BAR (Mobile)
   ============================================ */
.tp2-sticky{
    position:fixed;
    bottom:0;
    left:0;
    right:0;
    background:#fff;
    padding:12px 16px;
    box-shadow:0 -4px 20px rgba(0,0,0,0.1);
    z-index:1000;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
}
.tp2-sticky-price{
    display:flex;
    flex-direction:column;
}
.tp2-sticky-amount{
    font-family:'Oswald',sans-serif;
    font-size:22px;
    font-weight:700;
    color:#0A0A0A;
    line-height:1;
}
.tp2-sticky-unit{font-size:12px;color:#6B7280}
.tp2-sticky-cta{
    flex:1;
    max-width:200px;
    padding:14px 24px;
    background:#FCB900;
    color:#0A0A0A;
    font-family:'Oswald',sans-serif;
    font-size:15px;
    font-weight:700;
    text-transform:uppercase;
    border:none;
    border-radius:8px;
    cursor:pointer;
    text-align:center;
    text-decoration:none;
    display:block;
}
.tp2-sticky-cta:active{background:#E5A800}

/* ============================================
   DESKTOP ENHANCEMENTS
   ============================================ */
@media(min-width:768px){
    .tp2-hero{padding:40px 24px 48px}
    .tp2-hero-card{gap:32px;align-items:center}
    .tp2-hero-photo{width:200px;height:260px}
    .tp2-hero-name{font-size:36px}
    .tp2-hero-headline{font-size:16px;-webkit-line-clamp:3}
    .tp2-hero-meta{font-size:15px;gap:20px}
    .tp2-price-amount{font-size:36px}
    
    .tp2-main{padding:32px 24px 140px}
    .tp2-grid{
        grid-template-columns:1fr 380px;
        gap:24px;
    }
    .tp2-info-column{
        order:0; /* Reset order on desktop */
    }
    .tp2-card{border-radius:16px}
    .tp2-card-header{padding:20px}
    .tp2-card-body{padding:0 20px 20px}
    
    .tp2-gallery{grid-template-columns:repeat(3,1fr);gap:12px}
    
    /* Desktop booking sidebar */
    .tp2-booking{
        display:block;
        order:0; /* Reset order on desktop */
        position:sticky;
        top:20px;
    }
    .tp2-booking .tp2-book-card{
        border-radius:16px;
        padding:24px;
    }
    .tp2-sticky{display:none}
}

@media(min-width:1024px){
    .tp2-hero-card{gap:40px}
    .tp2-hero-photo{width:240px;height:310px}
    .tp2-hero-name{font-size:42px}
    .tp2-grid{grid-template-columns:1fr 420px}
}

/* ============================================
   BOOKING WIDGET STYLES
   ============================================ */
.tp2-book-card{
    background:#fff;
    border:2px solid #E5E7EB;
    border-radius:12px;
    padding:16px;
}
.tp2-book-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:16px;
}
.tp2-book-price{
    font-family:'Oswald',sans-serif;
    font-size:28px;
    font-weight:700;
}
.tp2-book-avail{
    display:flex;align-items:center;gap:5px;
    padding:6px 12px;
    background:#D1FAE5;
    border-radius:16px;
    font-size:12px;
    font-weight:700;
    color:#059669;
}
.tp2-book-avail::before{
    content:'';
    width:6px;height:6px;
    background:#059669;
    border-radius:50%;
}

/* Package Selection */
.tp2-packages{margin-bottom:16px}
.tp2-package{
    padding:12px 14px;
    border:2px solid #E5E7EB;
    border-radius:10px;
    cursor:pointer;
    margin-bottom:8px;
    transition:all 0.15s;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.tp2-package:hover{border-color:#FCB900;background:#FFFBEB}
.tp2-package.selected{border-color:#FCB900;background:#FEF3C7}
.tp2-package:last-child{margin-bottom:0}
.tp2-package-name{font-weight:700;font-size:14px}
.tp2-package-desc{font-size:12px;color:#6B7280}
.tp2-package-price{font-family:'Oswald',sans-serif;font-size:16px;font-weight:700}
.tp2-package-badge{
    display:inline-block;
    background:#059669;
    color:#fff;
    font-size:9px;
    font-weight:700;
    padding:2px 6px;
    border-radius:8px;
    margin-left:6px;
    text-transform:uppercase;
}

/* Desktop sizing */
@media(min-width:768px){
    .tp2-book-card{
        border-radius:16px;
        padding:24px;
    }
    .tp2-book-header{margin-bottom:20px}
    .tp2-book-price{font-size:32px}
    .tp2-book-avail{padding:8px 14px;font-size:13px}
    .tp2-packages{margin-bottom:20px}
    .tp2-package{padding:16px}
    .tp2-package-name{font-size:15px}
    .tp2-package-desc{font-size:13px}
    .tp2-package-price{font-size:18px}
    .tp2-package-badge{font-size:10px;padding:3px 8px}
}

/* Calendar */
.tp2-cal-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:16px;
}
.tp2-cal-month{
    font-family:'Oswald',sans-serif;
    font-size:16px;
    font-weight:700;
    text-transform:uppercase;
}
.tp2-cal-nav{
    display:flex;gap:8px;
}
.tp2-cal-btn{
    width:32px;height:32px;
    border:1px solid #E5E7EB;
    border-radius:8px;
    background:#fff;
    cursor:pointer;
    display:flex;align-items:center;justify-content:center;
}
.tp2-cal-btn:hover{background:#F3F4F6}

.tp2-cal-days{
    display:grid;
    grid-template-columns:repeat(7,1fr);
    gap:4px;
    margin-bottom:8px;
    text-align:center;
    font-size:11px;
    font-weight:600;
    color:#9CA3AF;
    text-transform:uppercase;
}
.tp2-cal{
    display:grid;
    grid-template-columns:repeat(7,1fr);
    gap:4px;
}
.tp2-cal-day{
    aspect-ratio:1;
    display:flex;align-items:center;justify-content:center;
    font-size:14px;
    font-weight:600;
    border-radius:8px;
    cursor:pointer;
    transition:all 0.15s;
}
.tp2-cal-day.available{background:#FFFBEB}
.tp2-cal-day.available:hover{background:#FEF3C7}
.tp2-cal-day.selected{background:#FCB900!important}
.tp2-cal-day.disabled{color:#D1D5DB;cursor:default;background:transparent}

/* Time slots */
.tp2-slots{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:8px;
    margin-top:16px;
}
.tp2-slot{
    padding:12px;
    border:1px solid #E5E7EB;
    border-radius:8px;
    text-align:center;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    transition:all 0.15s;
}
.tp2-slot:hover{border-color:#FCB900;background:#FFFBEB}
.tp2-slot.selected{border-color:#FCB900;background:#FCB900}

/* Book button */
.tp2-book-btn{
    width:100%;
    padding:16px;
    margin-top:20px;
    background:#FCB900;
    color:#0A0A0A;
    border:none;
    border-radius:10px;
    font-family:'Oswald',sans-serif;
    font-size:16px;
    font-weight:700;
    text-transform:uppercase;
    cursor:pointer;
    transition:all 0.2s;
}
.tp2-book-btn:hover{background:#E5A800;transform:translateY(-1px)}
.tp2-book-btn:disabled{opacity:0.5;cursor:not-allowed;transform:none}

/* Lightbox */
.tp2-lightbox{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,0.95);
    z-index:9999;
    align-items:center;
    justify-content:center;
    padding:20px;
}
.tp2-lightbox.active{display:flex}
.tp2-lightbox-close{
    position:absolute;
    top:16px;
    right:16px;
    width:44px;height:44px;
    background:rgba(255,255,255,0.1);
    border:none;
    border-radius:50%;
    color:#fff;
    font-size:24px;
    cursor:pointer;
}
.tp2-lightbox-close:hover{background:#FCB900;color:#0A0A0A}
.tp2-lightbox-img{
    max-width:90vw;
    max-height:85vh;
    object-fit:contain;
    border-radius:8px;
}
.tp2-lightbox-nav{
    position:absolute;
    top:50%;
    transform:translateY(-50%);
    width:44px;height:44px;
    background:rgba(255,255,255,0.1);
    border:none;
    border-radius:50%;
    color:#fff;
    font-size:20px;
    cursor:pointer;
}
.tp2-lightbox-nav:hover{background:#FCB900;color:#0A0A0A}
.tp2-lightbox-prev{left:16px}
.tp2-lightbox-next{right:16px}
</style>

<div class="tp2">
    <!-- HERO SECTION -->
    <div class="tp2-hero">
        <div class="tp2-hero-inner">
            <div class="tp2-hero-card">
                <div class="tp2-hero-photo">
                    <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>">
                </div>
                <div class="tp2-hero-info">
                    <div class="tp2-hero-badges">
                        <?php if ($level_label): ?>
                        <span class="tp2-badge tp2-badge-level">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <?php echo esc_html($level_label); ?> Athlete
                        </span>
                        <?php endif; ?>
                        <?php if (!$has_reviews): ?>
                        <span class="tp2-badge tp2-badge-new">New</span>
                        <?php endif; ?>
                        <?php if ($happy_score >= 80): ?>
                        <span class="tp2-badge tp2-badge-score"><?php echo $happy_score; ?>%</span>
                        <?php endif; ?>
                    </div>
                    
                    <h1 class="tp2-hero-name"><?php echo esc_html($trainer->display_name); ?></h1>
                    
                    <?php if ($headline): ?>
                    <p class="tp2-hero-headline"><?php echo esc_html($headline); ?></p>
                    <?php endif; ?>
                    
                    <div class="tp2-hero-meta">
                        <?php if ($has_reviews): ?>
                        <span style="display:flex;align-items:center;gap:4px">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="#FCB900"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <strong style="color:#fff"><?php echo esc_html($rating); ?></strong>
                            <span>(<?php echo $review_count; ?>)</span>
                        </span>
                        <?php endif; ?>
                        <span style="display:flex;align-items:center;gap:4px">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#FCB900" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            <?php echo esc_html($location); ?>
                        </span>
                    </div>
                    
                    <?php if ($instagram || $facebook): ?>
                    <div class="tp2-social">
                        <?php if ($instagram): 
                            $insta_url = strpos($instagram, 'http') === 0 ? $instagram : 'https://instagram.com/' . ltrim($instagram, '@');
                        ?>
                        <a href="<?php echo esc_url($insta_url); ?>" target="_blank" rel="noopener">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                        </a>
                        <?php endif; ?>
                        <?php if ($facebook): 
                            $fb_url = strpos($facebook, 'http') === 0 ? $facebook : 'https://facebook.com/' . $facebook;
                        ?>
                        <a href="<?php echo esc_url($fb_url); ?>" target="_blank" rel="noopener">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <!-- Share Button -->
                    <div class="tp2-share-row" style="margin-top:12px">
                        <?php if (class_exists('PTP_Growth')) { PTP_Growth::render_share_button(); } ?>
                    </div>
                    
                    <div class="tp2-hero-actions">
                        <div class="tp2-price">
                            <span class="tp2-price-amount">$<?php echo $rate; ?></span>
                            <span class="tp2-price-unit">/hour</span>
                        </div>
                        <button class="tp2-hero-cta" onclick="scrollToBooking()">
                            Book Now
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- TRUST BAR -->
    <div class="tp2-trust">
        <div class="tp2-trust-inner">
            <div class="tp2-trust-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                SafeSport Certified
            </div>
            <div class="tp2-trust-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                Background Verified
            </div>
            <div class="tp2-trust-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                Secure Payment
            </div>
            <div class="tp2-trust-item">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                Verified Athlete
            </div>
        </div>
    </div>
    
    <!-- MAIN CONTENT -->
    <div class="tp2-main">
        <div class="tp2-grid">
            <!-- LEFT COLUMN - Info Cards -->
            <div class="tp2-info-column">
                <!-- About -->
                <div class="tp2-card">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            About <?php echo esc_html($first_name); ?>
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <?php if ($bio): ?>
                        <p style="font-size:15px;line-height:1.75;color:#4B5563"><?php echo nl2br(esc_html($bio)); ?></p>
                        <?php else: ?>
                        <p style="font-size:15px;line-height:1.75;color:#4B5563">
                            <?php echo esc_html($first_name); ?> is a <?php echo $level_label ? strtolower($level_label) . ' level' : 'professional'; ?> trainer 
                            <?php echo $trainer->college ? 'from ' . esc_html($trainer->college) : ''; ?> specializing in personalized 1-on-1 training.
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Specialties -->
                <?php if (!empty($specialties)): ?>
                <div class="tp2-card collapsed">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
                            Specialties
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <div class="tp2-specs">
                            <?php foreach ($specialties as $spec): 
                                $label = isset($specialty_labels[$spec]) ? $specialty_labels[$spec] : ucfirst(str_replace('_', ' ', $spec));
                            ?>
                            <span class="tp2-spec"><?php echo esc_html($label); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Training Locations -->
                <div class="tp2-card collapsed">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            Training Locations
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <?php foreach ($training_locations as $loc): ?>
                        <div class="tp2-location">
                            <div class="tp2-location-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0A0A0A" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            </div>
                            <div>
                                <div class="tp2-location-name"><?php echo esc_html($loc['name']); ?></div>
                                <?php if (!empty($loc['address']) && $loc['address'] !== $loc['name']): ?>
                                <div class="tp2-location-addr"><?php echo esc_html($loc['address']); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <!-- Gallery -->
                <?php if (!empty($gallery)): ?>
                <div class="tp2-card collapsed">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
                            Action Shots
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <div class="tp2-gallery">
                            <?php foreach ($gallery as $i => $image): 
                                $img_url = is_array($image) ? ($image['url'] ?? '') : $image;
                                if (empty($img_url)) continue;
                            ?>
                            <div class="tp2-gallery-item" onclick="openGallery(<?php echo $i; ?>)">
                                <img src="<?php echo esc_url($img_url); ?>" alt="<?php echo esc_attr($first_name); ?> training" loading="lazy">
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- FAQs -->
                <?php if (!empty($admin_faqs) || !empty($trainer_faqs)): ?>
                <div class="tp2-card collapsed">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                            FAQs
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <?php foreach (array_merge($admin_faqs, $trainer_faqs) as $faq): ?>
                        <div class="tp2-faq" onclick="toggleFaq(this)">
                            <div class="tp2-faq-q">
                                <span><?php echo esc_html($faq['question']); ?></span>
                                <svg class="tp2-faq-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                            </div>
                            <div class="tp2-faq-a"><?php echo wp_kses_post($faq['answer']); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Message -->
                <div class="tp2-card">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                            Message <?php echo esc_html($first_name); ?>
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <?php if ($is_logged_in): ?>
                        <form id="tp2-message-form">
                            <textarea class="tp2-msg-input" id="tp2-message" placeholder="Hi <?php echo esc_attr($first_name); ?>, I'm interested in training sessions..."><?php echo isset($_GET['msg']) ? esc_textarea($_GET['msg']) : ''; ?></textarea>
                            <button type="submit" class="tp2-msg-btn" id="tp2-send-btn">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
                                Send Message
                            </button>
                        </form>
                        <div id="tp2-msg-success" style="display:none;text-align:center;padding:20px;background:#D1FAE5;border-radius:10px">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2" style="margin:0 auto 8px;display:block"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <p style="font-weight:700;color:#059669;margin:0">Message sent!</p>
                        </div>
                        <?php else: ?>
                        <p style="font-size:14px;color:#6B7280;margin-bottom:12px">Log in to send a message</p>
                        <a href="<?php echo esc_url(home_url('/login/?redirect=' . urlencode($_SERVER['REQUEST_URI']))); ?>" class="tp2-msg-btn" style="text-decoration:none;display:flex">
                            Log In to Message
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Text Us -->
                <div class="tp2-card">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                            Questions? Text Us
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <p style="font-size:14px;color:#6B7280;margin:0 0 16px;line-height:1.5">Have questions before booking? Text us and we'll help you find the perfect training fit.</p>
                        <button type="button" class="tp2-schedule-btn" onclick="openContactModal()">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                            Text Us Now
                        </button>
                    </div>
                </div>
                
                <!-- Reviews -->
                <div class="tp2-card">
                    <div class="tp2-card-header" onclick="toggleCard(this)">
                        <h2 class="tp2-card-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="#FCB900"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            Reviews<?php echo $has_reviews ? ' (' . $review_count . ')' : ''; ?>
                        </h2>
                        <span class="tp2-card-toggle">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 12 15 18 9"/></svg>
                        </span>
                    </div>
                    <div class="tp2-card-body">
                        <?php if (!empty($reviews)): ?>
                            <?php foreach (array_slice($reviews, 0, 5) as $review): ?>
                            <div class="tp2-review">
                                <div class="tp2-review-header">
                                    <span class="tp2-review-name"><?php echo esc_html($review->reviewer_name ?: 'Parent'); ?></span>
                                    <div class="tp2-review-stars">
                                        <?php for ($s = 1; $s <= 5; $s++): ?>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="<?php echo $s <= $review->rating ? '#FCB900' : '#E5E7EB'; ?>"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                        <?php endfor; ?>
                                    </div>
                                </div>
                                <p class="tp2-review-text"><?php echo esc_html($review->comment); ?></p>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                        <div class="tp2-no-reviews">
                            <div class="tp2-no-reviews-icon">
                                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            </div>
                            <p style="font-weight:700;font-size:16px;margin-bottom:4px">No Reviews Yet</p>
                            <p style="font-size:14px;color:#6B7280">Be the first to train with <?php echo esc_html($first_name); ?>!</p>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <!-- RIGHT COLUMN - BOOKING (Desktop) -->
            <div class="tp2-booking" id="booking-section">
                <div class="tp2-book-card">
                    <div class="tp2-book-header">
                        <div class="tp2-book-price">$<?php echo $rate; ?><span style="font-size:16px;font-weight:400;color:#6B7280">/hr</span></div>
                        <div class="tp2-book-avail">Available</div>
                    </div>
                    
                    <!-- Package Selection -->
                    <div class="tp2-packages">
                        <div class="tp2-package selected" data-type="single" data-price="<?php echo $rate; ?>" onclick="selectPackage(this)">
                            <div>
                                <div class="tp2-package-name">Single Session</div>
                                <div class="tp2-package-desc">1 hour training</div>
                            </div>
                            <div class="tp2-package-price">$<?php echo $rate; ?></div>
                        </div>
                        <div class="tp2-package" data-type="5pack" data-price="<?php echo $rate_5pack; ?>" onclick="selectPackage(this)">
                            <div>
                                <div class="tp2-package-name">5-Session Pack<span class="tp2-package-badge">Save 10%</span></div>
                                <div class="tp2-package-desc">$<?php echo round($rate * 0.90); ?>/session</div>
                            </div>
                            <div class="tp2-package-price">$<?php echo $rate_5pack; ?></div>
                        </div>
                        <div class="tp2-package" data-type="10pack" data-price="<?php echo $rate_10pack; ?>" onclick="selectPackage(this)">
                            <div>
                                <div class="tp2-package-name">10-Session Pack<span class="tp2-package-badge">Save 15%</span></div>
                                <div class="tp2-package-desc">$<?php echo round($rate * 0.85); ?>/session</div>
                            </div>
                            <div class="tp2-package-price">$<?php echo $rate_10pack; ?></div>
                        </div>
                    </div>
                    
                    <!-- Calendar -->
                    <div class="tp2-cal-header">
                        <div class="tp2-cal-month" id="cal-month"></div>
                        <div class="tp2-cal-nav">
                            <button class="tp2-cal-btn" onclick="calPrev()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                            </button>
                            <button class="tp2-cal-btn" onclick="calNext()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="tp2-cal-days">
                        <div>S</div><div>M</div><div>T</div><div>W</div><div>T</div><div>F</div><div>S</div>
                    </div>
                    <div class="tp2-cal" id="cal-days"></div>
                    
                    <!-- Time Slots -->
                    <div id="slots-section" style="display:none;margin-top:20px">
                        <div style="font-family:Oswald,sans-serif;font-size:14px;font-weight:700;text-transform:uppercase;margin-bottom:12px;color:#6B7280">Select Time</div>
                        <div class="tp2-slots" id="time-slots"></div>
                    </div>
                    
                    <!-- Location -->
                    <div id="loc-section" style="display:none;margin-top:20px">
                        <div style="font-family:Oswald,sans-serif;font-size:14px;font-weight:700;text-transform:uppercase;margin-bottom:12px;color:#6B7280">Select Location</div>
                        <div id="locations-list">
                            <?php foreach ($training_locations as $loc): ?>
                            <div class="tp2-package" data-name="<?php echo esc_attr($loc['name']); ?>" onclick="selectLocation(this)" style="margin-bottom:8px">
                                <div style="display:flex;align-items:center;gap:12px">
                                    <div style="width:40px;height:40px;background:#F3F4F6;border-radius:8px;display:flex;align-items:center;justify-content:center">
                                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6B7280" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                    </div>
                                    <div>
                                        <div style="font-weight:700;font-size:14px"><?php echo esc_html($loc['name']); ?></div>
                                        <?php if (!empty($loc['address'])): ?>
                                        <div style="font-size:12px;color:#6B7280"><?php echo esc_html($loc['address']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <button class="tp2-book-btn" id="book-btn" disabled onclick="bookSession()">Select Date & Time</button>
                    
                    <p style="text-align:center;font-size:12px;color:#6B7280;margin-top:12px">Free cancellation 24hrs before</p>
                    
                    <!-- Social Proof -->
                    <div style="margin-top:16px;padding:12px;background:#F9FAFB;border-radius:10px;display:flex;align-items:center;gap:10px">
                        <div style="display:flex">
                            <div style="width:28px;height:28px;background:#FCB900;border-radius:50%;display:flex;align-items:center;justify-content:center;border:2px solid #fff">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#0A0A0A" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            </div>
                        </div>
                        <div style="flex:1;font-size:12px;color:#4B5563">
                            <strong style="color:#111"><?php echo rand(3, 8); ?> parents</strong> booked <?php echo esc_html($first_name); ?> this week
                        </div>
                    </div>
                    
                    <!-- Questions? Text Us -->
                    <div style="margin-top:12px;text-align:center">
                        <a href="#" onclick="openContactModal();return false;" style="font-size:13px;color:#6B7280;text-decoration:none;display:inline-flex;align-items:center;gap:6px">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                            Questions? <span style="color:#FCB900;font-weight:600">Text us</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- CAMPS & CLINICS CROSS-SELL -->
    <?php 
    if (function_exists('ptp_render_camps_crosssell')) {
        ptp_render_camps_crosssell(array(
            'limit' => 6,
            'title' => 'Camps & Clinics',
            'subtitle' => 'Level up with our group training programs',
            'context' => 'trainer_profile',
            'show_view_all' => true,
        ));
    }
    ?>
    
    <!-- REFERRAL BANNER (logged in users only) -->
    <?php 
    if (function_exists('ptp_render_referral_banner')) {
        echo '<div style="max-width:800px;margin:0 auto;padding:0 16px">';
        ptp_render_referral_banner();
        echo '</div>';
    }
    ?>
    
    <!-- STICKY MOBILE BAR -->
    <div class="tp2-sticky">
        <div class="tp2-sticky-price">
            <span class="tp2-sticky-amount">$<?php echo $rate; ?></span>
            <span class="tp2-sticky-unit">per hour</span>
        </div>
        <a href="<?php echo home_url('/book-session/?trainer_id=' . $trainer->id); ?>" class="tp2-sticky-cta">Book Now</a>
    </div>
</div>

<!-- Lightbox -->
<?php if (!empty($gallery)): ?>
<div id="tp2-lightbox" class="tp2-lightbox" onclick="if(event.target===this)closeLightbox()">
    <button class="tp2-lightbox-close" onclick="closeLightbox()">&times;</button>
    <button class="tp2-lightbox-nav tp2-lightbox-prev" onclick="prevImage()">&#10094;</button>
    <img id="tp2-lightbox-img" class="tp2-lightbox-img" src="">
    <button class="tp2-lightbox-nav tp2-lightbox-next" onclick="nextImage()">&#10095;</button>
</div>
<?php endif; ?>

<!-- Contact Modal -->
<div id="tp2-contact-modal" class="tp2-contact-modal" onclick="if(event.target===this)closeContactModal()">
    <div class="tp2-contact-content">
        <button class="tp2-contact-close" onclick="closeContactModal()">&times;</button>
        <div class="tp2-contact-icon">
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#0A0A0A" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
        </div>
        <h3 class="tp2-contact-title">Text Us</h3>
        <p class="tp2-contact-subtitle">Have questions about training with <?php echo esc_html($first_name); ?>? Send us a text and we'll get back to you quickly!</p>
        <p class="tp2-contact-phone">(484) 572-4770</p>
        <div class="tp2-contact-actions">
            <a href="sms:+14845724770?body=Hi! I have a question about training with <?php echo urlencode($first_name); ?>..." class="tp2-contact-btn text primary">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                Send a Text
            </a>
        </div>
        <p class="tp2-contact-hours">💬 We typically respond within a few hours</p>
    </div>
</div>

<script>
// Booking state
var trainerId = <?php echo (int)$trainer->id; ?>;
var baseRate = <?php echo $rate; ?>;
var selectedType = 'single';
var selectedPrice = baseRate;
var selectedDate = null;
var selectedTime = null;
var selectedLoc = null;
var calMonth = new Date().getMonth();
var calYear = new Date().getFullYear();

// Card toggle (mobile)
function toggleCard(header) {
    if (window.innerWidth >= 768) return;
    header.parentElement.classList.toggle('collapsed');
}

// FAQ toggle
function toggleFaq(el) {
    el.classList.toggle('open');
}

// Contact modal
function openContactModal() {
    document.getElementById('tp2-contact-modal').classList.add('show');
    document.body.style.overflow = 'hidden';
}

function closeContactModal() {
    document.getElementById('tp2-contact-modal').classList.remove('show');
    document.body.style.overflow = '';
}

// Close modal on escape key
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        closeContactModal();
    }
});

// Scroll to booking
function scrollToBooking() {
    document.getElementById('booking-section').scrollIntoView({behavior:'smooth',block:'start'});
}

// Package selection
function selectPackage(el) {
    document.querySelectorAll('.tp2-package[data-type]').forEach(p => p.classList.remove('selected'));
    el.classList.add('selected');
    selectedType = el.dataset.type;
    selectedPrice = parseInt(el.dataset.price);
    updateBookBtn();
}

// Calendar
function renderCal() {
    var months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
    document.getElementById('cal-month').textContent = months[calMonth] + ' ' + calYear;
    
    var first = new Date(calYear, calMonth, 1).getDay();
    var days = new Date(calYear, calMonth + 1, 0).getDate();
    var now = new Date();
    now.setHours(0,0,0,0);
    
    var html = '';
    for (var i = 0; i < first; i++) html += '<div></div>';
    for (var d = 1; d <= days; d++) {
        var dt = new Date(calYear, calMonth, d);
        var str = calYear + '-' + String(calMonth + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
        var past = dt < now;
        var cls = 'tp2-cal-day' + (past ? ' disabled' : ' available') + (selectedDate === str ? ' selected' : '');
        html += '<div class="' + cls + '" data-d="' + str + '" onclick="pickDate(\'' + str + '\')">' + d + '</div>';
    }
    document.getElementById('cal-days').innerHTML = html;
}
function calPrev() { calMonth--; if (calMonth < 0) { calMonth = 11; calYear--; } renderCal(); }
function calNext() { calMonth++; if (calMonth > 11) { calMonth = 0; calYear++; } renderCal(); }

function pickDate(d) {
    if (document.querySelector('[data-d="' + d + '"]').classList.contains('disabled')) return;
    selectedDate = d;
    selectedTime = null;
    selectedLoc = null;
    document.querySelectorAll('.tp2-cal-day').forEach(el => el.classList.remove('selected'));
    document.querySelector('[data-d="' + d + '"]').classList.add('selected');
    loadSlots(d);
    updateBookBtn();
}

function loadSlots(d) {
    document.getElementById('slots-section').style.display = 'block';
    document.getElementById('time-slots').innerHTML = '<div style="grid-column:span 3;text-align:center;padding:16px;color:#6B7280">Loading...</div>';
    
    fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=ptp_get_available_slots&trainer_id=' + trainerId + '&date=' + d)
    .then(r => r.json())
    .then(data => {
        var slots = data.data?.slots || data.data || [];
        if (data.success && slots.length) {
            var html = '';
            slots.forEach(s => {
                if (s.available) html += '<div class="tp2-slot" onclick="pickTime(\'' + s.time + '\',this)">' + s.display + '</div>';
            });
            document.getElementById('time-slots').innerHTML = html || '<div style="grid-column:span 3;text-align:center;padding:16px;color:#6B7280">No available times</div>';
        } else {
            document.getElementById('time-slots').innerHTML = '<div style="grid-column:span 3;text-align:center;padding:16px;color:#6B7280">No available times</div>';
        }
    });
}

function pickTime(t, el) {
    document.querySelectorAll('.tp2-slot').forEach(s => s.classList.remove('selected'));
    el.classList.add('selected');
    selectedTime = t;
    selectedLoc = null;
    document.getElementById('loc-section').style.display = 'block';
    document.querySelectorAll('#locations-list .tp2-package').forEach(l => l.classList.remove('selected'));
    updateBookBtn();
}

function selectLocation(el) {
    document.querySelectorAll('#locations-list .tp2-package').forEach(l => l.classList.remove('selected'));
    el.classList.add('selected');
    selectedLoc = el.dataset.name;
    updateBookBtn();
}

function updateBookBtn() {
    var btn = document.getElementById('book-btn');
    if (selectedDate && selectedTime && selectedLoc) {
        btn.disabled = false;
        btn.textContent = 'Book - $' + selectedPrice;
    } else if (selectedDate && selectedTime) {
        btn.disabled = true;
        btn.textContent = 'Select Location';
    } else if (selectedDate) {
        btn.disabled = true;
        btn.textContent = 'Select Time';
    } else {
        btn.disabled = true;
        btn.textContent = 'Select Date & Time';
    }
}

function bookSession() {
    if (selectedDate && selectedTime && selectedLoc) {
        // Check if we should show camp upsell
        if (typeof showCampUpsell === 'function' && !sessionStorage.getItem('ptp_upsell_shown')) {
            sessionStorage.setItem('ptp_upsell_shown', '1');
            sessionStorage.setItem('ptp_booking_url', '<?php echo home_url('/book-session/'); ?>?trainer_id=' + trainerId + '&date=' + selectedDate + '&time=' + encodeURIComponent(selectedTime) + '&location=' + encodeURIComponent(selectedLoc) + '&type=' + selectedType);
            showCampUpsell(selectedPrice);
            return;
        }
        window.location.href = '<?php echo home_url('/book-session/'); ?>?trainer_id=' + trainerId + '&date=' + selectedDate + '&time=' + encodeURIComponent(selectedTime) + '&location=' + encodeURIComponent(selectedLoc) + '&type=' + selectedType;
    }
}

// Gallery
<?php if (!empty($gallery)): ?>
var galleryImages = <?php echo json_encode(array_map(function($img) {
    return is_array($img) ? ($img['url'] ?? '') : $img;
}, $gallery)); ?>;
var currentIndex = 0;

function openGallery(i) {
    currentIndex = i;
    document.getElementById('tp2-lightbox-img').src = galleryImages[i];
    document.getElementById('tp2-lightbox').classList.add('active');
    document.body.style.overflow = 'hidden';
}
function closeLightbox() {
    document.getElementById('tp2-lightbox').classList.remove('active');
    document.body.style.overflow = '';
}
function prevImage() {
    currentIndex = (currentIndex - 1 + galleryImages.length) % galleryImages.length;
    document.getElementById('tp2-lightbox-img').src = galleryImages[currentIndex];
}
function nextImage() {
    currentIndex = (currentIndex + 1) % galleryImages.length;
    document.getElementById('tp2-lightbox-img').src = galleryImages[currentIndex];
}
document.addEventListener('keydown', function(e) {
    if (!document.getElementById('tp2-lightbox').classList.contains('active')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') prevImage();
    if (e.key === 'ArrowRight') nextImage();
});
<?php endif; ?>

// Messaging
<?php if ($is_logged_in): ?>
document.getElementById('tp2-message-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    var msg = document.getElementById('tp2-message').value.trim();
    if (!msg) return;
    var btn = document.getElementById('tp2-send-btn');
    btn.disabled = true;
    btn.innerHTML = 'Sending...';
    fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'action=ptp_send_public_message&nonce=<?php echo wp_create_nonce('ptp_nonce'); ?>&trainer_id=<?php echo $trainer->id; ?>&message=' + encodeURIComponent(msg)
    }).then(r => r.json()).then(data => {
        if (data.success) {
            document.getElementById('tp2-message-form').style.display = 'none';
            document.getElementById('tp2-msg-success').style.display = 'block';
        } else {
            alert(data.data?.message || 'Failed to send');
            btn.disabled = false;
            btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg> Send Message';
        }
    });
});
<?php endif; ?>

// Init
renderCal();
</script>

<?php get_footer(); ?>
