<?php
/**
 * Template: Booking Wizard - TeachMe.to Style 4-Step Funnel
 * Version 48.0.0
 * 
 * STEP 1: Location Selection
 * STEP 2: Date & Time Selection  
 * STEP 3: Package Selection
 * STEP 4: Checkout
 */
defined('ABSPATH') || exit;

// Trainer should be set from shortcode
if (!isset($trainer) || !$trainer) {
    return;
}

$logo_url = PTP_Images::logo();
$trainer_photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 200);
$first_name = explode(' ', $trainer->display_name)[0];
$base_rate = intval($trainer->hourly_rate ?: 80);

// Get locations
$locations = PTP_Booking_Wizard::get_locations($trainer->id);

// Get initial calendar data
$current_month = date('n');
$current_year = date('Y');
$available_dates = PTP_Booking_Wizard::get_available_dates($trainer->id, $current_month, $current_year);

// User state
$is_logged_in = is_user_logged_in();
$current_user = wp_get_current_user();

// Get Stripe key
$stripe_key = '';
if (class_exists('PTP_Stripe')) {
    PTP_Stripe::init();
    $stripe_key = PTP_Stripe::get_publishable_key();
}

// Google Maps API key
$maps_key = get_option('ptp_google_maps_key', '');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Book Training with <?php echo esc_html($trainer->display_name); ?> | PTP Training</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php if ($stripe_key): ?>
    <script src="https://js.stripe.com/v3/"></script>
    <?php endif; ?>
    <?php if ($maps_key): ?>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr($maps_key); ?>&libraries=places" async defer></script>
    <?php endif; ?>
    <style>
    /* ============================================
       PTP BOOKING WIZARD - BASE STYLES
       ============================================ */
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    :root {
        --gold: #FCB900;
        --gold-hover: #e5a800;
        --black: #0A0A0A;
        --white: #FFFFFF;
        --gray-50: #F9FAFB;
        --gray-100: #F3F4F6;
        --gray-200: #E5E7EB;
        --gray-400: #9CA3AF;
        --gray-500: #6B7280;
        --gray-600: #4B5563;
        --gray-700: #374151;
        --green: #059669;
        --green-bg: #D1FAE5;
        --red: #DC2626;
        --red-bg: #FEF2F2;
    }
    
    body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        background: var(--gray-50);
        color: var(--black);
        line-height: 1.5;
        -webkit-font-smoothing: antialiased;
    }
    
    .wizard-heading {
        font-family: 'Oswald', sans-serif;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        font-weight: 700;
    }
    
    /* ============================================
       HEADER
       ============================================ */
    .wizard-header {
        background: var(--black);
        padding: 16px 20px;
        position: sticky;
        top: 0;
        z-index: 100;
    }
    
    .wizard-header-inner {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .wizard-logo {
        height: 32px;
    }
    
    .wizard-back {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--gray-400);
        text-decoration: none;
        font-size: 14px;
        transition: color 0.2s;
    }
    
    .wizard-back:hover {
        color: var(--gold);
    }
    
    /* ============================================
       PROGRESS BAR
       ============================================ */
    .wizard-progress {
        background: var(--white);
        border-bottom: 1px solid var(--gray-200);
        padding: 0 20px;
    }
    
    .wizard-progress-inner {
        max-width: 1200px;
        margin: 0 auto;
        display: flex;
        gap: 0;
    }
    
    .wizard-step-indicator {
        flex: 1;
        padding: 16px 12px;
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 14px;
        color: var(--gray-400);
        position: relative;
        cursor: pointer;
        transition: all 0.2s;
    }
    
    .wizard-step-indicator::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: transparent;
    }
    
    .wizard-step-indicator.active {
        color: var(--black);
    }
    
    .wizard-step-indicator.active::after {
        background: var(--gold);
    }
    
    .wizard-step-indicator.completed {
        color: var(--green);
    }
    
    .wizard-step-indicator.completed::after {
        background: var(--green);
    }
    
    .wizard-step-number {
        width: 28px;
        height: 28px;
        border-radius: 50%;
        background: var(--gray-200);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
        font-size: 13px;
        flex-shrink: 0;
    }
    
    .wizard-step-indicator.active .wizard-step-number {
        background: var(--gold);
        color: var(--black);
    }
    
    .wizard-step-indicator.completed .wizard-step-number {
        background: var(--green);
        color: var(--white);
    }
    
    .wizard-step-label {
        font-weight: 500;
    }
    
    /* ============================================
       MAIN LAYOUT
       ============================================ */
    .wizard-main {
        max-width: 1200px;
        margin: 0 auto;
        padding: 32px 20px 100px;
        display: grid;
        grid-template-columns: 1fr 380px;
        gap: 32px;
    }
    
    .wizard-content {
        background: var(--white);
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        padding: 32px;
    }
    
    .wizard-sidebar {
        position: sticky;
        top: 100px;
        height: fit-content;
    }
    
    /* ============================================
       STEP CONTENT
       ============================================ */
    .wizard-panel {
        display: none;
    }
    
    .wizard-panel.active {
        display: block;
    }
    
    .wizard-title {
        font-family: 'Oswald', sans-serif;
        font-size: 24px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .wizard-title svg {
        color: var(--gold);
    }
    
    .wizard-subtitle {
        color: var(--gray-500);
        margin-bottom: 24px;
    }
    
    /* ============================================
       STEP 1: LOCATIONS
       ============================================ */
    .location-map {
        height: 200px;
        background: var(--gray-100);
        border-radius: 8px;
        margin-bottom: 20px;
        overflow: hidden;
    }
    
    .location-list {
        display: flex;
        flex-direction: column;
        gap: 12px;
    }
    
    .location-card {
        border: 2px solid var(--gray-200);
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        transition: all 0.15s;
        display: flex;
        gap: 16px;
        align-items: flex-start;
    }
    
    .location-card:hover {
        border-color: var(--gold);
        background: #FFFBEB;
    }
    
    .location-card.selected {
        border-color: var(--gold);
        background: #FEF3C7;
        box-shadow: 0 0 0 3px rgba(252, 185, 0, 0.2);
    }
    
    .location-icon {
        width: 48px;
        height: 48px;
        background: var(--gray-100);
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
    }
    
    .location-card.selected .location-icon {
        background: var(--gold);
    }
    
    .location-info {
        flex: 1;
    }
    
    .location-name {
        font-weight: 600;
        font-size: 15px;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .location-free-badge {
        background: var(--green);
        color: white;
        font-size: 10px;
        font-weight: 700;
        padding: 2px 8px;
        border-radius: 20px;
        font-family: 'Oswald', sans-serif;
        text-transform: uppercase;
    }
    
    .location-address {
        color: var(--gray-500);
        font-size: 13px;
        margin-bottom: 4px;
    }
    
    .location-distance {
        color: var(--gray-400);
        font-size: 12px;
        display: flex;
        align-items: center;
        gap: 4px;
    }
    
    /* ============================================
       STEP 2: DATE & TIME
       ============================================ */
    .calendar-container {
        margin-bottom: 24px;
    }
    
    .calendar-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
    }
    
    .calendar-month {
        font-family: 'Oswald', sans-serif;
        font-size: 18px;
        font-weight: 600;
    }
    
    .calendar-nav {
        display: flex;
        gap: 8px;
    }
    
    .calendar-nav button {
        width: 36px;
        height: 36px;
        border: 1px solid var(--gray-200);
        background: var(--white);
        border-radius: 8px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.15s;
    }
    
    .calendar-nav button:hover {
        border-color: var(--gold);
        background: #FFFBEB;
    }
    
    .calendar-grid {
        display: grid;
        grid-template-columns: repeat(7, 1fr);
        gap: 4px;
    }
    
    .calendar-day-header {
        padding: 8px 4px;
        text-align: center;
        font-size: 12px;
        font-weight: 600;
        color: var(--gray-500);
        text-transform: uppercase;
    }
    
    .calendar-day {
        aspect-ratio: 1;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s;
        position: relative;
    }
    
    .calendar-day.disabled {
        color: var(--gray-300);
        cursor: default;
    }
    
    .calendar-day.available {
        background: #FFFBEB;
    }
    
    .calendar-day.available:hover {
        background: #FEF3C7;
    }
    
    .calendar-day.selected {
        background: var(--gold) !important;
        transform: scale(1.05);
    }
    
    .calendar-day.has-suggested::after {
        content: '';
        position: absolute;
        bottom: 4px;
        width: 6px;
        height: 6px;
        background: var(--green);
        border-radius: 50%;
    }
    
    /* Time Slots */
    .time-slots-container {
        margin-top: 24px;
    }
    
    .time-slots-title {
        font-weight: 600;
        margin-bottom: 12px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .time-slots-grid {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 8px;
    }
    
    .time-slot {
        padding: 12px 8px;
        border: 2px solid var(--gray-200);
        border-radius: 8px;
        text-align: center;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.15s;
        position: relative;
    }
    
    .time-slot:hover {
        border-color: var(--gold);
        background: #FFFBEB;
    }
    
    .time-slot.selected {
        border-color: var(--gold);
        background: var(--gold);
    }
    
    .time-slot.suggested::before {
        content: 'SUGGESTED';
        position: absolute;
        top: -8px;
        left: 50%;
        transform: translateX(-50%);
        background: var(--green);
        color: white;
        font-size: 8px;
        font-weight: 700;
        padding: 2px 6px;
        border-radius: 10px;
        font-family: 'Oswald', sans-serif;
    }
    
    .time-slots-expand {
        margin-top: 12px;
        text-align: center;
    }
    
    .time-slots-expand button {
        background: none;
        border: none;
        color: var(--gold);
        font-weight: 600;
        cursor: pointer;
        font-size: 14px;
    }
    
    /* ============================================
       STEP 3: PACKAGE SELECTION
       ============================================ */
    .package-toggle {
        display: flex;
        background: var(--gray-100);
        border-radius: 8px;
        padding: 4px;
        margin-bottom: 24px;
    }
    
    .package-toggle button {
        flex: 1;
        padding: 12px 16px;
        border: none;
        background: transparent;
        font-family: 'Oswald', sans-serif;
        font-size: 14px;
        font-weight: 600;
        text-transform: uppercase;
        cursor: pointer;
        border-radius: 6px;
        transition: all 0.2s;
    }
    
    .package-toggle button.active {
        background: var(--white);
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    }
    
    .package-section {
        display: none;
    }
    
    .package-section.active {
        display: block;
    }
    
    .trial-banner {
        background: var(--green-bg);
        border: 2px solid var(--green);
        border-radius: 10px;
        padding: 16px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 12px;
    }
    
    .trial-banner-icon {
        width: 40px;
        height: 40px;
        background: var(--green);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        flex-shrink: 0;
    }
    
    .trial-banner-text strong {
        display: block;
        color: #047857;
        font-size: 15px;
    }
    
    .trial-banner-text span {
        font-size: 13px;
        color: #059669;
    }
    
    .frequency-options {
        display: flex;
        flex-direction: column;
        gap: 10px;
        margin-bottom: 24px;
    }
    
    .frequency-option {
        border: 2px solid var(--gray-200);
        border-radius: 10px;
        padding: 16px;
        cursor: pointer;
        transition: all 0.15s;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .frequency-option:hover {
        border-color: var(--gold);
        background: #FFFBEB;
    }
    
    .frequency-option.selected {
        border-color: var(--gold);
        background: #FEF3C7;
    }
    
    .frequency-option.popular {
        border-color: var(--gold);
    }
    
    .frequency-label {
        font-weight: 600;
    }
    
    .frequency-badge {
        background: var(--gold);
        color: var(--black);
        font-size: 10px;
        font-weight: 700;
        padding: 3px 8px;
        border-radius: 20px;
        margin-left: 8px;
        font-family: 'Oswald', sans-serif;
        text-transform: uppercase;
    }
    
    .frequency-price {
        text-align: right;
    }
    
    .frequency-price-amount {
        font-weight: 700;
        font-size: 18px;
    }
    
    .frequency-price-period {
        font-size: 12px;
        color: var(--gray-500);
    }
    
    .frequency-savings {
        color: var(--green);
        font-size: 12px;
        font-weight: 600;
    }
    
    /* Options Grid */
    .options-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
        margin-bottom: 24px;
    }
    
    .option-group label {
        display: block;
        font-size: 12px;
        font-weight: 600;
        text-transform: uppercase;
        color: var(--gray-600);
        margin-bottom: 8px;
    }
    
    .option-select {
        width: 100%;
        padding: 12px 16px;
        border: 2px solid var(--gray-200);
        border-radius: 8px;
        font-size: 15px;
        font-family: inherit;
        appearance: none;
        background: var(--white) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E") no-repeat right 12px center;
        cursor: pointer;
    }
    
    .option-select:focus {
        border-color: var(--gold);
        outline: none;
    }
    
    /* ============================================
       STEP 4: CHECKOUT
       ============================================ */
    .checkout-section {
        margin-bottom: 28px;
    }
    
    .checkout-section-title {
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    
    .checkout-section-title svg {
        color: var(--gold);
    }
    
    .checkout-row {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }
    
    .checkout-field {
        margin-bottom: 16px;
    }
    
    .checkout-field label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: var(--gray-700);
        margin-bottom: 6px;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }
    
    .checkout-input {
        width: 100%;
        padding: 14px 16px;
        border: 2px solid var(--gray-200);
        font-size: 15px;
        font-family: inherit;
        transition: border-color 0.2s;
    }
    
    .checkout-input:focus {
        border-color: var(--gold);
        outline: none;
    }
    
    #card-element {
        padding: 14px 16px;
        border: 2px solid var(--gray-200);
        background: var(--white);
        min-height: 50px;
        transition: border-color 0.2s;
    }
    
    #card-element.StripeElement--focus {
        border-color: var(--gold);
    }
    
    #card-element.StripeElement--invalid {
        border-color: var(--red);
    }
    
    #card-element.StripeElement--complete {
        border-color: var(--green);
        background: #F0FDF4;
    }
    
    .card-accepted {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-top: 12px;
        font-size: 12px;
        color: var(--gray-500);
    }
    
    .card-icons {
        display: flex;
        gap: 6px;
    }
    
    .card-icons img {
        height: 20px;
    }
    
    .security-badges {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        margin-top: 16px;
        padding-top: 16px;
        border-top: 1px solid var(--gray-100);
    }
    
    .security-badge {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        color: var(--green);
        font-weight: 500;
    }
    
    /* Gift Card Field */
    .gift-card-toggle {
        margin-bottom: 16px;
    }
    
    .gift-card-toggle button {
        background: none;
        border: none;
        color: var(--gold);
        font-weight: 600;
        cursor: pointer;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    
    .gift-card-field {
        display: none;
        margin-bottom: 16px;
    }
    
    .gift-card-field.active {
        display: flex;
        gap: 8px;
    }
    
    .gift-card-field input {
        flex: 1;
        padding: 12px;
        border: 2px solid var(--gray-200);
        font-size: 14px;
        text-transform: uppercase;
    }
    
    .gift-card-field button {
        padding: 12px 20px;
        background: var(--gray-100);
        border: 2px solid var(--gray-200);
        font-weight: 600;
        cursor: pointer;
    }
    
    /* ============================================
       SIDEBAR
       ============================================ */
    .sidebar-card {
        background: var(--white);
        border: 1px solid var(--gray-200);
        border-radius: 12px;
        padding: 24px;
        margin-bottom: 20px;
    }
    
    .sidebar-title {
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 16px;
    }
    
    .trainer-mini {
        display: flex;
        gap: 12px;
        padding-bottom: 16px;
        border-bottom: 1px solid var(--gray-200);
        margin-bottom: 16px;
    }
    
    .trainer-mini-photo {
        width: 56px;
        height: 56px;
        border-radius: 8px;
        overflow: hidden;
        border: 2px solid var(--gold);
        flex-shrink: 0;
    }
    
    .trainer-mini-photo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .trainer-mini-name {
        font-weight: 700;
        margin-bottom: 2px;
    }
    
    .trainer-mini-location {
        font-size: 13px;
        color: var(--gray-500);
    }
    
    .summary-row {
        display: flex;
        justify-content: space-between;
        padding: 10px 0;
        font-size: 14px;
    }
    
    .summary-row.total {
        border-top: 2px solid var(--gray-200);
        margin-top: 8px;
        padding-top: 16px;
    }
    
    .summary-label {
        color: var(--gray-600);
    }
    
    .summary-value {
        font-weight: 600;
    }
    
    .summary-value.strike {
        text-decoration: line-through;
        color: var(--gray-400);
    }
    
    .summary-total {
        font-family: 'Oswald', sans-serif;
        font-size: 28px;
        font-weight: 700;
    }
    
    .summary-trial {
        background: var(--green-bg);
        border: 2px solid var(--green);
        padding: 12px;
        margin-top: 16px;
        text-align: center;
    }
    
    .summary-trial-amount {
        font-family: 'Oswald', sans-serif;
        font-size: 24px;
        font-weight: 700;
        color: var(--green);
    }
    
    .summary-trial-text {
        font-size: 12px;
        color: #047857;
    }
    
    /* Continue Button */
    .wizard-continue {
        width: 100%;
        padding: 18px;
        background: var(--gold);
        color: var(--black);
        border: 2px solid var(--black);
        font-family: 'Oswald', sans-serif;
        font-size: 16px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        cursor: pointer;
        transition: all 0.2s;
        margin-top: 24px;
    }
    
    .wizard-continue:hover:not(:disabled) {
        background: var(--gold-hover);
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    .wizard-continue:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    
    /* Guarantee */
    .guarantee-badge {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 16px;
        background: var(--green-bg);
        border: 2px solid var(--green);
        margin-top: 20px;
    }
    
    .guarantee-badge svg {
        color: var(--green);
        flex-shrink: 0;
    }
    
    .guarantee-badge strong {
        display: block;
        color: #047857;
        font-size: 14px;
    }
    
    .guarantee-badge span {
        font-size: 12px;
        color: #059669;
    }
    
    /* Terms */
    .terms-text {
        text-align: center;
        font-size: 12px;
        color: var(--gray-500);
        margin-top: 16px;
        line-height: 1.5;
    }
    
    .terms-text a {
        color: var(--black);
        text-decoration: underline;
    }
    
    /* ============================================
       CROSS-SELL: SIMILAR TRAINERS
       ============================================ */
    .similar-trainers {
        margin-top: 24px;
        padding-top: 24px;
        border-top: 1px solid var(--gray-200);
    }
    
    .similar-trainers-title {
        font-size: 14px;
        font-weight: 600;
        color: var(--gray-600);
        margin-bottom: 16px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .similar-trainer-card {
        display: flex;
        gap: 12px;
        padding: 12px;
        border: 1px solid var(--gray-200);
        border-radius: 8px;
        margin-bottom: 10px;
        cursor: pointer;
        transition: all 0.15s;
    }
    
    .similar-trainer-card:hover {
        border-color: var(--gold);
        background: #FFFBEB;
    }
    
    .similar-trainer-photo {
        width: 48px;
        height: 48px;
        border-radius: 8px;
        overflow: hidden;
        flex-shrink: 0;
    }
    
    .similar-trainer-photo img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }
    
    .similar-trainer-name {
        font-weight: 600;
        font-size: 14px;
    }
    
    .similar-trainer-meta {
        font-size: 12px;
        color: var(--gray-500);
    }
    
    /* ============================================
       LEAD CAPTURE MODAL
       ============================================ */
    .lead-modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,0.7);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        opacity: 0;
        visibility: hidden;
        transition: all 0.3s;
    }
    
    .lead-modal-overlay.active {
        opacity: 1;
        visibility: visible;
    }
    
    .lead-modal {
        background: var(--white);
        border: 2px solid var(--black);
        padding: 32px;
        max-width: 420px;
        width: 90%;
    }
    
    .lead-modal-title {
        font-family: 'Oswald', sans-serif;
        font-size: 22px;
        font-weight: 700;
        text-transform: uppercase;
        margin-bottom: 8px;
    }
    
    .lead-modal-text {
        color: var(--gray-600);
        margin-bottom: 20px;
    }
    
    .lead-response-time {
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--green-bg);
        padding: 10px 12px;
        margin-bottom: 20px;
        font-size: 13px;
        color: var(--green);
        font-weight: 500;
    }
    
    .lead-modal-close {
        position: absolute;
        top: 16px;
        right: 16px;
        background: none;
        border: none;
        cursor: pointer;
        color: var(--gray-400);
    }
    
    /* ============================================
       RESPONSIVE
       ============================================ */
    @media (max-width: 900px) {
        .wizard-main {
            grid-template-columns: 1fr;
            gap: 24px;
            padding: 20px 16px 120px;
        }
        
        .wizard-sidebar {
            position: relative;
            top: 0;
            order: -1;
        }
        
        .wizard-step-label {
            display: none;
        }
        
        .time-slots-grid {
            grid-template-columns: repeat(3, 1fr);
        }
    }
    
    @media (max-width: 600px) {
        .wizard-header {
            padding: 12px 16px;
        }
        
        .wizard-logo {
            height: 28px;
        }
        
        .wizard-progress {
            padding: 0 12px;
        }
        
        .wizard-step-indicator {
            padding: 12px 8px;
            gap: 8px;
        }
        
        .wizard-step-number {
            width: 32px;
            height: 32px;
            font-size: 14px;
        }
        
        .wizard-content {
            padding: 20px 16px;
            border-radius: 8px;
        }
        
        .wizard-title {
            font-size: 20px;
        }
        
        .sidebar-card {
            padding: 16px;
            border-radius: 8px;
        }
        
        .checkout-row {
            grid-template-columns: 1fr;
            gap: 12px;
        }
        
        .options-grid {
            grid-template-columns: 1fr;
        }
        
        .time-slots-grid {
            grid-template-columns: repeat(2, 1fr);
            gap: 8px;
        }
        
        .time-slot {
            padding: 14px 12px;
            min-height: 48px;
        }
        
        /* Form inputs - prevent iOS zoom */
        .checkout-input,
        .option-select,
        input[type="text"],
        input[type="email"],
        input[type="tel"],
        select {
            font-size: 16px !important;
            min-height: 48px;
        }
        
        .wizard-continue {
            min-height: 56px;
            font-size: 16px;
        }
        
        /* Location cards mobile */
        .location-card {
            padding: 14px;
            flex-direction: column;
            gap: 12px;
        }
        
        .location-icon {
            width: 40px;
            height: 40px;
        }
        
        /* Calendar mobile */
        .calendar-day {
            min-height: 44px;
            font-size: 14px;
        }
        
        .calendar-nav button {
            width: 44px;
            height: 44px;
        }
        
        /* Package cards mobile */
        .package-card {
            padding: 16px;
        }
        
        /* Trainer info mobile */
        .trainer-info {
            flex-direction: column;
            text-align: center;
        }
        
        .trainer-photo {
            width: 80px;
            height: 80px;
            margin: 0 auto;
        }
        
        /* Fixed bottom continue button on mobile */
        .wizard-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: #fff;
            border-top: 2px solid var(--gray-200);
            padding: 12px 16px;
            padding-bottom: calc(12px + env(safe-area-inset-bottom));
            z-index: 90;
        }
        
        .wizard-main {
            padding-bottom: 100px;
        }
    }
    
    /* iOS safe area support */
    @supports (padding-bottom: env(safe-area-inset-bottom)) {
        .wizard-main {
            padding-bottom: calc(100px + env(safe-area-inset-bottom));
        }
    }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="wizard-header">
        <div class="wizard-header-inner">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" class="wizard-logo">
            </a>
            <a href="<?php echo esc_url(home_url('/trainer/' . $trainer->slug . '/')); ?>" class="wizard-back">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to Profile
            </a>
        </div>
    </header>
    
    <!-- Progress Bar -->
    <nav class="wizard-progress">
        <div class="wizard-progress-inner">
            <div class="wizard-step-indicator active" data-step="1">
                <span class="wizard-step-number">1</span>
                <span class="wizard-step-label">Location</span>
            </div>
            <div class="wizard-step-indicator" data-step="2">
                <span class="wizard-step-number">2</span>
                <span class="wizard-step-label">Date & Time</span>
            </div>
            <div class="wizard-step-indicator" data-step="3">
                <span class="wizard-step-number">3</span>
                <span class="wizard-step-label">Package</span>
            </div>
            <div class="wizard-step-indicator" data-step="4">
                <span class="wizard-step-number">4</span>
                <span class="wizard-step-label">Checkout</span>
            </div>
        </div>
    </nav>
    
    <!-- Main Content -->
    <main class="wizard-main">
        <!-- Left: Step Content -->
        <div class="wizard-content">
            <!-- STEP 1: Location Selection -->
            <div class="wizard-panel active" data-panel="1">
                <h2 class="wizard-title">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    Choose Training Location
                </h2>
                <p class="wizard-subtitle">Select where you'd like to train with <?php echo esc_html($first_name); ?></p>
                
                <div id="location-map" class="location-map"></div>
                
                <div class="location-list" id="location-list">
                    <?php foreach ($locations as $idx => $loc): ?>
                    <div class="location-card<?php echo $idx === 0 ? ' selected' : ''; ?>" 
                         data-location-id="<?php echo esc_attr($loc['id']); ?>"
                         data-location-name="<?php echo esc_attr($loc['name']); ?>"
                         data-lat="<?php echo esc_attr($loc['lat']); ?>"
                         data-lng="<?php echo esc_attr($loc['lng']); ?>">
                        <div class="location-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        </div>
                        <div class="location-info">
                            <div class="location-name">
                                <?php echo esc_html($loc['name']); ?>
                                <?php if (!empty($loc['is_free'])): ?>
                                <span class="location-free-badge">Free Venue</span>
                                <?php endif; ?>
                            </div>
                            <div class="location-address"><?php echo esc_html($loc['address']); ?></div>
                            <div class="location-distance" data-distance-holder>
                                <?php if ($loc['distance']): ?>
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                                <?php echo esc_html($loc['distance_text']); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                
                <button type="button" class="wizard-continue" onclick="wizardNext()">
                    Continue to Date & Time →
                </button>
            </div>
            
            <!-- STEP 2: Date & Time Selection -->
            <div class="wizard-panel" data-panel="2">
                <h2 class="wizard-title">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    Select Date & Time
                </h2>
                <p class="wizard-subtitle">Pick your preferred training slot</p>
                
                <div class="calendar-container">
                    <div class="calendar-header">
                        <span class="calendar-month" id="calendar-month"><?php echo date('F Y'); ?></span>
                        <div class="calendar-nav">
                            <button type="button" onclick="calendarPrev()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                            </button>
                            <button type="button" onclick="calendarNext()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="calendar-grid" id="calendar-grid">
                        <div class="calendar-day-header">Su</div>
                        <div class="calendar-day-header">Mo</div>
                        <div class="calendar-day-header">Tu</div>
                        <div class="calendar-day-header">We</div>
                        <div class="calendar-day-header">Th</div>
                        <div class="calendar-day-header">Fr</div>
                        <div class="calendar-day-header">Sa</div>
                        <!-- Days will be rendered by JS -->
                    </div>
                </div>
                
                <div class="time-slots-container" id="time-slots-container" style="display:none;">
                    <div class="time-slots-title">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <span id="time-slots-date">Select a date</span>
                    </div>
                    <div class="time-slots-grid" id="time-slots-grid">
                        <!-- Slots rendered by JS -->
                    </div>
                    <div class="time-slots-expand" id="time-slots-expand" style="display:none;">
                        <button type="button" onclick="showMoreSlots()">+ Show more times</button>
                    </div>
                </div>
                
                <button type="button" class="wizard-continue" id="step2-continue" disabled onclick="wizardNext()">
                    Continue to Package →
                </button>
            </div>
            
            <!-- STEP 3: Package Selection -->
            <div class="wizard-panel" data-panel="3">
                <h2 class="wizard-title">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/></svg>
                    Choose Your Training Package
                </h2>
                <p class="wizard-subtitle">Select subscription or one-time lessons</p>
                
                <div class="package-toggle">
                    <button type="button" class="active" data-package-type="subscription">Weekly Subscription</button>
                    <button type="button" data-package-type="one_time">Lesson Packs</button>
                </div>
                
                <!-- Subscription Section -->
                <div class="package-section active" data-section="subscription">
                    <div class="trial-banner">
                        <div class="trial-banner-icon">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        </div>
                        <div class="trial-banner-text">
                            <strong>First Session FREE</strong>
                            <span>Try before you commit. Cancel anytime.</span>
                        </div>
                    </div>
                    
                    <div class="frequency-options" id="frequency-options">
                        <!-- Rendered by JS -->
                    </div>
                </div>
                
                <!-- One-Time Section -->
                <div class="package-section" data-section="one_time">
                    <div class="frequency-options" id="pack-options">
                        <!-- Rendered by JS -->
                    </div>
                </div>
                
                <div class="options-grid">
                    <div class="option-group">
                        <label>Session Duration</label>
                        <select class="option-select" id="duration-select">
                            <option value="30">30 minutes</option>
                            <option value="60" selected>60 minutes</option>
                            <option value="90">90 minutes</option>
                        </select>
                    </div>
                    <div class="option-group">
                        <label>Participants</label>
                        <select class="option-select" id="participants-select">
                            <option value="1">1 Player</option>
                            <option value="2">2 Players (save 10%)</option>
                            <option value="3">3 Players (save 20%)</option>
                            <option value="4">4 Players (save 30%)</option>
                        </select>
                    </div>
                </div>
                
                <button type="button" class="wizard-continue" onclick="wizardNext()">
                    Continue to Checkout →
                </button>
            </div>
            
            <!-- STEP 4: Checkout -->
            <div class="wizard-panel" data-panel="4">
                <form id="checkout-form">
                    <input type="hidden" name="trainer_id" value="<?php echo esc_attr($trainer->id); ?>">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('ptp_booking_wizard'); ?>">
                    <input type="hidden" name="location_id" id="hidden-location">
                    <input type="hidden" name="date" id="hidden-date">
                    <input type="hidden" name="time" id="hidden-time">
                    <input type="hidden" name="package_type" id="hidden-package-type" value="subscription">
                    <input type="hidden" name="frequency" id="hidden-frequency" value="1">
                    <input type="hidden" name="pack_count" id="hidden-pack-count" value="1">
                    <input type="hidden" name="duration" id="hidden-duration" value="60">
                    <input type="hidden" name="participants" id="hidden-participants" value="1">
                    <input type="hidden" name="amount" id="hidden-amount" value="0">
                    
                    <!-- Contact Info -->
                    <div class="checkout-section">
                        <h3 class="checkout-section-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            Contact Information
                        </h3>
                        
                        <?php if ($is_logged_in): ?>
                        <div style="background:var(--green-bg);border:2px solid var(--green);padding:16px;margin-bottom:16px;display:flex;align-items:center;gap:12px">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--green)" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <div>
                                <div style="font-weight:700;color:#047857"><?php echo esc_html($current_user->display_name); ?></div>
                                <div style="font-size:13px;color:#059669"><?php echo esc_html($current_user->user_email); ?></div>
                            </div>
                        </div>
                        <input type="hidden" name="email" value="<?php echo esc_attr($current_user->user_email); ?>">
                        <input type="hidden" name="first_name" value="<?php echo esc_attr($current_user->first_name ?: $current_user->display_name); ?>">
                        <input type="hidden" name="last_name" value="<?php echo esc_attr($current_user->last_name); ?>">
                        <?php else: ?>
                        <div class="checkout-row">
                            <div class="checkout-field">
                                <label>First Name *</label>
                                <input type="text" name="first_name" class="checkout-input" required placeholder="John">
                            </div>
                            <div class="checkout-field">
                                <label>Last Name</label>
                                <input type="text" name="last_name" class="checkout-input" placeholder="Smith">
                            </div>
                        </div>
                        <div class="checkout-field">
                            <label>Email *</label>
                            <input type="email" name="email" class="checkout-input" required placeholder="john@example.com">
                        </div>
                        <?php endif; ?>
                        
                        <div class="checkout-field">
                            <label>Phone Number *</label>
                            <input type="tel" name="phone" class="checkout-input" required placeholder="(555) 123-4567">
                        </div>
                    </div>
                    
                    <!-- Player Info -->
                    <div class="checkout-section">
                        <h3 class="checkout-section-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                            Player Information
                        </h3>
                        
                        <div class="checkout-row">
                            <div class="checkout-field">
                                <label>Player Name *</label>
                                <input type="text" name="player_name" class="checkout-input" required placeholder="Player's first name">
                            </div>
                            <div class="checkout-field">
                                <label>Age *</label>
                                <select name="player_age" class="checkout-input option-select" required>
                                    <option value="">Select age</option>
                                    <?php for ($i = 5; $i <= 18; $i++): ?>
                                    <option value="<?php echo $i; ?>"><?php echo $i; ?> years old</option>
                                    <?php endfor; ?>
                                    <option value="19">Adult (18+)</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="checkout-row">
                            <div class="checkout-field">
                                <label>Skill Level</label>
                                <select name="skill_level" class="checkout-input option-select">
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate" selected>Intermediate</option>
                                    <option value="advanced">Advanced</option>
                                    <option value="elite">Elite/Competitive</option>
                                </select>
                            </div>
                            <div class="checkout-field">
                                <label>Position</label>
                                <select name="position" class="checkout-input option-select">
                                    <option value="">Any position</option>
                                    <option value="goalkeeper">Goalkeeper</option>
                                    <option value="defender">Defender</option>
                                    <option value="midfielder">Midfielder</option>
                                    <option value="forward">Forward</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="checkout-field">
                            <label>Training Goals (Optional)</label>
                            <input type="text" name="goals" class="checkout-input" placeholder="What would you like to work on?">
                        </div>
                    </div>
                    
                    <!-- Payment -->
                    <div class="checkout-section">
                        <h3 class="checkout-section-title">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                            Payment
                        </h3>
                        
                        <div class="gift-card-toggle">
                            <button type="button" onclick="toggleGiftCard()">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M12 8V3M12 8l-4 4M12 8l4 4"/></svg>
                                Have a gift card?
                            </button>
                        </div>
                        
                        <div class="gift-card-field" id="gift-card-field">
                            <input type="text" name="gift_card_code" placeholder="Enter gift card code">
                            <button type="button" onclick="applyGiftCard()">Apply</button>
                        </div>
                        
                        <div class="checkout-field">
                            <label>Card Details</label>
                            <div id="card-element"></div>
                            <div id="card-errors" style="color:var(--red);font-size:13px;margin-top:8px"></div>
                        </div>
                        
                        <div class="card-accepted">
                            <span>Accepted:</span>
                            <div class="card-icons">
                                <svg width="40" height="24" viewBox="0 0 40 24"><rect fill="#1A1F71" width="40" height="24" rx="4"/><text x="20" y="15" fill="white" font-size="10" text-anchor="middle" font-weight="bold">VISA</text></svg>
                                <svg width="40" height="24" viewBox="0 0 40 24"><rect fill="#EB001B" width="40" height="24" rx="4"/><circle cx="15" cy="12" r="7" fill="#EB001B"/><circle cx="25" cy="12" r="7" fill="#F79E1B" opacity="0.8"/></svg>
                                <svg width="40" height="24" viewBox="0 0 40 24"><rect fill="#006FCF" width="40" height="24" rx="4"/><text x="20" y="15" fill="white" font-size="7" text-anchor="middle" font-weight="bold">AMEX</text></svg>
                            </div>
                        </div>
                        
                        <div class="security-badges">
                            <div class="security-badge">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                                SSL Encrypted
                            </div>
                            <div class="security-badge">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                                PCI Compliant
                            </div>
                            <div class="security-badge">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                                Secure Checkout
                            </div>
                        </div>
                    </div>
                    
                    <button type="submit" class="wizard-continue" id="submit-btn">
                        <span id="submit-text">Complete Booking</span>
                        <span id="submit-loading" style="display:none">Processing...</span>
                    </button>
                    
                    <div class="guarantee-badge">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>
                        <div>
                            <strong>100% Satisfaction Guarantee</strong>
                            <span>Not happy after your first session? Full refund, no questions.</span>
                        </div>
                    </div>
                    
                    <div class="terms-text">
                        By completing this booking, you agree to our <a href="/terms">Terms of Service</a> and <a href="/privacy">Privacy Policy</a>.
                        <span id="subscription-terms" style="display:none">Your subscription will renew weekly. Cancel anytime.</span>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Right: Sidebar -->
        <aside class="wizard-sidebar">
            <div class="sidebar-card">
                <h3 class="sidebar-title">Booking Summary</h3>
                
                <div class="trainer-mini">
                    <div class="trainer-mini-photo">
                        <img src="<?php echo esc_url($trainer_photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>">
                    </div>
                    <div class="trainer-mini-info">
                        <div class="trainer-mini-name"><?php echo esc_html($trainer->display_name); ?></div>
                        <div class="trainer-mini-location"><?php echo esc_html($trainer->city ?? 'Philadelphia'); ?>, <?php echo esc_html($trainer->state ?? 'PA'); ?></div>
                    </div>
                </div>
                
                <div id="summary-details">
                    <div class="summary-row">
                        <span class="summary-label">Location</span>
                        <span class="summary-value" id="summary-location">-</span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Date</span>
                        <span class="summary-value" id="summary-date">-</span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Time</span>
                        <span class="summary-value" id="summary-time">-</span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Package</span>
                        <span class="summary-value" id="summary-package">-</span>
                    </div>
                    <div class="summary-row">
                        <span class="summary-label">Duration</span>
                        <span class="summary-value" id="summary-duration">60 min</span>
                    </div>
                    <div class="summary-row total">
                        <span class="summary-label">Total</span>
                        <span class="summary-total" id="summary-total">$<?php echo $base_rate; ?></span>
                    </div>
                </div>
                
                <div class="summary-trial" id="summary-trial">
                    <div class="summary-trial-amount">$0 today</div>
                    <div class="summary-trial-text">First session free, then $<?php echo $base_rate; ?>/week</div>
                </div>
            </div>
            
            <!-- Similar Trainers (shown when needed) -->
            <div class="sidebar-card" id="similar-trainers-card" style="display:none">
                <div class="similar-trainers">
                    <div class="similar-trainers-title">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>
                        Similar Trainers Nearby
                    </div>
                    <div id="similar-trainers-list">
                        <!-- Populated by JS -->
                    </div>
                </div>
            </div>
            
            <!-- Talk to Coordinator -->
            <div class="sidebar-card">
                <button type="button" onclick="openLeadModal()" style="width:100%;padding:12px;background:transparent;border:2px solid var(--gray-200);cursor:pointer;font-weight:600;display:flex;align-items:center;justify-content:center;gap:8px;transition:all 0.15s">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                    Talk to a Coordinator
                </button>
                <div style="text-align:center;margin-top:8px;font-size:12px;color:var(--gray-500)">
                    Avg. response time: 2 hours
                </div>
            </div>
        </aside>
    </main>
    
    <!-- Lead Capture Modal -->
    <div class="lead-modal-overlay" id="lead-modal">
        <div class="lead-modal">
            <h3 class="lead-modal-title">Have a Question?</h3>
            <p class="lead-modal-text">We're here to help! Leave your details and we'll get back to you.</p>
            
            <div class="lead-response-time">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                Average response time: 2 hours
            </div>
            
            <form id="lead-form">
                <input type="hidden" name="trainer_id" value="<?php echo esc_attr($trainer->id); ?>">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('ptp_nonce'); ?>">
                
                <div class="checkout-field">
                    <label>Your Name</label>
                    <input type="text" name="name" class="checkout-input" placeholder="John Smith">
                </div>
                <div class="checkout-field">
                    <label>Email *</label>
                    <input type="email" name="email" class="checkout-input" required placeholder="john@example.com">
                </div>
                <div class="checkout-field">
                    <label>Phone</label>
                    <input type="tel" name="phone" class="checkout-input" placeholder="(555) 123-4567">
                </div>
                <div class="checkout-field">
                    <label>Your Question</label>
                    <textarea name="message" class="checkout-input" rows="3" placeholder="What would you like to know?"></textarea>
                </div>
                
                <button type="submit" class="wizard-continue" style="margin-top:16px">Send Message</button>
            </form>
            
            <button type="button" onclick="closeLeadModal()" style="position:absolute;top:16px;right:16px;background:none;border:none;cursor:pointer;color:var(--gray-400)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
        </div>
    </div>
    
    <script>
    // ==========================================
    // PTP BOOKING WIZARD JAVASCRIPT
    // ==========================================
    
    const TRAINER_ID = <?php echo intval($trainer->id); ?>;
    const BASE_RATE = <?php echo intval($base_rate); ?>;
    const AJAX_URL = '<?php echo admin_url('admin-ajax.php'); ?>';
    
    // State
    let currentStep = 1;
    let selectedLocation = null;
    let selectedDate = null;
    let selectedTime = null;
    let packageType = 'subscription';
    let frequency = 1;
    let packCount = 1;
    let duration = 60;
    let participants = 1;
    let currentMonth = <?php echo $current_month; ?>;
    let currentYear = <?php echo $current_year; ?>;
    let availableDates = <?php echo json_encode($available_dates); ?>;
    let allSlots = [];
    let showAllSlots = false;
    
    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        // Select first location by default
        const firstLocation = document.querySelector('.location-card');
        if (firstLocation) {
            selectedLocation = {
                id: firstLocation.dataset.locationId,
                name: firstLocation.dataset.locationName
            };
            updateSummary();
        }
        
        // Render calendar
        renderCalendar();
        
        // Load packages
        loadPackages();
        
        // Init Stripe
        initStripe();
        
        // Location selection
        document.querySelectorAll('.location-card').forEach(card => {
            card.addEventListener('click', function() {
                document.querySelectorAll('.location-card').forEach(c => c.classList.remove('selected'));
                this.classList.add('selected');
                selectedLocation = {
                    id: this.dataset.locationId,
                    name: this.dataset.locationName
                };
                updateSummary();
            });
        });
        
        // Package toggle
        document.querySelectorAll('.package-toggle button').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.package-toggle button').forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                packageType = this.dataset.packageType;
                document.querySelectorAll('.package-section').forEach(s => s.classList.remove('active'));
                document.querySelector(`[data-section="${packageType}"]`).classList.add('active');
                updateSummary();
            });
        });
        
        // Duration/participants change
        document.getElementById('duration-select').addEventListener('change', function() {
            duration = parseInt(this.value);
            document.getElementById('hidden-duration').value = duration;
            loadPackages();
            updateSummary();
        });
        
        document.getElementById('participants-select').addEventListener('change', function() {
            participants = parseInt(this.value);
            document.getElementById('hidden-participants').value = participants;
            loadPackages();
            updateSummary();
        });
        
        // Get user location for distance
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(pos) {
                loadLocationsWithDistance(pos.coords.latitude, pos.coords.longitude);
            });
        }
        
        // Form submit
        document.getElementById('checkout-form').addEventListener('submit', handleCheckout);
        document.getElementById('lead-form').addEventListener('submit', handleLeadSubmit);
    });
    
    // ==========================================
    // NAVIGATION
    // ==========================================
    
    function wizardNext() {
        if (currentStep >= 4) return;
        
        // Validation
        if (currentStep === 1 && !selectedLocation) {
            alert('Please select a location');
            return;
        }
        if (currentStep === 2 && (!selectedDate || !selectedTime)) {
            alert('Please select a date and time');
            return;
        }
        
        currentStep++;
        updateSteps();
        updatePanels();
        
        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    function wizardBack() {
        if (currentStep <= 1) return;
        currentStep--;
        updateSteps();
        updatePanels();
    }
    
    function goToStep(step) {
        if (step > currentStep) return; // Can't skip ahead
        currentStep = step;
        updateSteps();
        updatePanels();
    }
    
    function updateSteps() {
        document.querySelectorAll('.wizard-step-indicator').forEach((el, idx) => {
            el.classList.remove('active', 'completed');
            const step = idx + 1;
            if (step < currentStep) {
                el.classList.add('completed');
            } else if (step === currentStep) {
                el.classList.add('active');
            }
        });
    }
    
    function updatePanels() {
        document.querySelectorAll('.wizard-panel').forEach(panel => {
            panel.classList.remove('active');
        });
        document.querySelector(`[data-panel="${currentStep}"]`).classList.add('active');
    }
    
    // ==========================================
    // CALENDAR
    // ==========================================
    
    function renderCalendar() {
        const grid = document.getElementById('calendar-grid');
        const monthLabel = document.getElementById('calendar-month');
        
        const firstDay = new Date(currentYear, currentMonth - 1, 1);
        const lastDay = new Date(currentYear, currentMonth, 0);
        const startPad = firstDay.getDay();
        
        monthLabel.textContent = firstDay.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        
        // Clear existing days (keep headers)
        const headers = grid.querySelectorAll('.calendar-day-header');
        grid.innerHTML = '';
        headers.forEach(h => grid.appendChild(h));
        
        // Padding for start of month
        for (let i = 0; i < startPad; i++) {
            const pad = document.createElement('div');
            pad.className = 'calendar-day disabled';
            grid.appendChild(pad);
        }
        
        // Days of month
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const dateStr = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            const dayEl = document.createElement('div');
            dayEl.className = 'calendar-day';
            dayEl.textContent = day;
            dayEl.dataset.date = dateStr;
            
            const dateInfo = availableDates[dateStr];
            
            if (dateInfo) {
                dayEl.classList.add('available');
                if (dateInfo.has_suggested) {
                    dayEl.classList.add('has-suggested');
                }
                dayEl.addEventListener('click', () => selectDate(dateStr, dayEl));
            } else {
                dayEl.classList.add('disabled');
            }
            
            if (dateStr === selectedDate) {
                dayEl.classList.add('selected');
            }
            
            grid.appendChild(dayEl);
        }
    }
    
    function calendarPrev() {
        currentMonth--;
        if (currentMonth < 1) {
            currentMonth = 12;
            currentYear--;
        }
        loadCalendarData();
    }
    
    function calendarNext() {
        currentMonth++;
        if (currentMonth > 12) {
            currentMonth = 1;
            currentYear++;
        }
        loadCalendarData();
    }
    
    async function loadCalendarData() {
        const res = await fetch(`${AJAX_URL}?action=ptp_wizard_get_slots&trainer_id=${TRAINER_ID}&month=${currentMonth}&year=${currentYear}`);
        const data = await res.json();
        if (data.success) {
            availableDates = data.data.dates || {};
            renderCalendar();
        }
    }
    
    async function selectDate(dateStr, el) {
        document.querySelectorAll('.calendar-day').forEach(d => d.classList.remove('selected'));
        el.classList.add('selected');
        selectedDate = dateStr;
        
        // Load time slots
        const res = await fetch(`${AJAX_URL}?action=ptp_wizard_get_slots&trainer_id=${TRAINER_ID}&date=${dateStr}`);
        const data = await res.json();
        
        if (data.success && data.data.slots) {
            allSlots = data.data.slots;
            showAllSlots = false;
            renderSlots();
        }
        
        updateSummary();
    }
    
    function renderSlots() {
        const container = document.getElementById('time-slots-container');
        const grid = document.getElementById('time-slots-grid');
        const dateLabel = document.getElementById('time-slots-date');
        const expandBtn = document.getElementById('time-slots-expand');
        
        container.style.display = 'block';
        dateLabel.textContent = new Date(selectedDate + 'T12:00:00').toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });
        
        grid.innerHTML = '';
        
        const slotsToShow = showAllSlots ? allSlots : allSlots.slice(0, 8);
        
        slotsToShow.forEach(slot => {
            const slotEl = document.createElement('div');
            slotEl.className = 'time-slot';
            slotEl.textContent = slot.display;
            slotEl.dataset.time = slot.time;
            
            if (slot.is_suggested) {
                slotEl.classList.add('suggested');
            }
            
            if (slot.time === selectedTime) {
                slotEl.classList.add('selected');
            }
            
            slotEl.addEventListener('click', () => selectTime(slot.time, slotEl));
            grid.appendChild(slotEl);
        });
        
        expandBtn.style.display = (!showAllSlots && allSlots.length > 8) ? 'block' : 'none';
    }
    
    function showMoreSlots() {
        showAllSlots = true;
        renderSlots();
    }
    
    function selectTime(time, el) {
        document.querySelectorAll('.time-slot').forEach(s => s.classList.remove('selected'));
        el.classList.add('selected');
        selectedTime = time;
        document.getElementById('step2-continue').disabled = false;
        updateSummary();
    }
    
    // ==========================================
    // PACKAGES
    // ==========================================
    
    async function loadPackages() {
        const res = await fetch(`${AJAX_URL}?action=ptp_wizard_get_packages&trainer_id=${TRAINER_ID}&duration=${duration}&participants=${participants}`);
        const data = await res.json();
        
        if (data.success) {
            renderPackages(data.data);
        }
    }
    
    function renderPackages(data) {
        // Subscription options
        const freqContainer = document.getElementById('frequency-options');
        freqContainer.innerHTML = '';
        
        data.packages.subscription.options.forEach(opt => {
            const div = document.createElement('div');
            div.className = `frequency-option${opt.popular ? ' popular' : ''}${frequency === opt.frequency ? ' selected' : ''}`;
            div.dataset.frequency = opt.frequency;
            div.innerHTML = `
                <div>
                    <span class="frequency-label">${opt.frequency_label}</span>
                    ${opt.popular ? '<span class="frequency-badge">Most Popular</span>' : ''}
                </div>
                <div class="frequency-price">
                    <div class="frequency-price-amount">${opt.price_display}</div>
                    <div class="frequency-price-period">/week</div>
                    ${opt.savings_text ? `<div class="frequency-savings">${opt.savings_text}</div>` : ''}
                </div>
            `;
            div.addEventListener('click', () => {
                document.querySelectorAll('#frequency-options .frequency-option').forEach(o => o.classList.remove('selected'));
                div.classList.add('selected');
                frequency = opt.frequency;
                document.getElementById('hidden-frequency').value = frequency;
                updateSummary();
            });
            freqContainer.appendChild(div);
        });
        
        // One-time packs
        const packContainer = document.getElementById('pack-options');
        packContainer.innerHTML = '';
        
        data.packages.one_time.options.forEach(opt => {
            const div = document.createElement('div');
            div.className = `frequency-option${opt.popular ? ' popular' : ''}${packCount === opt.count ? ' selected' : ''}`;
            div.dataset.count = opt.count;
            div.innerHTML = `
                <div>
                    <span class="frequency-label">${opt.label}</span>
                    ${opt.popular ? '<span class="frequency-badge">Best Value</span>' : ''}
                </div>
                <div class="frequency-price">
                    <div class="frequency-price-amount">${opt.price_display}</div>
                    ${opt.savings_text ? `<div class="frequency-savings">${opt.savings_text}</div>` : ''}
                </div>
            `;
            div.addEventListener('click', () => {
                document.querySelectorAll('#pack-options .frequency-option').forEach(o => o.classList.remove('selected'));
                div.classList.add('selected');
                packCount = opt.count;
                document.getElementById('hidden-pack-count').value = packCount;
                updateSummary();
            });
            packContainer.appendChild(div);
        });
    }
    
    // ==========================================
    // SUMMARY
    // ==========================================
    
    function updateSummary() {
        document.getElementById('summary-location').textContent = selectedLocation?.name || '-';
        document.getElementById('summary-date').textContent = selectedDate 
            ? new Date(selectedDate + 'T12:00:00').toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
            : '-';
        document.getElementById('summary-time').textContent = selectedTime 
            ? new Date('2000-01-01T' + selectedTime).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })
            : '-';
        document.getElementById('summary-duration').textContent = duration + ' min';
        
        // Calculate price
        let price = BASE_RATE * (duration / 60);
        let packageLabel = '';
        
        if (packageType === 'subscription') {
            price = price * frequency;
            if (frequency === 2) price *= 0.95;
            if (frequency === 3) price *= 0.90;
            packageLabel = frequency + 'x/week subscription';
            document.getElementById('summary-trial').style.display = 'block';
            document.getElementById('subscription-terms').style.display = 'inline';
        } else {
            if (packCount === 3) price = price * 3 * 0.93;
            else if (packCount === 5) price = price * 5 * 0.90;
            else if (packCount === 10) price = price * 10 * 0.85;
            else price = price * packCount;
            packageLabel = packCount === 1 ? 'Single session' : packCount + '-pack';
            document.getElementById('summary-trial').style.display = 'none';
            document.getElementById('subscription-terms').style.display = 'none';
        }
        
        // Participants
        if (participants > 1) {
            const discount = Math.min((participants - 1) * 10, 30) / 100;
            price = price * participants * (1 - discount);
            packageLabel += ` (${participants} players)`;
        }
        
        price = Math.round(price);
        
        document.getElementById('summary-package').textContent = packageLabel;
        document.getElementById('summary-total').textContent = '$' + price;
        document.getElementById('hidden-amount').value = price;
        document.getElementById('hidden-package-type').value = packageType;
        
        // Update hidden fields
        document.getElementById('hidden-location').value = selectedLocation?.id || '';
        document.getElementById('hidden-date').value = selectedDate || '';
        document.getElementById('hidden-time').value = selectedTime || '';
        
        // Update trial text
        if (packageType === 'subscription') {
            document.querySelector('.summary-trial-text').textContent = `First session free, then $${price}/week`;
        }
    }
    
    // ==========================================
    // STRIPE
    // ==========================================
    
    let stripe, cardElement;
    
    function initStripe() {
        <?php if ($stripe_key): ?>
        stripe = Stripe('<?php echo esc_js($stripe_key); ?>');
        const elements = stripe.elements();
        cardElement = elements.create('card', {
            style: {
                base: {
                    fontSize: '15px',
                    fontFamily: 'Inter, sans-serif',
                    color: '#0A0A0A',
                    '::placeholder': { color: '#9CA3AF' }
                }
            }
        });
        cardElement.mount('#card-element');
        
        cardElement.on('change', function(event) {
            const errors = document.getElementById('card-errors');
            errors.textContent = event.error ? event.error.message : '';
        });
        <?php endif; ?>
    }
    
    async function handleCheckout(e) {
        e.preventDefault();
        
        const btn = document.getElementById('submit-btn');
        const btnText = document.getElementById('submit-text');
        const btnLoading = document.getElementById('submit-loading');
        
        btn.disabled = true;
        btnText.style.display = 'none';
        btnLoading.style.display = 'inline';
        
        try {
            // Create payment method
            const { paymentMethod, error } = await stripe.createPaymentMethod({
                type: 'card',
                card: cardElement,
                billing_details: {
                    name: document.querySelector('[name="first_name"]')?.value + ' ' + (document.querySelector('[name="last_name"]')?.value || ''),
                    email: document.querySelector('[name="email"]')?.value,
                    phone: document.querySelector('[name="phone"]')?.value
                }
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            // Submit to server
            const formData = new FormData(document.getElementById('checkout-form'));
            formData.append('action', 'ptp_wizard_process_booking');
            formData.append('payment_method_id', paymentMethod.id);
            
            const res = await fetch(AJAX_URL, {
                method: 'POST',
                body: formData
            });
            
            const data = await res.json();
            
            if (!data.success) {
                throw new Error(data.data?.message || 'Booking failed');
            }
            
            // Confirm payment if needed
            if (data.data.client_secret) {
                const { error: confirmError } = await stripe.confirmCardPayment(data.data.client_secret, {
                    payment_method: paymentMethod.id
                });
                
                if (confirmError) {
                    throw new Error(confirmError.message);
                }
            }
            
            // Success - redirect
            window.location.href = data.data.redirect || '/booking-confirmation/';
            
        } catch (err) {
            alert(err.message);
            btn.disabled = false;
            btnText.style.display = 'inline';
            btnLoading.style.display = 'none';
        }
    }
    
    // ==========================================
    // LOCATIONS WITH DISTANCE
    // ==========================================
    
    async function loadLocationsWithDistance(lat, lng) {
        const res = await fetch(`${AJAX_URL}?action=ptp_wizard_get_locations&trainer_id=${TRAINER_ID}&lat=${lat}&lng=${lng}`);
        const data = await res.json();
        
        if (data.success) {
            // Update distance displays
            data.data.locations.forEach(loc => {
                const card = document.querySelector(`[data-location-id="${loc.id}"]`);
                if (card && loc.distance_text) {
                    const distanceEl = card.querySelector('[data-distance-holder]');
                    if (distanceEl) {
                        distanceEl.innerHTML = `
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                            ${loc.distance_text}
                        `;
                    }
                }
            });
        }
    }
    
    // ==========================================
    // LEAD MODAL
    // ==========================================
    
    function openLeadModal() {
        document.getElementById('lead-modal').classList.add('active');
    }
    
    function closeLeadModal() {
        document.getElementById('lead-modal').classList.remove('active');
    }
    
    async function handleLeadSubmit(e) {
        e.preventDefault();
        
        const form = e.target;
        const btn = form.querySelector('button[type="submit"]');
        btn.disabled = true;
        btn.textContent = 'Sending...';
        
        const formData = new FormData(form);
        formData.append('action', 'ptp_wizard_submit_lead');
        
        try {
            const res = await fetch(AJAX_URL, { method: 'POST', body: formData });
            const data = await res.json();
            
            if (data.success) {
                alert(data.data.message);
                closeLeadModal();
                form.reset();
            } else {
                alert(data.data?.message || 'Failed to send');
            }
        } catch (err) {
            alert('Error: ' + err.message);
        }
        
        btn.disabled = false;
        btn.textContent = 'Send Message';
    }
    
    // ==========================================
    // GIFT CARD
    // ==========================================
    
    function toggleGiftCard() {
        document.getElementById('gift-card-field').classList.toggle('active');
    }
    
    async function applyGiftCard() {
        const code = document.querySelector('[name="gift_card_code"]').value;
        if (!code) return;
        
        const res = await fetch(`${AJAX_URL}?action=ptp_check_gift_card&code=${encodeURIComponent(code)}`);
        const data = await res.json();
        
        if (data.success) {
            alert('Gift card applied! Balance: $' + data.data.balance);
        } else {
            alert(data.data?.message || 'Invalid gift card');
        }
    }
    
    // Close modal on escape
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') closeLeadModal();
    });
    
    // Close modal on overlay click
    document.getElementById('lead-modal').addEventListener('click', function(e) {
        if (e.target === this) closeLeadModal();
    });
    </script>
</body>
</html>
