<?php
/**
 * Template: Logout v36.0.0
 * PTP Design System - Oswald/Inter, sharp edges, gold accents
 */
defined('ABSPATH') || exit;

// Get user info before logout
$user_name = '';
if (is_user_logged_in()) {
    $current_user = wp_get_current_user();
    $user_name = $current_user->first_name ?: $current_user->display_name;
}

// Handle logout
$logged_out = false;
if (is_user_logged_in()) {
    // Check for confirm parameter to actually log out
    if (isset($_GET['confirm']) && $_GET['confirm'] === '1') {
        wp_logout();
        $logged_out = true;
    }
} else {
    $logged_out = true;
}

$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title><?php echo $logged_out ? 'Logged Out' : 'Log Out'; ?> - PTP Training</title>
    <?php wp_head(); ?>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap');
    
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    
    html, body {
        width: 100% !important;
        min-height: 100vh !important;
        margin: 0 !important;
        padding: 0 !important;
        font-family: 'Inter', -apple-system, sans-serif !important;
        -webkit-font-smoothing: antialiased;
        -webkit-tap-highlight-color: transparent;
        background: #0A0A0A !important;
    }
    
    body.ptp-logout-page #page, body.ptp-logout-page #content, body.ptp-logout-page .site-content,
    body.ptp-logout-page .entry-content, body.ptp-logout-page main, body.ptp-logout-page article,
    body.ptp-logout-page header:not(.ptp-header), body.ptp-logout-page footer:not(.ptp-footer),
    body.ptp-logout-page .site-header, body.ptp-logout-page .site-footer,
    body.ptp-logout-page #masthead, body.ptp-logout-page .main-navigation { display: none !important; }
    
    .ptp-logout {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 16px;
        background: linear-gradient(135deg, #0A0A0A 0%, #1a1a1a 100%);
    }
    
    .ptp-logout-card {
        background: #FFFFFF;
        width: 100%;
        max-width: 400px;
        padding: 32px 20px;
        text-align: center;
    }
    
    .ptp-logout-logo {
        height: 40px;
        margin-bottom: 24px;
    }
    
    .ptp-logout-icon {
        width: 72px;
        height: 72px;
        margin: 0 auto 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
    }
    
    .ptp-logout-icon.confirm {
        background: #FEF3C7;
        border: 3px solid #FCB900;
    }
    
    .ptp-logout-icon.success {
        background: #D1FAE5;
        border: 3px solid #10B981;
    }
    
    .ptp-logout-title {
        font-family: 'Oswald', sans-serif;
        font-size: 28px;
        font-weight: 700;
        color: #0A0A0A;
        margin-bottom: 12px;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }
    
    .ptp-logout-subtitle {
        font-size: 15px;
        color: #6B7280;
        margin-bottom: 32px;
        line-height: 1.6;
    }
    
    .ptp-logout-name {
        color: #0A0A0A;
        font-weight: 700;
    }
    
    .ptp-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 14px 24px;
        font-family: 'Oswald', sans-serif;
        font-size: 14px;
        font-weight: 700;
        text-decoration: none;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        transition: all 0.15s;
        cursor: pointer;
        border: 2px solid #0A0A0A;
        min-height: 48px;
    }
    
    .ptp-btn-primary {
        background: #FCB900;
        color: #0A0A0A;
    }
    
    .ptp-btn-primary:hover, .ptp-btn-primary:active {
        background: #e5a800;
    }
    
    .ptp-btn-outline {
        background: transparent;
        color: #0A0A0A;
        border: 2px solid #E5E5E5;
    }
    
    .ptp-btn-outline:hover, .ptp-btn-outline:active {
        border-color: #0A0A0A;
        background: #F9FAFB;
    }
    
    .ptp-btn-danger {
        background: #EF4444;
        color: #FFFFFF;
        border-color: #DC2626;
    }
    
    .ptp-btn-danger:hover, .ptp-btn-danger:active {
        background: #DC2626;
    }
    
    .ptp-logout-buttons {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }
    
    .ptp-logout-buttons-row {
        display: flex;
        gap: 10px;
    }
    
    .ptp-logout-buttons-row .ptp-btn {
        flex: 1;
    }
    
    .ptp-logout-footer {
        margin-top: 28px;
        padding-top: 24px;
        border-top: 2px solid #E5E5E5;
    }
    
    .ptp-logout-footer p {
        font-size: 14px;
        color: #6B7280;
        margin: 0;
    }
    
    .ptp-logout-footer a {
        color: #0A0A0A;
        font-weight: 600;
        text-decoration: none;
    }
    
    .ptp-logout-footer a:hover {
        color: #FCB900;
    }
    
    @keyframes checkmark {
        0% { transform: scale(0); }
        50% { transform: scale(1.2); }
        100% { transform: scale(1); }
    }
    
    @keyframes fadeUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    .ptp-logout-card {
        animation: fadeUp 0.3s ease;
    }
    
    .ptp-logout-icon.success svg {
        animation: checkmark 0.4s ease 0.15s both;
    }
    
    @media (min-width: 480px) {
        .ptp-logout { padding: 24px; }
        .ptp-logout-card { padding: 40px 36px; max-width: 440px; }
        .ptp-logout-logo { height: 48px; margin-bottom: 32px; }
        .ptp-logout-icon { width: 80px; height: 80px; margin-bottom: 24px; }
        .ptp-logout-title { font-size: 28px; }
        .ptp-btn { padding: 16px 32px; font-size: 15px; }
    }
    </style>
</head>
<body class="ptp-logout-page">
    <div class="ptp-logout">
        <div class="ptp-logout-card">
            <?php if ($logo_url): ?>
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" class="ptp-logout-logo">
            </a>
            <?php endif; ?>
            
            <?php if ($logged_out): ?>
                <!-- Logged Out State -->
                <div class="ptp-logout-icon success">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="3">
                        <polyline points="20 6 9 17 4 12"/>
                    </svg>
                </div>
                
                <h1 class="ptp-logout-title">You're Logged Out</h1>
                <p class="ptp-logout-subtitle">Thanks for training with us! You've been successfully signed out of your account.</p>
                
                <div class="ptp-logout-buttons">
                    <a href="<?php echo esc_url(home_url('/login/')); ?>" class="ptp-btn ptp-btn-primary">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M15 3h4a2 2 0 012 2v14a2 2 0 01-2 2h-4"/>
                            <polyline points="10 17 15 12 10 7"/>
                            <line x1="15" y1="12" x2="3" y2="12"/>
                        </svg>
                        Sign In Again
                    </a>
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="ptp-btn ptp-btn-outline">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>
                            <polyline points="9 22 9 12 15 12 15 22"/>
                        </svg>
                        Back to Home
                    </a>
                </div>
                
            <?php else: ?>
                <!-- Confirm Logout State -->
                <div class="ptp-logout-icon confirm">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#F59E0B" stroke-width="2">
                        <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                        <polyline points="16 17 21 12 16 7"/>
                        <line x1="21" y1="12" x2="9" y2="12"/>
                    </svg>
                </div>
                
                <h1 class="ptp-logout-title">Log Out?</h1>
                <p class="ptp-logout-subtitle">
                    Hey <span class="ptp-logout-name"><?php echo esc_html($user_name); ?></span>, are you sure you want to sign out of your account?
                </p>
                
                <div class="ptp-logout-buttons">
                    <div class="ptp-logout-buttons-row">
                        <a href="<?php echo esc_url(home_url('/my-training/')); ?>" class="ptp-btn ptp-btn-outline">
                            Cancel
                        </a>
                        <a href="<?php echo esc_url(add_query_arg('confirm', '1')); ?>" class="ptp-btn ptp-btn-danger">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                                <polyline points="16 17 21 12 16 7"/>
                                <line x1="21" y1="12" x2="9" y2="12"/>
                            </svg>
                            Log Out
                        </a>
                    </div>
                </div>
                
                <div class="ptp-logout-footer">
                    <p>Want to stay? <a href="<?php echo esc_url(home_url('/my-training/')); ?>">Go to Dashboard</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
