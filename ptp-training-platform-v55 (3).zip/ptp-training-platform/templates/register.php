<?php
/**
 * Template: Register v42.0.0
 * PTP Design System - Oswald/Inter, sharp edges, gold accents
 * Mobile-first with 44px touch targets
 */
defined('ABSPATH') || exit;

if (is_user_logged_in()) {
    wp_redirect(home_url('/my-training/'));
    exit;
}

$error = '';
$success = false;

if (isset($_POST['ptp_register']) && wp_verify_nonce($_POST['ptp_register_nonce'], 'ptp_register')) {
    $email = sanitize_email($_POST['email']);
    $password = $_POST['password'];
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    
    if (!is_email($email)) {
        $error = 'Please enter a valid email address.';
    } elseif (email_exists($email)) {
        $error = 'An account with this email already exists. <a href="' . esc_url(home_url('/login/')) . '">Sign in</a>';
    } elseif (strlen($password) < 8) {
        $error = 'Password must be at least 8 characters.';
    } else {
        $user_id = wp_create_user($email, $password, $email);
        if (is_wp_error($user_id)) {
            $error = $user_id->get_error_message();
        } else {
            wp_update_user(array(
                'ID' => $user_id,
                'first_name' => $first_name,
                'last_name' => $last_name,
                'display_name' => $first_name . ' ' . $last_name,
                'role' => 'subscriber'
            ));
            
            if (class_exists('PTP_Parent')) {
                PTP_Parent::create($user_id, array(
                    'display_name' => $first_name . ' ' . $last_name,
                    'phone' => $phone
                ));
            }
            
            wp_set_current_user($user_id);
            wp_set_auth_cookie($user_id);
            wp_redirect(home_url('/my-training/'));
            exit;
        }
    }
}

$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';
$bg_image = 'https://ptpsummercamps.com/wp-content/uploads/2025/12/PHL_8711.jpg';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>Create Account - PTP Training</title>
    <?php wp_head(); ?>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap');
    
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    
    html, body {
        width: 100% !important; min-height: 100vh !important;
        margin: 0 !important; padding: 0 !important;
        font-family: 'Inter', -apple-system, sans-serif !important;
        -webkit-font-smoothing: antialiased; background: #0A0A0A !important;
    }
    
    body.ptp-register-page #page, body.ptp-register-page #content, body.ptp-register-page .site-content,
    body.ptp-register-page .entry-content, body.ptp-register-page main, body.ptp-register-page article,
    body.ptp-register-page header:not(.ptp-header), body.ptp-register-page footer:not(.ptp-footer),
    body.ptp-register-page .site-header, body.ptp-register-page .site-footer { display: none !important; }
    
    .ptp-auth { min-height: 100vh; display: flex; width: 100%; }
    
    .ptp-auth-left {
        flex: 1;
        background: linear-gradient(135deg, rgba(10,10,10,0.9), rgba(10,10,10,0.7)), url('<?php echo esc_url($bg_image); ?>') center/cover;
        display: flex; flex-direction: column; justify-content: center; padding: 60px;
    }
    
    .ptp-auth-right {
        width: 520px; background: #FFFFFF;
        display: flex; align-items: center; justify-content: center; padding: 40px;
    }
    
    .ptp-auth-card { width: 100%; max-width: 400px; }
    .ptp-auth-logo { height: 48px; margin-bottom: 32px; }
    
    .ptp-auth-title {
        font-family: 'Oswald', sans-serif; font-size: 28px; font-weight: 700;
        color: #0A0A0A; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-auth-subtitle { font-size: 15px; color: #6B7280; margin-bottom: 32px; }
    .ptp-form-group { margin-bottom: 20px; }
    .ptp-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    
    .ptp-label {
        display: block; font-size: 12px; font-weight: 700; color: #374151;
        margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-input {
        width: 100%; padding: 14px 16px; border: 2px solid #E5E5E5;
        font-family: 'Inter', sans-serif; font-size: 16px;
        transition: border-color 0.2s; background: #FFFFFF;
        min-height: 48px;
        -webkit-appearance: none;
        appearance: none;
    }
    
    .ptp-input:focus { border-color: #FCB900; outline: none; }
    
    .ptp-btn-primary {
        width: 100%; padding: 16px; background: #FCB900; color: #0A0A0A;
        border: 2px solid #0A0A0A; font-family: 'Oswald', sans-serif;
        font-size: 16px; font-weight: 700; cursor: pointer;
        transition: background 0.2s; text-transform: uppercase; letter-spacing: 0.02em;
        margin-top: 8px;
    }
    
    .ptp-btn-primary:hover { background: #e5a800; }
    
    .ptp-error {
        background: #FEF2F2; border: 2px solid #EF4444;
        color: #DC2626; padding: 14px 16px; margin-bottom: 20px; font-size: 14px;
    }
    
    .ptp-error a { color: #DC2626; font-weight: 700; }
    
    .ptp-divider { display: flex; align-items: center; gap: 16px; margin: 28px 0; }
    .ptp-divider-line { flex: 1; height: 2px; background: #E5E5E5; }
    .ptp-divider-text { font-size: 12px; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.05em; }
    
    .ptp-login-link { text-align: center; font-size: 14px; color: #6B7280; }
    .ptp-login-link a { color: #0A0A0A; font-weight: 700; text-decoration: none; }
    .ptp-login-link a:hover { color: #FCB900; }
    
    .ptp-hero-text { max-width: 500px; }
    
    .ptp-hero-badge {
        display: inline-flex; align-items: center; gap: 6px;
        background: rgba(252,185,0,0.2); border: 2px solid rgba(252,185,0,0.5);
        padding: 8px 14px; font-family: 'Oswald', sans-serif; font-size: 12px;
        font-weight: 700; color: #FCB900; margin-bottom: 20px;
        text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-hero-title {
        font-family: 'Oswald', sans-serif; font-size: 48px; font-weight: 700;
        color: #FFFFFF; line-height: 1.1; margin-bottom: 16px;
        text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-hero-subtitle { font-size: 18px; color: #9CA3AF; line-height: 1.6; }
    
    .ptp-terms { font-size: 12px; color: #6B7280; text-align: center; margin-top: 16px; }
    .ptp-terms a { color: #0A0A0A; text-decoration: underline; }
    
    @media (max-width: 968px) {
        .ptp-auth-left { display: none; }
        .ptp-auth-right { width: 100%; min-height: 100vh; }
    }
    
    @media (max-width: 480px) {
        .ptp-auth-right { padding: 24px 20px; }
        .ptp-auth-title { font-size: 24px; }
        .ptp-form-row { grid-template-columns: 1fr; }
        .ptp-btn-primary { min-height: 52px; }
    }
    
    /* iOS Safe Area Support */
    @supports (padding-bottom: env(safe-area-inset-bottom)) {
        .ptp-auth-right {
            padding-bottom: calc(24px + env(safe-area-inset-bottom));
        }
    }
    </style>
</head>
<body class="ptp-register-page">
    <!-- Dark Header -->
    <div style="position:fixed;top:0;left:0;right:0;background:#0A0A0A;padding:12px 16px;z-index:100;display:flex;align-items:center;justify-content:space-between">
        <a href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" style="height:28px">
        </a>
        <div style="display:flex;align-items:center;gap:5px;font-size:12px;color:#10B981;font-weight:600">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Secure
        </div>
    </div>
    
    <div class="ptp-auth" style="padding-top:52px">
        <div class="ptp-auth-left">
            <div class="ptp-hero-text">
                <div class="ptp-hero-badge">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
                    Players Teaching Players
                </div>
                <h1 class="ptp-hero-title">Start Your Journey</h1>
                <p class="ptp-hero-subtitle">Join thousands of athletes training with elite NCAA and professional players.</p>
            </div>
        </div>
        
        <div class="ptp-auth-right">
            <div class="ptp-auth-card">
                <?php if ($logo_url): ?>
                <a href="<?php echo esc_url(home_url('/')); ?>">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" class="ptp-auth-logo">
                </a>
                <?php endif; ?>
                
                <h2 class="ptp-auth-title">Create Account</h2>
                <p class="ptp-auth-subtitle">Sign up to book training sessions</p>
                
                <?php if ($error): ?>
                <div class="ptp-error"><?php echo wp_kses_post($error); ?></div>
                <?php endif; ?>
                
                <form method="post">
                    <?php wp_nonce_field('ptp_register', 'ptp_register_nonce'); ?>
                    
                    <div class="ptp-form-row">
                        <div class="ptp-form-group">
                            <label class="ptp-label">First Name</label>
                            <input type="text" name="first_name" class="ptp-input" placeholder="First name" required value="<?php echo esc_attr($_POST['first_name'] ?? ''); ?>">
                        </div>
                        <div class="ptp-form-group">
                            <label class="ptp-label">Last Name</label>
                            <input type="text" name="last_name" class="ptp-input" placeholder="Last name" required value="<?php echo esc_attr($_POST['last_name'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="ptp-form-group">
                        <label class="ptp-label">Email</label>
                        <input type="email" name="email" class="ptp-input" placeholder="your@email.com" required value="<?php echo esc_attr($_POST['email'] ?? ''); ?>">
                    </div>
                    
                    <div class="ptp-form-group">
                        <label class="ptp-label">Phone (Optional)</label>
                        <input type="tel" name="phone" class="ptp-input" placeholder="(555) 555-5555" value="<?php echo esc_attr($_POST['phone'] ?? ''); ?>">
                    </div>
                    
                    <div class="ptp-form-group">
                        <label class="ptp-label">Password</label>
                        <input type="password" name="password" class="ptp-input" placeholder="Min 8 characters" required minlength="8">
                    </div>
                    
                    <button type="submit" name="ptp_register" value="1" class="ptp-btn-primary">Create Account</button>
                    
                    <p class="ptp-terms">By signing up, you agree to our <a href="<?php echo esc_url(home_url('/terms/')); ?>">Terms</a> and <a href="<?php echo esc_url(home_url('/privacy/')); ?>">Privacy Policy</a></p>
                </form>
                
                <div class="ptp-divider">
                    <div class="ptp-divider-line"></div>
                    <span class="ptp-divider-text">or</span>
                    <div class="ptp-divider-line"></div>
                </div>
                
                <p class="ptp-login-link">Already have an account? <a href="<?php echo esc_url(home_url('/login/')); ?>">Sign in</a></p>
            </div>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
