<?php
/**
 * Template: Login v42.0.0
 * PTP Design System - Oswald/Inter, sharp edges, gold accents
 * Mobile-first with 44px touch targets
 */
defined('ABSPATH') || exit;

if (is_user_logged_in()) {
    $redirect_url = class_exists('PTP_User') ? PTP_User::get_dashboard_url() : home_url('/my-training/');
    wp_redirect($redirect_url);
    exit;
}

$error = '';
if (isset($_POST['ptp_login']) && wp_verify_nonce($_POST['ptp_login_nonce'], 'ptp_login')) {
    $creds = array(
        'user_login' => sanitize_user($_POST['username']),
        'user_password' => $_POST['password'],
        'remember' => isset($_POST['remember'])
    );
    $user = wp_signon($creds, is_ssl());
    if (is_wp_error($user)) {
        $error = 'Invalid username or password.';
    } else {
        if (isset($_GET['redirect_to']) && !empty($_GET['redirect_to'])) {
            $redirect = esc_url($_GET['redirect_to']);
        } else {
            $redirect = class_exists('PTP_User') ? PTP_User::get_dashboard_url($user->ID) : home_url('/my-training/');
        }
        wp_redirect($redirect);
        exit;
    }
}

$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';
$bg_image = 'https://ptpsummercamps.com/wp-content/uploads/2025/12/PHL_8689.jpg';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>Login - PTP Training</title>
    <?php wp_head(); ?>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap');
    
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    
    html, body {
        width: 100% !important;
        min-height: 100vh !important;
        margin: 0 !important;
        padding: 0 !important;
        font-family: 'Inter', -apple-system, sans-serif !important;
        -webkit-font-smoothing: antialiased;
        -webkit-tap-highlight-color: transparent;
        background: #0A0A0A !important;
    }
    
    body.ptp-login-page #page, body.ptp-login-page #content, body.ptp-login-page .site-content,
    body.ptp-login-page .entry-content, body.ptp-login-page main, body.ptp-login-page article,
    body.ptp-login-page header:not(.ptp-header), body.ptp-login-page footer:not(.ptp-footer),
    body.ptp-login-page .site-header, body.ptp-login-page .site-footer,
    body.ptp-login-page #masthead, body.ptp-login-page .main-navigation { display: none !important; }
    
    .ptp-auth { min-height: 100vh; display: flex; width: 100%; }
    
    .ptp-auth-left {
        flex: 1;
        background: linear-gradient(135deg, rgba(10,10,10,0.9), rgba(10,10,10,0.7)), url('<?php echo esc_url($bg_image); ?>') center/cover;
        display: none; flex-direction: column; justify-content: center; padding: 60px;
    }
    
    .ptp-auth-right {
        width: 100%; background: #FFFFFF;
        display: flex; align-items: center; justify-content: center; padding: 24px 16px;
        min-height: 100vh;
    }
    
    .ptp-auth-card { width: 100%; max-width: 360px; }
    .ptp-auth-logo { height: 40px; margin-bottom: 28px; }
    
    .ptp-auth-title {
        font-family: 'Oswald', sans-serif; font-size: 24px; font-weight: 700;
        color: #0A0A0A; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-auth-subtitle { font-size: 14px; color: #6B7280; margin-bottom: 28px; }
    .ptp-form-group { margin-bottom: 18px; }
    
    .ptp-label {
        display: block; font-size: 12px; font-weight: 700; color: #374151;
        margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-input {
        width: 100%; padding: 14px 16px; border: 2px solid #E5E5E5;
        font-family: 'Inter', sans-serif; font-size: 16px;
        transition: border-color 0.15s; background: #FFFFFF;
        min-height: 48px;
    }
    
    .ptp-input:focus { border-color: #FCB900; outline: none; }
    
    .ptp-checkbox-row { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 12px; }
    
    .ptp-checkbox-label {
        display: flex; align-items: center; gap: 10px;
        font-size: 14px; color: #4B5563; cursor: pointer;
        min-height: 44px;
    }
    
    .ptp-checkbox-label input { width: 20px; height: 20px; accent-color: #FCB900; }
    .ptp-forgot { font-size: 14px; color: #FCB900; text-decoration: none; font-weight: 600; min-height: 44px; display: flex; align-items: center; }
    .ptp-forgot:hover, .ptp-forgot:active { text-decoration: underline; }
    
    .ptp-btn-primary {
        width: 100%; padding: 16px; background: #FCB900; color: #0A0A0A;
        border: 2px solid #0A0A0A; font-family: 'Oswald', sans-serif;
        font-size: 16px; font-weight: 700; cursor: pointer;
        transition: background 0.15s; text-transform: uppercase; letter-spacing: 0.02em;
        min-height: 52px;
    }
    
    .ptp-btn-primary:hover, .ptp-btn-primary:active { background: #e5a800; }
    
    .ptp-error {
        background: #FEF2F2; border: 2px solid #EF4444;
        color: #DC2626; padding: 14px 16px; margin-bottom: 20px; font-size: 14px;
    }
    
    .ptp-divider { display: flex; align-items: center; gap: 16px; margin: 24px 0; }
    .ptp-divider-line { flex: 1; height: 2px; background: #E5E5E5; }
    .ptp-divider-text { font-size: 12px; color: #9CA3AF; text-transform: uppercase; letter-spacing: 0.05em; }
    
    .ptp-register-link { text-align: center; font-size: 14px; color: #6B7280; }
    .ptp-register-link a { color: #0A0A0A; font-weight: 700; text-decoration: none; padding: 8px 0; display: inline-block; }
    .ptp-register-link a:hover, .ptp-register-link a:active { color: #FCB900; }
    
    .ptp-hero-text { max-width: 500px; }
    
    .ptp-hero-badge {
        display: inline-flex; align-items: center; gap: 6px;
        background: rgba(252,185,0,0.2); border: 2px solid rgba(252,185,0,0.5);
        padding: 8px 14px; font-family: 'Oswald', sans-serif; font-size: 12px;
        font-weight: 700; color: #FCB900; margin-bottom: 20px;
        text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-hero-title {
        font-family: 'Oswald', sans-serif; font-size: 48px; font-weight: 700;
        color: #FFFFFF; line-height: 1.1; margin-bottom: 16px;
        text-transform: uppercase; letter-spacing: 0.02em;
    }
    
    .ptp-hero-subtitle { font-size: 18px; color: #9CA3AF; line-height: 1.6; }
    
    @media (min-width: 640px) {
        .ptp-auth-right { padding: 40px; }
        .ptp-auth-logo { height: 48px; margin-bottom: 32px; }
        .ptp-auth-title { font-size: 28px; }
        .ptp-auth-subtitle { margin-bottom: 32px; }
    }
    
    @media (min-width: 968px) {
        .ptp-auth-left { display: flex; }
        .ptp-auth-right { width: 480px; min-height: auto; }
    }
    </style>
</head>
<body class="ptp-login-page">
    <!-- Dark Header -->
    <div style="position:fixed;top:0;left:0;right:0;background:#0A0A0A;padding:12px 16px;z-index:100;display:flex;align-items:center;justify-content:space-between">
        <a href="<?php echo esc_url(home_url('/')); ?>">
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" style="height:28px">
        </a>
        <div style="display:flex;align-items:center;gap:5px;font-size:12px;color:#10B981;font-weight:600">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Secure
        </div>
    </div>
    
    <div class="ptp-auth" style="padding-top:52px">
        <div class="ptp-auth-left">
            <div class="ptp-hero-text">
                <div class="ptp-hero-badge">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
                    Players Teaching Players
                </div>
                <h1 class="ptp-hero-title">Train With The Best</h1>
                <p class="ptp-hero-subtitle">Connect with elite NCAA and professional athletes for personalized training.</p>
            </div>
        </div>
        
        <div class="ptp-auth-right">
            <div class="ptp-auth-card">
                <?php if ($logo_url): ?>
                <a href="<?php echo esc_url(home_url('/')); ?>">
                    <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" class="ptp-auth-logo">
                </a>
                <?php endif; ?>
                
                <h2 class="ptp-auth-title">Welcome Back</h2>
                <p class="ptp-auth-subtitle">Sign in to continue to your account</p>
                
                <?php if ($error): ?>
                <div class="ptp-error"><?php echo esc_html($error); ?></div>
                <?php endif; ?>
                
                <form method="post">
                    <?php wp_nonce_field('ptp_login', 'ptp_login_nonce'); ?>
                    
                    <div class="ptp-form-group">
                        <label class="ptp-label">Email or Username</label>
                        <input type="text" name="username" class="ptp-input" placeholder="Enter your email" required>
                    </div>
                    
                    <div class="ptp-form-group">
                        <label class="ptp-label">Password</label>
                        <input type="password" name="password" class="ptp-input" placeholder="Enter your password" required>
                    </div>
                    
                    <div class="ptp-checkbox-row">
                        <label class="ptp-checkbox-label">
                            <input type="checkbox" name="remember" value="1"> Remember me
                        </label>
                        <a href="<?php echo esc_url(wp_lostpassword_url()); ?>" class="ptp-forgot">Forgot password?</a>
                    </div>
                    
                    <button type="submit" name="ptp_login" value="1" class="ptp-btn-primary">Sign In</button>
                </form>
                
                <div class="ptp-divider">
                    <div class="ptp-divider-line"></div>
                    <span class="ptp-divider-text">or</span>
                    <div class="ptp-divider-line"></div>
                </div>
                
                <p class="ptp-register-link">Don't have an account? <a href="<?php echo esc_url(home_url('/register/')); ?>">Create one</a></p>
            </div>
        </div>
    </div>
    <?php wp_footer(); ?>
</body>
</html>
