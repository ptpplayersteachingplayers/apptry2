<?php
/**
 * Template: Book Session Checkout v42.0.0
 * 
 * Mobile-first with 44px touch targets, iOS zoom prevention,
 * enhanced secure checkout with trust signals, processing overlay,
 * better error handling, and retry mechanism.
 * 
 * Custom checkout experience separate from WooCommerce /cart
 * Handles: single sessions, 5-pack, 10-pack, group sessions
 * 
 * URL Parameters:
 * - trainer_id: Trainer ID
 * - date: Session date (YYYY-MM-DD)
 * - time: Session time (HH:MM)
 * - location: Training location name
 * - type: single, package_5, package_10, group
 */
defined('ABSPATH') || exit;

// Check if loaded via shortcode (header already exists)
$is_shortcode = defined('DOING_AJAX') || did_action('wp_head') > 0;

$logo_url = PTP_Images::logo();

// Get URL parameters
$trainer_id = intval($_GET['trainer_id'] ?? 0);
$date = sanitize_text_field($_GET['date'] ?? '');
$time = sanitize_text_field($_GET['time'] ?? '');
$location = sanitize_text_field($_GET['location'] ?? '');
$session_type = sanitize_text_field($_GET['type'] ?? 'single');

// Validate trainer - this should already be validated by shortcode but double-check
$trainer = $trainer_id ? PTP_Trainer::get($trainer_id) : null;
if (!$trainer || $trainer->status !== 'active') {
    echo '<div style="min-height:60vh;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Inter,-apple-system,sans-serif;background:#FFFFFF">
        <div style="background:#FFFFFF;border:2px solid #E5E5E5;padding:48px 40px;text-align:center;max-width:420px">
            <img src="' . esc_url($logo_url) . '" alt="PTP Training" style="height:40px;max-width:160px;width:auto;object-fit:contain;margin-bottom:24px">
            <h2 style="font-family:Oswald,sans-serif;font-size:24px;font-weight:700;margin:0 0 12px;color:#0A0A0A;text-transform:uppercase;letter-spacing:0.02em">Invalid Booking</h2>
            <p style="color:#6B7280;margin:0 0 28px">The trainer is not available or the booking link is invalid.</p>
            <a href="' . esc_url(home_url('/find-trainers/')) . '" style="display:inline-flex;background:#FCB900;color:#0A0A0A;padding:14px 32px;font-family:Oswald,sans-serif;font-weight:700;text-decoration:none;text-transform:uppercase;letter-spacing:0.02em;border:2px solid #0A0A0A">Find Trainers</a>
        </div>
    </div>';
    return;
}

// Validate required parameters
if (!$date || !$time) {
    echo '<div style="min-height:60vh;display:flex;align-items:center;justify-content:center;padding:24px;font-family:Inter,-apple-system,sans-serif;background:#FFFFFF">
        <div style="background:#FFFFFF;border:2px solid #E5E5E5;padding:48px 40px;text-align:center;max-width:420px">
            <img src="' . esc_url($logo_url) . '" alt="PTP Training" style="height:40px;max-width:160px;width:auto;object-fit:contain;margin-bottom:24px">
            <h2 style="font-family:Oswald,sans-serif;font-size:24px;font-weight:700;margin:0 0 12px;color:#0A0A0A;text-transform:uppercase;letter-spacing:0.02em">Missing Information</h2>
            <p style="color:#6B7280;margin:0 0 28px">Please select a date and time from the trainer\'s profile.</p>
            <a href="' . esc_url(home_url('/trainer/' . $trainer->slug . '/')) . '" style="display:inline-flex;background:#FCB900;color:#0A0A0A;padding:14px 32px;font-family:Oswald,sans-serif;font-weight:700;text-decoration:none;text-transform:uppercase;letter-spacing:0.02em;border:2px solid #0A0A0A">Back to Profile</a>
        </div>
    </div>';
    return;
}

// Calculate pricing
$base_rate = (int)($trainer->hourly_rate ?: 80);
$total_amount = $base_rate;
$session_count = 1;
$per_session_rate = $base_rate;
$savings_percent = 0;
$package_label = 'Single Session';

// Normalize session type (accept both '5pack' and 'package_5' formats)
if ($session_type === '5pack') $session_type = 'package_5';
if ($session_type === '10pack') $session_type = 'package_10';

switch ($session_type) {
    case 'package_5':
        $per_session_rate = round($base_rate * 0.90);
        $session_count = 5;
        $total_amount = $per_session_rate * 5;
        $savings_percent = 10;
        $package_label = '5-Session Pack';
        break;
    case 'package_10':
        $per_session_rate = round($base_rate * 0.85);
        $session_count = 10;
        $total_amount = $per_session_rate * 10;
        $savings_percent = 15;
        $package_label = '10-Session Pack';
        break;
    case 'group':
        $per_session_rate = round($base_rate * 0.60);
        $total_amount = $per_session_rate; // Per player, will be calculated based on player count
        $savings_percent = 40;
        $package_label = 'Group Session';
        break;
}

// Format date/time for display
$date_display = date('l, F j, Y', strtotime($date));
$time_display = date('g:i A', strtotime($time));

// Get trainer info
$trainer_photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 200);
$trainer_location = $trainer->city && $trainer->state ? $trainer->city . ', ' . $trainer->state : ($trainer->location ?: 'Philadelphia Area');
$first_name = explode(' ', $trainer->display_name)[0];

// Check if user is logged in
$is_logged_in = is_user_logged_in();
$current_user = wp_get_current_user();

// Get existing players if logged in
$existing_players = array();
if ($is_logged_in) {
    $parent = PTP_Parent::get_by_user_id(get_current_user_id());
    if ($parent) {
        $existing_players = PTP_Player::get_by_parent($parent->id);
    }
}

// Get Stripe publishable key using proper class method
$stripe_key = '';
if (class_exists('PTP_Stripe')) {
    PTP_Stripe::init();
    $stripe_key = PTP_Stripe::get_publishable_key();
}
// Fallback to direct option check
if (empty($stripe_key)) {
    $test_mode = get_option('ptp_stripe_test_mode', true);
    $stripe_key = $test_mode 
        ? get_option('ptp_stripe_test_publishable', '')
        : get_option('ptp_stripe_live_publishable', '');
}
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800;900&display=swap');
*{box-sizing:border-box}
.bs{font-family:'Inter',-apple-system,sans-serif;-webkit-font-smoothing:antialiased;background:#FFFFFF;color:#0A0A0A;min-height:100vh}
.bs *{box-sizing:border-box}.bs h1,.bs h2,.bs h3,.bs p{margin:0}
.bs-heading{font-family:'Oswald',sans-serif;text-transform:uppercase;letter-spacing:0.02em;font-weight:700}

/* Header */
.bs-header{background:#0A0A0A;padding:20px}
.bs-header-inner{max-width:1100px;margin:0 auto;display:flex;justify-content:space-between;align-items:center}
.bs-logo{height:36px}
.bs-back{color:#9CA3AF;text-decoration:none;font-size:14px;display:flex;align-items:center;gap:6px}
.bs-back:hover{color:#FCB900}

/* Main Layout */
.bs-main{max-width:1100px;margin:0 auto;padding:32px 20px 80px;display:grid;grid-template-columns:1fr 380px;gap:40px}

/* Form Card */
.bs-form-card{background:#FFFFFF;border:2px solid #E5E5E5;padding:32px}
.bs-section{margin-bottom:32px}
.bs-section:last-child{margin-bottom:0}
.bs-section-title{font-family:'Oswald',sans-serif;font-size:18px;font-weight:700;margin-bottom:20px;color:#0A0A0A;text-transform:uppercase;letter-spacing:0.02em;display:flex;align-items:center;gap:10px}
.bs-section-title svg{color:#FCB900}

/* Form Fields */
.bs-field{margin-bottom:16px}
.bs-label{display:block;font-size:13px;font-weight:600;color:#374151;margin-bottom:6px;text-transform:uppercase;letter-spacing:0.02em}
.bs-input{width:100%;padding:14px 16px;border:2px solid #E5E5E5;font-family:inherit;font-size:15px;outline:none;transition:border-color 0.2s;background:#FFFFFF}
.bs-input:focus{border-color:#FCB900}
.bs-input::placeholder{color:#9CA3AF}
.bs-row{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.bs-select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center}

/* Player Selection */
.bs-player-select{padding:16px;border:2px solid #E5E5E5;cursor:pointer;transition:all 0.15s;margin-bottom:10px;display:flex;align-items:center;gap:12px}
.bs-player-select:hover{border-color:#FCB900;background:#FFFBEB}
.bs-player-select.selected{border-color:#FCB900;background:#FEF3C7}
.bs-player-icon{width:40px;height:40px;background:#F3F4F6;display:flex;align-items:center;justify-content:center;border-radius:50%}
.bs-player-select.selected .bs-player-icon{background:#FCB900}

/* Group Players */
.bs-group-player{background:#F9FAFB;border:2px solid #E5E5E5;padding:20px;margin-bottom:12px}
.bs-group-player-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
.bs-group-player-title{font-weight:700;font-size:15px}
.bs-remove-player{background:none;border:none;color:#EF4444;cursor:pointer;font-size:13px;font-weight:600}

/* Submit */
.bs-submit{width:100%;padding:18px;background:#FCB900;color:#0A0A0A;border:2px solid #0A0A0A;font-family:'Oswald',sans-serif;font-size:16px;font-weight:700;cursor:pointer;text-transform:uppercase;letter-spacing:0.02em;transition:all 0.2s}
.bs-submit:hover{background:#e5a800}
.bs-submit:disabled{opacity:0.5;cursor:not-allowed}

/* Stripe Element */
#card-element{padding:14px 16px;border:2px solid #E5E5E5;background:#FFFFFF;transition:border-color 0.2s;min-height:50px}
#card-element.StripeElement--focus{border-color:#FCB900;box-shadow:0 0 0 3px rgba(252,185,0,0.1)}
#card-element.StripeElement--invalid{border-color:#EF4444}
#card-element.StripeElement--complete{border-color:#059669;background:#F0FDF4}
.bs-card-errors{min-height:20px;margin-top:8px}
.bs-error-message{display:flex;align-items:flex-start;gap:10px;padding:14px 16px;background:#FEF2F2;border:2px solid #EF4444;margin-top:12px;animation:shake 0.5s ease-in-out}
.bs-error-message svg{flex-shrink:0;margin-top:1px;color:#DC2626}
.bs-error-message span{color:#DC2626;font-size:14px;font-weight:500;line-height:1.4}
@keyframes shake{0%,100%{transform:translateX(0)}10%,30%,50%,70%,90%{transform:translateX(-4px)}20%,40%,60%,80%{transform:translateX(4px)}}
.stripe-loading{padding:14px 16px;border:2px solid #E5E5E5;background:#F9FAFB;color:#6B7280;font-size:14px;min-height:50px;display:flex;align-items:center;gap:10px}
.stripe-error-box{padding:16px;border:2px solid #EF4444;background:#FEF2F2;color:#DC2626;font-size:14px;margin-bottom:16px}

/* Accepted Cards */
.bs-accepted-cards{display:flex;align-items:center;gap:12px;margin-bottom:16px;padding:12px 16px;background:#F9FAFB;border:1px solid #E5E5E5}
.bs-accepted-label{font-size:12px;color:#6B7280;font-weight:500;text-transform:uppercase;letter-spacing:0.02em}
.bs-card-icons{display:flex;gap:8px;align-items:center}
.bs-card-icon{height:24px;width:auto}

/* Security Badges */
.bs-security-badges{display:flex;flex-wrap:wrap;gap:12px;margin-top:16px;padding-top:16px;border-top:1px solid #F3F4F6}
.bs-security-badge{display:flex;align-items:center;gap:6px;font-size:12px;color:#059669;font-weight:500}
.bs-security-badge svg{flex-shrink:0}

/* Enhanced Submit Button */
.bs-submit{width:100%;padding:18px 24px;background:#FCB900;color:#0A0A0A;border:2px solid #0A0A0A;font-family:'Oswald',sans-serif;font-size:16px;font-weight:700;cursor:pointer;text-transform:uppercase;letter-spacing:0.02em;transition:all 0.2s;margin-top:24px}
.bs-submit:hover:not(:disabled){background:#e5a800;transform:translateY(-1px);box-shadow:0 4px 12px rgba(0,0,0,0.15)}
.bs-submit:disabled{opacity:0.6;cursor:not-allowed;transform:none;box-shadow:none}
.bs-submit-text,.bs-submit-processing{display:flex;align-items:center;justify-content:center;gap:10px}

/* Guarantee Badge */
.bs-guarantee{display:flex;align-items:flex-start;gap:12px;margin-top:20px;padding:16px;background:#ECFDF5;border:2px solid #059669}
.bs-guarantee svg{flex-shrink:0;margin-top:2px}
.bs-guarantee-text{display:flex;flex-direction:column;gap:2px}
.bs-guarantee-text strong{font-size:14px;color:#047857;font-weight:700}
.bs-guarantee-text span{font-size:12px;color:#059669}

/* Terms */
.bs-terms{text-align:center;font-size:12px;color:#6B7280;margin-top:16px;line-height:1.5}
.bs-terms a{color:#0A0A0A;text-decoration:underline}
.bs-terms a:hover{color:#FCB900}

/* Processing Overlay */
.bs-processing-overlay{position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.7);display:flex;align-items:center;justify-content:center;z-index:9999;opacity:0;visibility:hidden;transition:all 0.3s}
.bs-processing-overlay.active{opacity:1;visibility:visible}
.bs-processing-modal{background:#FFFFFF;padding:40px 48px;text-align:center;max-width:400px;width:90%;border:2px solid #0A0A0A}
.bs-processing-spinner{width:48px;height:48px;border:3px solid #E5E5E5;border-top-color:#FCB900;border-radius:50%;animation:spin 1s linear infinite;margin:0 auto 20px}
.bs-processing-title{font-family:'Oswald',sans-serif;font-size:20px;font-weight:700;color:#0A0A0A;text-transform:uppercase;margin-bottom:8px}
.bs-processing-text{font-size:14px;color:#6B7280}
.bs-processing-steps{margin-top:24px;text-align:left}
.bs-processing-step{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #F3F4F6;font-size:13px;color:#6B7280}
.bs-processing-step:last-child{border-bottom:none}
.bs-processing-step.active{color:#0A0A0A;font-weight:600}
.bs-processing-step.complete{color:#059669}
.bs-processing-step svg{flex-shrink:0}
.bs-step-spinner{width:18px;height:18px;border:2px solid #E5E5E5;border-top-color:#FCB900;border-radius:50%;animation:spin 1s linear infinite}
.bs-step-check{color:#059669}

/* Sidebar */
.bs-sidebar{position:sticky;top:20px;height:fit-content}
.bs-summary{background:#FFFFFF;border:2px solid #E5E5E5;padding:28px}
.bs-summary-title{font-family:'Oswald',sans-serif;font-size:18px;font-weight:700;margin-bottom:20px;color:#0A0A0A;text-transform:uppercase;letter-spacing:0.02em}

/* Trainer Info */
.bs-trainer{display:flex;gap:16px;padding-bottom:20px;border-bottom:2px solid #E5E5E5;margin-bottom:20px}
.bs-trainer-photo{width:70px;height:70px;overflow:hidden;border:2px solid #FCB900;flex-shrink:0}
.bs-trainer-photo img{width:100%;height:100%;object-fit:cover;image-rendering:-webkit-optimize-contrast;-webkit-backface-visibility:hidden;backface-visibility:hidden;transform:translateZ(0)}
.bs-trainer-name{font-weight:700;font-size:16px;margin-bottom:4px}
.bs-trainer-loc{font-size:13px;color:#6B7280}

/* Summary Details */
.bs-detail{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #F3F4F6}
.bs-detail:last-child{border-bottom:none}
.bs-detail-label{color:#6B7280;font-size:14px}
.bs-detail-value{font-weight:600;font-size:14px}
.bs-package-badge{display:inline-block;background:#059669;color:#fff;font-size:10px;font-weight:700;padding:3px 8px;margin-left:6px;font-family:'Oswald',sans-serif;text-transform:uppercase}
.bs-package-badge.purple{background:#7C3AED}
.bs-package-badge.blue{background:#3B82F6}

/* Total */
.bs-total{background:#F9FAFB;padding:20px;margin-top:20px;border:2px solid #E5E5E5}
.bs-total-row{display:flex;justify-content:space-between;align-items:center}
.bs-total-label{font-family:'Oswald',sans-serif;font-size:16px;font-weight:700;text-transform:uppercase}
.bs-total-amount{font-family:'Oswald',sans-serif;font-size:28px;font-weight:900;color:#0A0A0A}
.bs-savings{text-align:center;margin-top:10px;color:#059669;font-size:13px;font-weight:600}

/* Policy */
.bs-policy{margin-top:20px;padding:16px;background:#D1FAE5;border:2px solid #059669}
.bs-policy-title{font-weight:700;font-size:13px;color:#059669;margin-bottom:4px}
.bs-policy-text{font-size:12px;color:#047857}

/* Responsive */
@media(max-width:900px){
    .bs-main{grid-template-columns:1fr;gap:24px}
    .bs-sidebar{position:relative;top:0;order:-1}
}
@media(max-width:600px){
    .bs-main{padding:20px 16px 60px}
    .bs-form-card{padding:24px 16px}
    .bs-summary{padding:24px 16px}
    .bs-row{grid-template-columns:1fr}
    .bs-header-inner{padding:0 4px}
    .bs-back{font-size:13px}
    .bs-section-title{font-size:16px}
    .bs-trainer{flex-direction:column;align-items:center;text-align:center}
    .bs-trainer-photo{width:80px;height:80px}
    /* Prevent iOS zoom */
    .bs-input,.bs-select{font-size:16px !important}
    /* Touch targets */
    .bs-submit,.bs-player-select{min-height:48px}
    /* Processing modal */
    .bs-processing-modal{padding:32px 24px;width:95%}
}
@media(max-width:380px){
    .bs-form-card{padding:20px 12px}
    .bs-summary{padding:20px 12px}
    .bs-total-amount{font-size:24px}
}
</style>

<div class="bs">
    <!-- Header -->
    <div class="bs-header">
        <div class="bs-header-inner">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training" class="bs-logo">
            </a>
            <a href="<?php echo esc_url(home_url('/trainer/' . $trainer->slug . '/')); ?>" class="bs-back">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                Back to Profile
            </a>
        </div>
    </div>

    <!-- Main -->
    <div class="bs-main">
        <!-- Form -->
        <div class="bs-form-card">
            <form id="checkout-form">
                <input type="hidden" name="trainer_id" value="<?php echo esc_attr($trainer_id); ?>">
                <input type="hidden" name="date" value="<?php echo esc_attr($date); ?>">
                <input type="hidden" name="time" value="<?php echo esc_attr($time); ?>">
                <input type="hidden" name="location" value="<?php echo esc_attr($location); ?>">
                <input type="hidden" name="session_type" value="<?php echo esc_attr($session_type); ?>">
                <input type="hidden" name="amount" id="total-amount" value="<?php echo esc_attr($total_amount); ?>">
                <input type="hidden" name="nonce" value="<?php echo wp_create_nonce('ptp_checkout'); ?>">

                <!-- Contact Information -->
                <div class="bs-section">
                    <h2 class="bs-section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        Contact Information
                    </h2>
                    
                    <?php if ($is_logged_in): ?>
                    <div style="background:#D1FAE5;border:2px solid #059669;padding:16px;margin-bottom:20px;display:flex;align-items:center;gap:12px">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                        <div>
                            <div style="font-weight:700;color:#059669;font-size:14px">Logged in as <?php echo esc_html($current_user->display_name); ?></div>
                            <div style="font-size:13px;color:#047857"><?php echo esc_html($current_user->user_email); ?></div>
                        </div>
                    </div>
                    <input type="hidden" name="email" value="<?php echo esc_attr($current_user->user_email); ?>">
                    <input type="hidden" name="first_name" value="<?php echo esc_attr($current_user->first_name ?: $current_user->display_name); ?>">
                    <input type="hidden" name="last_name" value="<?php echo esc_attr($current_user->last_name); ?>">
                    <?php else: ?>
                    <div class="bs-row">
                        <div class="bs-field">
                            <label class="bs-label">First Name *</label>
                            <input type="text" name="first_name" class="bs-input" required placeholder="John">
                        </div>
                        <div class="bs-field">
                            <label class="bs-label">Last Name</label>
                            <input type="text" name="last_name" class="bs-input" placeholder="Smith">
                        </div>
                    </div>
                    <div class="bs-field">
                        <label class="bs-label">Email *</label>
                        <input type="email" name="email" class="bs-input" required placeholder="john@example.com">
                    </div>
                    <?php endif; ?>
                    
                    <div class="bs-field">
                        <label class="bs-label">Phone Number *</label>
                        <input type="tel" name="phone" class="bs-input" required placeholder="(555) 123-4567" <?php echo $is_logged_in && !empty($parent->phone) ? 'value="' . esc_attr($parent->phone) . '"' : ''; ?>>
                    </div>
                </div>

                <!-- Player Information -->
                <div class="bs-section">
                    <h2 class="bs-section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                        Player Information
                    </h2>
                    
                    <?php if (!empty($existing_players)): ?>
                    <div style="margin-bottom:20px">
                        <label class="bs-label" style="margin-bottom:10px">Select a Player</label>
                        <?php foreach ($existing_players as $player): ?>
                        <div class="bs-player-select" data-player-id="<?php echo esc_attr($player->id); ?>" onclick="selectPlayer(this)">
                            <div class="bs-player-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                            </div>
                            <div>
                                <div style="font-weight:700"><?php echo esc_html($player->name); ?></div>
                                <div style="font-size:13px;color:#6B7280">Age <?php echo esc_html($player->age); ?> • <?php echo esc_html(ucfirst($player->skill_level)); ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <div class="bs-player-select" data-player-id="new" onclick="selectPlayer(this)">
                            <div class="bs-player-icon">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                            </div>
                            <div style="font-weight:700">Add New Player</div>
                        </div>
                    </div>
                    <input type="hidden" name="player_id" id="selected-player-id" value="">
                    <?php endif; ?>
                    
                    <div id="new-player-fields" <?php echo !empty($existing_players) ? 'style="display:none"' : ''; ?>>
                        <div class="bs-row">
                            <div class="bs-field">
                                <label class="bs-label">Player First Name *</label>
                                <input type="text" name="player_first_name" class="bs-input" placeholder="Alex">
                            </div>
                            <div class="bs-field">
                                <label class="bs-label">Player Last Name</label>
                                <input type="text" name="player_last_name" class="bs-input" placeholder="Smith">
                            </div>
                        </div>
                        <div class="bs-row">
                            <div class="bs-field">
                                <label class="bs-label">Age *</label>
                                <input type="number" name="player_age" class="bs-input" min="4" max="25" placeholder="12">
                            </div>
                            <div class="bs-field">
                                <label class="bs-label">Skill Level</label>
                                <select name="player_skill" class="bs-input bs-select">
                                    <option value="beginner">Beginner</option>
                                    <option value="intermediate" selected>Intermediate</option>
                                    <option value="advanced">Advanced</option>
                                    <option value="competitive">Competitive</option>
                                </select>
                            </div>
                        </div>
                        <div class="bs-field">
                            <label class="bs-label">Goals / Notes for Trainer</label>
                            <textarea name="player_notes" class="bs-input" rows="3" placeholder="What would you like to work on? Any injuries or special considerations?"><?php echo isset($_GET['notes']) ? esc_textarea($_GET['notes']) : ''; ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- Group Players (for group sessions) -->
                <?php if ($session_type === 'group'): ?>
                <div class="bs-section" id="group-players-section">
                    <h2 class="bs-section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                        Additional Players (Group Session)
                    </h2>
                    <p style="font-size:14px;color:#6B7280;margin-bottom:16px">Add 1-3 more players for your group session. Each additional player is $<?php echo $per_session_rate; ?>.</p>
                    
                    <div id="additional-players"></div>
                    
                    <button type="button" id="add-player-btn" onclick="addGroupPlayer()" style="width:100%;padding:14px;background:#F3F4F6;border:2px dashed #D1D5DB;font-family:'Oswald',sans-serif;font-size:14px;font-weight:600;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;text-transform:uppercase;letter-spacing:0.02em;color:#6B7280">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                        Add Another Player
                    </button>
                </div>
                <?php endif; ?>

                <!-- Payment -->
                <div class="bs-section">
                    <h2 class="bs-section-title">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                        Secure Payment
                    </h2>
                    
                    <?php if (empty($stripe_key)): ?>
                    <div class="stripe-error-box">
                        <strong>Payment not configured.</strong> Please contact support to complete your booking.
                    </div>
                    <?php else: ?>
                    
                    <!-- Accepted Cards -->
                    <div class="bs-accepted-cards">
                        <span class="bs-accepted-label">We Accept:</span>
                        <div class="bs-card-icons">
                            <svg class="bs-card-icon" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg"><path fill="#1A1F71" d="M15.245 17.831h-2.969l1.857-11.662h2.969l-1.857 11.662zm12.389-11.375c-.586-.236-1.505-.489-2.652-.489-2.922 0-4.98 1.582-4.996 3.847-.017 1.674 1.466 2.609 2.585 3.167 1.149.571 1.535.937 1.529 1.448-.008.782-.917 1.14-1.765 1.14-1.181 0-1.809-.177-2.779-.612l-.38-.185-.414 2.606c.689.324 1.964.605 3.289.619 3.108 0 5.126-1.564 5.15-3.983.012-1.327-.776-2.337-2.479-3.169-1.032-.54-1.664-.9-1.658-1.448 0-.486.535-.999 1.691-.999.965-.016 1.664.21 2.208.446l.265.135.4-2.523zm7.677-.287h-2.285c-.708 0-1.238.208-1.55.968l-4.391 10.681h3.103s.507-1.436.622-1.751l3.784.005c.089.408.36 1.746.36 1.746h2.742l-2.385-11.649zm-3.636 7.513c.244-.674 1.179-3.267 1.179-3.267-.017.031.243-.676.393-1.115l.2 1.007s.567 2.791.686 3.375h-2.458z"/><path fill="#1A1F71" d="M10.351 6.169l-2.896 7.96-.31-1.614c-.538-1.861-2.218-3.878-4.096-4.886l2.645 10.2h3.128l4.654-11.66h-3.125z"/><path fill="#F9A51A" d="M5.253 6.169H.461l-.05.311c3.707.966 6.161 3.3 7.181 6.104l-1.037-5.349c-.179-.734-.698-.95-1.302-1.066z"/></svg>
                            <svg class="bs-card-icon" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg"><circle fill="#EB001B" cx="15" cy="12" r="7"/><circle fill="#F79E1B" cx="23" cy="12" r="7"/><path fill="#FF5F00" d="M19 7.5c1.32 1.08 2.17 2.74 2.17 4.5s-.85 3.42-2.17 4.5c-1.32-1.08-2.17-2.74-2.17-4.5s.85-3.42 2.17-4.5z"/></svg>
                            <svg class="bs-card-icon" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg"><path fill="#016FD0" d="M35 0H3C1.3 0 0 1.3 0 3v18c0 1.7 1.3 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.3-3-3-3z"/><path fill="#FFF" d="M35 1c1.1 0 2 .9 2 2v18c0 1.1-.9 2-2 2H3c-1.1 0-2-.9-2-2V3c0-1.1.9-2 2-2h32m0-1H3C1.3 0 0 1.3 0 3v18c0 1.7 1.3 3 3 3h32c1.7 0 3-1.3 3-3V3c0-1.7-1.3-3-3-3z"/><text fill="#FFF" font-family="Arial" font-size="10" font-weight="bold" x="5" y="16">AMEX</text></svg>
                            <svg class="bs-card-icon" viewBox="0 0 38 24" xmlns="http://www.w3.org/2000/svg"><rect fill="#1A1F71" width="38" height="24" rx="3"/><text fill="#FFF" font-family="Arial" font-size="8" font-weight="bold" x="5" y="15">DISCOVER</text></svg>
                        </div>
                    </div>
                    
                    <div class="bs-field">
                        <label class="bs-label">Card Information</label>
                        <div id="card-element-loading" class="stripe-loading">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"/><path d="M12 2a10 10 0 0 1 10 10" stroke-opacity="1"/></svg>
                            Loading secure payment form...
                        </div>
                        <div id="card-element" style="display:none"></div>
                        <div id="card-errors" class="bs-card-errors" role="alert"></div>
                    </div>
                    
                    <!-- Security Trust Signals -->
                    <div class="bs-security-badges">
                        <div class="bs-security-badge">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                            <span>256-bit SSL Encryption</span>
                        </div>
                        <div class="bs-security-badge">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>
                            <span>Secure Checkout</span>
                        </div>
                        <div class="bs-security-badge">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span>PCI Compliant</span>
                        </div>
                    </div>
                    

                    <?php endif; ?>
                </div>

                <!-- Submit -->
                <button type="submit" class="bs-submit" id="submit-btn" <?php echo empty($stripe_key) ? 'disabled' : ''; ?>>
                    <span class="bs-submit-text">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0110 0v4"/></svg>
                        Pay Securely - $<span id="submit-total"><?php echo $total_amount; ?></span>
                    </span>
                    <span class="bs-submit-processing" style="display:none">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="animation:spin 1s linear infinite"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"/><path d="M12 2a10 10 0 0 1 10 10" stroke-opacity="1"/></svg>
                        Processing Payment...
                    </span>
                </button>
                
                <!-- Guarantee Badge -->
                <div class="bs-guarantee">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                    <div class="bs-guarantee-text">
                        <strong>100% Money-Back Guarantee</strong>
                        <span>Free cancellation up to 24 hours before your session</span>
                    </div>
                </div>
                
                <p class="bs-terms">
                    By completing this booking, you agree to our <a href="<?php echo esc_url(home_url('/terms/')); ?>">Terms of Service</a> and <a href="<?php echo esc_url(home_url('/privacy/')); ?>">Privacy Policy</a>. Your payment information is encrypted and secure.
                </p>
            </form>
        </div>

        <!-- Sidebar -->
        <div class="bs-sidebar">
            <div class="bs-summary">
                <h3 class="bs-summary-title">Booking Summary</h3>
                
                <!-- Trainer -->
                <div class="bs-trainer">
                    <div class="bs-trainer-photo">
                        <img src="<?php echo esc_url($trainer_photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>">
                    </div>
                    <div>
                        <div class="bs-trainer-name"><?php echo esc_html($trainer->display_name); ?></div>
                        <div class="bs-trainer-loc">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display:inline;vertical-align:middle;margin-right:4px"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                            <?php echo esc_html($trainer_location); ?>
                        </div>
                    </div>
                </div>
                
                <!-- Details -->
                <div class="bs-detail">
                    <span class="bs-detail-label">Package</span>
                    <span class="bs-detail-value">
                        <?php echo esc_html($package_label); ?>
                        <?php if ($savings_percent > 0): ?>
                        <span class="bs-package-badge <?php echo $session_type === 'package_10' ? 'purple' : ($session_type === 'group' ? 'blue' : ''); ?>">
                            <?php echo $savings_percent; ?>% Off
                        </span>
                        <?php endif; ?>
                    </span>
                </div>
                
                <?php if ($session_count > 1): ?>
                <div class="bs-detail">
                    <span class="bs-detail-label">Sessions</span>
                    <span class="bs-detail-value"><?php echo $session_count; ?> sessions</span>
                </div>
                <div class="bs-detail">
                    <span class="bs-detail-label">Per Session</span>
                    <span class="bs-detail-value">$<?php echo $per_session_rate; ?></span>
                </div>
                <?php endif; ?>
                
                <?php if ($session_type === 'group'): ?>
                <div class="bs-detail">
                    <span class="bs-detail-label">Players</span>
                    <span class="bs-detail-value" id="player-count-display">1 player</span>
                </div>
                <?php endif; ?>
                
                <div class="bs-detail">
                    <span class="bs-detail-label">First Session</span>
                    <span class="bs-detail-value"><?php echo esc_html($date_display); ?></span>
                </div>
                <div class="bs-detail">
                    <span class="bs-detail-label">Time</span>
                    <span class="bs-detail-value"><?php echo esc_html($time_display); ?></span>
                </div>
                <div class="bs-detail">
                    <span class="bs-detail-label">Location</span>
                    <span class="bs-detail-value"><?php echo esc_html($location ?: 'TBD'); ?></span>
                </div>
                
                <!-- Total -->
                <div class="bs-total">
                    <div class="bs-total-row">
                        <span class="bs-total-label">Total</span>
                        <span class="bs-total-amount">$<span id="sidebar-total"><?php echo $total_amount; ?></span></span>
                    </div>
                    <?php if ($savings_percent > 0 && $session_type !== 'group'): ?>
                    <div class="bs-savings">
                        You save $<?php echo ($base_rate * $session_count) - $total_amount; ?> with this package!
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Policy -->
                <div class="bs-policy">
                    <div class="bs-policy-title">✓ Free Cancellation</div>
                    <div class="bs-policy-text">Cancel up to 24 hours before your session for a full refund</div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Processing Overlay -->
<div class="bs-processing-overlay" id="processing-overlay">
    <div class="bs-processing-modal">
        <div class="bs-processing-spinner"></div>
        <div class="bs-processing-title">Processing Payment</div>
        <div class="bs-processing-text">Please wait while we secure your booking...</div>
        <div class="bs-processing-steps">
            <div class="bs-processing-step" id="step-validate">
                <span class="bs-step-icon"><div class="bs-step-spinner"></div></span>
                <span>Validating card information</span>
            </div>
            <div class="bs-processing-step" id="step-process">
                <span class="bs-step-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"/></svg></span>
                <span>Processing payment</span>
            </div>
            <div class="bs-processing-step" id="step-confirm">
                <span class="bs-step-icon"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"/></svg></span>
                <span>Confirming booking</span>
            </div>
        </div>
    </div>
</div>

<style>@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}</style>
<?php if (!empty($stripe_key)): ?>
<script src="https://js.stripe.com/v3/"></script>
<script>
// Debug logging
console.log('PTP Checkout: Stripe key present:', '<?php echo !empty($stripe_key) ? 'YES' : 'NO'; ?>');
console.log('PTP Checkout: Stripe object exists:', typeof Stripe !== 'undefined');

var stripe, elements, cardElement;

function initStripe() {
    if (typeof Stripe === 'undefined') {
        console.error('PTP Checkout: Stripe.js failed to load');
        document.getElementById('card-element-loading').innerHTML = '<span style="color:#EF4444">Failed to load payment system. Please refresh the page or disable ad blockers.</span>';
        return;
    }
    
    try {
        console.log('PTP Checkout: Initializing Stripe...');
        stripe = Stripe('<?php echo esc_js($stripe_key); ?>');
        elements = stripe.elements({
            fonts: [{cssSrc: 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500&display=swap'}]
        });
        cardElement = elements.create('card', {
            style: {
                base: {
                    fontSize: '16px',
                    fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, sans-serif',
                    fontWeight: '400',
                    color: '#0A0A0A',
                    '::placeholder': {color: '#9CA3AF'},
                    iconColor: '#FCB900'
                },
                invalid: {
                    color: '#EF4444',
                    iconColor: '#EF4444'
                }
            },
            hidePostalCode: false
        });
        
        cardElement.mount('#card-element');
        console.log('PTP Checkout: Card element mounted');
        
        // Show card element once ready
        cardElement.on('ready', function() {
            console.log('PTP Checkout: Card element ready');
            document.getElementById('card-element-loading').style.display = 'none';
            document.getElementById('card-element').style.display = 'block';
        });
        
        cardElement.on('change', function(event) {
            var display = document.getElementById('card-errors');
            if (event.error) {
                display.textContent = event.error.message;
            } else {
                display.textContent = '';
            }
            if (event.complete) {
                console.log('PTP Checkout: Card input complete');
            }
        });
    } catch (err) {
        console.error('PTP Checkout: Stripe init error:', err);
        document.getElementById('card-element-loading').innerHTML = '<span style="color:#EF4444">Failed to load payment: ' + err.message + '</span>';
    }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initStripe);
} else {
    initStripe();
}
<?php else: ?>
<script>
console.error('PTP Checkout: No Stripe publishable key configured');
var stripe = null, cardElement = null;
<?php endif; ?>

// Player selection
function selectPlayer(el) {
    document.querySelectorAll('.bs-player-select').forEach(p => p.classList.remove('selected'));
    el.classList.add('selected');
    var playerId = el.dataset.playerId;
    document.getElementById('selected-player-id').value = playerId;
    document.getElementById('new-player-fields').style.display = playerId === 'new' ? 'block' : 'none';
}

// Group session player management
<?php if ($session_type === 'group'): ?>
var groupPlayerCount = 0;
var baseRate = <?php echo $per_session_rate; ?>;
var maxPlayers = 3;

function addGroupPlayer() {
    if (groupPlayerCount >= maxPlayers) return;
    groupPlayerCount++;
    updateTotal();
    
    var container = document.getElementById('additional-players');
    var div = document.createElement('div');
    div.className = 'bs-group-player';
    div.id = 'group-player-' + groupPlayerCount;
    div.innerHTML = `
        <div class="bs-group-player-header">
            <span class="bs-group-player-title">Player ${groupPlayerCount + 1}</span>
            <button type="button" class="bs-remove-player" onclick="removeGroupPlayer(${groupPlayerCount})">Remove</button>
        </div>
        <div class="bs-row">
            <div class="bs-field">
                <label class="bs-label">Name *</label>
                <input type="text" name="group_player_${groupPlayerCount}_name" class="bs-input" placeholder="Player name" required>
            </div>
            <div class="bs-field">
                <label class="bs-label">Age *</label>
                <input type="number" name="group_player_${groupPlayerCount}_age" class="bs-input" min="4" max="25" placeholder="Age" required>
            </div>
        </div>
    `;
    container.appendChild(div);
    
    if (groupPlayerCount >= maxPlayers) {
        document.getElementById('add-player-btn').style.display = 'none';
    }
}

function removeGroupPlayer(num) {
    var el = document.getElementById('group-player-' + num);
    if (el) el.remove();
    groupPlayerCount--;
    updateTotal();
    document.getElementById('add-player-btn').style.display = 'flex';
}

function updateTotal() {
    var playerCount = groupPlayerCount + 1; // +1 for the main player
    var total = baseRate * playerCount;
    document.getElementById('total-amount').value = total;
    document.getElementById('sidebar-total').textContent = total;
    document.getElementById('submit-total').textContent = total;
    document.getElementById('player-count-display').textContent = playerCount + ' player' + (playerCount > 1 ? 's' : '');
}
<?php endif; ?>

// Form submission with enhanced error handling and processing overlay
var isProcessing = false;
var retryCount = 0;
var maxRetries = 2;

function showProcessingOverlay() {
    document.getElementById('processing-overlay').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function hideProcessingOverlay() {
    document.getElementById('processing-overlay').classList.remove('active');
    document.body.style.overflow = '';
}

function updateStep(stepId, status) {
    var step = document.getElementById(stepId);
    var icon = step.querySelector('.bs-step-icon');
    
    step.classList.remove('active', 'complete');
    
    if (status === 'active') {
        step.classList.add('active');
        icon.innerHTML = '<div class="bs-step-spinner"></div>';
    } else if (status === 'complete') {
        step.classList.add('complete');
        icon.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#059669" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>';
    } else {
        icon.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10" stroke-opacity="0.25"/></svg>';
    }
}

function resetSteps() {
    updateStep('step-validate', 'pending');
    updateStep('step-process', 'pending');
    updateStep('step-confirm', 'pending');
}

function showError(message) {
    var errorDiv = document.getElementById('card-errors');
    errorDiv.innerHTML = '<div class="bs-error-message"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><span>' + message + '</span></div>';
    // Scroll error into view
    errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

function clearError() {
    document.getElementById('card-errors').innerHTML = '';
}

function handleError(message) {
    console.error('PTP Checkout: Error -', message);
    hideProcessingOverlay();
    showError(message);
    resetButton();
}

function resetButton() {
    var btn = document.getElementById('submit-btn');
    btn.disabled = false;
    var textEl = btn.querySelector('.bs-submit-text');
    var procEl = btn.querySelector('.bs-submit-processing');
    if (textEl) textEl.style.display = 'flex';
    if (procEl) procEl.style.display = 'none';
    isProcessing = false;
}

function setButtonProcessing() {
    var btn = document.getElementById('submit-btn');
    btn.disabled = true;
    btn.querySelector('.bs-submit-text').style.display = 'none';
    btn.querySelector('.bs-submit-processing').style.display = 'flex';
}

document.getElementById('checkout-form').addEventListener('submit', async function(e) {
    e.preventDefault();
    console.log('PTP Checkout: Form submitted');
    
    // Prevent double submission
    if (isProcessing) {
        console.log('PTP Checkout: Already processing, ignoring');
        return;
    }
    isProcessing = true;
    
    var btn = document.getElementById('submit-btn');
    clearError();
    
    // Validate form fields first
    var form = this;
    if (!form.checkValidity()) {
        console.log('PTP Checkout: Form validation failed');
        form.reportValidity();
        isProcessing = false;
        return;
    }
    
    // Check if Stripe is initialized
    if (!stripe || !cardElement) {
        console.error('PTP Checkout: Stripe not initialized', {stripe: !!stripe, cardElement: !!cardElement});
        showError('Payment system not available. Please refresh the page and try again.');
        isProcessing = false;
        return;
    }
    
    console.log('PTP Checkout: Starting payment process');
    setButtonProcessing();
    showProcessingOverlay();
    resetSteps();
    
    // Step 1: Validate card
    updateStep('step-validate', 'active');
    
    try {
        console.log('PTP Checkout: Creating payment method...');
        var {paymentMethod, error} = await stripe.createPaymentMethod({
            type: 'card',
            card: cardElement,
            billing_details: {
                name: form.querySelector('[name="first_name"]')?.value + ' ' + (form.querySelector('[name="last_name"]')?.value || ''),
                email: form.querySelector('[name="email"]')?.value,
                phone: form.querySelector('[name="phone"]')?.value,
            }
        });
        
        if (error) {
            handleError(getReadableErrorMessage(error.code, error.message));
            return;
        }
        
        console.log('PTP Checkout: Payment method created', paymentMethod.id);
        updateStep('step-validate', 'complete');
        
        // Step 2: Process payment
        updateStep('step-process', 'active');
        
        var formData = new FormData(form);
        formData.append('action', 'ptp_process_checkout');
        formData.append('payment_method_id', paymentMethod.id);
        
        console.log('PTP Checkout: Sending to server...');
        var response = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: formData
        });
        
        console.log('PTP Checkout: Server response status', response.status);
        
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.status);
        }
        
        var data = await response.json();
        console.log('PTP Checkout: Server response', data);
        
        if (!data.success) {
            console.error('PTP Checkout: Server returned error', data);
            handleError(data.data?.message || 'Unable to process your booking. Please try again.');
            return;
        }
        
        if (!data.data.client_secret) {
            console.error('PTP Checkout: No client_secret in response');
            handleError('Payment setup incomplete. Please contact support.');
            return;
        }
        
        console.log('PTP Checkout: Confirming payment with Stripe...');
        // Confirm the payment with Stripe - must pass payment_method since we created it separately
        var {error: confirmError, paymentIntent} = await stripe.confirmCardPayment(data.data.client_secret, {
            payment_method: paymentMethod.id
        });
        
        if (confirmError) {
            handleError(getReadableErrorMessage(confirmError.code, confirmError.message));
            return;
        }
        
        console.log('PTP Checkout: Payment confirmed', paymentIntent.status);
        updateStep('step-process', 'complete');
        
        // Step 3: Confirm booking
        updateStep('step-confirm', 'active');
        
        var confirmData = new FormData();
        confirmData.append('action', 'ptp_confirm_checkout_payment');
        confirmData.append('nonce', '<?php echo wp_create_nonce('ptp_checkout'); ?>');
        confirmData.append('booking_id', data.data.booking_id);
        confirmData.append('payment_intent_id', paymentIntent.id);
        
        console.log('PTP Checkout: Confirming booking...');
        var confirmResponse = await fetch('<?php echo admin_url('admin-ajax.php'); ?>', {
            method: 'POST',
            body: confirmData
        });
        
        var confirmResult = await confirmResponse.json();
        console.log('PTP Checkout: Booking confirmation result', confirmResult);
        
        if (confirmResult.success) {
            console.log('PTP Checkout: SUCCESS! Redirecting...');
            updateStep('step-confirm', 'complete');
            // Brief pause to show success before redirect
            setTimeout(function() {
                window.location.href = confirmResult.data.redirect;
            }, 500);
        } else {
            handleError(confirmResult.data?.message || 'Your payment was processed but we encountered an error creating your booking. Please contact support with your payment confirmation.');
        }
        
    } catch (err) {
        console.error('Checkout error:', err);
        
        // Network/connection error - offer retry
        if (err.message && (err.message.includes('network') || err.message.includes('Network')) || err.name === 'TypeError') {
            if (retryCount < maxRetries) {
                retryCount++;
                hideProcessingOverlay();
                showError('Connection error. Retrying... (Attempt ' + (retryCount + 1) + ' of ' + (maxRetries + 1) + ')');
                setTimeout(function() {
                    isProcessing = false;
                    document.getElementById('checkout-form').dispatchEvent(new Event('submit'));
                }, 2000);
                return;
            }
        }
        
        handleError('An unexpected error occurred. Please check your internet connection and try again.');
        retryCount = 0;
    }
});

// Human-readable error messages
function getReadableErrorMessage(code, defaultMessage) {
    var messages = {
        'card_declined': 'Your card was declined. Please try a different card or contact your bank.',
        'expired_card': 'Your card has expired. Please use a different card.',
        'incorrect_cvc': 'The security code (CVC) is incorrect. Please check and try again.',
        'incorrect_number': 'The card number is incorrect. Please check and try again.',
        'insufficient_funds': 'Insufficient funds. Please try a different card.',
        'invalid_cvc': 'The security code (CVC) is invalid. Please check and try again.',
        'invalid_expiry_month': 'The expiration month is invalid.',
        'invalid_expiry_year': 'The expiration year is invalid.',
        'invalid_number': 'The card number is not a valid credit card number.',
        'processing_error': 'An error occurred while processing your card. Please try again.',
        'rate_limit': 'Too many requests. Please wait a moment and try again.',
        'generic_decline': 'Your card was declined. Please try a different payment method.',
        'fraudulent': 'This transaction has been flagged as potentially fraudulent.',
        'lost_card': 'This card has been reported lost. Please use a different card.',
        'stolen_card': 'This card has been reported stolen. Please use a different card.',
    };
    
    return messages[code] || defaultMessage || 'An error occurred with your payment. Please try again.';
}

// Prevent accidental navigation during payment
window.addEventListener('beforeunload', function(e) {
    if (isProcessing) {
        e.preventDefault();
        e.returnValue = 'Payment is being processed. Are you sure you want to leave?';
        return e.returnValue;
    }
});
</script>
