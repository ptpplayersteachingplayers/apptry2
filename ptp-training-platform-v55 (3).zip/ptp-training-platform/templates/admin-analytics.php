<?php
/**
 * Template: Admin Analytics Dashboard v1.0.0
 * Real-time stats, funnel visualization, revenue tracking
 */

defined('ABSPATH') || exit;

if (!current_user_can('manage_options')) {
    wp_die('Unauthorized');
}

$stats = PTP_Analytics::get_dashboard_stats(30);
$realtime = PTP_Analytics::get_realtime_stats();
$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics Dashboard - PTP Training</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
        font-family: 'Inter', -apple-system, sans-serif; 
        background: #F3F4F6; 
        min-height: 100vh;
        color: #111827;
    }
    
    .dash-header {
        background: #0A0A0A;
        padding: 16px 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .dash-logo { height: 32px; }
    .dash-title {
        font-family: 'Oswald', sans-serif;
        color: #fff;
        font-size: 20px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.02em;
    }
    .dash-realtime {
        display: flex;
        align-items: center;
        gap: 8px;
        background: rgba(16, 185, 129, 0.2);
        padding: 8px 16px;
        border-radius: 20px;
    }
    .dash-realtime-dot {
        width: 8px;
        height: 8px;
        background: #10B981;
        border-radius: 50%;
        animation: pulse 2s infinite;
    }
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.5; }
    }
    .dash-realtime-text {
        color: #10B981;
        font-size: 14px;
        font-weight: 600;
    }
    
    .dash-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 24px;
    }
    
    /* Summary Cards */
    .dash-summary {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 16px;
        margin-bottom: 24px;
    }
    @media (max-width: 1024px) {
        .dash-summary { grid-template-columns: repeat(2, 1fr); }
    }
    @media (max-width: 640px) {
        .dash-summary { grid-template-columns: 1fr; }
    }
    
    .dash-card {
        background: #fff;
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .dash-card-label {
        font-size: 13px;
        color: #6B7280;
        margin-bottom: 8px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .dash-card-value {
        font-family: 'Oswald', sans-serif;
        font-size: 36px;
        font-weight: 700;
        color: #111827;
    }
    .dash-card-value.gold { color: #F59E0B; }
    .dash-card-value.green { color: #10B981; }
    .dash-card-change {
        font-size: 13px;
        margin-top: 8px;
    }
    .dash-card-change.up { color: #10B981; }
    .dash-card-change.down { color: #EF4444; }
    
    /* Grid Layout */
    .dash-grid {
        display: grid;
        grid-template-columns: 2fr 1fr;
        gap: 24px;
        margin-bottom: 24px;
    }
    @media (max-width: 1024px) {
        .dash-grid { grid-template-columns: 1fr; }
    }
    
    .dash-section-title {
        font-family: 'Oswald', sans-serif;
        font-size: 18px;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.02em;
        margin-bottom: 16px;
        color: #111827;
    }
    
    /* Funnel */
    .dash-funnel {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .funnel-step {
        display: flex;
        align-items: center;
        gap: 16px;
        padding: 12px 0;
        border-bottom: 1px solid #F3F4F6;
    }
    .funnel-step:last-child { border-bottom: none; }
    .funnel-bar-container {
        flex: 1;
        height: 32px;
        background: #F3F4F6;
        border-radius: 4px;
        overflow: hidden;
    }
    .funnel-bar {
        height: 100%;
        background: linear-gradient(90deg, #FCB900, #F59E0B);
        display: flex;
        align-items: center;
        justify-content: flex-end;
        padding-right: 8px;
        min-width: 40px;
        transition: width 0.5s ease;
    }
    .funnel-bar-text {
        font-size: 12px;
        font-weight: 700;
        color: #0A0A0A;
    }
    .funnel-label {
        width: 140px;
        font-size: 13px;
        font-weight: 500;
        color: #374151;
    }
    .funnel-count {
        width: 60px;
        text-align: right;
        font-weight: 600;
        color: #111827;
    }
    .funnel-rate {
        width: 60px;
        text-align: right;
        font-size: 13px;
        color: #6B7280;
    }
    
    /* Chart */
    .dash-chart {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .chart-container {
        height: 300px;
    }
    
    /* Top Trainers */
    .dash-trainers {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .trainer-row {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 0;
        border-bottom: 1px solid #F3F4F6;
    }
    .trainer-row:last-child { border-bottom: none; }
    .trainer-rank {
        width: 24px;
        height: 24px;
        background: #F3F4F6;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: 700;
        color: #6B7280;
    }
    .trainer-rank.gold { background: #FCB900; color: #0A0A0A; }
    .trainer-photo {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }
    .trainer-info { flex: 1; }
    .trainer-name {
        font-weight: 600;
        font-size: 14px;
        color: #111827;
    }
    .trainer-bookings {
        font-size: 12px;
        color: #6B7280;
    }
    .trainer-revenue {
        font-weight: 700;
        color: #10B981;
    }
    
    /* Device Breakdown */
    .dash-devices {
        background: #fff;
        border-radius: 12px;
        padding: 24px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .device-row {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 12px 0;
    }
    .device-icon {
        width: 40px;
        height: 40px;
        background: #F3F4F6;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .device-info { flex: 1; }
    .device-name { font-weight: 600; font-size: 14px; }
    .device-bar {
        height: 6px;
        background: #E5E7EB;
        border-radius: 3px;
        margin-top: 6px;
        overflow: hidden;
    }
    .device-bar-fill {
        height: 100%;
        background: #FCB900;
        border-radius: 3px;
    }
    .device-percent {
        font-weight: 600;
        font-size: 14px;
        color: #111827;
    }
    
    /* Quick Actions */
    .dash-actions {
        display: flex;
        gap: 12px;
        margin-bottom: 24px;
    }
    .dash-action-btn {
        padding: 12px 20px;
        background: #fff;
        border: 2px solid #E5E7EB;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        color: #374151;
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
    }
    .dash-action-btn:hover {
        border-color: #FCB900;
        background: #FFFBEB;
    }
    .dash-action-btn.primary {
        background: #FCB900;
        border-color: #FCB900;
        color: #0A0A0A;
    }
    </style>
</head>
<body>

<div class="dash-header">
    <div style="display:flex;align-items:center;gap:24px">
        <img src="<?php echo esc_url($logo_url); ?>" alt="PTP" class="dash-logo">
        <span class="dash-title">Analytics Dashboard</span>
    </div>
    <div class="dash-realtime">
        <div class="dash-realtime-dot"></div>
        <span class="dash-realtime-text"><?php echo intval($realtime['active_users']); ?> active now</span>
    </div>
</div>

<div class="dash-container">
    
    <!-- Quick Actions -->
    <div class="dash-actions">
        <a href="<?php echo admin_url('admin.php?page=ptp-trainers'); ?>" class="dash-action-btn">Manage Trainers</a>
        <a href="<?php echo admin_url('admin.php?page=ptp-bookings'); ?>" class="dash-action-btn">View Bookings</a>
        <a href="<?php echo admin_url('admin.php?page=ptp-payouts'); ?>" class="dash-action-btn">Payouts</a>
        <a href="<?php echo home_url('/find-trainers/'); ?>" class="dash-action-btn primary" target="_blank">View Live Site →</a>
    </div>
    
    <!-- Summary Cards -->
    <div class="dash-summary">
        <div class="dash-card">
            <div class="dash-card-label">Visitors (30 days)</div>
            <div class="dash-card-value"><?php echo number_format($stats['summary']['visitors'] ?? 0); ?></div>
            <div class="dash-card-change up">↑ Real-time: <?php echo intval($realtime['active_users']); ?> now</div>
        </div>
        <div class="dash-card">
            <div class="dash-card-label">Bookings (30 days)</div>
            <div class="dash-card-value gold"><?php echo number_format($stats['summary']['bookings'] ?? 0); ?></div>
            <div class="dash-card-change">Today: <?php echo intval($realtime['bookings_today']); ?></div>
        </div>
        <div class="dash-card">
            <div class="dash-card-label">GMV (30 days)</div>
            <div class="dash-card-value">$<?php echo number_format($stats['summary']['gmv'] ?? 0); ?></div>
            <div class="dash-card-change">
                AOV: $<?php echo ($stats['summary']['bookings'] ?? 0) > 0 ? number_format(($stats['summary']['gmv'] ?? 0) / $stats['summary']['bookings'], 0) : 0; ?>
            </div>
        </div>
        <div class="dash-card">
            <div class="dash-card-label">Platform Revenue</div>
            <div class="dash-card-value green">$<?php echo number_format($stats['summary']['revenue'] ?? 0); ?></div>
            <div class="dash-card-change">Today: $<?php echo number_format($realtime['revenue_today'] ?? 0); ?></div>
        </div>
    </div>
    
    <div class="dash-grid">
        <!-- Revenue Chart -->
        <div class="dash-chart">
            <h3 class="dash-section-title">Revenue Trend</h3>
            <div class="chart-container">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
        
        <!-- Funnel -->
        <div class="dash-funnel">
            <h3 class="dash-section-title">Conversion Funnel (30 days)</h3>
            <?php
            $funnel = $stats['funnel'] ?? array();
            $steps = array(
                array('label' => 'Homepage', 'key' => 'step_1'),
                array('label' => 'Browse Trainers', 'key' => 'step_2'),
                array('label' => 'View Profile', 'key' => 'step_3'),
                array('label' => 'Start Booking', 'key' => 'step_4'),
                array('label' => 'Checkout', 'key' => 'step_5'),
                array('label' => 'Complete', 'key' => 'step_6'),
            );
            $max_value = max(array_values($funnel) ?: array(1));
            
            foreach ($steps as $i => $step):
                $value = intval($funnel[$step['key']] ?? 0);
                $percent = $max_value > 0 ? round(($value / $max_value) * 100) : 0;
                $prev_value = $i > 0 ? intval($funnel[$steps[$i-1]['key']] ?? 0) : $value;
                $conversion = $prev_value > 0 ? round(($value / $prev_value) * 100) : 0;
            ?>
            <div class="funnel-step">
                <div class="funnel-label"><?php echo esc_html($step['label']); ?></div>
                <div class="funnel-bar-container">
                    <div class="funnel-bar" style="width:<?php echo $percent; ?>%">
                        <span class="funnel-bar-text"><?php echo $percent; ?>%</span>
                    </div>
                </div>
                <div class="funnel-count"><?php echo number_format($value); ?></div>
                <div class="funnel-rate"><?php echo $i > 0 ? $conversion . '%' : ''; ?></div>
            </div>
            <?php endforeach; ?>
            
            <div style="margin-top:16px;padding-top:16px;border-top:2px solid #E5E7EB">
                <div style="display:flex;justify-content:space-between;font-size:14px">
                    <span style="color:#6B7280">Overall Conversion Rate:</span>
                    <span style="font-weight:700;color:#10B981">
                        <?php 
                        $overall = ($funnel['step_1'] ?? 0) > 0 
                            ? round((($funnel['step_6'] ?? 0) / $funnel['step_1']) * 100, 2) 
                            : 0;
                        echo $overall . '%';
                        ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
    
    <div class="dash-grid">
        <!-- Top Trainers -->
        <div class="dash-trainers">
            <h3 class="dash-section-title">Top Trainers (30 days)</h3>
            <?php if (!empty($stats['top_trainers'])): ?>
                <?php foreach ($stats['top_trainers'] as $i => $trainer): ?>
                <div class="trainer-row">
                    <div class="trainer-rank <?php echo $i === 0 ? 'gold' : ''; ?>"><?php echo $i + 1; ?></div>
                    <img src="<?php echo esc_url($trainer['photo_url'] ?: 'https://ui-avatars.com/api/?name=' . urlencode($trainer['display_name'])); ?>" 
                         alt="" class="trainer-photo">
                    <div class="trainer-info">
                        <div class="trainer-name"><?php echo esc_html($trainer['display_name']); ?></div>
                        <div class="trainer-bookings"><?php echo intval($trainer['bookings']); ?> bookings</div>
                    </div>
                    <div class="trainer-revenue">$<?php echo number_format($trainer['revenue'] ?? 0); ?></div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color:#6B7280;text-align:center;padding:20px">No booking data yet</p>
            <?php endif; ?>
        </div>
        
        <!-- Device Breakdown -->
        <div class="dash-devices">
            <h3 class="dash-section-title">Device Breakdown</h3>
            <?php
            $devices = $stats['devices'] ?? array();
            $total_devices = array_sum(array_column($devices, 'visitors')) ?: 1;
            $device_icons = array(
                'mobile' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12" y2="18"/></svg>',
                'desktop' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
                'tablet' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2"/><line x1="12" y1="18" x2="12" y2="18"/></svg>',
            );
            foreach ($devices as $device):
                $percent = round(($device['visitors'] / $total_devices) * 100);
            ?>
            <div class="device-row">
                <div class="device-icon">
                    <?php echo $device_icons[$device['device']] ?? $device_icons['desktop']; ?>
                </div>
                <div class="device-info">
                    <div class="device-name"><?php echo ucfirst(esc_html($device['device'])); ?></div>
                    <div class="device-bar">
                        <div class="device-bar-fill" style="width:<?php echo $percent; ?>%"></div>
                    </div>
                </div>
                <div class="device-percent"><?php echo $percent; ?>%</div>
            </div>
            <?php endforeach; ?>
            
            <?php if (empty($devices)): ?>
                <p style="color:#6B7280;text-align:center;padding:20px">No device data yet</p>
            <?php endif; ?>
        </div>
    </div>
    
</div>

<script>
// Revenue Chart
var ctx = document.getElementById('revenueChart').getContext('2d');
var dailyData = <?php echo json_encode($stats['daily_trend'] ?? array()); ?>;

// Process data
var dates = [];
var gmvData = [];
var bookingsData = [];
var dataByDate = {};

dailyData.forEach(function(row) {
    if (!dataByDate[row.stat_date]) {
        dataByDate[row.stat_date] = { gmv: 0, bookings: 0 };
    }
    if (row.metric === 'gmv') dataByDate[row.stat_date].gmv = parseFloat(row.value);
    if (row.metric === 'bookings') dataByDate[row.stat_date].bookings = parseInt(row.value);
});

Object.keys(dataByDate).sort().forEach(function(date) {
    dates.push(date);
    gmvData.push(dataByDate[date].gmv);
    bookingsData.push(dataByDate[date].bookings);
});

new Chart(ctx, {
    type: 'line',
    data: {
        labels: dates.map(function(d) { 
            return new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }); 
        }),
        datasets: [{
            label: 'GMV ($)',
            data: gmvData,
            borderColor: '#FCB900',
            backgroundColor: 'rgba(252, 185, 0, 0.1)',
            fill: true,
            tension: 0.3,
            yAxisID: 'y'
        }, {
            label: 'Bookings',
            data: bookingsData,
            borderColor: '#10B981',
            backgroundColor: 'transparent',
            borderDash: [5, 5],
            tension: 0.3,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
            mode: 'index',
            intersect: false,
        },
        plugins: {
            legend: {
                position: 'top',
            }
        },
        scales: {
            y: {
                type: 'linear',
                display: true,
                position: 'left',
                ticks: {
                    callback: function(value) { return '$' + value; }
                }
            },
            y1: {
                type: 'linear',
                display: true,
                position: 'right',
                grid: {
                    drawOnChartArea: false,
                },
            }
        }
    }
});

// Auto-refresh realtime stats every 30 seconds
setInterval(function() {
    fetch('<?php echo admin_url('admin-ajax.php'); ?>?action=ptp_get_realtime_stats')
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                document.querySelector('.dash-realtime-text').textContent = data.data.active_users + ' active now';
            }
        });
}, 30000);
</script>

</body>
</html>
