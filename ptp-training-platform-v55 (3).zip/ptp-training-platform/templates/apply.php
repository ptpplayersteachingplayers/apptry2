<?php
/**
 * Template: Apply as Trainer v34
 * STANDALONE full-page template - no theme interference
 */
defined('ABSPATH') || exit;

$error = '';
$success = false;
$submitted_name = '';

// Ensure database table exists
global $wpdb;
$table_name = $wpdb->prefix . 'ptp_applications';
$table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;

if (!$table_exists && class_exists('PTP_Database')) {
    PTP_Database::create_tables();
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ptp_apply'])) {
    if (!isset($_POST['ptp_apply_nonce']) || !wp_verify_nonce($_POST['ptp_apply_nonce'], 'ptp_apply')) {
        $error = 'Security verification failed. Please refresh and try again.';
    } elseif (!$table_exists) {
        $error = 'System error. Please contact support.';
    } else {
        $name = sanitize_text_field($_POST['name'] ?? '');
        $email = sanitize_email($_POST['email'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $password = $_POST['password'] ?? '';
        $password_confirm = $_POST['password_confirm'] ?? '';
        $playing_level = sanitize_text_field($_POST['playing_level'] ?? '');
        $college = sanitize_text_field($_POST['college'] ?? '');
        $team = sanitize_text_field($_POST['team'] ?? '');
        $position = sanitize_text_field($_POST['position'] ?? '');
        $city = sanitize_text_field($_POST['city'] ?? '');
        $state = sanitize_text_field($_POST['state'] ?? '');
        $specialties = isset($_POST['specialties']) ? array_map('sanitize_text_field', $_POST['specialties']) : array();
        $instagram = sanitize_text_field($_POST['instagram'] ?? '');
        $bio = sanitize_textarea_field($_POST['bio'] ?? '');
        $hourly_rate = floatval($_POST['hourly_rate'] ?? 70);
        $travel_radius = intval($_POST['travel_radius'] ?? 15);
        $how_heard = sanitize_text_field($_POST['how_heard'] ?? '');

        $submitted_name = $name;

        if (empty($name) || empty($email) || empty($phone) || empty($playing_level) || empty($city) || empty($state)) {
            $error = 'Please fill in all required fields.';
        } elseif (!is_email($email)) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters.';
        } elseif ($password !== $password_confirm) {
            $error = 'Passwords do not match.';
        } else {
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}ptp_applications WHERE email = %s", $email
            ));

            $is_trainer = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}ptp_trainers WHERE email = %s", $email
            ));

            if ($exists) {
                $error = 'An application with this email already exists.';
            } elseif ($is_trainer) {
                $error = 'You\'re already a trainer. Please log in.';
            } else {
                $result = $wpdb->insert(
                    $wpdb->prefix . 'ptp_applications',
                    array(
                        'name' => $name,
                        'email' => $email,
                        'phone' => $phone,
                        'password_hash' => wp_hash_password($password),
                        'playing_level' => $playing_level,
                        'college' => $college,
                        'team' => $team,
                        'position' => $position,
                        'location' => trim($city . ', ' . $state),
                        'specialties' => implode(', ', $specialties),
                        'instagram' => ltrim($instagram, '@'),
                        'bio' => $bio,
                        'hourly_rate' => $hourly_rate,
                        'travel_radius' => $travel_radius,
                        'admin_notes' => 'How heard: ' . $how_heard,
                        'status' => 'pending',
                        'created_at' => current_time('mysql')
                    ),
                    array('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%d', '%s', '%s', '%s')
                );

                if ($result) {
                    $application_id = $wpdb->insert_id;
                    $success = true;
                    
                    // Handle trainer referral
                    $referral_code = $_COOKIE['ptp_trainer_ref'] ?? sanitize_text_field($_POST['referral_code'] ?? '');
                    if (!empty($referral_code) && class_exists('PTP_Trainer_Referrals')) {
                        do_action('ptp_after_application_submit', $application_id, array(
                            'name' => $name,
                            'email' => $email,
                        ));
                    }
                    
                    // Fire action for other integrations
                    do_action('ptp_trainer_application_submitted', $application_id);

                    // Send notifications
                    $admin_email = get_option('admin_email');
                    add_filter('wp_mail_content_type', function() { return 'text/html'; });
                    wp_mail($admin_email, 'New Trainer Application - ' . $name,
                        '<h2>New Application</h2><p><strong>' . esc_html($name) . '</strong><br>' . esc_html($email) . '<br>' . esc_html($phone) . '</p>'
                    );
                    remove_filter('wp_mail_content_type', function() { return 'text/html'; });

                    if (class_exists('PTP_Email')) {
                        PTP_Email::send_application_received($email, $name);
                    }
                } else {
                    $error = 'Error submitting application. Please try again.';
                    error_log('PTP Application Error: ' . $wpdb->last_error);
                }
            }
        }
    }
}

$logo_url = class_exists('PTP_Images') ? PTP_Images::logo() : '';
$home_url = home_url('/');
$login_url = home_url('/login/');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Become a Trainer - PTP Training</title>
    <?php wp_head(); ?>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800;900&display=swap');
    
    /* Reset */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    
    /* Base - Override everything */
    html, body { 
        width: 100% !important;
        min-height: 100vh !important;
        margin: 0 !important;
        padding: 0 !important;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important;
        -webkit-font-smoothing: antialiased;
        background: #0A0A0A !important;
    }
    
    /* Kill all theme wrappers */
    body.ptp-apply-page #page,
    body.ptp-apply-page #content,
    body.ptp-apply-page .site-content,
    body.ptp-apply-page .entry-content,
    body.ptp-apply-page main,
    body.ptp-apply-page article,
    body.ptp-apply-page header:not(.apply-header),
    body.ptp-apply-page footer:not(.ptp-footer),
    body.ptp-apply-page .site-header,
    body.ptp-apply-page .site-footer,
    body.ptp-apply-page #masthead,
    body.ptp-apply-page .main-navigation {
        display: none !important;
    }
    
    /* Main Layout */
    .ptp-apply {
        width: 100%;
        min-height: 100vh;
        background: #0A0A0A;
        display: flex;
        flex-direction: column;
    }
    
    /* Header */
    .apply-header {
        padding: 20px 24px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 700px;
        margin: 0 auto;
        width: 100%;
    }
    .apply-logo { height: 36px; width: auto; }
    .apply-login { 
        color: #9CA3AF; 
        font-size: 14px; 
        text-decoration: none;
    }
    .apply-login:hover { color: #fff; }
    
    /* Hero - Centered */
    .apply-hero {
        text-align: center;
        padding: 40px 24px 50px;
        max-width: 700px;
        margin: 0 auto;
        width: 100%;
    }
    .apply-hero h1 {
        font-size: 42px;
        font-weight: 900;
        color: #fff;
        line-height: 1.1;
        margin: 0 0 16px;
    }
    .apply-hero h1 span { color: #FCB900; }
    .apply-hero p {
        font-size: 17px;
        color: #9CA3AF;
        margin: 0;
        line-height: 1.5;
    }
    
    /* Form Section - Centered */
    .apply-form-section {
        background: #fff;
        border-radius: 24px 24px 0 0;
        flex: 1;
        display: flex;
        justify-content: center;
        padding: 40px 24px 60px;
    }
    .apply-form-container {
        width: 100%;
        max-width: 500px;
    }
    
    /* Progress */
    .apply-progress {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        margin-bottom: 32px;
    }
    .progress-step {
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .progress-circle {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background: #E5E7EB;
        color: #6B7280;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 14px;
        transition: all 0.3s;
    }
    .progress-step.active .progress-circle,
    .progress-step.completed .progress-circle {
        background: #FCB900;
        color: #0A0A0A;
    }
    .progress-label {
        font-size: 13px;
        color: #6B7280;
        font-weight: 500;
    }
    .progress-step.active .progress-label { color: #111; }
    .progress-line {
        width: 40px;
        height: 2px;
        background: #E5E7EB;
    }
    .progress-line.completed { background: #FCB900; }
    
    /* Step Content */
    .step-title {
        font-size: 24px;
        font-weight: 800;
        color: #111;
        margin: 0 0 6px;
        text-align: center;
    }
    .step-subtitle {
        font-size: 15px;
        color: #6B7280;
        margin: 0 0 28px;
        text-align: center;
    }
    
    /* Form Elements */
    .form-step { display: none; }
    .form-step.active { display: block; }
    
    .form-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 16px;
    }
    .form-group { margin-bottom: 0; }
    .form-group.full { grid-column: 1 / -1; }
    
    .form-label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 6px;
    }
    .form-label .req { color: #EF4444; }
    
    .form-input {
        width: 100%;
        padding: 12px 14px;
        border: 2px solid #E5E7EB;
        ;
        font-family: inherit;
        font-size: 16px;
        transition: border-color 0.2s;
        background: #fff;
        min-height: 48px;
        -webkit-appearance: none;
        appearance: none;
    }
    .form-input:focus {
        outline: none;
        border-color: #FCB900;
    }
    select.form-input {
        appearance: none;
        background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='20' height='20' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
        background-repeat: no-repeat;
        background-position: right 10px center;
        padding-right: 36px;
    }
    
    /* Specialty Pills */
    .specialty-pills {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
    }
    .specialty-pill input { display: none; }
    .specialty-pill label {
        display: inline-block;
        padding: 10px 14px;
        background: #F3F4F6;
        border: 2px solid transparent;
        ;
        font-size: 13px;
        font-weight: 500;
        color: #374151;
        cursor: pointer;
        transition: all 0.2s;
    }
    .specialty-pill input:checked + label {
        background: #FEF3C7;
        border-color: #FCB900;
        color: #92400E;
    }
    
    /* Rate Slider */
    .rate-slider-wrap { margin-top: 16px; }
    .rate-display {
        font-size: 40px;
        font-weight: 800;
        color: #0A0A0A;
        text-align: center;
    }
    .rate-display span { color: #6B7280; font-size: 20px; }
    .rate-slider {
        width: 100%;
        height: 6px;
        ;
        background: #E5E7EB;
        appearance: none;
        margin: 16px 0;
    }
    .rate-slider::-webkit-slider-thumb {
        appearance: none;
        width: 24px;
        height: 24px;
        background: #FCB900;
        border-radius: 50%;
        cursor: pointer;
        box-shadow: 0 2px 6px rgba(0,0,0,0.2);
    }
    .rate-labels {
        display: flex;
        justify-content: space-between;
        font-size: 13px;
        color: #6B7280;
    }
    
    /* Navigation */
    .form-nav {
        display: flex;
        gap: 12px;
        margin-top: 32px;
        padding-top: 20px;
        border-top: 1px solid #E5E7EB;
    }
    .btn {
        padding: 14px 24px;
        ;
        font-size: 15px;
        font-weight: 600;
        font-family: inherit;
        cursor: pointer;
        transition: all 0.2s;
        border: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
    }
    .btn-back {
        background: #F3F4F6;
        color: #374151;
    }
    .btn-back:hover { background: #E5E7EB; }
    .btn-primary {
        flex: 1;
        background: #FCB900;
        color: #0A0A0A;
    }
    .btn-primary:hover {
        background: #E5A800;
    }
    .btn-primary:disabled {
        opacity: 0.6;
        cursor: not-allowed;
    }
    
    /* Error */
    .form-error {
        background: #FEF2F2;
        border: 1px solid #FECACA;
        ;
        padding: 14px;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        color: #DC2626;
        font-size: 14px;
    }
    
    /* Success */
    .apply-success {
        width: 100%;
        max-width: 500px;
        margin: 0 auto;
        text-align: center;
        padding: 40px 0;
    }
    .success-icon {
        width: 70px;
        height: 70px;
        background: #ECFDF5;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
    }
    .success-icon svg { color: #10B981; }
    .apply-success h2 {
        font-size: 24px;
        font-weight: 800;
        color: #111;
        margin: 0 0 10px;
    }
    .apply-success p {
        font-size: 15px;
        color: #6B7280;
        margin: 0 0 28px;
        line-height: 1.5;
    }
    .success-steps {
        text-align: left;
        background: #F9FAFB;
        ;
        padding: 20px;
        margin-bottom: 24px;
    }
    .success-step {
        display: flex;
        align-items: flex-start;
        gap: 12px;
        padding: 10px 0;
        border-bottom: 1px solid #E5E7EB;
    }
    .success-step:last-child { border: none; }
    .success-num {
        width: 24px;
        height: 24px;
        background: #FCB900;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: 700;
        flex-shrink: 0;
    }
    .success-step strong { display: block; color: #111; margin-bottom: 2px; font-size: 14px; }
    .success-step span { font-size: 13px; color: #6B7280; }
    
    /* Mobile */
    @media (max-width: 600px) {
        .apply-header { padding: 16px 20px; }
        .apply-logo { height: 30px; }
        .apply-hero { padding: 30px 20px 40px; }
        .apply-hero h1 { font-size: 32px; }
        .apply-hero p { font-size: 15px; }
        .apply-form-section { padding: 32px 20px 50px; border-radius: 20px 20px 0 0; }
        .form-grid { grid-template-columns: 1fr; gap: 14px; }
        .progress-label { display: none; }
        .progress-circle { width: 32px; height: 32px; font-size: 13px; }
        .progress-line { width: 30px; }
        .step-title { font-size: 20px; }
        .form-nav { flex-direction: column; }
        .btn-back { order: 2; }
        .btn { width: 100%; min-height: 52px; }
        .rate-display { font-size: 32px; }
        /* Touch targets */
        .specialty-pill label { min-height: 44px; display: flex; align-items: center; }
        .form-input, select.form-input, textarea.form-input { min-height: 48px; }
        /* Better radio/checkbox touch targets */
        input[type="radio"], input[type="checkbox"] {
            width: 24px; height: 24px;
        }
    }
    
    /* iOS Safe Area Support */
    @supports (padding-bottom: env(safe-area-inset-bottom)) {
        .apply-form-section {
            padding-bottom: calc(50px + env(safe-area-inset-bottom));
        }
    }
    </style>
</head>
<body <?php body_class('ptp-apply-page'); ?>>

<div class="ptp-apply">
    <!-- Header -->
    <div class="apply-header">
        <a href="<?php echo esc_url($home_url); ?>">
            <?php if ($logo_url): ?>
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP" class="apply-logo">
            <?php else: ?>
            <span style="color:#FCB900;font-weight:800;font-size:24px">PTP</span>
            <?php endif; ?>
        </a>
        <a href="<?php echo esc_url($login_url); ?>" class="apply-login">Already a trainer? Log in</a>
    </div>

    <?php if ($success): ?>
    <!-- Success State -->
    <div class="apply-form-section">
        <div class="apply-success">
            <div class="success-icon">
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                    <polyline points="22 4 12 14.01 9 11.01"/>
                </svg>
            </div>
            <h2>Application Received!</h2>
            <p>Thanks <?php echo esc_html(explode(' ', $submitted_name)[0]); ?>! We'll review your application and get back to you within 24-48 hours.</p>

            <div class="success-steps">
                <div class="success-step">
                    <div class="success-num">1</div>
                    <div><strong>Review</strong><span>We'll verify your playing experience</span></div>
                </div>
                <div class="success-step">
                    <div class="success-num">2</div>
                    <div><strong>Approval</strong><span>Receive login credentials via email</span></div>
                </div>
                <div class="success-step">
                    <div class="success-num">3</div>
                    <div><strong>Setup</strong><span>Complete your profile & availability</span></div>
                </div>
                <div class="success-step">
                    <div class="success-num">4</div>
                    <div><strong>Earn</strong><span>Get matched with families & start training</span></div>
                </div>
            </div>

            <a href="<?php echo esc_url($home_url); ?>" class="btn btn-primary" style="width:100%">Back to Home</a>
        </div>
    </div>

    <?php else: ?>

    <!-- Hero -->
    <div class="apply-hero">
        <h1>Train Athletes.<br><span>Get Paid.</span></h1>
        <p>Join our network of elite trainers earning $50-100/hr on your own schedule.<br>We handle the bookings, you focus on training.</p>
    </div>

    <!-- Form Section -->
    <div class="apply-form-section">
        <div class="apply-form-container">
            <!-- Progress -->
            <div class="apply-progress">
                <div class="progress-step active" data-step="1">
                    <div class="progress-circle">1</div>
                    <span class="progress-label">Your Info</span>
                </div>
                <div class="progress-line" id="line1"></div>
                <div class="progress-step" data-step="2">
                    <div class="progress-circle">2</div>
                    <span class="progress-label">Experience</span>
                </div>
                <div class="progress-line" id="line2"></div>
                <div class="progress-step" data-step="3">
                    <div class="progress-circle">3</div>
                    <span class="progress-label">Preferences</span>
                </div>
            </div>

            <?php if ($error): ?>
            <div class="form-error">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="12" y1="8" x2="12" y2="12"/>
                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <?php echo esc_html($error); ?>
            </div>
            <?php endif; ?>
            
            <?php 
            // Check for referral code
            $referral_code = $_GET['ref'] ?? $_COOKIE['ptp_trainer_ref'] ?? '';
            $referrer_name = '';
            if (!empty($referral_code)) {
                $referrer = $wpdb->get_row($wpdb->prepare(
                    "SELECT t.display_name FROM {$wpdb->prefix}ptp_trainer_referrals tr
                     JOIN {$wpdb->prefix}ptp_trainers t ON tr.referrer_trainer_id = t.id
                     WHERE tr.referrer_code = %s LIMIT 1",
                    $referral_code
                ));
                $referrer_name = $referrer ? $referrer->display_name : '';
            }
            
            if ($referrer_name): ?>
            <div style="background:linear-gradient(135deg,#059669,#047857);border-radius:12px;padding:20px;margin-bottom:24px;text-align:center">
                <p style="margin:0 0 4px;color:#fff;font-size:14px">🎁 Referred by <strong><?php echo esc_html($referrer_name); ?></strong></p>
                <p style="margin:0;color:rgba(255,255,255,0.9);font-size:20px;font-weight:700">Get $25 added to your first payout!</p>
            </div>
            <?php endif; ?>

            <form method="post" id="applyForm" action="<?php echo esc_url(home_url('/apply/')); ?>" novalidate>
                <?php wp_nonce_field('ptp_apply', 'ptp_apply_nonce'); ?>
                <input type="hidden" name="ptp_apply" value="1">
                <input type="hidden" name="referral_code" value="<?php echo esc_attr($referral_code); ?>">

                <!-- Step 1: Basic Info -->
                <div class="form-step active" data-step="1">
                    <h2 class="step-title">Let's start with your info</h2>
                    <p class="step-subtitle">Tell us about yourself so we can set up your profile.</p>

                    <div class="form-grid">
                        <div class="form-group full">
                            <label class="form-label">Full Name <span class="req">*</span></label>
                            <input type="text" name="name" class="form-input" placeholder="John Smith" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Email <span class="req">*</span></label>
                            <input type="email" name="email" class="form-input" placeholder="john@email.com" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Phone <span class="req">*</span></label>
                            <input type="tel" name="phone" class="form-input" placeholder="(555) 123-4567" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Create Password <span class="req">*</span></label>
                            <input type="password" name="password" id="password" class="form-input" placeholder="Min 8 characters" minlength="8" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Confirm Password <span class="req">*</span></label>
                            <input type="password" name="password_confirm" id="password_confirm" class="form-input" placeholder="Confirm password" minlength="8" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">City <span class="req">*</span></label>
                            <input type="text" name="city" class="form-input" placeholder="Philadelphia" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">State <span class="req">*</span></label>
                            <select name="state" class="form-input" required>
                                <option value="">Select state</option>
                                <option value="PA">Pennsylvania</option>
                                <option value="NJ">New Jersey</option>
                                <option value="DE">Delaware</option>
                                <option value="MD">Maryland</option>
                                <option value="NY">New York</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-nav">
                        <button type="button" class="btn btn-primary" onclick="nextStep()">
                            Continue →
                        </button>
                    </div>
                </div>

                <!-- Step 2: Experience -->
                <div class="form-step" data-step="2">
                    <h2 class="step-title">Your playing experience</h2>
                    <p class="step-subtitle">Parents want trainers who've competed at a high level.</p>

                    <div class="form-grid">
                        <div class="form-group full">
                            <label class="form-label">Highest Playing Level <span class="req">*</span></label>
                            <select name="playing_level" class="form-input" required>
                                <option value="">Select your level</option>
                                <option value="pro">Professional</option>
                                <option value="college_d1">NCAA Division 1</option>
                                <option value="college_d2">NCAA Division 2</option>
                                <option value="college_d3">NCAA Division 3</option>
                                <option value="semi_pro">Semi-Professional</option>
                                <option value="academy">Elite Academy / Club</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">College/University</label>
                            <input type="text" name="college" class="form-input" placeholder="e.g., Villanova University">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Team/Club</label>
                            <input type="text" name="team" class="form-input" placeholder="e.g., Philadelphia Union">
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Primary Sport</label>
                            <select name="position" class="form-input">
                                <option value="soccer">Soccer</option>
                                <option value="basketball">Basketball</option>
                                <option value="baseball">Baseball</option>
                                <option value="lacrosse">Lacrosse</option>
                                <option value="field_hockey">Field Hockey</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group full">
                            <label class="form-label">Training Specialties</label>
                            <div class="specialty-pills">
                                <div class="specialty-pill"><input type="checkbox" name="specialties[]" value="Technical Skills" id="s1"><label for="s1">Technical Skills</label></div>
                                <div class="specialty-pill"><input type="checkbox" name="specialties[]" value="Speed & Agility" id="s2"><label for="s2">Speed & Agility</label></div>
                                <div class="specialty-pill"><input type="checkbox" name="specialties[]" value="Finishing" id="s3"><label for="s3">Finishing</label></div>
                                <div class="specialty-pill"><input type="checkbox" name="specialties[]" value="Goalkeeping" id="s4"><label for="s4">Goalkeeping</label></div>
                                <div class="specialty-pill"><input type="checkbox" name="specialties[]" value="Defense" id="s5"><label for="s5">Defense</label></div>
                                <div class="specialty-pill"><input type="checkbox" name="specialties[]" value="Game IQ" id="s6"><label for="s6">Game IQ</label></div>
                            </div>
                        </div>
                    </div>

                    <div class="form-nav">
                        <button type="button" class="btn btn-back" onclick="prevStep()">← Back</button>
                        <button type="button" class="btn btn-primary" onclick="nextStep()">Continue →</button>
                    </div>
                </div>

                <!-- Step 3: Preferences -->
                <div class="form-step" data-step="3">
                    <h2 class="step-title">Almost done!</h2>
                    <p class="step-subtitle">Set your rate and tell us a bit more.</p>

                    <div class="form-group">
                        <label class="form-label">Your Hourly Rate</label>
                        <div class="rate-slider-wrap">
                            <div class="rate-display">$<span id="rateValue">70</span><span>/hr</span></div>
                            <input type="range" name="hourly_rate" class="rate-slider" min="40" max="150" value="70" oninput="document.getElementById('rateValue').textContent=this.value">
                            <div class="rate-labels"><span>$40</span><span>$150</span></div>
                        </div>
                    </div>

                    <div class="form-group" style="margin-top:24px">
                        <label class="form-label">Instagram Handle</label>
                        <input type="text" name="instagram" class="form-input" placeholder="@yourhandle">
                    </div>

                    <div class="form-group" style="margin-top:20px">
                        <label class="form-label">Short Bio</label>
                        <textarea name="bio" class="form-input" rows="4" placeholder="Tell parents about your background and training style..."></textarea>
                    </div>

                    <div class="form-group" style="margin-top:20px">
                        <label class="form-label">How did you hear about us?</label>
                        <select name="how_heard" class="form-input">
                            <option value="">Select one</option>
                            <option value="instagram">Instagram</option>
                            <option value="friend">Friend/Teammate</option>
                            <option value="google">Google Search</option>
                            <option value="coach">Coach/Program</option>
                            <option value="other">Other</option>
                        </select>
                    </div>

                    <div class="form-nav">
                        <button type="button" class="btn btn-back" onclick="prevStep()">← Back</button>
                        <button type="submit" class="btn btn-primary" id="submitBtn">Submit Application</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<script>
let currentStep = 1;
const totalSteps = 3;

function updateProgress() {
    document.querySelectorAll('.progress-step').forEach((step, i) => {
        const stepNum = i + 1;
        if (stepNum < currentStep) {
            step.classList.add('completed');
            step.classList.remove('active');
        } else if (stepNum === currentStep) {
            step.classList.add('active');
            step.classList.remove('completed');
        } else {
            step.classList.remove('active', 'completed');
        }
    });
    
    if (document.getElementById('line1')) {
        document.getElementById('line1').classList.toggle('completed', currentStep > 1);
    }
    if (document.getElementById('line2')) {
        document.getElementById('line2').classList.toggle('completed', currentStep > 2);
    }
}

function showStep(step) {
    document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
    const target = document.querySelector('.form-step[data-step="' + step + '"]');
    if (target) target.classList.add('active');
    updateProgress();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function validateStep(step) {
    const stepEl = document.querySelector('.form-step[data-step="' + step + '"]');
    const required = stepEl.querySelectorAll('[required]');
    let valid = true;
    
    required.forEach(input => {
        if (!input.value.trim()) {
            input.style.borderColor = '#EF4444';
            valid = false;
        } else {
            input.style.borderColor = '#E5E7EB';
        }
    });
    
    return valid;
}

function nextStep() {
    if (!validateStep(currentStep)) {
        return;
    }
    
    // Extra validation for step 1 passwords
    if (currentStep === 1) {
        const password = document.getElementById('password').value;
        const confirm = document.getElementById('password_confirm').value;
        
        if (password.length < 8) {
            alert('Password must be at least 8 characters.');
            document.getElementById('password').focus();
            return;
        }
        
        if (password !== confirm) {
            alert('Passwords do not match.');
            document.getElementById('password_confirm').focus();
            return;
        }
    }
    
    if (currentStep < totalSteps) {
        currentStep++;
        showStep(currentStep);
    }
}

function prevStep() {
    if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
    }
}

// Form submission - validate all steps before submitting
document.getElementById('applyForm')?.addEventListener('submit', function(e) {
    // Validate all steps
    let allValid = true;
    let firstInvalidStep = 0;
    
    for (let step = 1; step <= totalSteps; step++) {
        if (!validateStep(step)) {
            allValid = false;
            if (!firstInvalidStep) firstInvalidStep = step;
        }
    }
    
    if (!allValid) {
        e.preventDefault();
        currentStep = firstInvalidStep;
        showStep(currentStep);
        alert('Please fill in all required fields before submitting.');
        return false;
    }
    
    const btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.innerHTML = '<span style="display:inline-block;width:20px;height:20px;border:2px solid #0A0A0A;border-top-color:transparent;border-radius:50%;animation:spin 1s linear infinite"></span> Submitting...';
});

// Input focus effects
document.querySelectorAll('.form-input').forEach(input => {
    input.addEventListener('focus', () => input.style.borderColor = '#FCB900');
    input.addEventListener('blur', function() {
        if (!this.value.trim() && this.required) {
            this.style.borderColor = '#EF4444';
        } else {
            this.style.borderColor = '#E5E7EB';
        }
    });
});
</script>
<style>@keyframes spin { to { transform: rotate(360deg); } }</style>

<?php wp_footer(); ?>
</body>
</html>
<?php exit; ?>
