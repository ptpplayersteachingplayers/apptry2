<?php
/**
 * Template: Checkout v51.0.0
 * - Redesigned to match trainer profile v2 style
 * - Dark header, Oswald fonts, gold accents
 * - Camps cross-sell integrated throughout
 * - Mobile-first with compact design
 */
defined('ABSPATH') || exit;

$logo_url = PTP_Images::logo();

// Get booking data from URL params
$trainer_id = isset($_GET['trainer_id']) ? intval($_GET['trainer_id']) : 0;
$date = isset($_GET['date']) ? sanitize_text_field($_GET['date']) : '';
$time = isset($_GET['time']) ? sanitize_text_field($_GET['time']) : '';
$location = isset($_GET['location']) ? sanitize_text_field($_GET['location']) : '';
// Accept both 'package' and 'type' parameters for compatibility
$package_type = isset($_GET['package']) ? sanitize_text_field($_GET['package']) : (isset($_GET['type']) ? sanitize_text_field($_GET['type']) : 'single');

// Get trainer
$trainer = null;
if ($trainer_id) {
    $trainer = PTP_Trainer::get($trainer_id);
}

// Redirect if no trainer or missing data (only if not loaded via shortcode - shortcode handles this)
if (!$trainer || !$date || !$time) {
    // If headers not sent, we can redirect
    if (!headers_sent()) {
        wp_redirect(home_url('/training/'));
        exit;
    }
    // Otherwise just return - shortcode will handle error display
    return;
}

// Calculate amounts based on package
$rate = floatval($trainer->hourly_rate ?: 80);
$session_count = 1;
$discount = 0;

// Normalize package type (accept both formats)
if ($package_type === 'package_5') $package_type = '5pack';
if ($package_type === 'package_10') $package_type = '10pack';

switch ($package_type) {
    case '5pack':
        $session_count = 5;
        $discount = 0.10;
        $total = round($rate * 5 * (1 - $discount), 2);
        $per_session = round($rate * 0.90);
        break;
    case '10pack':
        $session_count = 10;
        $discount = 0.15;
        $total = round($rate * 10 * (1 - $discount), 2);
        $per_session = round($rate * 0.85);
        break;
    default:
        $total = $rate;
        $per_session = $rate;
}

// Trainer data
$trainer_photo = $trainer->photo_url ?: PTP_Images::avatar($trainer->display_name, 120);
$trainer_slug = $trainer->slug ?: sanitize_title($trainer->display_name);
$first_name = explode(' ', $trainer->display_name)[0];

// Check for bundle discount (if user has camp in WooCommerce cart)
$has_bundle_discount = false;
$bundle_discount_amount = 0;
$original_total = $total;

if (function_exists('WC') && WC()->cart) {
    foreach (WC()->cart->get_cart() as $item) {
        $product = $item['data'];
        $title = strtolower($product->get_name());
        $cats = wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'slugs'));
        
        if (strpos($title, 'camp') !== false || 
            strpos($title, 'clinic') !== false ||
            array_intersect($cats, array('camps', 'clinics', 'camp', 'clinic', 'winter-clinics', 'summer-camps'))) {
            $has_bundle_discount = true;
            break;
        }
    }
}

// Also check session flag (from upsell modal flow)
if (!$has_bundle_discount && function_exists('WC') && WC()->session && WC()->session->get('ptp_bundle_discount')) {
    $has_bundle_discount = true;
}

// Apply 15% bundle discount to training if they have a camp
if ($has_bundle_discount) {
    $bundle_discount_percent = defined('PTP_Growth::BUNDLE_DISCOUNT_PERCENT') ? PTP_Growth::BUNDLE_DISCOUNT_PERCENT : 15;
    $bundle_discount_amount = round($total * ($bundle_discount_percent / 100), 2);
    $total = $total - $bundle_discount_amount;
}

// Format date/time for display
$display_date = date('l, F j, Y', strtotime($date));
$display_time = date('g:i A', strtotime($time));
$end_time = date('g:i A', strtotime($time . ' +1 hour'));

// Check if user logged in
$is_logged_in = is_user_logged_in();
$current_user = $is_logged_in ? wp_get_current_user() : null;

// Get existing parent profile and players if logged in
$parent = null;
$players = array();
if ($is_logged_in) {
    $parent = PTP_Parent::get_by_user_id(get_current_user_id());
    if ($parent) {
        $players = PTP_Player::get_by_parent($parent->id);
    }
}

// Stripe
$stripe_key = class_exists('PTP_Stripe') ? PTP_Stripe::get_publishable_key() : '';
$stripe_enabled = class_exists('PTP_Stripe') ? PTP_Stripe::is_enabled() : false;

// Detect if loaded via shortcode (wp_head already fired) vs standalone
$is_shortcode_context = did_action('wp_head') > 0;

wp_enqueue_script('stripe-js', 'https://js.stripe.com/v3/', array(), null, true);

// Only output full HTML wrapper if NOT loaded via shortcode
if (!$is_shortcode_context): ?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Complete Your Booking - PTP Training</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
<?php endif; ?>
    <style>
/* ============================================
   BASE STYLES
   ============================================ */
* { box-sizing: border-box; margin: 0; padding: 0; }
body, .co-wrap { 
    font-family: 'Inter', -apple-system, sans-serif; 
    background: #F9FAFB; 
    min-height: 100vh; 
    -webkit-font-smoothing: antialiased;
    color: #111;
}

/* ============================================
   HEADER - Clean White
   ============================================ */
.co-header {
    background: #fff;
    padding: 12px 16px;
    position: sticky;
    top: 0;
    z-index: 100;
    border-bottom: 1px solid #E5E7EB;
}
.co-header-inner {
    max-width: 1100px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.co-logo img {
    height: 28px;
    width: auto;
}
.co-back {
    display: flex;
    align-items: center;
    gap: 6px;
    color: #6B7280;
    text-decoration: none;
    font-size: 13px;
    font-weight: 500;
    transition: color 0.2s;
}
.co-back:hover { color: #0A0A0A; }
.co-secure {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    color: #10B981;
    font-weight: 600;
}

/* ============================================
   BOOKING SUMMARY HERO
   ============================================ */
.co-hero {
    background: linear-gradient(135deg, #0A0A0A 0%, #1F2937 100%);
    padding: 20px 16px;
}
.co-hero-inner {
    max-width: 1100px;
    margin: 0 auto;
}
.co-hero-card {
    display: flex;
    flex-direction: column;
    gap: 16px;
    align-items: center;
    text-align: center;
}
.co-hero-photo {
    width: 120px;
    height: 120px;
    border-radius: 16px;
    overflow: hidden;
    flex-shrink: 0;
    border: 4px solid #FCB900;
    box-shadow: 0 8px 24px rgba(0,0,0,0.3);
}
.co-hero-photo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.co-hero-info {
    flex: 1;
    min-width: 0;
    color: #fff;
}
.co-hero-price {
    margin-top: 4px;
}
.co-hero-title {
    font-family: 'Oswald', sans-serif;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #FCB900;
    margin-bottom: 4px;
}
.co-hero-name {
    font-family: 'Oswald', sans-serif;
    font-size: 22px;
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 6px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.co-hero-details {
    display: flex;
    flex-wrap: wrap;
    gap: 12px;
    font-size: 12px;
    color: rgba(255,255,255,0.8);
    justify-content: center;
}
.co-hero-details span {
    display: flex;
    align-items: center;
    gap: 4px;
}
.co-hero-details svg {
    width: 14px;
    height: 14px;
    color: #FCB900;
}
.co-hero-price {
    text-align: center;
}
.co-hero-amount {
    font-family: 'Oswald', sans-serif;
    font-size: 32px;
    font-weight: 700;
    color: #FCB900;
}
.co-hero-unit {
    font-size: 11px;
    color: rgba(255,255,255,0.6);
}

/* ============================================
   MAIN LAYOUT
   ============================================ */
.co-main {
    max-width: 1100px;
    margin: 0 auto;
    padding: 16px;
}
.co-grid {
    display: grid;
    gap: 16px;
}

/* ============================================
   CARDS
   ============================================ */
.co-card {
    background: #fff;
    border-radius: 12px;
    border: 1px solid #E5E7EB;
    overflow: hidden;
}
.co-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
    border-bottom: 1px solid #E5E7EB;
    background: #FAFAFA;
}
.co-card-icon {
    width: 32px;
    height: 32px;
    background: #FCB900;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #0A0A0A;
}
.co-card-title {
    font-family: 'Oswald', sans-serif;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.02em;
}
.co-card-body {
    padding: 16px;
}

/* ============================================
   FORM ELEMENTS
   ============================================ */
.co-field {
    margin-bottom: 14px;
}
.co-field:last-child {
    margin-bottom: 0;
}
.co-label {
    display: block;
    font-size: 12px;
    font-weight: 600;
    color: #6B7280;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    margin-bottom: 6px;
}
.co-input {
    width: 100%;
    padding: 12px 14px;
    border: 2px solid #E5E7EB;
    border-radius: 8px;
    font-family: inherit;
    font-size: 15px;
    color: #111;
    transition: border-color 0.2s;
    background: #fff;
}
.co-input:focus {
    outline: none;
    border-color: #FCB900;
}
.co-input::placeholder {
    color: #9CA3AF;
}
select.co-input {
    background: #fff url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%236B7280' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E") no-repeat right 12px center;
    appearance: none;
    padding-right: 40px;
    cursor: pointer;
}
.co-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 12px;
}
@media (max-width: 480px) {
    .co-row { grid-template-columns: 1fr; }
}

/* Logged in indicator */
.co-logged-in {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    background: #D1FAE5;
    border-radius: 8px;
    margin-bottom: 14px;
}
.co-logged-in-icon {
    width: 36px;
    height: 36px;
    background: #059669;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
}
.co-logged-in-text {
    flex: 1;
}
.co-logged-in-name {
    font-weight: 600;
    color: #065F46;
    font-size: 14px;
}
.co-logged-in-email {
    font-size: 12px;
    color: #047857;
}

/* Player selection */
.co-player-list {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-bottom: 14px;
}
.co-player-opt {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    background: #F9FAFB;
    border: 2px solid #E5E7EB;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.15s;
}
.co-player-opt:hover {
    border-color: #FCB900;
}
.co-player-opt.selected {
    border-color: #FCB900;
    background: #FFFBEB;
}
.co-player-opt input {
    width: 18px;
    height: 18px;
    accent-color: #FCB900;
}
.co-player-icon {
    width: 36px;
    height: 36px;
    background: #E5E7EB;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #6B7280;
}
.co-player-opt.selected .co-player-icon {
    background: #FCB900;
    color: #0A0A0A;
}
.co-player-info {
    flex: 1;
}
.co-player-name {
    font-weight: 600;
    color: #111;
    font-size: 14px;
}
.co-player-meta {
    font-size: 12px;
    color: #6B7280;
}
.co-new-player {
    display: none;
    padding: 14px;
    background: #F9FAFB;
    border-radius: 8px;
    margin-top: 12px;
}
.co-new-player.show {
    display: block;
}

/* Payment accepted badges */
.co-payment-badges {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    background: #F9FAFB;
    border-radius: 8px;
    margin-bottom: 14px;
}
.co-payment-badges span {
    font-size: 12px;
    color: #6B7280;
    font-weight: 500;
}
.co-payment-badges img {
    height: 20px;
}

/* Card element */
#card-element {
    padding: 14px;
    border: 2px solid #E5E7EB;
    border-radius: 8px;
    background: #fff;
    transition: border-color 0.2s;
}
#card-element.StripeElement--focus {
    border-color: #FCB900;
}
#card-errors {
    color: #DC2626;
    font-size: 12px;
    margin-top: 6px;
    min-height: 18px;
}

/* Checkbox */
.co-check {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px;
    background: #F9FAFB;
    border-radius: 8px;
    cursor: pointer;
}
.co-check input {
    width: 18px;
    height: 18px;
    margin-top: 2px;
    accent-color: #FCB900;
}
.co-check-text {
    font-size: 13px;
    color: #4B5563;
    line-height: 1.4;
}
.co-check-text strong {
    color: #111;
}

/* ============================================
   ORDER SUMMARY SIDEBAR
   ============================================ */
.co-summary {
    order: -1;
}
.co-summary-card {
    background: #fff;
    border-radius: 12px;
    border: 2px solid #E5E7EB;
    padding: 16px;
}
.co-summary-title {
    font-family: 'Oswald', sans-serif;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    margin-bottom: 14px;
    padding-bottom: 12px;
    border-bottom: 1px solid #E5E7EB;
}
.co-summary-trainer {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-bottom: 14px;
    padding-bottom: 14px;
    border-bottom: 1px solid #E5E7EB;
}
.co-summary-trainer img {
    width: 50px;
    height: 50px;
    border-radius: 10px;
    object-fit: cover;
}
.co-summary-trainer-name {
    font-weight: 700;
    font-size: 15px;
}
.co-summary-trainer-sub {
    font-size: 12px;
    color: #6B7280;
    display: flex;
    align-items: center;
    gap: 4px;
}
.co-summary-detail {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 8px 0;
    font-size: 13px;
}
.co-summary-detail-label {
    color: #6B7280;
}
.co-summary-detail-value {
    font-weight: 600;
    text-align: right;
    max-width: 60%;
}
.co-summary-total {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 0 0;
    margin-top: 10px;
    border-top: 2px solid #E5E7EB;
}
.co-summary-total-label {
    font-family: 'Oswald', sans-serif;
    font-size: 16px;
    font-weight: 700;
    text-transform: uppercase;
}
.co-summary-total-amount {
    font-family: 'Oswald', sans-serif;
    font-size: 28px;
    font-weight: 700;
    color: #0A0A0A;
}

/* Cancellation policy */
.co-cancel-policy {
    margin-top: 14px;
    padding: 12px;
    background: #ECFDF5;
    border-radius: 8px;
    border: 1px solid #D1FAE5;
}
.co-cancel-policy-title {
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 13px;
    font-weight: 600;
    color: #065F46;
    margin-bottom: 4px;
}
.co-cancel-policy-text {
    font-size: 12px;
    color: #047857;
    line-height: 1.4;
}

/* ============================================
   SUBMIT BUTTON
   ============================================ */
.co-submit-btn {
    width: 100%;
    padding: 16px;
    background: #FCB900;
    color: #0A0A0A;
    border: none;
    border-radius: 10px;
    font-family: 'Oswald', sans-serif;
    font-size: 16px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: all 0.2s;
    margin-top: 14px;
}
.co-submit-btn:hover {
    background: #E5A800;
    transform: translateY(-1px);
}
.co-submit-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

/* Money-back guarantee */
.co-guarantee {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px;
    background: #FEF3C7;
    border-radius: 8px;
    margin-top: 12px;
}
.co-guarantee-icon {
    width: 32px;
    height: 32px;
    background: #FCB900;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}
.co-guarantee-text {
    font-size: 12px;
    color: #92400E;
    line-height: 1.4;
}
.co-guarantee-text strong {
    display: block;
    color: #78350F;
    font-size: 13px;
}

/* ============================================
   TRUST BADGES
   ============================================ */
.co-trust {
    display: flex;
    justify-content: center;
    gap: 16px;
    flex-wrap: wrap;
    padding: 16px;
    font-size: 11px;
    color: #6B7280;
}
.co-trust span {
    display: flex;
    align-items: center;
    gap: 4px;
}

/* ============================================
   LOADING OVERLAY
   ============================================ */
.co-loading {
    display: none;
    position: fixed;
    inset: 0;
    background: rgba(255,255,255,0.97);
    z-index: 9999;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    gap: 16px;
}
.co-loading.show {
    display: flex;
}
.co-spinner {
    width: 48px;
    height: 48px;
    border: 4px solid #E5E7EB;
    border-top-color: #FCB900;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
.co-loading-text {
    font-family: 'Oswald', sans-serif;
    font-size: 18px;
    font-weight: 600;
    color: #111;
    text-transform: uppercase;
}

/* ============================================
   DESKTOP ENHANCEMENTS
   ============================================ */
@media (min-width: 768px) {
    .co-header { padding: 14px 24px; }
    .co-logo img { height: 32px; }
    .co-hero { padding: 28px 24px; }
    .co-hero-card { 
        flex-direction: row;
        gap: 24px;
        text-align: left;
    }
    .co-hero-photo { width: 110px; height: 110px; }
    .co-hero-name { font-size: 28px; }
    .co-hero-details { font-size: 13px; gap: 16px; justify-content: flex-start; }
    .co-hero-amount { font-size: 36px; }
    .co-hero-price { margin-top: 0; text-align: right; }
    
    .co-main { padding: 24px; }
    .co-grid {
        grid-template-columns: 1fr 360px;
        gap: 24px;
    }
    .co-summary { order: 0; }
    .co-summary-card {
        position: sticky;
        top: 80px;
    }
    
    .co-card { border-radius: 16px; }
    .co-card-header { padding: 16px 20px; }
    .co-card-body { padding: 20px; }
    .co-card-icon { width: 36px; height: 36px; }
    .co-card-title { font-size: 15px; }
}

@media (min-width: 1024px) {
    .co-grid { grid-template-columns: 1fr 400px; }
}

/* ============================================
   MOBILE ENHANCEMENTS (v54)
   ============================================ */
@media (max-width: 767px) {
    /* Prevent iOS zoom on inputs */
    .co-input,
    input[type="text"],
    input[type="email"],
    input[type="tel"],
    input[type="number"],
    select {
        font-size: 16px !important;
        min-height: 48px;
    }
    
    /* Touch targets */
    .co-btn,
    .co-player-opt,
    .co-package-opt {
        min-height: 48px;
    }
    
    /* Full width button */
    .co-btn-pay {
        width: 100%;
        font-size: 16px;
        min-height: 56px;
    }
    
    /* Stripe card element spacing */
    #card-element {
        padding: 16px;
        min-height: 48px;
    }
    
    /* Summary card - not sticky on mobile */
    .co-summary-card {
        position: relative !important;
        top: auto !important;
    }
    
    /* Better spacing */
    .co-card-body {
        padding: 16px;
    }
    
    /* Package options - stack vertically */
    .co-package-grid {
        grid-template-columns: 1fr !important;
        gap: 10px;
    }
    
    /* Player selection - larger touch targets */
    .co-player-opt {
        padding: 14px;
    }
    
    .co-player-opt input[type="radio"],
    .co-player-opt input[type="checkbox"] {
        width: 24px;
        height: 24px;
    }
    
    /* Hero section - compact on mobile */
    .co-hero {
        padding: 16px;
    }
    
    .co-hero-photo {
        width: 80px;
        height: 80px;
        border-radius: 12px;
    }
    
    .co-hero-name {
        font-size: 20px;
    }
    
    .co-hero-amount {
        font-size: 28px;
    }
    
    /* Back button larger touch target */
    .co-back {
        padding: 8px;
        margin: -8px;
        min-height: 44px;
        display: inline-flex;
        align-items: center;
    }
}

/* iOS Safe Area Support */
@supports (padding-bottom: env(safe-area-inset-bottom)) {
    @media (max-width: 767px) {
        .co-main {
            padding-bottom: calc(16px + env(safe-area-inset-bottom));
        }
        
        .co-fixed-footer {
            padding-bottom: calc(16px + env(safe-area-inset-bottom));
        }
    }
}
    </style>
<?php if (!$is_shortcode_context): ?>
</head>
<body>
<?php endif; ?>

<div class="co-wrap">
<!-- HEADER -->
<header class="co-header">
    <div class="co-header-inner">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="co-logo">
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training">
        </a>
        <a href="<?php echo esc_url(home_url('/trainer/' . $trainer_slug . '/')); ?>" class="co-back">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
            Back to Profile
        </a>
        <div class="co-secure">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
            Secure
        </div>
    </div>
</header>

<!-- BOOKING SUMMARY HERO -->
<div class="co-hero">
    <div class="co-hero-inner">
        <div class="co-hero-card">
            <div class="co-hero-photo">
                <img src="<?php echo esc_url($trainer_photo); ?>" alt="<?php echo esc_attr($trainer->display_name); ?>">
            </div>
            <div class="co-hero-info">
                <div class="co-hero-title">Booking With</div>
                <div class="co-hero-name"><?php echo esc_html($trainer->display_name); ?></div>
                <div class="co-hero-details">
                    <span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        <?php echo date('M j', strtotime($date)); ?>
                    </span>
                    <span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        <?php echo esc_html($display_time); ?>
                    </span>
                    <span>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                        <?php echo esc_html($location ? explode(',', $location)[0] : 'TBD'); ?>
                    </span>
                </div>
            </div>
            <div class="co-hero-price">
                <?php if ($has_bundle_discount): ?>
                <div class="co-hero-amount-original" style="font-size:16px;text-decoration:line-through;opacity:0.6">$<?php echo number_format($original_total, 0); ?></div>
                <?php endif; ?>
                <div class="co-hero-amount">$<?php echo number_format($total, 0); ?></div>
                <div class="co-hero-unit">
                    <?php echo $session_count > 1 ? $session_count . ' sessions' : 'Single session'; ?>
                    <?php if ($has_bundle_discount): ?>
                    <span style="color:#10B981;font-weight:600"> • Bundle Price</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- MAIN CONTENT -->
<div class="co-main">
    <form id="checkout-form">
        <input type="hidden" name="trainer_id" value="<?php echo (int)$trainer->id; ?>">
        <input type="hidden" name="date" value="<?php echo esc_attr($date); ?>">
        <input type="hidden" name="time" value="<?php echo esc_attr($time); ?>">
        <input type="hidden" name="location" value="<?php echo esc_attr($location); ?>">
        <input type="hidden" name="amount" value="<?php echo esc_attr($total); ?>">
        <input type="hidden" name="original_amount" value="<?php echo esc_attr($original_total); ?>">
        <input type="hidden" name="bundle_discount" value="<?php echo $has_bundle_discount ? '1' : '0'; ?>">
        <input type="hidden" name="package_type" value="<?php echo esc_attr($package_type); ?>">
        <input type="hidden" name="session_count" value="<?php echo $session_count; ?>">
        
        <div class="co-grid">
            <!-- LEFT COLUMN - Forms -->
            <div>
                <!-- Contact Information -->
                <div class="co-card">
                    <div class="co-card-header">
                        <div class="co-card-icon">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        </div>
                        <span class="co-card-title">Contact Information</span>
                    </div>
                    <div class="co-card-body">
                        <?php if ($is_logged_in): ?>
                        <input type="hidden" name="first_name" value="<?php echo esc_attr($current_user->first_name ?: $current_user->display_name); ?>">
                        <input type="hidden" name="last_name" value="<?php echo esc_attr($current_user->last_name); ?>">
                        <input type="hidden" name="email" value="<?php echo esc_attr($current_user->user_email); ?>">
                        
                        <div class="co-logged-in">
                            <div class="co-logged-in-icon">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            </div>
                            <div class="co-logged-in-text">
                                <div class="co-logged-in-name">Logged in as <?php echo esc_html($current_user->display_name); ?></div>
                                <div class="co-logged-in-email"><?php echo esc_html($current_user->user_email); ?></div>
                            </div>
                        </div>
                        <?php else: ?>
                        <div class="co-row">
                            <div class="co-field">
                                <label class="co-label">First Name *</label>
                                <input type="text" name="first_name" class="co-input" placeholder="Your first name" required>
                            </div>
                            <div class="co-field">
                                <label class="co-label">Last Name *</label>
                                <input type="text" name="last_name" class="co-input" placeholder="Your last name" required>
                            </div>
                        </div>
                        <div class="co-field">
                            <label class="co-label">Email Address *</label>
                            <input type="email" name="email" class="co-input" placeholder="your@email.com" required>
                        </div>
                        <?php endif; ?>
                        
                        <div class="co-field">
                            <label class="co-label">Phone Number *</label>
                            <input type="tel" name="phone" class="co-input" placeholder="(555) 123-4567" value="<?php echo $parent ? esc_attr($parent->phone) : ''; ?>" required>
                        </div>
                        
                        <?php if (!$is_logged_in): ?>
                        <label class="co-check">
                            <input type="checkbox" name="create_account" value="1" checked>
                            <div class="co-check-text">
                                <strong>Create an account</strong><br>
                                Save your info for faster checkout and track sessions.
                            </div>
                        </label>
                        
                        <div id="password-field" class="co-field" style="margin-top:14px">
                            <label class="co-label">Password *</label>
                            <input type="password" name="password" class="co-input" placeholder="Create a password (min 8 characters)" minlength="8">
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Player Information -->
                <div class="co-card">
                    <div class="co-card-header">
                        <div class="co-card-icon">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
                        </div>
                        <span class="co-card-title">Player Information</span>
                    </div>
                    <div class="co-card-body">
                        <?php if (!empty($players)): ?>
                        <p style="font-size:12px;color:#6B7280;margin-bottom:10px;text-transform:uppercase;font-weight:600;letter-spacing:0.02em">Select a Player</p>
                        <div class="co-player-list">
                            <?php foreach ($players as $i => $player): ?>
                            <label class="co-player-opt <?php echo $i === 0 ? 'selected' : ''; ?>">
                                <input type="radio" name="player_id" value="<?php echo $player->id; ?>" <?php checked($i, 0); ?> onchange="selectPlayer(this)">
                                <div class="co-player-icon">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                </div>
                                <div class="co-player-info">
                                    <div class="co-player-name"><?php echo esc_html($player->name); ?></div>
                                    <div class="co-player-meta">Age <?php echo esc_html($player->age); ?> • <?php echo esc_html(ucfirst($player->skill_level ?: 'Beginner')); ?></div>
                                </div>
                            </label>
                            <?php endforeach; ?>
                            <label class="co-player-opt" id="new-player-opt">
                                <input type="radio" name="player_id" value="new" onchange="selectPlayer(this)">
                                <div class="co-player-icon">
                                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                </div>
                                <div class="co-player-info">
                                    <div class="co-player-name">Add New Player</div>
                                    <div class="co-player-meta">Register a different child</div>
                                </div>
                            </label>
                        </div>
                        <?php endif; ?>
                        
                        <div id="new-player-form" class="co-new-player <?php echo empty($players) ? 'show' : ''; ?>">
                            <div class="co-row">
                                <div class="co-field">
                                    <label class="co-label">Player's First Name *</label>
                                    <input type="text" name="player_first_name" class="co-input" placeholder="First name" <?php echo empty($players) ? 'required' : ''; ?>>
                                </div>
                                <div class="co-field">
                                    <label class="co-label">Last Name *</label>
                                    <input type="text" name="player_last_name" class="co-input" placeholder="Last name" <?php echo empty($players) ? 'required' : ''; ?>>
                                </div>
                            </div>
                            <div class="co-row">
                                <div class="co-field">
                                    <label class="co-label">Age *</label>
                                    <select name="player_age" class="co-input" <?php echo empty($players) ? 'required' : ''; ?>>
                                        <option value="">Select age</option>
                                        <?php for ($a = 5; $a <= 18; $a++): ?>
                                        <option value="<?php echo $a; ?>"><?php echo $a; ?> years old</option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="co-field">
                                    <label class="co-label">Skill Level *</label>
                                    <select name="player_skill" class="co-input" <?php echo empty($players) ? 'required' : ''; ?>>
                                        <option value="">Select level</option>
                                        <option value="beginner">Beginner</option>
                                        <option value="intermediate">Intermediate</option>
                                        <option value="advanced">Advanced</option>
                                        <option value="competitive">Competitive/Club</option>
                                    </select>
                                </div>
                            </div>
                            <div class="co-field">
                                <label class="co-label">Goals or Focus Areas (optional)</label>
                                <textarea name="player_notes" class="co-input" rows="2" placeholder="E.g., wants to improve dribbling, preparing for tryouts..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Secure Payment -->
                <div class="co-card">
                    <div class="co-card-header">
                        <div class="co-card-icon">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                        </div>
                        <span class="co-card-title">Secure Payment</span>
                    </div>
                    <div class="co-card-body">
                        <div class="co-payment-badges">
                            <span>We accept:</span>
                            <svg width="40" height="24" viewBox="0 0 40 24"><rect width="40" height="24" rx="4" fill="#1A1F71"/><text x="20" y="15" fill="#fff" font-size="8" text-anchor="middle" font-weight="bold">VISA</text></svg>
                            <svg width="40" height="24" viewBox="0 0 40 24"><rect width="40" height="24" rx="4" fill="#EB001B"/><circle cx="15" cy="12" r="7" fill="#EB001B"/><circle cx="25" cy="12" r="7" fill="#F79E1B"/><path d="M20 6.5a7 7 0 000 11" fill="#FF5F00"/></svg>
                            <svg width="40" height="24" viewBox="0 0 40 24"><rect width="40" height="24" rx="4" fill="#006FCF"/><text x="20" y="15" fill="#fff" font-size="6" text-anchor="middle" font-weight="bold">AMEX</text></svg>
                        </div>
                        
                        <div class="co-field">
                            <label class="co-label">Card Information</label>
                            <div id="card-element"></div>
                            <div id="card-errors"></div>
                        </div>
                        
                        <div class="co-field">
                            <label class="co-label">Notes for Trainer (optional)</label>
                            <textarea name="notes" class="co-input" rows="2" placeholder="Any specific requests or things the trainer should know?"></textarea>
                        </div>
                    </div>
                </div>
                
                <!-- Trust badges -->
                <div class="co-trust">
                    <span>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        SSL Encrypted
                    </span>
                    <span>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
                        Secure Payments
                    </span>
                    <span>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        Verified Trainers
                    </span>
                </div>
            </div>
            
            <!-- RIGHT COLUMN - Summary -->
            <div class="co-summary">
                <div class="co-summary-card">
                    <div class="co-summary-title">Booking Summary</div>
                    
                    <div class="co-summary-trainer">
                        <img src="<?php echo esc_url($trainer_photo); ?>" alt="">
                        <div>
                            <div class="co-summary-trainer-name"><?php echo esc_html($trainer->display_name); ?></div>
                            <div class="co-summary-trainer-sub">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                <?php echo esc_html($trainer->city ?: 'Philadelphia Area'); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="co-summary-detail">
                        <span class="co-summary-detail-label">Package</span>
                        <span class="co-summary-detail-value">
                            <?php 
                            if ($package_type === '5pack') echo '5-Session Pack';
                            elseif ($package_type === '10pack') echo '10-Session Pack';
                            else echo 'Single Session';
                            ?>
                        </span>
                    </div>
                    
                    <div class="co-summary-detail">
                        <span class="co-summary-detail-label">First Session</span>
                        <span class="co-summary-detail-value"><?php echo date('D, M j, Y', strtotime($date)); ?></span>
                    </div>
                    
                    <div class="co-summary-detail">
                        <span class="co-summary-detail-label">Time</span>
                        <span class="co-summary-detail-value"><?php echo esc_html($display_time); ?></span>
                    </div>
                    
                    <div class="co-summary-detail">
                        <span class="co-summary-detail-label">Location</span>
                        <span class="co-summary-detail-value"><?php echo esc_html($location ?: 'To be confirmed'); ?></span>
                    </div>
                    
                    <?php if ($has_bundle_discount): ?>
                    <div class="co-summary-detail" style="border-top:1px dashed #E5E7EB;padding-top:12px;margin-top:12px">
                        <span class="co-summary-detail-label">Subtotal</span>
                        <span class="co-summary-detail-value">$<?php echo number_format($original_total, 0); ?></span>
                    </div>
                    <div class="co-summary-detail" style="color:#10B981">
                        <span class="co-summary-detail-label">🎁 Bundle Discount</span>
                        <span class="co-summary-detail-value">-$<?php echo number_format($bundle_discount_amount, 0); ?></span>
                    </div>
                    <div style="background:#ECFDF5;border-radius:8px;padding:10px 12px;margin:12px 0;font-size:12px;color:#065F46">
                        <strong>Camp + Training Bundle</strong><br>
                        You're saving <?php echo isset($bundle_discount_percent) ? $bundle_discount_percent : 15; ?>% by booking training with your camp!
                    </div>
                    <?php endif; ?>
                    
                    <div class="co-summary-total">
                        <span class="co-summary-total-label">Total</span>
                        <span class="co-summary-total-amount">$<?php echo number_format($total, 0); ?></span>
                    </div>
                    
                    <div class="co-cancel-policy">
                        <div class="co-cancel-policy-title">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            Free Cancellation
                        </div>
                        <div class="co-cancel-policy-text">Cancel up to 24 hours before your session for a full refund</div>
                    </div>
                    
                    <button type="submit" id="submit-btn" class="co-submit-btn">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        Pay Securely - $<?php echo number_format($total, 0); ?>
                    </button>
                    
                    <div class="co-guarantee">
                        <div class="co-guarantee-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#0A0A0A" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                        </div>
                        <div class="co-guarantee-text">
                            <strong>100% Money-Back Guarantee</strong>
                            Free cancellation up to 24 hours before your session
                        </div>
                    </div>
                    
                    <!-- Questions? Text Us -->
                    <div style="margin-top:16px;padding:14px;background:#F9FAFB;border-radius:10px;text-align:center">
                        <div style="font-size:13px;color:#6B7280;margin-bottom:6px">Questions before booking?</div>
                        <a href="sms:+14845724770" style="display:inline-flex;align-items:center;gap:6px;color:#FCB900;font-weight:600;font-size:14px;text-decoration:none">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                            Text us at (484) 572-4770
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<!-- CAMPS & CLINICS CROSS-SELL -->
<?php 
if (function_exists('ptp_render_camps_crosssell')) {
    ptp_render_camps_crosssell(array(
        'limit' => 4,
        'title' => 'Add Group Training',
        'subtitle' => 'Book a camp or clinic while you\'re here',
        'context' => 'checkout',
        'show_view_all' => true,
    ));
}
?>

<!-- Loading Overlay -->
<div id="loading" class="co-loading">
    <div class="co-spinner"></div>
    <p class="co-loading-text">Processing your booking...</p>
</div>
</div><!-- /.co-wrap -->

<script>
(function() {
    const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
    const nonce = '<?php echo wp_create_nonce('ptp_checkout'); ?>';
    const isLoggedIn = <?php echo $is_logged_in ? 'true' : 'false'; ?>;
    
    // Track checkout start for abandoned cart recovery
    function trackCheckoutStart() {
        const email = document.querySelector('input[name="email"]')?.value || '';
        if (!email) return;
        
        const data = new FormData();
        data.append('action', 'ptp_track_checkout_start');
        data.append('email', email);
        data.append('trainer_id', '<?php echo intval($trainer->id); ?>');
        data.append('session_date', '<?php echo esc_js($date); ?>');
        data.append('session_time', '<?php echo esc_js($time); ?>');
        data.append('package_type', '<?php echo esc_js($package_type); ?>');
        
        navigator.sendBeacon(ajaxUrl, data);
    }
    
    // Track when email is entered
    document.querySelector('input[name="email"]')?.addEventListener('blur', trackCheckoutStart);
    
    // Track analytics event
    if (window.ptpTrack) {
        ptpTrack('checkout_started', { 
            trainer_id: <?php echo intval($trainer->id); ?>,
            package: '<?php echo esc_js($package_type); ?>',
            amount: <?php echo intval($total); ?>
        });
    }
    
    // Player selection
    window.selectPlayer = function(input) {
        document.querySelectorAll('.co-player-opt').forEach(el => el.classList.remove('selected'));
        input.closest('.co-player-opt').classList.add('selected');
        
        const newForm = document.getElementById('new-player-form');
        const newInputs = newForm.querySelectorAll('input, select');
        
        if (input.value === 'new') {
            newForm.classList.add('show');
            newInputs.forEach(i => { if (i.name.startsWith('player_')) i.required = true; });
        } else {
            newForm.classList.remove('show');
            newInputs.forEach(i => { if (i.name.startsWith('player_')) i.required = false; });
        }
    };
    
    // Account creation toggle
    <?php if (!$is_logged_in): ?>
    document.querySelector('input[name="create_account"]')?.addEventListener('change', function() {
        const pwField = document.getElementById('password-field');
        const pwInput = pwField.querySelector('input');
        if (this.checked) {
            pwField.style.display = 'block';
            pwInput.required = true;
        } else {
            pwField.style.display = 'none';
            pwInput.required = false;
        }
    });
    <?php endif; ?>
    
    // Stripe setup
    <?php if ($stripe_enabled && $stripe_key): ?>
    const stripe = Stripe('<?php echo esc_js($stripe_key); ?>');
    const elements = stripe.elements();
    const cardElement = elements.create('card', {
        style: {
            base: {
                fontSize: '16px',
                color: '#111827',
                fontFamily: 'Inter, -apple-system, sans-serif',
                '::placeholder': { color: '#9CA3AF' }
            },
            invalid: { color: '#DC2626' }
        }
    });
    cardElement.mount('#card-element');
    
    cardElement.on('change', function(e) {
        document.getElementById('card-errors').textContent = e.error ? e.error.message : '';
    });
    
    // Form submission
    document.getElementById('checkout-form').addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const btn = document.getElementById('submit-btn');
        const form = this;
        
        // Basic validation
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        btn.disabled = true;
        btn.innerHTML = 'Processing...';
        document.getElementById('loading').classList.add('show');
        
        try {
            // Collect form data
            const formData = new FormData(form);
            formData.append('action', 'ptp_process_checkout');
            formData.append('nonce', nonce);
            
            // Step 1: Create booking and payment intent
            const response = await fetch(ajaxUrl, { method: 'POST', body: formData });
            const data = await response.json();
            
            if (!data.success) {
                throw new Error(data.data?.message || 'Failed to create booking');
            }
            
            // Step 2: Confirm payment with Stripe
            const { error, paymentIntent } = await stripe.confirmCardPayment(data.data.client_secret, {
                payment_method: { card: cardElement }
            });
            
            if (error) {
                throw new Error(error.message);
            }
            
            // Step 3: Confirm payment on server
            const confirmData = new FormData();
            confirmData.append('action', 'ptp_confirm_checkout_payment');
            confirmData.append('nonce', nonce);
            confirmData.append('booking_id', data.data.booking_id);
            confirmData.append('payment_intent_id', paymentIntent.id);
            
            const confirmResponse = await fetch(ajaxUrl, { method: 'POST', body: confirmData });
            const confirmResult = await confirmResponse.json();
            
            if (!confirmResult.success) {
                throw new Error(confirmResult.data?.message || 'Payment confirmation failed');
            }
            
            // Success! Redirect to confirmation
            window.location.href = confirmResult.data.redirect;
            
        } catch (err) {
            document.getElementById('card-errors').textContent = err.message;
            btn.disabled = false;
            btn.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> Pay Securely - $<?php echo number_format($total, 0); ?>';
            document.getElementById('loading').classList.remove('show');
        }
    });
    <?php else: ?>
    document.getElementById('checkout-form').addEventListener('submit', function(e) {
        e.preventDefault();
        alert('Payment processing is not configured. Please contact support.');
    });
    <?php endif; ?>
})();
</script>

<?php if (!$is_shortcode_context): ?>
<?php wp_footer(); ?>
</body>
</html>
<?php endif; ?>
