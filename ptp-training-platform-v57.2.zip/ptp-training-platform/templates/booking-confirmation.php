<?php
/**
 * Template: Booking Confirmation v51.0.0
 * - Redesigned to match checkout/trainer profile v2 style
 * - Dark header, Oswald fonts, gold accents
 * - Big trainer photo on mobile (centered)
 * - Cross-sell integrated
 */
defined('ABSPATH') || exit;

$logo_url = PTP_Images::logo();

$payment_intent = isset($_GET['payment_intent']) ? sanitize_text_field($_GET['payment_intent']) : '';
$booking_id = isset($_GET['booking_id']) ? intval($_GET['booking_id']) : 0;

global $wpdb;
$booking = null;

// Try to get booking by payment intent or ID
if ($payment_intent) {
    $booking = $wpdb->get_row($wpdb->prepare(
        "SELECT b.*, t.display_name as trainer_name, t.photo_url, t.slug, t.city, t.state, t.id as trainer_id
         FROM {$wpdb->prefix}ptp_bookings b 
         JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id 
         WHERE b.stripe_payment_intent = %s",
        $payment_intent
    ));
} elseif ($booking_id) {
    $booking = $wpdb->get_row($wpdb->prepare(
        "SELECT b.*, t.display_name as trainer_name, t.photo_url, t.slug, t.city, t.state, t.id as trainer_id
         FROM {$wpdb->prefix}ptp_bookings b 
         JOIN {$wpdb->prefix}ptp_trainers t ON b.trainer_id = t.id 
         WHERE b.id = %d",
        $booking_id
    ));
}

$trainer_photo = $booking && $booking->photo_url ? $booking->photo_url : PTP_Images::avatar($booking ? $booking->trainer_name : 'Trainer', 120);
$trainer_name = $booking ? $booking->trainer_name : 'Your Trainer';
$trainer_slug = $booking && $booking->slug ? $booking->slug : '';
$session_date = $booking ? date('l, F j, Y', strtotime($booking->session_date)) : 'Date TBD';
$session_date_short = $booking ? date('M j', strtotime($booking->session_date)) : 'TBD';
$session_time = $booking ? date('g:i A', strtotime($booking->session_date)) : 'Time TBD';
$location = $booking && $booking->city ? $booking->city . ', ' . $booking->state : 'Location TBD';
$location_short = $booking && $booking->city ? $booking->city : 'TBD';
$amount = $booking ? number_format($booking->total_amount, 0) : '0';
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <title>Booking Confirmed - PTP Training</title>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <?php wp_head(); ?>
    <style>
/* ============================================
   BASE STYLES
   ============================================ */
* { box-sizing: border-box; margin: 0; padding: 0; }
body { 
    font-family: 'Inter', -apple-system, sans-serif; 
    background: #F9FAFB; 
    min-height: 100vh; 
    -webkit-font-smoothing: antialiased;
    color: #111;
}

/* ============================================
   HEADER - Clean White
   ============================================ */
.bc-header {
    background: #fff;
    padding: 12px 16px;
    border-bottom: 1px solid #E5E7EB;
}
.bc-header-inner {
    max-width: 600px;
    margin: 0 auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.bc-logo img {
    height: 28px;
    width: auto;
}
.bc-secure {
    display: flex;
    align-items: center;
    gap: 5px;
    font-size: 12px;
    color: #10B981;
    font-weight: 600;
}

/* ============================================
   SUCCESS HERO
   ============================================ */
.bc-hero {
    background: linear-gradient(135deg, #059669 0%, #047857 100%);
    padding: 32px 16px;
    text-align: center;
}
.bc-hero-inner {
    max-width: 600px;
    margin: 0 auto;
}
.bc-check {
    width: 80px;
    height: 80px;
    background: rgba(255,255,255,0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 16px;
    animation: checkPop 0.5s ease 0.2s both;
}
@keyframes checkPop {
    0% { transform: scale(0); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}
.bc-hero-title {
    font-family: 'Oswald', sans-serif;
    font-size: 28px;
    font-weight: 700;
    text-transform: uppercase;
    color: #fff;
    margin-bottom: 8px;
}
.bc-hero-sub {
    font-size: 15px;
    color: rgba(255,255,255,0.9);
}

/* ============================================
   TRAINER CARD
   ============================================ */
.bc-trainer-card {
    max-width: 600px;
    margin: -40px auto 0;
    padding: 0 16px;
    position: relative;
    z-index: 10;
}
.bc-trainer {
    background: #fff;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.1);
    text-align: center;
}
.bc-trainer-photo {
    width: 100px;
    height: 100px;
    border-radius: 16px;
    overflow: hidden;
    margin: 0 auto 16px;
    border: 4px solid #FCB900;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.bc-trainer-photo img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}
.bc-trainer-label {
    font-family: 'Oswald', sans-serif;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.1em;
    color: #6B7280;
    margin-bottom: 4px;
}
.bc-trainer-name {
    font-family: 'Oswald', sans-serif;
    font-size: 24px;
    font-weight: 700;
    text-transform: uppercase;
    color: #0A0A0A;
    margin-bottom: 16px;
}
.bc-trainer-details {
    display: flex;
    justify-content: center;
    gap: 16px;
    flex-wrap: wrap;
    font-size: 13px;
    color: #6B7280;
}
.bc-trainer-details span {
    display: flex;
    align-items: center;
    gap: 6px;
}
.bc-trainer-details svg {
    width: 16px;
    height: 16px;
    color: #FCB900;
}

/* ============================================
   BOOKING DETAILS
   ============================================ */
.bc-main {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px 16px;
}
.bc-details {
    background: #fff;
    border-radius: 12px;
    border: 1px solid #E5E7EB;
    overflow: hidden;
    margin-bottom: 16px;
}
.bc-details-header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
    background: #FAFAFA;
    border-bottom: 1px solid #E5E7EB;
}
.bc-details-icon {
    width: 32px;
    height: 32px;
    background: #FCB900;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #0A0A0A;
}
.bc-details-title {
    font-family: 'Oswald', sans-serif;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.02em;
}
.bc-details-body {
    padding: 16px;
}
.bc-detail-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    padding: 12px 0;
    border-bottom: 1px solid #F3F4F6;
}
.bc-detail-row:last-child {
    border-bottom: none;
}
.bc-detail-label {
    font-size: 13px;
    color: #6B7280;
    display: flex;
    align-items: center;
    gap: 8px;
}
.bc-detail-label svg {
    width: 16px;
    height: 16px;
}
.bc-detail-value {
    font-size: 14px;
    font-weight: 600;
    color: #111;
    text-align: right;
    max-width: 60%;
}
.bc-amount-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 16px;
    background: #ECFDF5;
    border-radius: 10px;
    margin-top: 12px;
}
.bc-amount-label {
    font-family: 'Oswald', sans-serif;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    color: #065F46;
}
.bc-amount-value {
    font-family: 'Oswald', sans-serif;
    font-size: 28px;
    font-weight: 700;
    color: #059669;
}

/* ============================================
   ACTIONS
   ============================================ */
.bc-actions {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 20px;
}
.bc-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    width: 100%;
    padding: 16px;
    border-radius: 10px;
    font-family: 'Oswald', sans-serif;
    font-size: 15px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.02em;
    text-decoration: none;
    transition: all 0.2s;
}
.bc-btn-primary {
    background: #FCB900;
    color: #0A0A0A;
}
.bc-btn-primary:hover {
    background: #E5A800;
    transform: translateY(-1px);
}
.bc-btn-secondary {
    background: #fff;
    color: #374151;
    border: 2px solid #E5E7EB;
}
.bc-btn-secondary:hover {
    border-color: #FCB900;
    color: #0A0A0A;
}

/* ============================================
   INFO FOOTER
   ============================================ */
.bc-info {
    text-align: center;
    padding: 20px;
    background: #fff;
    border-radius: 12px;
    border: 1px solid #E5E7EB;
    margin-bottom: 20px;
}
.bc-info-item {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-size: 14px;
    color: #6B7280;
    margin-bottom: 8px;
}
.bc-info-item:last-child {
    margin-bottom: 0;
}
.bc-info-item a {
    color: #FCB900;
    font-weight: 600;
    text-decoration: none;
}
.bc-info-item a:hover {
    text-decoration: underline;
}

/* ============================================
   WHAT'S NEXT
   ============================================ */
.bc-next {
    background: #fff;
    border-radius: 12px;
    border: 1px solid #E5E7EB;
    padding: 20px;
    margin-bottom: 20px;
}
.bc-next-title {
    font-family: 'Oswald', sans-serif;
    font-size: 14px;
    font-weight: 700;
    text-transform: uppercase;
    color: #0A0A0A;
    margin-bottom: 16px;
}
.bc-next-item {
    display: flex;
    gap: 12px;
    margin-bottom: 12px;
}
.bc-next-item:last-child {
    margin-bottom: 0;
}
.bc-next-num {
    width: 24px;
    height: 24px;
    background: #FCB900;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    font-weight: 700;
    color: #0A0A0A;
    flex-shrink: 0;
}
.bc-next-text {
    font-size: 14px;
    color: #4B5563;
    line-height: 1.5;
}
.bc-next-text strong {
    color: #111;
}

/* ============================================
   DESKTOP ENHANCEMENTS
   ============================================ */
@media (min-width: 768px) {
    .bc-header { padding: 14px 24px; }
    .bc-logo img { height: 32px; }
    .bc-hero { padding: 40px 24px; }
    .bc-hero-title { font-size: 32px; }
    .bc-trainer-card { margin-top: -50px; }
    .bc-trainer { padding: 32px; }
    .bc-trainer-photo { width: 120px; height: 120px; }
    .bc-trainer-name { font-size: 28px; }
    .bc-main { padding: 24px; }
    .bc-actions { flex-direction: row; }
    .bc-btn { flex: 1; }
}
    </style>
</head>
<body>

<!-- HEADER -->
<header class="bc-header">
    <div class="bc-header-inner">
        <a href="<?php echo esc_url(home_url('/')); ?>" class="bc-logo">
            <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Training">
        </a>
        <div class="bc-secure">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
            Confirmed
        </div>
    </div>
</header>

<!-- SUCCESS HERO -->
<div class="bc-hero">
    <div class="bc-hero-inner">
        <div class="bc-check">
            <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <h1 class="bc-hero-title">Booking Confirmed!</h1>
        <p class="bc-hero-sub">Your training session has been scheduled</p>
    </div>
</div>

<!-- TRAINER CARD -->
<div class="bc-trainer-card">
    <div class="bc-trainer">
        <div class="bc-trainer-photo">
            <img src="<?php echo esc_url($trainer_photo); ?>" alt="<?php echo esc_attr($trainer_name); ?>">
        </div>
        <div class="bc-trainer-label">Your Trainer</div>
        <div class="bc-trainer-name"><?php echo esc_html($trainer_name); ?></div>
        <div class="bc-trainer-details">
            <span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                <?php echo esc_html($session_date_short); ?>
            </span>
            <span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                <?php echo esc_html($session_time); ?>
            </span>
            <span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                <?php echo esc_html($location_short); ?>
            </span>
        </div>
    </div>
</div>

<!-- MAIN CONTENT -->
<div class="bc-main">
    <!-- Booking Details -->
    <div class="bc-details">
        <div class="bc-details-header">
            <div class="bc-details-icon">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
            </div>
            <span class="bc-details-title">Session Details</span>
        </div>
        <div class="bc-details-body">
            <div class="bc-detail-row">
                <span class="bc-detail-label">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                    Date
                </span>
                <span class="bc-detail-value"><?php echo esc_html($session_date); ?></span>
            </div>
            <div class="bc-detail-row">
                <span class="bc-detail-label">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                    Time
                </span>
                <span class="bc-detail-value"><?php echo esc_html($session_time); ?></span>
            </div>
            <div class="bc-detail-row">
                <span class="bc-detail-label">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    Location
                </span>
                <span class="bc-detail-value"><?php echo esc_html($location); ?></span>
            </div>
            
            <div class="bc-amount-row">
                <span class="bc-amount-label">Amount Paid</span>
                <span class="bc-amount-value">$<?php echo $amount; ?></span>
            </div>
        </div>
    </div>
    
    <!-- What's Next -->
    <div class="bc-next">
        <div class="bc-next-title">What's Next</div>
        <div class="bc-next-item">
            <span class="bc-next-num">1</span>
            <span class="bc-next-text"><strong>Confirmation email sent</strong> – Check your inbox for details</span>
        </div>
        <div class="bc-next-item">
            <span class="bc-next-num">2</span>
            <span class="bc-next-text"><strong>Your trainer will reach out</strong> – Expect a message within 24 hours</span>
        </div>
        <div class="bc-next-item">
            <span class="bc-next-num">3</span>
            <span class="bc-next-text"><strong>Show up ready!</strong> – Bring water, cleats, and a great attitude</span>
        </div>
    </div>
    
    <!-- Actions -->
    <div class="bc-actions">
        <a href="<?php echo esc_url(home_url('/my-training/')); ?>" class="bc-btn bc-btn-primary">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
            View My Sessions
        </a>
        <a href="<?php echo esc_url(home_url('/find-trainers/')); ?>" class="bc-btn bc-btn-secondary">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            Find More Trainers
        </a>
    </div>
    
    <!-- Info -->
    <div class="bc-info">
        <div class="bc-info-item">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>
            Confirmation email has been sent
        </div>
        <div class="bc-info-item">
            Questions? <a href="sms:+14845724770">Text us at (484) 572-4770</a>
        </div>
    </div>
</div>

<!-- CAMPS & CLINICS CROSS-SELL -->
<?php 
// Fire the post-booking hooks for upsells and sharing
if ($booking) {
    // This triggers cross-sell engine and viral engine
    do_action('ptp_after_booking_confirm', $booking_id ?: $booking->id, $booking);
}

// Check if user already has a camp (either in WooCommerce orders or cart)
$has_camp_already = false;

// Check WooCommerce cart
if (function_exists('WC') && WC()->cart) {
    foreach (WC()->cart->get_cart() as $item) {
        $product = $item['data'];
        $title = strtolower($product->get_name());
        if (strpos($title, 'camp') !== false || strpos($title, 'clinic') !== false) {
            $has_camp_already = true;
            break;
        }
    }
}

// Check recent WooCommerce orders (last 7 days)
if (!$has_camp_already && function_exists('wc_get_orders') && is_user_logged_in()) {
    $recent_orders = wc_get_orders(array(
        'customer_id' => get_current_user_id(),
        'date_created' => '>' . date('Y-m-d', strtotime('-7 days')),
        'limit' => 5,
    ));
    
    foreach ($recent_orders as $order) {
        foreach ($order->get_items() as $item) {
            $title = strtolower($item->get_name());
            if (strpos($title, 'camp') !== false || strpos($title, 'clinic') !== false) {
                $has_camp_already = true;
                break 2;
            }
        }
    }
}

// Only show camps cross-sell if they don't already have a camp
if (!$has_camp_already && function_exists('ptp_render_camps_crosssell')) {
    ptp_render_camps_crosssell(array(
        'limit' => 4,
        'title' => 'Level Up Your Training',
        'subtitle' => 'Bundle with a camp & save 15%',
        'context' => 'confirmation',
        'show_view_all' => true,
    ));
} elseif ($has_camp_already) {
    // They have a camp - show a different message
    ?>
    <div style="max-width:800px;margin:32px auto;padding:0 16px">
        <div style="background:linear-gradient(135deg,#059669,#047857);border-radius:16px;padding:24px;text-align:center;color:#fff">
            <div style="font-size:32px;margin-bottom:12px">🎉</div>
            <h3 style="font-family:'Oswald',sans-serif;font-size:22px;margin:0 0 8px;text-transform:uppercase">Bundle Complete!</h3>
            <p style="margin:0;opacity:0.9">You've got both training and a camp booked. You're all set for an amazing experience!</p>
        </div>
    </div>
    <?php
}
?>

<script>
// Clear pending training booking since they've completed checkout
localStorage.removeItem('ptp_pending_training_booking');
localStorage.removeItem('ptp_bundle_discount');
sessionStorage.removeItem('ptp_upsell_shown');
sessionStorage.removeItem('ptp_booking_url');
</script>

<?php wp_footer(); ?>
</body>
</html>
