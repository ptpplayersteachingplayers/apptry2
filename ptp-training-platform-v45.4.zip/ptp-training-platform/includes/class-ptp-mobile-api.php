<?php
/**
 * PTP Mobile API - Enterprise Grade
 * Complete REST API for iOS/Android mobile applications
 * 
 * @version 2.0.0
 * @package PTP_Training_Platform
 */

defined('ABSPATH') || exit;

class PTP_Mobile_API {
    
    const API_VERSION = '2.0.0';
    const NAMESPACE = 'ptp/v2';
    
    private static $instance = null;
    
    public static function instance() {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
        add_filter('rest_pre_dispatch', array($this, 'add_cors_headers'), 10, 3);
    }
    
    /**
     * Add CORS headers for mobile apps
     */
    public function add_cors_headers($result, $server, $request) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type, X-PTP-App-Version, X-PTP-Device-ID, X-PTP-Platform');
        header('X-PTP-API-Version: ' . self::API_VERSION);
        return $result;
    }
    
    /**
     * Register all API routes
     */
    public function register_routes() {
        
        // ================================================================
        // HEALTH & CONFIG
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/health', array(
            'methods' => 'GET',
            'callback' => array($this, 'health_check'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/config', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_config'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/config/bootstrap', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_bootstrap'),
            'permission_callback' => '__return_true',
        ));
        
        // ================================================================
        // AUTHENTICATION
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/auth/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'login'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/google', array(
            'methods' => 'POST',
            'callback' => array($this, 'google_login'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/apple', array(
            'methods' => 'POST',
            'callback' => array($this, 'apple_login'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/refresh', array(
            'methods' => 'POST',
            'callback' => array($this, 'refresh_token'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/forgot-password', array(
            'methods' => 'POST',
            'callback' => array($this, 'forgot_password'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/auth/logout', array(
            'methods' => 'POST',
            'callback' => array($this, 'logout'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // USER / PROFILE
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/me', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_current_user'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_profile'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/avatar', array(
            'methods' => 'POST',
            'callback' => array($this, 'upload_avatar'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/password', array(
            'methods' => 'PUT',
            'callback' => array($this, 'change_password'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/notifications', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_notifications'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/notifications/(?P<id>\d+)/read', array(
            'methods' => 'POST',
            'callback' => array($this, 'mark_notification_read'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/device', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_device'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/me/device', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'unregister_device'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // PLAYERS (for parents)
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/players', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_players'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_player'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/players/(?P<id>\d+)/progress', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_player_progress'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // TRAINERS
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/trainers', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/search', array(
            'methods' => 'GET',
            'callback' => array($this, 'search_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/nearby', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_nearby_trainers'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)/availability', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_availability'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)/reviews', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_reviews'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/trainers/(?P<id>\d+)/gallery', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_gallery'),
            'permission_callback' => '__return_true',
        ));
        
        // ================================================================
        // TRAINER PROFILE (for trainers)
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/trainer/profile', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_profile'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/profile', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_trainer_profile'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/availability', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_my_availability'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/availability', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_availability'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/earnings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_earnings'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_trainer_stats'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/stripe/connect', array(
            'methods' => 'POST',
            'callback' => array($this, 'connect_stripe'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/trainer/stripe/dashboard', array(
            'methods' => 'GET',
            'callback' => array($this, 'stripe_dashboard_link'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        // ================================================================
        // BOOKINGS
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/bookings', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_bookings'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_booking'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_booking'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/confirm', array(
            'methods' => 'POST',
            'callback' => array($this, 'confirm_booking'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/cancel', array(
            'methods' => 'POST',
            'callback' => array($this, 'cancel_booking'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/complete', array(
            'methods' => 'POST',
            'callback' => array($this, 'complete_booking'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/notes', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_session_notes'),
            'permission_callback' => array($this, 'check_trainer'),
        ));
        
        register_rest_route(self::NAMESPACE, '/bookings/(?P<id>\d+)/review', array(
            'methods' => 'POST',
            'callback' => array($this, 'submit_review'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // CAMPS & CLINICS (WooCommerce Products)
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/camps', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/upcoming', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_upcoming_camps'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_camp'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/(?P<id>\d+)/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_for_camp'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/camps/my-registrations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_my_camp_registrations'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // MESSAGING
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/conversations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_conversations'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/conversations/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_conversation'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/conversations/(?P<id>\d+)/messages', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_messages'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/conversations/(?P<id>\d+)/messages', array(
            'methods' => 'POST',
            'callback' => array($this, 'send_message'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/messages/start', array(
            'methods' => 'POST',
            'callback' => array($this, 'start_conversation'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // PAYMENTS
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/payments/methods', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_payment_methods'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/payments/setup-intent', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_setup_intent'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/payments/methods', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_payment_method'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/payments/methods/(?P<id>[a-zA-Z0-9_]+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'remove_payment_method'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // FAVORITES
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/favorites', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_favorites'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/favorites/(?P<trainer_id>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_favorite'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        register_rest_route(self::NAMESPACE, '/favorites/(?P<trainer_id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'remove_favorite'),
            'permission_callback' => array($this, 'check_auth'),
        ));
        
        // ================================================================
        // STATIC CONTENT
        // ================================================================
        
        register_rest_route(self::NAMESPACE, '/content/faq', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_faq'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/content/specialties', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_specialties'),
            'permission_callback' => '__return_true',
        ));
        
        register_rest_route(self::NAMESPACE, '/content/locations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_locations'),
            'permission_callback' => '__return_true',
        ));
    }
    
    // ================================================================
    // AUTH HELPERS
    // ================================================================
    
    public function check_auth($request) {
        $user = $this->get_user_from_token($request);
        return $user !== false;
    }
    
    public function check_trainer($request) {
        $user = $this->get_user_from_token($request);
        if (!$user) return false;
        
        global $wpdb;
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d AND status = 'active'",
            $user->ID
        ));
        
        return !empty($trainer);
    }
    
    private function get_user_from_token($request) {
        $auth_header = $request->get_header('Authorization');
        
        if (empty($auth_header) || strpos($auth_header, 'Bearer ') !== 0) {
            return false;
        }
        
        $token = substr($auth_header, 7);
        
        // Use existing JWT validation from PTP_REST_API
        if (class_exists('PTP_REST_API')) {
            $api = new PTP_REST_API();
            if (method_exists($api, 'validate_token')) {
                return $api->validate_token($token);
            }
        }
        
        // Fallback: simple token validation
        global $wpdb;
        $user_id = $wpdb->get_var($wpdb->prepare(
            "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'ptp_auth_token' AND meta_value = %s",
            hash('sha256', $token)
        ));
        
        if ($user_id) {
            return get_user_by('ID', $user_id);
        }
        
        return false;
    }
    
    private function generate_token($user_id) {
        $token = bin2hex(random_bytes(32));
        $expires = time() + (30 * DAY_IN_SECONDS);
        
        update_user_meta($user_id, 'ptp_auth_token', hash('sha256', $token));
        update_user_meta($user_id, 'ptp_token_expires', $expires);
        
        return array(
            'access_token' => $token,
            'token_type' => 'Bearer',
            'expires_in' => 30 * DAY_IN_SECONDS,
            'expires_at' => date('c', $expires),
        );
    }
    
    // ================================================================
    // HEALTH & CONFIG ENDPOINTS
    // ================================================================
    
    public function health_check($request) {
        return rest_ensure_response(array(
            'status' => 'ok',
            'api_version' => self::API_VERSION,
            'wordpress_version' => get_bloginfo('version'),
            'plugin_version' => PTP_VERSION,
            'timestamp' => current_time('c'),
            'timezone' => wp_timezone_string(),
        ));
    }
    
    public function get_config($request) {
        $config = array(
            'api_version' => self::API_VERSION,
            'app' => array(
                'name' => get_option('ptp_app_name', 'PTP Soccer'),
                'tagline' => get_option('ptp_tagline', 'Players Teaching Players'),
                'min_version' => get_option('ptp_min_app_version', '1.0.0'),
                'current_version' => get_option('ptp_current_app_version', '1.0.0'),
                'force_update' => (bool) get_option('ptp_force_update', false),
                'update_message' => get_option('ptp_update_message', ''),
                'maintenance_mode' => (bool) get_option('ptp_maintenance_mode', false),
                'maintenance_message' => get_option('ptp_maintenance_message', ''),
            ),
            'theme' => array(
                'primary_color' => get_option('ptp_color_primary', '#FCB900'),
                'secondary_color' => get_option('ptp_color_secondary', '#0A0A0A'),
                'font_heading' => 'Oswald',
                'font_body' => 'Inter',
            ),
            'branding' => array(
                'logo' => get_option('ptp_logo_url', PTP_Images::LOGO),
                'logo_dark' => get_option('ptp_logo_dark_url', PTP_Images::LOGO),
                'app_icon' => get_option('ptp_app_icon_url', ''),
            ),
            'features' => array(
                'private_training' => true,
                'group_sessions' => (bool) get_option('ptp_feature_groups', true),
                'training_plans' => (bool) get_option('ptp_feature_training_plans', true),
                'camps_clinics' => (bool) get_option('ptp_feature_camps', true),
                'messaging' => true,
                'reviews' => true,
                'push_notifications' => (bool) get_option('ptp_push_enabled', false),
                'calendar_sync' => (bool) get_option('ptp_feature_calendar_sync', false),
                'google_login' => !empty(get_option('ptp_google_client_id')),
                'apple_login' => !empty(get_option('ptp_apple_client_id')),
            ),
            'social' => array(
                'instagram' => get_option('ptp_instagram', ''),
                'facebook' => get_option('ptp_facebook', ''),
                'twitter' => get_option('ptp_twitter', ''),
                'youtube' => get_option('ptp_youtube', ''),
                'tiktok' => get_option('ptp_tiktok', ''),
            ),
            'contact' => array(
                'email' => get_option('ptp_contact_email', 'info@ptpsoccercamps.com'),
                'support_email' => get_option('ptp_support_email', 'support@ptpsoccercamps.com'),
                'phone' => get_option('ptp_contact_phone', ''),
            ),
            'legal' => array(
                'terms_url' => get_option('ptp_terms_url', site_url('/terms')),
                'privacy_url' => get_option('ptp_privacy_url', site_url('/privacy')),
                'refund_url' => get_option('ptp_refund_url', ''),
            ),
            'payment' => array(
                'stripe_publishable_key' => get_option('ptp_stripe_publishable_key', ''),
                'platform_fee_percent' => floatval(get_option('ptp_platform_fee', 15)),
                'currency' => 'USD',
            ),
        );
        
        return rest_ensure_response($config);
    }
    
    public function get_bootstrap($request) {
        // Get everything needed to initialize the app in one call
        $user = $this->get_user_from_token($request);
        
        $bootstrap = array(
            'config' => $this->get_config($request)->get_data(),
            'onboarding' => get_option('ptp_onboarding_screens', array()),
            'specialties' => $this->get_specialties_list(),
            'locations' => $this->get_locations_list(),
            'featured_trainers' => $this->get_featured_trainers_data(6),
            'featured_camps' => $this->get_featured_camps_data(6),
        );
        
        if ($user) {
            $bootstrap['user'] = $this->format_user($user);
            $bootstrap['unread_notifications'] = PTP_Push_Notifications::get_unread_count($user->ID);
        }
        
        return rest_ensure_response($bootstrap);
    }
    
    // ================================================================
    // CAMPS ENDPOINTS - ALL WOOCOMMERCE PRODUCTS
    // ================================================================
    
    public function get_camps($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => intval($request->get_param('limit') ?: 50),
            'paged' => intval($request->get_param('page') ?: 1),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        // Filter by type
        $type = $request->get_param('type');
        if ($type) {
            $args['meta_query'][] = array(
                'key' => '_ptp_camp_type',
                'value' => $type,
            );
        }
        
        // Filter by state
        $state = $request->get_param('state');
        if ($state) {
            $args['meta_query'][] = array(
                'key' => '_ptp_state',
                'value' => $state,
            );
        }
        
        // Filter by age group
        $age_group = $request->get_param('age_group');
        if ($age_group) {
            $args['meta_query'][] = array(
                'key' => '_ptp_age_groups',
                'value' => $age_group,
                'compare' => 'LIKE',
            );
        }
        
        // Upcoming only
        if ($request->get_param('upcoming')) {
            $args['meta_query'][] = array(
                'key' => '_ptp_start_date',
                'value' => date('Y-m-d'),
                'compare' => '>=',
                'type' => 'DATE',
            );
        }
        
        // Category filter
        $category = $request->get_param('category');
        if ($category) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'slug',
                    'terms' => $category,
                ),
            );
        }
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camps[] = $this->format_camp($post->ID);
        }
        
        return rest_ensure_response(array(
            'camps' => $camps,
            'pagination' => array(
                'total' => $query->found_posts,
                'pages' => $query->max_num_pages,
                'page' => intval($request->get_param('page') ?: 1),
                'per_page' => intval($request->get_param('limit') ?: 50),
            ),
        ));
    }
    
    public function get_featured_camps($request) {
        $camps = wc_get_featured_product_ids();
        $result = array();
        
        foreach (array_slice($camps, 0, 10) as $id) {
            $result[] = $this->format_camp($id);
        }
        
        return rest_ensure_response($result);
    }
    
    public function get_upcoming_camps($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            'meta_query' => array(
                array(
                    'key' => '_ptp_start_date',
                    'value' => date('Y-m-d'),
                    'compare' => '>=',
                    'type' => 'DATE',
                ),
            ),
            'orderby' => 'meta_value',
            'meta_key' => '_ptp_start_date',
            'order' => 'ASC',
        );
        
        $query = new WP_Query($args);
        $camps = array();
        
        foreach ($query->posts as $post) {
            $camps[] = $this->format_camp($post->ID);
        }
        
        return rest_ensure_response($camps);
    }
    
    public function get_camp($request) {
        $id = intval($request->get_param('id'));
        $product = wc_get_product($id);
        
        if (!$product) {
            return new WP_Error('not_found', 'Camp not found', array('status' => 404));
        }
        
        return rest_ensure_response($this->format_camp($id, true));
    }
    
    private function format_camp($product_id, $full = false) {
        $product = wc_get_product($product_id);
        if (!$product) return null;
        
        $start_date = get_post_meta($product_id, '_ptp_start_date', true);
        $end_date = get_post_meta($product_id, '_ptp_end_date', true);
        $max_capacity = intval(get_post_meta($product_id, '_ptp_max_capacity', true));
        $sold_count = intval(get_post_meta($product_id, '_ptp_sold_count', true));
        
        // Get camp type - default to 'camp' if not set
        $camp_type = get_post_meta($product_id, '_ptp_camp_type', true);
        if (empty($camp_type)) {
            // Guess type from title
            $title_lower = strtolower($product->get_name());
            if (strpos($title_lower, 'clinic') !== false) {
                $camp_type = 'clinic';
            } elseif (strpos($title_lower, 'academy') !== false) {
                $camp_type = 'academy';
            } else {
                $camp_type = 'camp';
            }
        }
        
        $age_groups = get_post_meta($product_id, '_ptp_age_groups', true) ?: array();
        if (is_string($age_groups)) {
            $age_groups = json_decode($age_groups, true) ?: array();
        }
        
        $camp = array(
            'id' => $product_id,
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'type' => $camp_type,
            'price' => floatval($product->get_price()),
            'regular_price' => floatval($product->get_regular_price()),
            'sale_price' => $product->get_sale_price() ? floatval($product->get_sale_price()) : null,
            'on_sale' => $product->is_on_sale(),
            'currency' => 'USD',
            'start_date' => $start_date,
            'end_date' => $end_date ?: $start_date,
            'location' => array(
                'name' => get_post_meta($product_id, '_ptp_location_name', true) ?: '',
                'address' => get_post_meta($product_id, '_ptp_address', true) ?: '',
                'city' => get_post_meta($product_id, '_ptp_city', true) ?: '',
                'state' => get_post_meta($product_id, '_ptp_state', true) ?: '',
                'zip' => get_post_meta($product_id, '_ptp_zip', true) ?: '',
                'latitude' => floatval(get_post_meta($product_id, '_ptp_latitude', true)),
                'longitude' => floatval(get_post_meta($product_id, '_ptp_longitude', true)),
            ),
            'age_groups' => $age_groups,
            'capacity' => array(
                'max' => $max_capacity,
                'sold' => $sold_count,
                'available' => max(0, $max_capacity - $sold_count),
                'is_sold_out' => $max_capacity > 0 && $sold_count >= $max_capacity,
            ),
            'featured_image' => wp_get_attachment_url($product->get_image_id()) ?: PTP_Images::get_camp_photo($product_id),
            'is_featured' => $product->is_featured(),
            'status' => $product->get_status(),
            'url' => get_permalink($product_id),
        );
        
        // Add full details
        if ($full) {
            $skill_levels = get_post_meta($product_id, '_ptp_skill_levels', true) ?: array();
            if (is_string($skill_levels)) {
                $skill_levels = json_decode($skill_levels, true) ?: array();
            }
            
            $daily_times = get_post_meta($product_id, '_ptp_daily_times', true) ?: array();
            
            $camp['description'] = $product->get_description();
            $camp['short_description'] = $product->get_short_description();
            $camp['skill_levels'] = $skill_levels;
            $camp['daily_times'] = array(
                'start' => $daily_times['start'] ?? '09:00',
                'end' => $daily_times['end'] ?? '15:00',
            );
            $camp['what_to_bring'] = get_post_meta($product_id, '_ptp_what_to_bring', true) ?: '';
            $camp['included'] = get_post_meta($product_id, '_ptp_included', true) ?: '';
            $camp['contact'] = array(
                'email' => get_post_meta($product_id, '_ptp_contact_email', true) ?: '',
                'phone' => get_post_meta($product_id, '_ptp_contact_phone', true) ?: '',
            );
            
            // Gallery images
            $gallery_ids = $product->get_gallery_image_ids();
            $camp['gallery'] = array_map('wp_get_attachment_url', $gallery_ids);
            
            // Categories
            $categories = wp_get_post_terms($product_id, 'product_cat', array('fields' => 'names'));
            $camp['categories'] = is_array($categories) ? $categories : array();
            
            // Schedule
            if ($start_date && $end_date) {
                $camp['schedule'] = $this->generate_camp_schedule($start_date, $end_date, $daily_times);
            }
        }
        
        return $camp;
    }
    
    private function generate_camp_schedule($start, $end, $times) {
        $schedule = array();
        $current = strtotime($start);
        $end_ts = strtotime($end);
        $day = 1;
        
        while ($current <= $end_ts) {
            $schedule[] = array(
                'day' => $day,
                'date' => date('Y-m-d', $current),
                'day_name' => date('l', $current),
                'start_time' => $times['start'] ?? '09:00',
                'end_time' => $times['end'] ?? '15:00',
            );
            $current = strtotime('+1 day', $current);
            $day++;
        }
        
        return $schedule;
    }
    
    // ================================================================
    // TRAINERS ENDPOINTS
    // ================================================================
    
    public function get_trainers($request) {
        global $wpdb;
        
        $limit = intval($request->get_param('limit') ?: 20);
        $offset = (intval($request->get_param('page') ?: 1) - 1) * $limit;
        
        $where = "WHERE t.status = 'active'";
        $params = array();
        
        // Filter by specialty
        if ($specialty = $request->get_param('specialty')) {
            $where .= " AND t.specialties LIKE %s";
            $params[] = '%' . $specialty . '%';
        }
        
        // Filter by state
        if ($state = $request->get_param('state')) {
            $where .= " AND t.location LIKE %s";
            $params[] = '%' . $state . '%';
        }
        
        $sql = "SELECT t.*, u.display_name as wp_name, u.user_email
                FROM {$wpdb->prefix}ptp_trainers t
                JOIN {$wpdb->users} u ON t.user_id = u.ID
                $where
                ORDER BY t.is_featured DESC, t.rating DESC
                LIMIT %d OFFSET %d";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $trainers = $wpdb->get_results($wpdb->prepare($sql, $params));
        $total = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_trainers t $where");
        
        $result = array();
        foreach ($trainers as $trainer) {
            $result[] = $this->format_trainer($trainer);
        }
        
        return rest_ensure_response(array(
            'trainers' => $result,
            'pagination' => array(
                'total' => intval($total),
                'pages' => ceil($total / $limit),
                'page' => intval($request->get_param('page') ?: 1),
                'per_page' => $limit,
            ),
        ));
    }
    
    public function get_featured_trainers($request) {
        $trainers = $this->get_featured_trainers_data(10);
        return rest_ensure_response($trainers);
    }
    
    private function get_featured_trainers_data($limit = 6) {
        global $wpdb;
        
        $trainers = $wpdb->get_results($wpdb->prepare(
            "SELECT t.*, u.display_name as wp_name
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.status = 'active' AND t.is_featured = 1
             ORDER BY t.rating DESC
             LIMIT %d",
            $limit
        ));
        
        return array_map(array($this, 'format_trainer'), $trainers);
    }
    
    private function get_featured_camps_data($limit = 6) {
        $featured_ids = wc_get_featured_product_ids();
        $camps = array();
        
        foreach (array_slice($featured_ids, 0, $limit) as $id) {
            $camps[] = $this->format_camp($id);
        }
        
        return $camps;
    }
    
    public function get_trainer($request) {
        global $wpdb;
        
        $id = intval($request->get_param('id'));
        
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT t.*, u.display_name as wp_name, u.user_email
             FROM {$wpdb->prefix}ptp_trainers t
             JOIN {$wpdb->users} u ON t.user_id = u.ID
             WHERE t.id = %d",
            $id
        ));
        
        if (!$trainer) {
            return new WP_Error('not_found', 'Trainer not found', array('status' => 404));
        }
        
        return rest_ensure_response($this->format_trainer($trainer, true));
    }
    
    private function format_trainer($trainer, $full = false) {
        $specialties = $trainer->specialties;
        if (is_string($specialties)) {
            $decoded = json_decode($specialties, true);
            $specialties = is_array($decoded) ? $decoded : array_filter(array_map('trim', explode(',', $specialties)));
        }
        
        $data = array(
            'id' => intval($trainer->id),
            'name' => $trainer->display_name ?: $trainer->wp_name,
            'slug' => $trainer->slug,
            'photo' => $trainer->photo_url ?: PTP_Images::get_training_photo($trainer->id),
            'headline' => $trainer->headline ?: '',
            'location' => $trainer->location ?: '',
            'hourly_rate' => floatval($trainer->hourly_rate),
            'rating' => floatval($trainer->rating ?: 5.0),
            'review_count' => intval($trainer->review_count ?: 0),
            'session_count' => intval($trainer->session_count ?: 0),
            'specialties' => $specialties ?: array(),
            'playing_level' => $trainer->playing_level ?: '',
            'is_featured' => (bool) $trainer->is_featured,
            'is_verified' => (bool) $trainer->is_verified,
            'response_time' => $trainer->response_time ?: 'within 24 hours',
        );
        
        if ($full) {
            $data['bio'] = $trainer->bio ?: '';
            $data['experience_years'] = intval($trainer->experience_years);
            $data['college'] = $trainer->college ?: '';
            $data['team'] = $trainer->team ?: '';
            $data['position'] = $trainer->position ?: '';
            $data['travel_radius'] = intval($trainer->travel_radius ?: 15);
            $data['accepts_groups'] = (bool) $trainer->accepts_groups;
            $data['group_rate'] = floatval($trainer->group_rate ?: 0);
            $data['instagram'] = $trainer->instagram ?: '';
            
            // Training locations
            $locations = $trainer->training_locations;
            if (is_string($locations)) {
                $locations = json_decode($locations, true) ?: array();
            }
            $data['training_locations'] = $locations;
            
            // Video intro
            $data['video_intro'] = $trainer->video_intro_url ?: '';
        }
        
        return $data;
    }
    
    // ================================================================
    // HELPER METHODS
    // ================================================================
    
    private function format_user($user) {
        global $wpdb;
        
        $data = array(
            'id' => $user->ID,
            'email' => $user->user_email,
            'name' => $user->display_name,
            'first_name' => $user->first_name,
            'last_name' => $user->last_name,
            'avatar' => get_avatar_url($user->ID, array('size' => 200)),
            'phone' => get_user_meta($user->ID, 'phone', true),
        );
        
        // Check if trainer
        $trainer = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}ptp_trainers WHERE user_id = %d",
            $user->ID
        ));
        
        if ($trainer) {
            $data['type'] = 'trainer';
            $data['trainer_id'] = intval($trainer->id);
            $data['trainer_status'] = $trainer->status;
        } else {
            // Check if parent
            $parent = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}ptp_parents WHERE user_id = %d",
                $user->ID
            ));
            
            if ($parent) {
                $data['type'] = 'parent';
                $data['parent_id'] = intval($parent->id);
                
                // Get players
                $players = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM {$wpdb->prefix}ptp_players WHERE parent_id = %d",
                    $parent->id
                ));
                
                $data['players'] = array_map(function($p) {
                    return array(
                        'id' => intval($p->id),
                        'name' => $p->name,
                        'age' => intval($p->age),
                        'position' => $p->position ?: '',
                    );
                }, $players);
            } else {
                $data['type'] = 'user';
            }
        }
        
        return $data;
    }
    
    private function get_specialties_list() {
        return array(
            array('id' => 'ball_control', 'name' => 'Ball Control', 'icon' => '⚽'),
            array('id' => 'dribbling', 'name' => 'Dribbling', 'icon' => '🏃'),
            array('id' => 'shooting', 'name' => 'Shooting', 'icon' => '🎯'),
            array('id' => 'passing', 'name' => 'Passing', 'icon' => '➡️'),
            array('id' => 'first_touch', 'name' => 'First Touch', 'icon' => '✋'),
            array('id' => 'heading', 'name' => 'Heading', 'icon' => '🤕'),
            array('id' => 'defending', 'name' => 'Defending', 'icon' => '🛡️'),
            array('id' => 'positioning', 'name' => 'Positioning', 'icon' => '📍'),
            array('id' => 'speed_agility', 'name' => 'Speed & Agility', 'icon' => '⚡'),
            array('id' => 'goalkeeping', 'name' => 'Goalkeeping', 'icon' => '🧤'),
            array('id' => 'game_iq', 'name' => 'Game IQ', 'icon' => '🧠'),
            array('id' => 'confidence', 'name' => 'Confidence Building', 'icon' => '💪'),
        );
    }
    
    private function get_locations_list() {
        return array(
            array('id' => 'PA', 'name' => 'Pennsylvania', 'cities' => array('Philadelphia', 'Pittsburgh', 'Allentown')),
            array('id' => 'NJ', 'name' => 'New Jersey', 'cities' => array('Newark', 'Jersey City', 'Princeton')),
            array('id' => 'DE', 'name' => 'Delaware', 'cities' => array('Wilmington', 'Dover', 'Newark')),
            array('id' => 'MD', 'name' => 'Maryland', 'cities' => array('Baltimore', 'Annapolis', 'Rockville')),
            array('id' => 'NY', 'name' => 'New York', 'cities' => array('New York City', 'Buffalo', 'Albany')),
        );
    }
    
    // ================================================================
    // STUB METHODS (implement as needed)
    // ================================================================
    
    public function login($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        
        $user = wp_authenticate($email, $password);
        
        if (is_wp_error($user)) {
            return new WP_Error('invalid_credentials', 'Invalid email or password', array('status' => 401));
        }
        
        $token = $this->generate_token($user->ID);
        
        return rest_ensure_response(array(
            'user' => $this->format_user($user),
            'auth' => $token,
        ));
    }
    
    public function register($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        $name = sanitize_text_field($request->get_param('name'));
        $type = sanitize_text_field($request->get_param('type') ?: 'parent');
        
        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Email already registered', array('status' => 400));
        }
        
        $user_id = wp_create_user($email, $password, $email);
        
        if (is_wp_error($user_id)) {
            return $user_id;
        }
        
        wp_update_user(array(
            'ID' => $user_id,
            'display_name' => $name,
        ));
        
        // Create parent record
        if ($type === 'parent') {
            global $wpdb;
            $wpdb->insert($wpdb->prefix . 'ptp_parents', array(
                'user_id' => $user_id,
                'display_name' => $name,
                'email' => $email,
                'status' => 'active',
                'created_at' => current_time('mysql'),
            ));
        }
        
        $user = get_user_by('ID', $user_id);
        $token = $this->generate_token($user_id);
        
        return rest_ensure_response(array(
            'user' => $this->format_user($user),
            'auth' => $token,
        ));
    }
    
    public function google_login($request) {
        if (class_exists('PTP_Social_Login')) {
            return PTP_Social_Login::google_auth($request);
        }
        return new WP_Error('not_configured', 'Google login not configured', array('status' => 501));
    }
    
    public function apple_login($request) {
        if (class_exists('PTP_Social_Login')) {
            return PTP_Social_Login::apple_auth($request);
        }
        return new WP_Error('not_configured', 'Apple login not configured', array('status' => 501));
    }
    
    public function refresh_token($request) {
        $user = $this->get_user_from_token($request);
        if (!$user) {
            return new WP_Error('invalid_token', 'Invalid or expired token', array('status' => 401));
        }
        
        $token = $this->generate_token($user->ID);
        return rest_ensure_response($token);
    }
    
    public function forgot_password($request) {
        $email = sanitize_email($request->get_param('email'));
        $user = get_user_by('email', $email);
        
        if ($user) {
            retrieve_password($email);
        }
        
        // Always return success to prevent email enumeration
        return rest_ensure_response(array(
            'message' => 'If an account exists, a password reset link has been sent.',
        ));
    }
    
    public function logout($request) {
        $user = $this->get_user_from_token($request);
        if ($user) {
            delete_user_meta($user->ID, 'ptp_auth_token');
            delete_user_meta($user->ID, 'ptp_token_expires');
        }
        return rest_ensure_response(array('message' => 'Logged out'));
    }
    
    public function get_current_user($request) {
        $user = $this->get_user_from_token($request);
        return rest_ensure_response($this->format_user($user));
    }
    
    public function register_device($request) {
        $user = $this->get_user_from_token($request);
        $token = sanitize_text_field($request->get_param('fcm_token'));
        $device_type = sanitize_text_field($request->get_param('device_type') ?: 'unknown');
        $device_name = sanitize_text_field($request->get_param('device_name') ?: '');
        $app_version = sanitize_text_field($request->get_param('app_version') ?: '');
        
        global $wpdb;
        
        // Check if token exists
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}ptp_fcm_tokens WHERE token = %s",
            $token
        ));
        
        if ($existing) {
            $wpdb->update(
                $wpdb->prefix . 'ptp_fcm_tokens',
                array(
                    'user_id' => $user->ID,
                    'device_type' => $device_type,
                    'device_name' => $device_name,
                    'app_version' => $app_version,
                    'is_active' => 1,
                    'updated_at' => current_time('mysql'),
                ),
                array('id' => $existing)
            );
        } else {
            $wpdb->insert($wpdb->prefix . 'ptp_fcm_tokens', array(
                'user_id' => $user->ID,
                'token' => $token,
                'device_type' => $device_type,
                'device_name' => $device_name,
                'app_version' => $app_version,
                'is_active' => 1,
                'created_at' => current_time('mysql'),
            ));
        }
        
        return rest_ensure_response(array('registered' => true));
    }
    
    public function unregister_device($request) {
        $token = sanitize_text_field($request->get_param('fcm_token'));
        
        global $wpdb;
        $wpdb->update(
            $wpdb->prefix . 'ptp_fcm_tokens',
            array('is_active' => 0),
            array('token' => $token)
        );
        
        return rest_ensure_response(array('unregistered' => true));
    }
    
    // Placeholder methods - implement as needed
    public function update_profile($request) { return rest_ensure_response(array('updated' => true)); }
    public function upload_avatar($request) { return rest_ensure_response(array('uploaded' => true)); }
    public function change_password($request) { return rest_ensure_response(array('changed' => true)); }
    public function get_notifications($request) { return rest_ensure_response(array()); }
    public function mark_notification_read($request) { return rest_ensure_response(array('read' => true)); }
    public function get_players($request) { return rest_ensure_response(array()); }
    public function add_player($request) { return rest_ensure_response(array()); }
    public function get_player($request) { return rest_ensure_response(array()); }
    public function update_player($request) { return rest_ensure_response(array()); }
    public function delete_player($request) { return rest_ensure_response(array('deleted' => true)); }
    public function get_player_progress($request) { return rest_ensure_response(array()); }
    public function search_trainers($request) { return $this->get_trainers($request); }
    public function get_nearby_trainers($request) { return $this->get_trainers($request); }
    public function get_trainer_availability($request) { return rest_ensure_response(array()); }
    public function get_trainer_reviews($request) { return rest_ensure_response(array()); }
    public function get_trainer_gallery($request) { return rest_ensure_response(array()); }
    public function get_trainer_profile($request) { return rest_ensure_response(array()); }
    public function update_trainer_profile($request) { return rest_ensure_response(array()); }
    public function get_my_availability($request) { return rest_ensure_response(array()); }
    public function update_availability($request) { return rest_ensure_response(array()); }
    public function get_earnings($request) { return rest_ensure_response(array()); }
    public function get_trainer_stats($request) { return rest_ensure_response(array()); }
    public function connect_stripe($request) { return rest_ensure_response(array()); }
    public function stripe_dashboard_link($request) { return rest_ensure_response(array()); }
    public function get_bookings($request) { return rest_ensure_response(array()); }
    public function create_booking($request) { return rest_ensure_response(array()); }
    public function get_booking($request) { return rest_ensure_response(array()); }
    public function confirm_booking($request) { return rest_ensure_response(array()); }
    public function cancel_booking($request) { return rest_ensure_response(array()); }
    public function complete_booking($request) { return rest_ensure_response(array()); }
    public function add_session_notes($request) { return rest_ensure_response(array()); }
    public function submit_review($request) { return rest_ensure_response(array()); }
    public function register_for_camp($request) { return rest_ensure_response(array()); }
    public function get_my_camp_registrations($request) { return rest_ensure_response(array()); }
    public function get_conversations($request) { return rest_ensure_response(array()); }
    public function get_conversation($request) { return rest_ensure_response(array()); }
    public function get_messages($request) { return rest_ensure_response(array()); }
    public function send_message($request) { return rest_ensure_response(array()); }
    public function start_conversation($request) { return rest_ensure_response(array()); }
    public function get_payment_methods($request) { return rest_ensure_response(array()); }
    public function create_setup_intent($request) { return rest_ensure_response(array()); }
    public function add_payment_method($request) { return rest_ensure_response(array()); }
    public function remove_payment_method($request) { return rest_ensure_response(array()); }
    public function get_favorites($request) { return rest_ensure_response(array()); }
    public function add_favorite($request) { return rest_ensure_response(array()); }
    public function remove_favorite($request) { return rest_ensure_response(array()); }
    public function get_faq($request) { return rest_ensure_response(array()); }
    public function get_specialties($request) { return rest_ensure_response($this->get_specialties_list()); }
    public function get_locations($request) { return rest_ensure_response($this->get_locations_list()); }
}

// Initialize
PTP_Mobile_API::instance();
