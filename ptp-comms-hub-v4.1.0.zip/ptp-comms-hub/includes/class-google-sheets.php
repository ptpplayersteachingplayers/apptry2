<?php
/**
 * Google Sheets Integration for PTP Comms Hub
 * 
 * Features:
 * - Export contacts, registrations, campaigns to Google Sheets
 * - Import contacts from Google Sheets
 * - Real-time sync on new orders/contacts
 * - Scheduled background sync
 * - Webhook triggers for instant updates
 * 
 * @package PTP_Comms_Hub
 * @version 1.1.0
 */

class PTP_Comms_Hub_Google_Sheets {
    
    private $client_id;
    private $client_secret;
    private $access_token;
    private $refresh_token;
    private $spreadsheet_id;
    
    const TOKEN_OPTION = 'ptp_comms_google_tokens';
    const SETTINGS_OPTION = 'ptp_comms_google_sheets_settings';
    const SYNC_QUEUE_OPTION = 'ptp_comms_sheets_sync_queue';
    
    public function __construct() {
        $this->client_id = ptp_comms_get_setting('google_client_id');
        $this->client_secret = ptp_comms_get_setting('google_client_secret');
        $this->spreadsheet_id = ptp_comms_get_setting('google_spreadsheet_id');
        
        $tokens = get_option(self::TOKEN_OPTION, array());
        $this->access_token = isset($tokens['access_token']) ? $tokens['access_token'] : '';
        $this->refresh_token = isset($tokens['refresh_token']) ? $tokens['refresh_token'] : '';
        
        // Register hooks
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        add_action('ptp_comms_google_sheets_sync', array($this, 'scheduled_sync'));
        add_action('ptp_comms_process_sheets_queue', array($this, 'process_sync_queue'));
        
        // Real-time sync hooks (if enabled)
        if ($this->is_realtime_enabled()) {
            add_action('ptp_comms_contact_created', array($this, 'queue_contact_sync'), 10, 1);
            add_action('ptp_comms_contact_updated', array($this, 'queue_contact_sync'), 10, 1);
            add_action('ptp_comms_registration_created', array($this, 'queue_registration_sync'), 10, 1);
            add_action('ptp_comms_message_sent', array($this, 'queue_message_sync'), 10, 1);
            add_action('woocommerce_order_status_changed', array($this, 'queue_order_sync'), 10, 1);
        }
        
        // Schedule queue processor
        if (!wp_next_scheduled('ptp_comms_process_sheets_queue')) {
            wp_schedule_event(time(), 'every_five_minutes', 'ptp_comms_process_sheets_queue');
        }
    }
    
    /**
     * Check if Google Sheets is configured
     */
    public function is_configured() {
        return !empty($this->client_id) 
            && !empty($this->client_secret) 
            && !empty($this->access_token)
            && !empty($this->spreadsheet_id);
    }
    
    /**
     * Check if real-time sync is enabled
     */
    public function is_realtime_enabled() {
        return ptp_comms_get_setting('google_sheets_realtime_sync', 'no') === 'yes' && $this->is_configured();
    }
    
    /**
     * Check if we have valid credentials (not necessarily connected)
     */
    public function has_credentials() {
        return !empty($this->client_id) && !empty($this->client_secret);
    }
    
    /**
     * Get OAuth authorization URL
     */
    public function get_auth_url() {
        if (!$this->has_credentials()) {
            return false;
        }
        
        $redirect_uri = $this->get_redirect_uri();
        
        return "https://accounts.google.com/o/oauth2/v2/auth?" . http_build_query(array(
            'client_id' => $this->client_id,
            'redirect_uri' => $redirect_uri,
            'response_type' => 'code',
            'scope' => 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/drive.file',
            'access_type' => 'offline',
            'prompt' => 'consent'
        ));
    }
    
    /**
     * Get redirect URI for OAuth
     */
    public function get_redirect_uri() {
        return admin_url('admin.php?page=ptp-comms-settings&tab=google-sheets&google_callback=1');
    }
    
    /**
     * Exchange authorization code for tokens
     */
    public function exchange_code($code) {
        ptp_comms_debug_log('Google Sheets', 'Exchanging authorization code for tokens');
        
        $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id' => $this->client_id,
                'client_secret' => $this->client_secret,
                'code' => $code,
                'grant_type' => 'authorization_code',
                'redirect_uri' => $this->get_redirect_uri()
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            ptp_comms_debug_log('Google Sheets', 'Token exchange error: ' . $response->get_error_message(), null, 'error');
            return array('success' => false, 'error' => $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['access_token'])) {
            $tokens = array(
                'access_token' => $body['access_token'],
                'refresh_token' => isset($body['refresh_token']) ? $body['refresh_token'] : $this->refresh_token,
                'expires_at' => time() + $body['expires_in']
            );
            
            update_option(self::TOKEN_OPTION, $tokens);
            
            $this->access_token = $tokens['access_token'];
            $this->refresh_token = $tokens['refresh_token'];
            
            ptp_comms_debug_log('Google Sheets', 'Successfully authenticated with Google');
            return array('success' => true);
        }
        
        ptp_comms_debug_log('Google Sheets', 'Token exchange failed', $body, 'error');
        return array('success' => false, 'error' => $body['error_description'] ?? 'Unknown error');
    }
    
    /**
     * Refresh access token
     */
    public function refresh_access_token() {
        if (empty($this->refresh_token)) {
            ptp_comms_debug_log('Google Sheets', 'No refresh token available', null, 'warning');
            return false;
        }
        
        ptp_comms_debug_log('Google Sheets', 'Refreshing access token');
        
        $response = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id' => $this->client_id,
                'client_secret' => $this->client_secret,
                'refresh_token' => $this->refresh_token,
                'grant_type' => 'refresh_token'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            ptp_comms_debug_log('Google Sheets', 'Token refresh failed: ' . $response->get_error_message(), null, 'error');
            return false;
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($body['access_token'])) {
            $tokens = get_option(self::TOKEN_OPTION, array());
            $tokens['access_token'] = $body['access_token'];
            $tokens['expires_at'] = time() + $body['expires_in'];
            
            update_option(self::TOKEN_OPTION, $tokens);
            $this->access_token = $body['access_token'];
            
            ptp_comms_debug_log('Google Sheets', 'Access token refreshed successfully');
            return true;
        }
        
        ptp_comms_debug_log('Google Sheets', 'Token refresh failed', $body, 'error');
        return false;
    }
    
    /**
     * Get valid access token (refresh if needed)
     */
    private function get_valid_token() {
        $tokens = get_option(self::TOKEN_OPTION, array());
        
        // Refresh if token expires in less than 5 minutes
        if (isset($tokens['expires_at']) && time() > ($tokens['expires_at'] - 300)) {
            ptp_comms_debug_log('Google Sheets', 'Token expiring soon, refreshing');
            $this->refresh_access_token();
        }
        
        return $this->access_token;
    }
    
    /**
     * Make authenticated API request with retry logic
     */
    private function api_request($endpoint, $method = 'GET', $body = null, $retry = true) {
        $token = $this->get_valid_token();
        
        if (empty($token)) {
            return array('success' => false, 'error' => 'Not authenticated');
        }
        
        ptp_comms_timer_start('sheets_api_' . $endpoint);
        
        $args = array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            ),
            'timeout' => 60
        );
        
        if ($body !== null) {
            $args['body'] = json_encode($body);
        }
        
        $url = 'https://sheets.googleapis.com/v4/' . $endpoint;
        
        ptp_comms_debug_log('Google Sheets', "API Request: {$method} {$endpoint}");
        
        if ($method === 'GET') {
            $response = wp_remote_get($url, $args);
        } else {
            $args['method'] = $method;
            $response = wp_remote_request($url, $args);
        }
        
        $elapsed = ptp_comms_timer_end('sheets_api_' . $endpoint, 'Google Sheets');
        
        if (is_wp_error($response)) {
            ptp_comms_debug_log('Google Sheets', 'API Error: ' . $response->get_error_message(), null, 'error');
            return array('success' => false, 'error' => $response->get_error_message());
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $data = json_decode(wp_remote_retrieve_body($response), true);
        
        ptp_comms_debug_log('Google Sheets', "API Response: {$code} ({$elapsed}ms)");
        
        if ($code >= 200 && $code < 300) {
            return array('success' => true, 'data' => $data);
        }
        
        // Token expired, try refresh once
        if ($code === 401 && $retry) {
            ptp_comms_debug_log('Google Sheets', 'Token expired, attempting refresh');
            if ($this->refresh_access_token()) {
                return $this->api_request($endpoint, $method, $body, false);
            }
        }
        
        // Rate limited - queue for later
        if ($code === 429) {
            ptp_comms_debug_log('Google Sheets', 'Rate limited, will retry later', null, 'warning');
            return array('success' => false, 'error' => 'Rate limited - will retry', 'retry' => true);
        }
        
        ptp_comms_debug_log('Google Sheets', 'API Error', array('code' => $code, 'data' => $data), 'error');
        return array('success' => false, 'error' => $data['error']['message'] ?? 'API error', 'code' => $code);
    }
    
    /**
     * Create a new spreadsheet with formatted headers
     */
    public function create_spreadsheet($title = 'PTP Comms Hub Data') {
        $token = $this->get_valid_token();
        
        if (empty($token)) {
            return array('success' => false, 'error' => 'Not authenticated');
        }
        
        ptp_comms_debug_log('Google Sheets', 'Creating new spreadsheet: ' . $title);
        
        $response = wp_remote_post('https://sheets.googleapis.com/v4/spreadsheets', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            ),
            'body' => json_encode(array(
                'properties' => array('title' => $title),
                'sheets' => array(
                    array('properties' => array('title' => 'Contacts', 'gridProperties' => array('frozenRowCount' => 1))),
                    array('properties' => array('title' => 'Registrations', 'gridProperties' => array('frozenRowCount' => 1))),
                    array('properties' => array('title' => 'Messages', 'gridProperties' => array('frozenRowCount' => 1))),
                    array('properties' => array('title' => 'Campaigns', 'gridProperties' => array('frozenRowCount' => 1))),
                    array('properties' => array('title' => 'Sync Log', 'gridProperties' => array('frozenRowCount' => 1)))
                )
            )),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'error' => $response->get_error_message());
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        
        if (isset($data['spreadsheetId'])) {
            $this->spreadsheet_id = $data['spreadsheetId'];
            
            // Save the spreadsheet ID
            PTP_Comms_Hub_Settings::set('google_spreadsheet_id', $data['spreadsheetId']);
            
            // Initialize headers with formatting
            $this->initialize_sheet_headers();
            
            // Format header rows
            $this->format_headers($data['sheets']);
            
            ptp_comms_debug_log('Google Sheets', 'Spreadsheet created: ' . $data['spreadsheetId']);
            
            return array(
                'success' => true,
                'spreadsheet_id' => $data['spreadsheetId'],
                'url' => $data['spreadsheetUrl']
            );
        }
        
        return array('success' => false, 'error' => $data['error']['message'] ?? 'Failed to create spreadsheet');
    }
    
    /**
     * Format header rows with bold text and background color
     */
    private function format_headers($sheets) {
        if (empty($sheets)) return;
        
        $requests = array();
        
        foreach ($sheets as $sheet) {
            $sheetId = $sheet['properties']['sheetId'];
            
            // Bold header row
            $requests[] = array(
                'repeatCell' => array(
                    'range' => array(
                        'sheetId' => $sheetId,
                        'startRowIndex' => 0,
                        'endRowIndex' => 1
                    ),
                    'cell' => array(
                        'userEnteredFormat' => array(
                            'backgroundColor' => array('red' => 0.2, 'green' => 0.2, 'blue' => 0.2),
                            'textFormat' => array('bold' => true, 'foregroundColor' => array('red' => 1, 'green' => 1, 'blue' => 1))
                        )
                    ),
                    'fields' => 'userEnteredFormat(backgroundColor,textFormat)'
                )
            );
        }
        
        if (!empty($requests)) {
            $this->api_request(
                "spreadsheets/{$this->spreadsheet_id}:batchUpdate",
                'POST',
                array('requests' => $requests)
            );
        }
    }
    
    /**
     * Initialize sheet headers
     */
    public function initialize_sheet_headers() {
        // Contacts headers
        $this->write_row('Contacts', 1, array(
            'ID', 'First Name', 'Last Name', 'Phone', 'Email', 
            'Child Name', 'Child Age', 'City', 'State', 'Zip',
            'Opted In', 'Opted Out', 'Source', 'Total Orders', 'Lifetime Value',
            'Relationship Score', 'Created', 'Updated'
        ));
        
        // Registrations headers
        $this->write_row('Registrations', 1, array(
            'ID', 'Contact ID', 'Parent Name', 'Order ID', 'Product', 
            'Event Date', 'Event End Date', 'Event Location', 'Child Name', 
            'Program Type', 'Market', 'Status', 'Created'
        ));
        
        // Messages headers
        $this->write_row('Messages', 1, array(
            'ID', 'Contact ID', 'Parent Name', 'Phone', 'Type', 'Direction', 
            'Content', 'Status', 'Campaign', 'Twilio SID', 'Created'
        ));
        
        // Campaigns headers
        $this->write_row('Campaigns', 1, array(
            'ID', 'Name', 'Type', 'Status', 'Target Segment', 
            'Total Recipients', 'Sent', 'Delivered', 'Failed', 
            'Response Rate', 'Created', 'Completed'
        ));
        
        // Sync Log headers
        $this->write_row('Sync Log', 1, array(
            'Timestamp', 'Action', 'Records', 'Status', 'Details'
        ));
        
        return true;
    }
    
    /**
     * Write a row to a sheet
     */
    public function write_row($sheet_name, $row_number, $values) {
        $range = "{$sheet_name}!A{$row_number}";
        
        return $this->api_request(
            "spreadsheets/{$this->spreadsheet_id}/values/{$range}?valueInputOption=RAW",
            'PUT',
            array('values' => array($values))
        );
    }
    
    /**
     * Append rows to a sheet
     */
    public function append_rows($sheet_name, $rows) {
        $range = "{$sheet_name}!A:Z";
        
        return $this->api_request(
            "spreadsheets/{$this->spreadsheet_id}/values/{$range}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS",
            'POST',
            array('values' => $rows)
        );
    }
    
    /**
     * Clear and rewrite entire sheet
     */
    public function clear_and_write($sheet_name, $data) {
        // Clear sheet
        $this->api_request(
            "spreadsheets/{$this->spreadsheet_id}/values/{$sheet_name}:clear",
            'POST'
        );
        
        // Write all data
        if (!empty($data)) {
            return $this->api_request(
                "spreadsheets/{$this->spreadsheet_id}/values/{$sheet_name}!A1?valueInputOption=RAW",
                'PUT',
                array('values' => $data)
            );
        }
        
        return array('success' => true);
    }
    
    /**
     * Read data from a sheet
     */
    public function read_sheet($sheet_name, $range = 'A:Z') {
        return $this->api_request(
            "spreadsheets/{$this->spreadsheet_id}/values/{$sheet_name}!{$range}"
        );
    }
    
    /**
     * Log sync activity to the Sync Log sheet
     */
    private function log_sync($action, $records, $status, $details = '') {
        $this->append_rows('Sync Log', array(
            array(
                current_time('Y-m-d H:i:s'),
                $action,
                $records,
                $status,
                $details
            )
        ));
    }
    
    /**
     * Export contacts to Google Sheets
     */
    public function export_contacts($limit = 0) {
        global $wpdb;
        
        ptp_comms_timer_start('export_contacts');
        ptp_comms_debug_log('Google Sheets', 'Starting contacts export');
        
        $query = "SELECT * FROM {$wpdb->prefix}ptp_contacts ORDER BY created_at DESC";
        if ($limit > 0) {
            $query .= " LIMIT " . intval($limit);
        }
        
        $contacts = $wpdb->get_results($query);
        
        // Prepare data with headers
        $data = array(
            array('ID', 'First Name', 'Last Name', 'Phone', 'Email', 
                  'Child Name', 'Child Age', 'City', 'State', 'Zip',
                  'Opted In', 'Opted Out', 'Source', 'Total Orders', 'Lifetime Value',
                  'Relationship Score', 'Created', 'Updated')
        );
        
        foreach ($contacts as $c) {
            $data[] = array(
                $c->id,
                $c->parent_first_name,
                $c->parent_last_name,
                $c->parent_phone,
                $c->parent_email,
                $c->child_name,
                $c->child_age,
                $c->city,
                $c->state,
                $c->zip_code,
                $c->opted_in ? 'Yes' : 'No',
                $c->opted_out ? 'Yes' : 'No',
                $c->source,
                $c->total_orders ?? 0,
                '$' . number_format($c->lifetime_value ?? 0, 2),
                $c->relationship_score ?? 50,
                $c->created_at,
                $c->updated_at
            );
        }
        
        $result = $this->clear_and_write('Contacts', $data);
        
        $elapsed = ptp_comms_timer_end('export_contacts', 'Google Sheets');
        
        if ($result['success']) {
            $this->log_sync('Export Contacts', count($contacts), 'Success', "Completed in {$elapsed}ms");
            ptp_comms_debug_log('Google Sheets', 'Exported ' . count($contacts) . ' contacts');
        } else {
            $this->log_sync('Export Contacts', 0, 'Failed', $result['error'] ?? 'Unknown error');
        }
        
        return array(
            'success' => $result['success'],
            'count' => count($contacts),
            'elapsed' => $elapsed,
            'error' => $result['error'] ?? null
        );
    }
    
    /**
     * Export registrations to Google Sheets
     */
    public function export_registrations($limit = 0) {
        global $wpdb;
        
        ptp_comms_timer_start('export_registrations');
        ptp_comms_debug_log('Google Sheets', 'Starting registrations export');
        
        $query = "SELECT r.*, c.parent_first_name, c.parent_last_name 
                  FROM {$wpdb->prefix}ptp_registrations r
                  LEFT JOIN {$wpdb->prefix}ptp_contacts c ON r.contact_id = c.id
                  ORDER BY r.created_at DESC";
        if ($limit > 0) {
            $query .= " LIMIT " . intval($limit);
        }
        
        $registrations = $wpdb->get_results($query);
        
        $data = array(
            array('ID', 'Contact ID', 'Parent Name', 'Order ID', 'Product', 
                  'Event Date', 'Event End Date', 'Event Location', 'Child Name', 
                  'Program Type', 'Market', 'Status', 'Created')
        );
        
        foreach ($registrations as $r) {
            $parent_name = trim(($r->parent_first_name ?? '') . ' ' . ($r->parent_last_name ?? ''));
            
            $data[] = array(
                $r->id,
                $r->contact_id,
                $parent_name,
                $r->order_id,
                $r->product_name,
                $r->event_date,
                $r->event_end_date ?? '',
                $r->event_location,
                $r->child_name,
                $r->program_type ?? '',
                $r->market_slug ?? '',
                $r->registration_status,
                $r->created_at
            );
        }
        
        $result = $this->clear_and_write('Registrations', $data);
        $elapsed = ptp_comms_timer_end('export_registrations', 'Google Sheets');
        
        if ($result['success']) {
            $this->log_sync('Export Registrations', count($registrations), 'Success', "Completed in {$elapsed}ms");
        }
        
        return array(
            'success' => $result['success'],
            'count' => count($registrations),
            'elapsed' => $elapsed,
            'error' => $result['error'] ?? null
        );
    }
    
    /**
     * Export recent messages to Google Sheets
     */
    public function export_messages($limit = 1000) {
        global $wpdb;
        
        ptp_comms_timer_start('export_messages');
        ptp_comms_debug_log('Google Sheets', 'Starting messages export');
        
        $messages = $wpdb->get_results($wpdb->prepare(
            "SELECT m.*, c.parent_first_name, c.parent_last_name, c.parent_phone,
                    camp.name as campaign_name
             FROM {$wpdb->prefix}ptp_messages m
             LEFT JOIN {$wpdb->prefix}ptp_contacts c ON m.contact_id = c.id
             LEFT JOIN {$wpdb->prefix}ptp_campaigns camp ON m.campaign_id = camp.id
             ORDER BY m.created_at DESC LIMIT %d",
            $limit
        ));
        
        $data = array(
            array('ID', 'Contact ID', 'Parent Name', 'Phone', 'Type', 'Direction', 
                  'Content', 'Status', 'Campaign', 'Twilio SID', 'Created')
        );
        
        foreach ($messages as $m) {
            $parent_name = trim(($m->parent_first_name ?? '') . ' ' . ($m->parent_last_name ?? ''));
            
            $data[] = array(
                $m->id,
                $m->contact_id,
                $parent_name,
                $m->parent_phone ?? '',
                $m->message_type,
                $m->direction,
                substr($m->message_body, 0, 500),
                $m->status,
                $m->campaign_name ?? '',
                $m->twilio_sid,
                $m->created_at
            );
        }
        
        $result = $this->clear_and_write('Messages', $data);
        $elapsed = ptp_comms_timer_end('export_messages', 'Google Sheets');
        
        if ($result['success']) {
            $this->log_sync('Export Messages', count($messages), 'Success', "Completed in {$elapsed}ms");
        }
        
        return array(
            'success' => $result['success'],
            'count' => count($messages),
            'elapsed' => $elapsed,
            'error' => $result['error'] ?? null
        );
    }
    
    /**
     * Export campaigns to Google Sheets
     */
    public function export_campaigns() {
        global $wpdb;
        
        ptp_comms_timer_start('export_campaigns');
        
        $campaigns = $wpdb->get_results(
            "SELECT c.*, s.name as segment_name
             FROM {$wpdb->prefix}ptp_campaigns c
             LEFT JOIN {$wpdb->prefix}ptp_saved_segments s ON c.segment_id = s.id
             ORDER BY c.created_at DESC"
        );
        
        $data = array(
            array('ID', 'Name', 'Type', 'Status', 'Target Segment', 
                  'Total Recipients', 'Sent', 'Delivered', 'Failed', 
                  'Response Rate', 'Created', 'Completed')
        );
        
        foreach ($campaigns as $c) {
            $response_rate = $c->sent_count > 0 
                ? round(($c->response_count ?? 0) / $c->sent_count * 100, 1) . '%'
                : '0%';
            
            $data[] = array(
                $c->id,
                $c->name,
                $c->campaign_type,
                $c->status,
                $c->segment_name ?? 'All Contacts',
                $c->total_recipients ?? 0,
                $c->sent_count,
                $c->delivered_count,
                $c->failed_count,
                $response_rate,
                $c->created_at,
                $c->completed_at
            );
        }
        
        $result = $this->clear_and_write('Campaigns', $data);
        $elapsed = ptp_comms_timer_end('export_campaigns', 'Google Sheets');
        
        if ($result['success']) {
            $this->log_sync('Export Campaigns', count($campaigns), 'Success', "Completed in {$elapsed}ms");
        }
        
        return array(
            'success' => $result['success'],
            'count' => count($campaigns),
            'elapsed' => $elapsed,
            'error' => $result['error'] ?? null
        );
    }
    
    /**
     * Full export to Google Sheets
     */
    public function full_export() {
        ptp_comms_debug_log('Google Sheets', 'Starting full export');
        ptp_comms_timer_start('full_export');
        
        $results = array();
        
        $results['contacts'] = $this->export_contacts();
        $results['registrations'] = $this->export_registrations();
        $results['messages'] = $this->export_messages();
        $results['campaigns'] = $this->export_campaigns();
        
        $elapsed = ptp_comms_timer_end('full_export', 'Google Sheets');
        
        $success = $results['contacts']['success'] 
            && $results['registrations']['success']
            && $results['messages']['success']
            && $results['campaigns']['success'];
        
        // Update last sync time
        update_option('ptp_comms_sheets_last_sync', current_time('mysql'));
        
        $total_records = ($results['contacts']['count'] ?? 0)
            + ($results['registrations']['count'] ?? 0)
            + ($results['messages']['count'] ?? 0)
            + ($results['campaigns']['count'] ?? 0);
        
        ptp_comms_debug_log('Google Sheets', "Full export complete: {$total_records} records in {$elapsed}ms");
        
        return array(
            'success' => $success,
            'results' => $results,
            'total_records' => $total_records,
            'elapsed' => $elapsed
        );
    }
    
    /**
     * Import contacts from Google Sheets
     */
    public function import_contacts() {
        ptp_comms_debug_log('Google Sheets', 'Starting contacts import');
        ptp_comms_timer_start('import_contacts');
        
        $result = $this->read_sheet('Contacts');
        
        if (!$result['success']) {
            return $result;
        }
        
        $rows = $result['data']['values'] ?? array();
        
        if (count($rows) < 2) {
            return array('success' => true, 'imported' => 0, 'message' => 'No data to import');
        }
        
        // Get header row to map columns dynamically
        $headers = array_shift($rows);
        $header_map = array_flip(array_map('strtolower', $headers));
        
        $imported = 0;
        $updated = 0;
        $errors = 0;
        $error_details = array();
        
        foreach ($rows as $index => $row) {
            // Map columns dynamically
            $phone_col = $header_map['phone'] ?? 3;
            $phone = isset($row[$phone_col]) ? $row[$phone_col] : '';
            
            if (empty($phone)) {
                $errors++;
                $error_details[] = "Row " . ($index + 2) . ": Missing phone number";
                continue;
            }
            
            $data = array(
                'parent_first_name' => $row[$header_map['first name'] ?? 1] ?? '',
                'parent_last_name' => $row[$header_map['last name'] ?? 2] ?? '',
                'parent_email' => $row[$header_map['email'] ?? 4] ?? '',
                'child_name' => $row[$header_map['child name'] ?? 5] ?? '',
                'child_age' => $row[$header_map['child age'] ?? 6] ?? '',
                'city' => $row[$header_map['city'] ?? 7] ?? '',
                'state' => $row[$header_map['state'] ?? 8] ?? '',
                'zip_code' => $row[$header_map['zip'] ?? 9] ?? '',
                'source' => 'google_sheets_import'
            );
            
            $contact_id = ptp_comms_get_or_create_contact($phone, $data);
            
            if ($contact_id) {
                $imported++;
            } else {
                $errors++;
                $error_details[] = "Row " . ($index + 2) . ": Failed to create contact for {$phone}";
            }
        }
        
        $elapsed = ptp_comms_timer_end('import_contacts', 'Google Sheets');
        
        $this->log_sync('Import Contacts', $imported, $errors > 0 ? 'Partial' : 'Success', 
            "{$imported} imported, {$errors} errors in {$elapsed}ms");
        
        ptp_comms_debug_log('Google Sheets', "Import complete: {$imported} imported, {$errors} errors");
        
        return array(
            'success' => true,
            'imported' => $imported,
            'errors' => $errors,
            'error_details' => array_slice($error_details, 0, 10), // First 10 errors
            'elapsed' => $elapsed
        );
    }
    
    /**
     * Queue contact for sync
     */
    public function queue_contact_sync($contact_id) {
        $this->add_to_queue('contact', $contact_id);
    }
    
    /**
     * Queue registration for sync
     */
    public function queue_registration_sync($registration_id) {
        $this->add_to_queue('registration', $registration_id);
    }
    
    /**
     * Queue message for sync
     */
    public function queue_message_sync($message_id) {
        $this->add_to_queue('message', $message_id);
    }
    
    /**
     * Queue order for sync
     */
    public function queue_order_sync($order_id) {
        $this->add_to_queue('order', $order_id);
    }
    
    /**
     * Add item to sync queue
     */
    private function add_to_queue($type, $id) {
        $queue = get_option(self::SYNC_QUEUE_OPTION, array());
        
        $queue[] = array(
            'type' => $type,
            'id' => $id,
            'queued_at' => time()
        );
        
        // Limit queue size
        if (count($queue) > 1000) {
            $queue = array_slice($queue, -500);
        }
        
        update_option(self::SYNC_QUEUE_OPTION, $queue);
    }
    
    /**
     * Process sync queue
     */
    public function process_sync_queue() {
        if (!$this->is_configured()) {
            return;
        }
        
        $queue = get_option(self::SYNC_QUEUE_OPTION, array());
        
        if (empty($queue)) {
            return;
        }
        
        ptp_comms_debug_log('Google Sheets', 'Processing sync queue: ' . count($queue) . ' items');
        
        // Group by type
        $grouped = array();
        foreach ($queue as $item) {
            $type = $item['type'];
            if (!isset($grouped[$type])) {
                $grouped[$type] = array();
            }
            $grouped[$type][] = $item['id'];
        }
        
        // Process each type
        foreach ($grouped as $type => $ids) {
            switch ($type) {
                case 'contact':
                    // For contacts, do a full re-export (simpler and ensures consistency)
                    $this->export_contacts();
                    break;
                case 'registration':
                    $this->export_registrations();
                    break;
                case 'message':
                    $this->export_messages();
                    break;
            }
        }
        
        // Clear queue
        update_option(self::SYNC_QUEUE_OPTION, array());
        
        ptp_comms_debug_log('Google Sheets', 'Sync queue processed');
    }
    
    /**
     * Scheduled sync handler
     */
    public function scheduled_sync() {
        if (!$this->is_configured()) {
            return;
        }
        
        $sync_enabled = ptp_comms_get_setting('google_sheets_auto_sync', 'no');
        
        if ($sync_enabled !== 'yes') {
            return;
        }
        
        ptp_comms_debug_log('Google Sheets', 'Running scheduled sync');
        $this->full_export();
    }
    
    /**
     * Register REST routes
     */
    public function register_rest_routes() {
        register_rest_route('ptp-comms/v1', '/google-sheets/export', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_export'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/google-sheets/import', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_import'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/google-sheets/create', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_create_spreadsheet'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/google-sheets/test', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_test_connection'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/google-sheets/status', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_status'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
    }
    
    /**
     * REST endpoint: Export
     */
    public function rest_export($request) {
        $type = $request->get_param('type') ?? 'full';
        
        ptp_comms_debug_log('Google Sheets', "REST export request: {$type}");
        
        switch ($type) {
            case 'contacts':
                $result = $this->export_contacts();
                break;
            case 'registrations':
                $result = $this->export_registrations();
                break;
            case 'messages':
                $result = $this->export_messages();
                break;
            case 'campaigns':
                $result = $this->export_campaigns();
                break;
            default:
                $result = $this->full_export();
        }
        
        return rest_ensure_response($result);
    }
    
    /**
     * REST endpoint: Import
     */
    public function rest_import($request) {
        return rest_ensure_response($this->import_contacts());
    }
    
    /**
     * REST endpoint: Create spreadsheet
     */
    public function rest_create_spreadsheet($request) {
        $title = $request->get_param('title') ?? 'PTP Comms Hub Data - ' . date('Y-m-d');
        return rest_ensure_response($this->create_spreadsheet($title));
    }
    
    /**
     * REST endpoint: Test connection
     */
    public function rest_test_connection($request) {
        if (!$this->is_configured()) {
            return rest_ensure_response(array(
                'success' => false,
                'error' => 'Google Sheets not configured'
            ));
        }
        
        ptp_comms_debug_log('Google Sheets', 'Testing connection');
        
        // Try to read the spreadsheet
        $result = $this->api_request("spreadsheets/{$this->spreadsheet_id}");
        
        if ($result['success']) {
            return rest_ensure_response(array(
                'success' => true,
                'spreadsheet_title' => $result['data']['properties']['title'] ?? 'Unknown',
                'spreadsheet_url' => $result['data']['spreadsheetUrl'] ?? '',
                'sheets' => array_map(function($s) {
                    return array(
                        'title' => $s['properties']['title'],
                        'rows' => $s['properties']['gridProperties']['rowCount'] ?? 0
                    );
                }, $result['data']['sheets'] ?? array())
            ));
        }
        
        return rest_ensure_response($result);
    }
    
    /**
     * REST endpoint: Get status
     */
    public function rest_get_status($request) {
        return rest_ensure_response($this->get_status());
    }
    
    /**
     * Disconnect Google Sheets
     */
    public function disconnect() {
        delete_option(self::TOKEN_OPTION);
        delete_option(self::SYNC_QUEUE_OPTION);
        $this->access_token = '';
        $this->refresh_token = '';
        ptp_comms_debug_log('Google Sheets', 'Disconnected from Google');
        return true;
    }
    
    /**
     * Get connection status
     */
    public function get_status() {
        $tokens = get_option(self::TOKEN_OPTION, array());
        $last_sync = get_option('ptp_comms_sheets_last_sync', '');
        $queue = get_option(self::SYNC_QUEUE_OPTION, array());
        
        return array(
            'has_credentials' => $this->has_credentials(),
            'is_connected' => !empty($this->access_token),
            'is_configured' => $this->is_configured(),
            'realtime_enabled' => $this->is_realtime_enabled(),
            'spreadsheet_id' => $this->spreadsheet_id,
            'spreadsheet_url' => $this->spreadsheet_id 
                ? "https://docs.google.com/spreadsheets/d/{$this->spreadsheet_id}" 
                : null,
            'last_sync' => $last_sync,
            'queue_size' => count($queue),
            'token_expires' => isset($tokens['expires_at']) ? date('Y-m-d H:i:s', $tokens['expires_at']) : null,
            'token_valid' => isset($tokens['expires_at']) ? time() < $tokens['expires_at'] : false
        );
    }
}

// Initialize the class
add_action('init', function() {
    global $ptp_google_sheets;
    $ptp_google_sheets = new PTP_Comms_Hub_Google_Sheets();
});

// Add custom cron schedule
add_filter('cron_schedules', function($schedules) {
    $schedules['every_five_minutes'] = array(
        'interval' => 300,
        'display' => 'Every 5 Minutes'
    );
    return $schedules;
});
