<?php
/**
 * API Request Logger for PTP Comms Hub
 * 
 * Logs all external API calls for debugging:
 * - Twilio SMS/Voice
 * - Google Sheets
 * - HubSpot
 * - Microsoft Teams
 * 
 * @package PTP_Comms_Hub
 * @version 1.0.0
 */

class PTP_Comms_Hub_API_Logger {
    
    const TABLE_NAME = 'ptp_api_logs';
    const MAX_LOGS = 1000;
    
    private static $instance = null;
    private $enabled = false;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function __construct() {
        $this->enabled = get_option('ptp_comms_api_logging', 'off') === 'on';
        
        // Register REST routes
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        
        // Hook into WordPress HTTP API
        if ($this->enabled) {
            add_filter('http_request_args', array($this, 'log_request_start'), 10, 2);
            add_action('http_api_debug', array($this, 'log_request_debug'), 10, 5);
            add_filter('pre_http_request', array($this, 'capture_request'), 10, 3);
        }
    }
    
    /**
     * Check if logging is enabled
     */
    public function is_enabled() {
        return $this->enabled;
    }
    
    /**
     * Enable/disable API logging
     */
    public function set_enabled($enabled) {
        $this->enabled = (bool) $enabled;
        update_option('ptp_comms_api_logging', $enabled ? 'on' : 'off');
    }
    
    /**
     * Log an API request
     */
    public function log_request($service, $endpoint, $method, $request_data, $response_data, $status_code, $duration_ms = 0, $error = null) {
        if (!$this->enabled) {
            return;
        }
        
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            $this->create_table();
        }
        
        // Sanitize large data
        $request_json = is_string($request_data) ? $request_data : json_encode($request_data);
        $response_json = is_string($response_data) ? $response_data : json_encode($response_data);
        
        // Truncate if too large
        if (strlen($request_json) > 65000) {
            $request_json = substr($request_json, 0, 65000) . '... [truncated]';
        }
        if (strlen($response_json) > 65000) {
            $response_json = substr($response_json, 0, 65000) . '... [truncated]';
        }
        
        $wpdb->insert($table, array(
            'service' => $service,
            'endpoint' => substr($endpoint, 0, 500),
            'method' => $method,
            'request_data' => $request_json,
            'response_data' => $response_json,
            'status_code' => $status_code,
            'duration_ms' => $duration_ms,
            'error_message' => $error,
            'created_at' => current_time('mysql')
        ));
        
        // Cleanup old logs
        $this->cleanup_old_logs();
    }
    
    /**
     * Create the API logs table
     */
    public function create_table() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            service varchar(50) NOT NULL,
            endpoint varchar(500) NOT NULL,
            method varchar(10) NOT NULL DEFAULT 'GET',
            request_data longtext,
            response_data longtext,
            status_code int(11) DEFAULT NULL,
            duration_ms int(11) DEFAULT 0,
            error_message text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY service (service),
            KEY status_code (status_code),
            KEY created_at (created_at)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
    
    /**
     * Cleanup old logs
     */
    private function cleanup_old_logs() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
        
        if ($count > self::MAX_LOGS) {
            $delete_count = $count - self::MAX_LOGS + 100; // Delete extra 100 for buffer
            $wpdb->query("DELETE FROM $table ORDER BY created_at ASC LIMIT $delete_count");
        }
    }
    
    /**
     * Get recent logs
     */
    public function get_logs($args = array()) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        // Check if table exists
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            return array();
        }
        
        $defaults = array(
            'limit' => 50,
            'offset' => 0,
            'service' => null,
            'status' => null, // 'success', 'error', or null for all
            'search' => null
        );
        
        $args = wp_parse_args($args, $defaults);
        
        $where = array('1=1');
        $values = array();
        
        if ($args['service']) {
            $where[] = 'service = %s';
            $values[] = $args['service'];
        }
        
        if ($args['status'] === 'success') {
            $where[] = 'status_code >= 200 AND status_code < 300';
        } elseif ($args['status'] === 'error') {
            $where[] = '(status_code < 200 OR status_code >= 300 OR error_message IS NOT NULL)';
        }
        
        if ($args['search']) {
            $where[] = '(endpoint LIKE %s OR request_data LIKE %s OR response_data LIKE %s)';
            $search_term = '%' . $wpdb->esc_like($args['search']) . '%';
            $values[] = $search_term;
            $values[] = $search_term;
            $values[] = $search_term;
        }
        
        $where_clause = implode(' AND ', $where);
        
        $query = "SELECT * FROM $table WHERE $where_clause ORDER BY created_at DESC LIMIT %d OFFSET %d";
        $values[] = $args['limit'];
        $values[] = $args['offset'];
        
        return $wpdb->get_results($wpdb->prepare($query, $values));
    }
    
    /**
     * Get log statistics
     */
    public function get_stats($hours = 24) {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            return array();
        }
        
        $since = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));
        
        return $wpdb->get_results($wpdb->prepare("
            SELECT 
                service,
                COUNT(*) as total_requests,
                SUM(CASE WHEN status_code >= 200 AND status_code < 300 THEN 1 ELSE 0 END) as success_count,
                SUM(CASE WHEN status_code < 200 OR status_code >= 300 THEN 1 ELSE 0 END) as error_count,
                AVG(duration_ms) as avg_duration,
                MAX(duration_ms) as max_duration
            FROM $table
            WHERE created_at >= %s
            GROUP BY service
            ORDER BY total_requests DESC
        ", $since));
    }
    
    /**
     * Clear all logs
     */
    public function clear_logs() {
        global $wpdb;
        $table = $wpdb->prefix . self::TABLE_NAME;
        $wpdb->query("TRUNCATE TABLE $table");
    }
    
    /**
     * Register REST routes
     */
    public function register_rest_routes() {
        register_rest_route('ptp-comms/v1', '/api-logs', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_logs'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/api-logs/stats', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_stats'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/api-logs/clear', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_clear_logs'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/api-logs/toggle', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_toggle_logging'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
    }
    
    /**
     * REST: Get logs
     */
    public function rest_get_logs($request) {
        $logs = $this->get_logs(array(
            'limit' => $request->get_param('limit') ?? 50,
            'offset' => $request->get_param('offset') ?? 0,
            'service' => $request->get_param('service'),
            'status' => $request->get_param('status'),
            'search' => $request->get_param('search')
        ));
        
        return rest_ensure_response(array(
            'success' => true,
            'logs' => $logs,
            'enabled' => $this->enabled
        ));
    }
    
    /**
     * REST: Get stats
     */
    public function rest_get_stats($request) {
        $hours = $request->get_param('hours') ?? 24;
        return rest_ensure_response(array(
            'success' => true,
            'stats' => $this->get_stats($hours),
            'enabled' => $this->enabled
        ));
    }
    
    /**
     * REST: Clear logs
     */
    public function rest_clear_logs($request) {
        $this->clear_logs();
        return rest_ensure_response(array('success' => true));
    }
    
    /**
     * REST: Toggle logging
     */
    public function rest_toggle_logging($request) {
        $enabled = $request->get_param('enabled');
        $this->set_enabled($enabled);
        return rest_ensure_response(array(
            'success' => true,
            'enabled' => $this->enabled
        ));
    }
    
    /**
     * Capture outgoing HTTP request for logging
     */
    public function capture_request($preempt, $args, $url) {
        // Store request start time
        $GLOBALS['ptp_api_request_start'] = microtime(true);
        $GLOBALS['ptp_api_request_url'] = $url;
        $GLOBALS['ptp_api_request_args'] = $args;
        
        return $preempt; // Don't preempt, let request continue
    }
    
    /**
     * Log request start
     */
    public function log_request_start($args, $url) {
        $GLOBALS['ptp_api_request_start'] = microtime(true);
        return $args;
    }
    
    /**
     * Log request debug
     */
    public function log_request_debug($response, $context, $class, $args, $url) {
        // Only log relevant API calls
        $services = array(
            'api.twilio.com' => 'Twilio',
            'sheets.googleapis.com' => 'Google Sheets',
            'oauth2.googleapis.com' => 'Google OAuth',
            'api.hubapi.com' => 'HubSpot',
            'graph.microsoft.com' => 'Microsoft Graph'
        );
        
        $service = null;
        foreach ($services as $domain => $name) {
            if (strpos($url, $domain) !== false) {
                $service = $name;
                break;
            }
        }
        
        if (!$service) {
            return;
        }
        
        $start_time = isset($GLOBALS['ptp_api_request_start']) ? $GLOBALS['ptp_api_request_start'] : 0;
        $duration = $start_time ? round((microtime(true) - $start_time) * 1000) : 0;
        
        $status_code = null;
        $response_data = null;
        $error = null;
        
        if (is_wp_error($response)) {
            $error = $response->get_error_message();
            $status_code = 0;
        } else {
            $status_code = wp_remote_retrieve_response_code($response);
            $response_data = wp_remote_retrieve_body($response);
        }
        
        // Mask sensitive data
        $request_data = isset($args['body']) ? $args['body'] : null;
        $request_data = $this->mask_sensitive_data($request_data);
        
        $this->log_request(
            $service,
            $url,
            isset($args['method']) ? $args['method'] : 'GET',
            $request_data,
            $response_data,
            $status_code,
            $duration,
            $error
        );
    }
    
    /**
     * Mask sensitive data in requests
     */
    private function mask_sensitive_data($data) {
        if (is_string($data)) {
            // Mask auth tokens
            $data = preg_replace('/Bearer\s+[a-zA-Z0-9\-_.]+/', 'Bearer [MASKED]', $data);
            // Mask API keys
            $data = preg_replace('/api_key["\']?\s*[:=]\s*["\']?[a-zA-Z0-9\-_]+/', 'api_key: [MASKED]', $data);
            // Mask passwords
            $data = preg_replace('/password["\']?\s*[:=]\s*["\']?[^"\'&\s]+/', 'password: [MASKED]', $data);
        }
        return $data;
    }
}

// Initialize
add_action('plugins_loaded', function() {
    PTP_Comms_Hub_API_Logger::get_instance();
});

/**
 * Helper function to log API requests manually
 */
function ptp_comms_log_api_request($service, $endpoint, $method, $request, $response, $status, $duration = 0, $error = null) {
    $logger = PTP_Comms_Hub_API_Logger::get_instance();
    $logger->log_request($service, $endpoint, $method, $request, $response, $status, $duration, $error);
}