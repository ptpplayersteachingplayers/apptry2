<?php
/**
 * Twilio Client Service - Browser-based softphone using WebRTC
 * Enables answering/making calls directly from the WordPress dashboard
 * 
 * @package PTP_Comms_Hub
 * @version 1.0.0
 */

class PTP_Comms_Hub_Twilio_Client {
    
    private $account_sid;
    private $auth_token;
    private $api_key_sid;
    private $api_key_secret;
    private $twiml_app_sid;
    private $phone_number;
    private $client_identity;
    
    public function __construct() {
        $this->account_sid = ptp_comms_get_setting('twilio_account_sid');
        $this->auth_token = ptp_comms_get_setting('twilio_auth_token');
        $this->api_key_sid = ptp_comms_get_setting('twilio_api_key_sid');
        $this->api_key_secret = ptp_comms_get_setting('twilio_api_key_secret');
        $this->twiml_app_sid = ptp_comms_get_setting('twilio_twiml_app_sid');
        $this->phone_number = ptp_comms_get_setting('twilio_phone_number');
    }
    
    /**
     * Check if Twilio Client is fully configured
     */
    public function is_configured() {
        return !empty($this->account_sid) 
            && !empty($this->auth_token)
            && !empty($this->api_key_sid)
            && !empty($this->api_key_secret)
            && !empty($this->twiml_app_sid);
    }
    
    /**
     * Check if basic Twilio is configured (for fallback)
     */
    public function is_basic_configured() {
        return !empty($this->account_sid) && !empty($this->auth_token);
    }
    
    /**
     * Generate an Access Token for Twilio Client SDK
     * This token allows the browser to connect to Twilio
     */
    public function generate_access_token($identity = null) {
        if (!$this->is_configured()) {
            return array('success' => false, 'error' => 'Twilio Client not fully configured. API Key and TwiML App required.');
        }
        
        // Use current user's ID as identity if not provided
        if (empty($identity)) {
            $current_user = wp_get_current_user();
            $identity = 'ptp_user_' . $current_user->ID;
        }
        
        $this->client_identity = $identity;
        
        // Build JWT token manually (since we can't use Twilio SDK)
        $token = $this->build_access_token($identity);
        
        if (!$token) {
            return array('success' => false, 'error' => 'Failed to generate access token');
        }
        
        return array(
            'success' => true,
            'token' => $token,
            'identity' => $identity
        );
    }
    
    /**
     * Build JWT Access Token manually
     * This creates the token needed for Twilio Client SDK
     */
    private function build_access_token($identity) {
        $header = array(
            'typ' => 'JWT',
            'alg' => 'HS256',
            'cty' => 'twilio-fpa;v=1'
        );
        
        $now = time();
        $ttl = 3600; // 1 hour validity
        
        $payload = array(
            'jti' => $this->api_key_sid . '-' . $now,
            'iss' => $this->api_key_sid,
            'sub' => $this->account_sid,
            'exp' => $now + $ttl,
            'grants' => array(
                'identity' => $identity,
                'voice' => array(
                    'incoming' => array(
                        'allow' => true
                    ),
                    'outgoing' => array(
                        'application_sid' => $this->twiml_app_sid
                    )
                )
            )
        );
        
        $header_encoded = $this->base64url_encode(json_encode($header));
        $payload_encoded = $this->base64url_encode(json_encode($payload));
        
        $signature = hash_hmac('sha256', $header_encoded . '.' . $payload_encoded, $this->api_key_secret, true);
        $signature_encoded = $this->base64url_encode($signature);
        
        return $header_encoded . '.' . $payload_encoded . '.' . $signature_encoded;
    }
    
    /**
     * Base64 URL encode (RFC 4648)
     */
    private function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }
    
    /**
     * Generate TwiML for incoming browser client calls
     * This handles calls TO the browser softphone
     */
    public function generate_client_twiml($to_client, $from_number, $caller_name = '') {
        header('Content-Type: text/xml');
        
        $caller_id = !empty($caller_name) ? $caller_name : $from_number;
        
        return '<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Dial callerId="' . esc_attr($this->phone_number) . '"
          record="record-from-answer-dual"
          recordingStatusCallback="' . esc_url(get_rest_url(null, 'ptp-comms/v1/recording-status')) . '"
          recordingStatusCallbackMethod="POST"
          action="' . esc_url(get_rest_url(null, 'ptp-comms/v1/client-call-status')) . '"
          method="POST">
        <Client>
            <Identity>' . esc_html($to_client) . '</Identity>
            <Parameter name="callerName" value="' . esc_attr($caller_id) . '"/>
            <Parameter name="callerNumber" value="' . esc_attr($from_number) . '"/>
        </Client>
    </Dial>
</Response>';
    }
    
    /**
     * Generate TwiML for outgoing browser client calls
     * This handles calls FROM the browser softphone to phone numbers
     */
    public function generate_outbound_twiml($to_number, $from_identity) {
        header('Content-Type: text/xml');
        
        // Normalize the phone number
        $to_number = ptp_comms_normalize_phone($to_number);
        
        if (!$to_number) {
            return '<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Say voice="Polly.Joanna">Invalid phone number. Please try again.</Say>
</Response>';
        }
        
        return '<?xml version="1.0" encoding="UTF-8"?>
<Response>
    <Dial callerId="' . esc_attr($this->phone_number) . '"
          record="record-from-answer-dual"
          recordingStatusCallback="' . esc_url(get_rest_url(null, 'ptp-comms/v1/recording-status')) . '"
          recordingStatusCallbackMethod="POST"
          answerOnBridge="true">
        <Number>' . esc_html($to_number) . '</Number>
    </Dial>
</Response>';
    }
    
    /**
     * Get list of currently registered browser clients
     * Note: This requires checking active WebSocket connections
     */
    public function get_active_clients() {
        // Active clients are tracked via transients when they connect
        $clients = get_transient('ptp_active_twilio_clients');
        return is_array($clients) ? $clients : array();
    }
    
    /**
     * Register a browser client as active
     */
    public function register_client($identity) {
        $clients = $this->get_active_clients();
        $clients[$identity] = array(
            'registered_at' => current_time('mysql'),
            'user_id' => get_current_user_id()
        );
        set_transient('ptp_active_twilio_clients', $clients, HOUR_IN_SECONDS);
        return true;
    }
    
    /**
     * Unregister a browser client
     */
    public function unregister_client($identity) {
        $clients = $this->get_active_clients();
        unset($clients[$identity]);
        set_transient('ptp_active_twilio_clients', $clients, HOUR_IN_SECONDS);
        return true;
    }
    
    /**
     * Check if any browser clients are available to take calls
     */
    public function has_available_clients() {
        $clients = $this->get_active_clients();
        return !empty($clients);
    }
    
    /**
     * Get the primary client identity for routing calls
     */
    public function get_primary_client_identity() {
        $clients = $this->get_active_clients();
        if (empty($clients)) {
            return null;
        }
        
        // Return the first registered client
        // Could be enhanced to support round-robin or priority routing
        return array_key_first($clients);
    }
    
    /**
     * Create or update TwiML App for browser calling
     */
    public function create_twiml_app() {
        if (!$this->is_basic_configured()) {
            return array('success' => false, 'error' => 'Twilio not configured');
        }
        
        $app_name = 'PTP Comms Hub Softphone';
        $voice_url = get_rest_url(null, 'ptp-comms/v1/client-voice');
        $status_url = get_rest_url(null, 'ptp-comms/v1/client-call-status');
        
        // Check if we already have an app
        if (!empty($this->twiml_app_sid)) {
            // Update existing app
            $url = "https://api.twilio.com/2010-04-01/Accounts/{$this->account_sid}/Applications/{$this->twiml_app_sid}.json";
            $method = 'POST';
        } else {
            // Create new app
            $url = "https://api.twilio.com/2010-04-01/Accounts/{$this->account_sid}/Applications.json";
            $method = 'POST';
        }
        
        $data = array(
            'FriendlyName' => $app_name,
            'VoiceUrl' => $voice_url,
            'VoiceMethod' => 'POST',
            'StatusCallback' => $status_url,
            'StatusCallbackMethod' => 'POST'
        );
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode("{$this->account_sid}:{$this->auth_token}")
            ),
            'body' => $data,
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'error' => $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!empty($body['sid'])) {
            return array(
                'success' => true,
                'app_sid' => $body['sid'],
                'app_name' => $body['friendly_name']
            );
        }
        
        return array('success' => false, 'error' => $body['message'] ?? 'Unknown error');
    }
    
    /**
     * Create API Key for access tokens
     */
    public function create_api_key() {
        if (!$this->is_basic_configured()) {
            return array('success' => false, 'error' => 'Twilio not configured');
        }
        
        $url = "https://api.twilio.com/2010-04-01/Accounts/{$this->account_sid}/Keys.json";
        
        $response = wp_remote_post($url, array(
            'headers' => array(
                'Authorization' => 'Basic ' . base64_encode("{$this->account_sid}:{$this->auth_token}")
            ),
            'body' => array(
                'FriendlyName' => 'PTP Comms Hub Browser Client'
            ),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return array('success' => false, 'error' => $response->get_error_message());
        }
        
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if (!empty($body['sid']) && !empty($body['secret'])) {
            return array(
                'success' => true,
                'api_key_sid' => $body['sid'],
                'api_key_secret' => $body['secret']
            );
        }
        
        return array('success' => false, 'error' => $body['message'] ?? 'Unknown error');
    }
    
    /**
     * Test the Twilio Client configuration
     */
    public function test_configuration() {
        $results = array(
            'account_sid' => !empty($this->account_sid),
            'auth_token' => !empty($this->auth_token),
            'api_key_sid' => !empty($this->api_key_sid),
            'api_key_secret' => !empty($this->api_key_secret),
            'twiml_app_sid' => !empty($this->twiml_app_sid),
            'phone_number' => !empty($this->phone_number)
        );
        
        $all_configured = !in_array(false, $results, true);
        
        // Try to generate a test token
        $token_result = array('success' => false);
        if ($all_configured) {
            $token_result = $this->generate_access_token('test_user');
        }
        
        return array(
            'configured' => $all_configured,
            'settings' => $results,
            'token_test' => $token_result['success']
        );
    }
}
