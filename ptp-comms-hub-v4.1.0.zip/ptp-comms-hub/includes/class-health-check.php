<?php
/**
 * Health Check & Diagnostics for PTP Comms Hub
 * 
 * Provides system status, connectivity tests, and troubleshooting tools
 * 
 * @package PTP_Comms_Hub
 * @version 1.0.0
 */

class PTP_Comms_Hub_Health_Check {
    
    /**
     * Run all health checks
     */
    public static function run_all_checks() {
        return array(
            'twilio' => self::check_twilio(),
            'database' => self::check_database(),
            'webhooks' => self::check_webhooks(),
            'cron' => self::check_cron(),
            'hubspot' => self::check_hubspot(),
            'teams' => self::check_teams(),
            'permissions' => self::check_permissions(),
            'php' => self::check_php_requirements()
        );
    }
    
    /**
     * Check Twilio connectivity
     */
    public static function check_twilio() {
        $result = array(
            'name' => 'Twilio',
            'status' => 'unknown',
            'message' => '',
            'details' => array()
        );
        
        if (!ptp_comms_is_twilio_configured()) {
            $result['status'] = 'warning';
            $result['message'] = 'Not configured';
            return $result;
        }
        
        $sid = ptp_comms_get_setting('twilio_account_sid');
        $token = ptp_comms_get_setting('twilio_auth_token');
        
        $response = wp_remote_get(
            "https://api.twilio.com/2010-04-01/Accounts/{$sid}.json",
            array(
                'headers' => array(
                    'Authorization' => 'Basic ' . base64_encode($sid . ':' . $token)
                ),
                'timeout' => 10
            )
        );
        
        if (is_wp_error($response)) {
            $result['status'] = 'error';
            $result['message'] = 'Connection failed: ' . $response->get_error_message();
            return $result;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code === 200) {
            $result['status'] = 'ok';
            $result['message'] = 'Connected';
            $result['details'] = array(
                'account_status' => $body['status'] ?? 'unknown',
                'friendly_name' => $body['friendly_name'] ?? '',
                'type' => $body['type'] ?? ''
            );
        } elseif ($code === 401) {
            $result['status'] = 'error';
            $result['message'] = 'Invalid credentials';
        } else {
            $result['status'] = 'error';
            $result['message'] = 'API error: ' . $code;
        }
        
        return $result;
    }
    
    /**
     * Check database tables
     */
    public static function check_database() {
        global $wpdb;
        
        $result = array(
            'name' => 'Database',
            'status' => 'ok',
            'message' => '',
            'details' => array()
        );
        
        $required_tables = array(
            'ptp_contacts',
            'ptp_registrations',
            'ptp_messages',
            'ptp_conversations',
            'ptp_campaigns',
            'ptp_communication_logs',
            'ptp_templates',
            'ptp_automations',
            'ptp_saved_segments',
            'ptp_contact_notes',
            'ptp_reminders',
            'ptp_canned_replies'
        );
        
        $missing = array();
        $counts = array();
        
        foreach ($required_tables as $table) {
            $full_name = $wpdb->prefix . $table;
            $exists = $wpdb->get_var("SHOW TABLES LIKE '{$full_name}'") === $full_name;
            
            if (!$exists) {
                $missing[] = $table;
            } else {
                $count = $wpdb->get_var("SELECT COUNT(*) FROM {$full_name}");
                $counts[$table] = (int) $count;
            }
        }
        
        if (!empty($missing)) {
            $result['status'] = 'error';
            $result['message'] = 'Missing tables: ' . implode(', ', $missing);
        } else {
            $result['message'] = 'All tables present';
        }
        
        $result['details'] = array(
            'tables_checked' => count($required_tables),
            'tables_missing' => count($missing),
            'record_counts' => $counts
        );
        
        return $result;
    }
    
    /**
     * Check webhook endpoints
     */
    public static function check_webhooks() {
        $result = array(
            'name' => 'Webhooks',
            'status' => 'ok',
            'message' => '',
            'details' => array()
        );
        
        $endpoints = array(
            'sms' => rest_url('ptp-comms/v1/incoming-sms'),
            'voice' => rest_url('ptp-comms/v1/incoming-call'),
            'status' => rest_url('ptp-comms/v1/sms-status')
        );
        
        $result['details']['endpoints'] = $endpoints;
        
        // Check if REST API is accessible
        $test_url = rest_url('ptp-comms/v1/');
        $response = wp_remote_get($test_url, array('timeout' => 5));
        
        if (is_wp_error($response)) {
            $result['status'] = 'warning';
            $result['message'] = 'REST API may not be accessible externally';
        } else {
            $result['message'] = 'Endpoints configured';
        }
        
        // Check for HTTPS
        if (strpos(home_url(), 'https://') !== 0) {
            $result['status'] = 'warning';
            $result['message'] = 'HTTPS recommended for webhooks';
        }
        
        return $result;
    }
    
    /**
     * Check WordPress cron
     */
    public static function check_cron() {
        $result = array(
            'name' => 'Scheduled Tasks',
            'status' => 'ok',
            'message' => '',
            'details' => array()
        );
        
        $scheduled_hooks = array(
            'ptp_comms_process_automations' => 'Automations',
            'ptp_comms_sync_hubspot' => 'HubSpot Sync',
            'ptp_comms_process_reminders' => 'Reminders',
            'ptp_comms_google_sheets_sync' => 'Google Sheets'
        );
        
        $scheduled = array();
        $missing = array();
        
        foreach ($scheduled_hooks as $hook => $name) {
            $next = wp_next_scheduled($hook);
            if ($next) {
                $scheduled[$name] = date('Y-m-d H:i:s', $next);
            } else {
                $missing[] = $name;
            }
        }
        
        $result['details'] = array(
            'scheduled' => $scheduled,
            'missing' => $missing
        );
        
        if (!empty($missing)) {
            $result['status'] = 'warning';
            $result['message'] = 'Some tasks not scheduled';
        } else {
            $result['message'] = 'All tasks scheduled';
        }
        
        // Check if cron is disabled
        if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) {
            $result['details']['cron_disabled'] = true;
            $result['message'] .= ' (WP Cron disabled - ensure server cron is configured)';
        }
        
        return $result;
    }
    
    /**
     * Check HubSpot connectivity
     */
    public static function check_hubspot() {
        $result = array(
            'name' => 'HubSpot',
            'status' => 'unknown',
            'message' => '',
            'details' => array()
        );
        
        if (!ptp_comms_is_hubspot_configured()) {
            $result['status'] = 'warning';
            $result['message'] = 'Not configured';
            return $result;
        }
        
        $api_key = ptp_comms_get_setting('hubspot_api_key');
        
        $response = wp_remote_get(
            'https://api.hubapi.com/crm/v3/objects/contacts?limit=1',
            array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $api_key
                ),
                'timeout' => 10
            )
        );
        
        if (is_wp_error($response)) {
            $result['status'] = 'error';
            $result['message'] = 'Connection failed';
            return $result;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        
        if ($code === 200) {
            $result['status'] = 'ok';
            $result['message'] = 'Connected';
        } elseif ($code === 401) {
            $result['status'] = 'error';
            $result['message'] = 'Invalid API key';
        } else {
            $result['status'] = 'error';
            $result['message'] = 'API error: ' . $code;
        }
        
        return $result;
    }
    
    /**
     * Check Microsoft Teams
     */
    public static function check_teams() {
        $result = array(
            'name' => 'Microsoft Teams',
            'status' => 'unknown',
            'message' => '',
            'details' => array()
        );
        
        if (!ptp_comms_is_teams_configured()) {
            $result['status'] = 'warning';
            $result['message'] = 'Not configured';
            return $result;
        }
        
        // Check which method is configured
        $bot_app_id = ptp_comms_get_setting('teams_bot_app_id');
        $webhook_url = ptp_comms_get_setting('teams_webhook_url');
        
        if (!empty($bot_app_id)) {
            $result['details']['method'] = 'Bot Framework';
            $result['status'] = 'ok';
            $result['message'] = 'Bot credentials configured';
        } elseif (!empty($webhook_url)) {
            $result['details']['method'] = 'Webhook';
            
            // Test webhook
            $test_response = wp_remote_post($webhook_url, array(
                'headers' => array('Content-Type' => 'application/json'),
                'body' => json_encode(array(
                    '@type' => 'MessageCard',
                    'summary' => 'Health Check',
                    'sections' => array(array('text' => 'PTP Comms Hub connectivity test'))
                )),
                'timeout' => 10
            ));
            
            if (is_wp_error($test_response)) {
                $result['status'] = 'error';
                $result['message'] = 'Webhook unreachable';
            } else {
                $code = wp_remote_retrieve_response_code($test_response);
                if ($code === 200) {
                    $result['status'] = 'ok';
                    $result['message'] = 'Webhook working';
                } else {
                    $result['status'] = 'warning';
                    $result['message'] = 'Webhook returned: ' . $code;
                }
            }
        }
        
        return $result;
    }
    
    /**
     * Check file permissions
     */
    public static function check_permissions() {
        $result = array(
            'name' => 'Permissions',
            'status' => 'ok',
            'message' => '',
            'details' => array()
        );
        
        $upload_dir = wp_upload_dir();
        $plugin_dir = PTP_COMMS_HUB_PATH;
        
        $checks = array(
            'upload_dir' => is_writable($upload_dir['basedir']),
            'plugin_readable' => is_readable($plugin_dir)
        );
        
        $result['details'] = $checks;
        
        if (!$checks['upload_dir']) {
            $result['status'] = 'error';
            $result['message'] = 'Upload directory not writable';
        } else {
            $result['message'] = 'All permissions OK';
        }
        
        return $result;
    }
    
    /**
     * Check PHP requirements
     */
    public static function check_php_requirements() {
        $result = array(
            'name' => 'PHP Environment',
            'status' => 'ok',
            'message' => '',
            'details' => array()
        );
        
        $php_version = phpversion();
        $required_version = '7.4';
        
        $result['details'] = array(
            'php_version' => $php_version,
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'curl_enabled' => function_exists('curl_init'),
            'json_enabled' => function_exists('json_encode'),
            'mbstring_enabled' => function_exists('mb_strlen')
        );
        
        if (version_compare($php_version, $required_version, '<')) {
            $result['status'] = 'error';
            $result['message'] = "PHP {$required_version}+ required";
        } elseif (!$result['details']['curl_enabled']) {
            $result['status'] = 'error';
            $result['message'] = 'cURL extension required';
        } else {
            $result['message'] = 'All requirements met';
        }
        
        return $result;
    }
    
    /**
     * Send test SMS
     */
    public static function send_test_sms($to) {
        if (!ptp_comms_is_twilio_configured()) {
            return array('success' => false, 'error' => 'Twilio not configured');
        }
        
        $normalized = ptp_comms_normalize_phone($to);
        if (!$normalized) {
            return array('success' => false, 'error' => 'Invalid phone number');
        }
        
        $sms_service = new PTP_Comms_Hub_SMS_Service();
        $result = $sms_service->send($normalized, 'PTP Comms Hub test message - ' . date('Y-m-d H:i:s'));
        
        ptp_comms_debug_log('Health Check', 'Test SMS sent to ' . $normalized, $result);
        
        return $result;
    }
    
    /**
     * Send test Teams message
     */
    public static function send_test_teams_message() {
        if (!ptp_comms_is_teams_configured()) {
            return array('success' => false, 'error' => 'Teams not configured');
        }
        
        $teams = new PTP_Comms_Hub_Teams_Integration();
        
        $card = array(
            '@type' => 'MessageCard',
            '@context' => 'http://schema.org/extensions',
            'themeColor' => 'FCB900',
            'summary' => 'PTP Comms Hub Test',
            'sections' => array(
                array(
                    'activityTitle' => '🧪 Health Check Test',
                    'activitySubtitle' => date('F j, Y g:i A'),
                    'text' => 'This is a test message from PTP Comms Hub to verify Teams connectivity.',
                    'facts' => array(
                        array('name' => 'Status', 'value' => 'Connected'),
                        array('name' => 'Site', 'value' => get_bloginfo('name'))
                    )
                )
            )
        );
        
        $result = $teams->send_card($card);
        
        ptp_comms_debug_log('Health Check', 'Test Teams message sent', $result);
        
        return $result;
    }
    
    /**
     * Get overall system status
     */
    public static function get_overall_status() {
        $checks = self::run_all_checks();
        
        $has_error = false;
        $has_warning = false;
        
        foreach ($checks as $check) {
            if ($check['status'] === 'error') {
                $has_error = true;
            }
            if ($check['status'] === 'warning') {
                $has_warning = true;
            }
        }
        
        if ($has_error) {
            return 'error';
        } elseif ($has_warning) {
            return 'warning';
        }
        
        return 'ok';
    }
    
    /**
     * Register REST routes
     */
    public static function register_rest_routes() {
        register_rest_route('ptp-comms/v1', '/health', array(
            'methods' => 'GET',
            'callback' => array(__CLASS__, 'rest_health_check'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/test-sms', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'rest_test_sms'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
        
        register_rest_route('ptp-comms/v1', '/test-teams', array(
            'methods' => 'POST',
            'callback' => array(__CLASS__, 'rest_test_teams'),
            'permission_callback' => function() {
                return current_user_can('manage_options');
            }
        ));
    }
    
    public static function rest_health_check($request) {
        return rest_ensure_response(array(
            'status' => self::get_overall_status(),
            'checks' => self::run_all_checks(),
            'timestamp' => current_time('mysql')
        ));
    }
    
    public static function rest_test_sms($request) {
        $to = $request->get_param('to');
        return rest_ensure_response(self::send_test_sms($to));
    }
    
    public static function rest_test_teams($request) {
        return rest_ensure_response(self::send_test_teams_message());
    }
}

// Register REST routes
add_action('rest_api_init', array('PTP_Comms_Hub_Health_Check', 'register_rest_routes'));
