# Browser Softphone Setup Guide

## Overview

The PTP Comms Hub now supports **browser-based calling** - you can answer and make calls directly from your WordPress dashboard without needing a separate phone. This uses Twilio's Client SDK to turn your browser into a softphone.

## How It Works

```
Caller → Twilio → Dashboard Softphone (Browser) → If no answer → Staff Phones → Voicemail
```

When enabled:
1. **Incoming calls ring in your browser first** (with desktop notifications)
2. You can **answer calls with one click** from the Calls page
3. If you don't answer, calls forward to mobile phone numbers
4. If no one answers, callers go to voicemail

## Quick Setup (Recommended)

### Step 1: Enable Browser Calling

1. Go to **PTP Comms Hub → Settings → Voice & IVR**
2. Find the blue "Browser Softphone" section
3. Check **"Enable Dashboard Softphone"**

### Step 2: Auto-Create Twilio Resources

Click these buttons in order:

1. **Create API Key** - Creates credentials for browser authentication
2. **Create TwiML App** - Creates the app that routes browser calls
3. **Save Settings** - Don't forget to save!
4. **Test Configuration** - Verify everything is working

### Step 3: Start Taking Calls

1. Go to **PTP Comms Hub → Calls**
2. You'll see the softphone panel at the top
3. Wait for status to show **"Ready"** (green indicator)
4. Keep this page open to receive calls

## Manual Setup (Advanced)

If auto-setup doesn't work, you can configure manually:

### Create API Key

1. Log into [Twilio Console](https://console.twilio.com)
2. Navigate to **Account → API Keys & Tokens → API Keys**
3. Click **Create API Key**
4. Choose **Standard** key type
5. Name it: `PTP Comms Hub Browser Client`
6. Copy the **SID** and **Secret** (secret only shown once!)
7. Paste into the settings page

### Create TwiML Application

1. Navigate to **Voice → Manage → TwiML Apps**
2. Click **Create new TwiML App**
3. Settings:
   - **Friendly Name**: `PTP Comms Hub Softphone`
   - **Voice URL**: `https://yoursite.com/wp-json/ptp-comms/v1/client-voice`
   - **Voice Method**: POST
   - **Status Callback URL**: `https://yoursite.com/wp-json/ptp-comms/v1/client-call-status`
4. Copy the **SID** and paste into settings

### Update Phone Number Webhook

Make sure your Twilio phone number's Voice webhook points to:
```
https://yoursite.com/wp-json/ptp-comms/v1/incoming-call
```

## Using the Softphone

### Receiving Calls

1. Keep the Calls page open in your browser
2. Allow browser notifications when prompted
3. When a call comes in:
   - You'll see an "Incoming Call" banner with caller info
   - Browser notification will appear
   - Click **Answer** to accept or **Decline** to reject

### Making Calls

1. Click **Dial Pad** to open the dialer
2. Enter the phone number
3. Click **Call**
4. Use **Mute** and **End Call** controls

### Call Controls

- **Mute** - Toggle microphone on/off
- **End Call** - Hang up
- **Dial Pad** - Send DTMF tones during call

## Priority Order

When browser calling is enabled, incoming calls are routed in this order:

1. **Browser Client** - If dashboard is open and logged in
2. **Staff Phones** - If browser doesn't answer within timeout
3. **Voicemail** - If no one answers

## Troubleshooting

### "Connecting..." stuck

- Check browser console for errors
- Verify API Key and TwiML App SID are correct
- Make sure Twilio account has sufficient balance

### No sound

- Check browser permissions for microphone
- Ensure headphones/speakers are working
- Try refreshing the page

### Calls not ringing in browser

- Verify **Browser Calling** is enabled in settings
- Make sure the Calls page is open
- Check that you're logged in as an admin

### "Error: Unable to get token"

- API Key or TwiML App may be misconfigured
- Run **Test Configuration** to check settings
- Verify all credentials are correct

## Browser Requirements

- **Chrome** (recommended) - version 60+
- **Firefox** - version 55+
- **Safari** - version 11+
- **Edge** - version 79+

WebRTC and microphone access required.

## Best Practices

1. **Use headphones** - Prevents echo and feedback
2. **Stable internet** - WebRTC needs good bandwidth
3. **Keep page open** - Close other tabs to save resources
4. **Desktop notifications** - Enable for call alerts
5. **Test regularly** - Make sure setup is still working

## Security Notes

- Access tokens expire after 1 hour and auto-refresh
- Only logged-in WordPress admins can use the softphone
- All calls are recorded (same as regular calls)
- Tokens are generated server-side, no credentials in browser

## Multiple Users

Currently, the first logged-in user to open the Calls page will receive incoming calls. Future updates will support:

- Multiple concurrent softphone users
- Round-robin or priority routing
- Transfer between browser users

## Support

If you have issues:
1. Check browser developer console for errors
2. Review WordPress error logs
3. Test with Twilio's debugger
4. Contact support with Call SID for investigation
