# Changelog - Version 4.1.0

## 🚀 Major New Features

### 📞 Browser Softphone (Twilio Client)
Answer and make calls directly from your WordPress dashboard!

- **Incoming Call Alerts** - Browser notifications when calls come in
- **One-Click Answer** - Accept calls without picking up a phone
- **Outbound Dialing** - Make calls using the built-in dial pad
- **Call Controls** - Mute, hangup, and send DTMF tones
- **Auto-Fallback** - If browser doesn't answer, rings staff phones
- **Full Recording** - All calls still recorded like before

**Setup:** Settings → Voice & IVR → Enable Dashboard Softphone

### 📊 Google Sheets Integration
Sync your data to Google Sheets for reporting and analysis.

- **Export All Data** - Contacts, registrations, messages, campaigns
- **Import Contacts** - Add/update contacts from spreadsheet
- **Auto-Sync** - Daily automatic exports
- **4 Organized Sheets** - Clean data structure

**Setup:** Settings → Google Sheets → Connect to Google

### 🔧 Debug & Diagnostics Panel
New tools for troubleshooting and monitoring.

- **Debug Mode Toggle** - Off / Basic / Verbose logging
- **System Information** - PHP, WordPress, plugin versions
- **Database Statistics** - Record counts at a glance
- **Live Debug Logs** - View recent activity in UI
- **Quick Actions** - Test connections, flush caches

**Location:** Settings → Debug

## 🔨 Technical Improvements

### Debug Logging System
- New `ptp_comms_debug_log()` function with toggle
- Respects debug mode setting
- Verbose mode stores logs in database
- Automatic cleanup (keeps last 500 entries)
- Performance timer helpers for optimization

### New REST API Endpoints
```
GET  /wp-json/ptp-comms/v1/client-token      - Get Twilio Client access token
POST /wp-json/ptp-comms/v1/client-voice      - Handle browser voice requests  
POST /wp-json/ptp-comms/v1/client-register   - Register browser as active
POST /wp-json/ptp-comms/v1/client-unregister - Unregister browser
GET  /wp-json/ptp-comms/v1/active-calls      - Get current active calls
POST /wp-json/ptp-comms/v1/setup-client      - Auto-setup Twilio Client

POST /wp-json/ptp-comms/v1/google-sheets/export  - Export to sheets
POST /wp-json/ptp-comms/v1/google-sheets/import  - Import from sheets
POST /wp-json/ptp-comms/v1/google-sheets/create  - Create new spreadsheet
GET  /wp-json/ptp-comms/v1/google-sheets/test    - Test connection
```

### New Database Table
- `ptp_debug_log` - Stores verbose debug entries

### New Settings
| Setting | Description |
|---------|-------------|
| `ivr_browser_client_enabled` | Enable browser softphone |
| `twilio_api_key_sid` | Twilio API Key for Client SDK |
| `twilio_api_key_secret` | API Key Secret |
| `twilio_twiml_app_sid` | TwiML Application SID |
| `google_client_id` | Google OAuth Client ID |
| `google_client_secret` | Google OAuth Client Secret |
| `google_spreadsheet_id` | Target spreadsheet ID |
| `google_sheets_auto_sync` | Enable auto daily sync |

## 📁 New Files

```
includes/class-twilio-client.php     - Browser softphone service
includes/class-google-sheets.php     - Google Sheets integration
BROWSER-SOFTPHONE-GUIDE.md           - Browser calling setup guide
GOOGLE-SHEETS-GUIDE.md               - Google Sheets setup guide
CHANGELOG-V4.1.0.md                   - This file
```

## 🔄 Modified Files

- `includes/class-loader.php` - Load new classes
- `includes/class-voice-service.php` - Priority routing to browser client
- `includes/class-rest-api.php` - New endpoints for browser/sheets
- `includes/class-activator.php` - Debug log table creation
- `includes/helpers.php` - Debug logging functions
- `admin/class-admin-page-calls.php` - Softphone UI
- `admin/class-admin-page-settings.php` - New settings tabs
- `ptp-comms-hub.php` - AJAX handlers for debug functions

## 📋 Call Routing Priority (Updated)

When browser calling is enabled:

```
1. Browser Client (if open and logged in)
   ↓ no answer
2. Staff Mobile Phones (ring all simultaneously)
   ↓ no answer
3. IVR Menu or Voicemail (based on settings)
```

## 🛠 Setup Checklist

### Browser Softphone
1. [ ] Enable in Settings → Voice & IVR
2. [ ] Click "Create API Key" button
3. [ ] Click "Create TwiML App" button  
4. [ ] Save settings
5. [ ] Go to Calls page - wait for "Ready" status
6. [ ] Test with incoming call

### Google Sheets
1. [ ] Create Google Cloud project
2. [ ] Enable Sheets API
3. [ ] Create OAuth credentials
4. [ ] Add redirect URI to Google
5. [ ] Enter credentials in WordPress
6. [ ] Click "Connect to Google"
7. [ ] Click "Export All Data"

### Debug Mode
1. [ ] Go to Settings → Debug
2. [ ] Select debug level
3. [ ] Save
4. [ ] View logs in Debug tab

## ⚡ Performance Notes

- Browser softphone uses WebRTC (low bandwidth)
- Access tokens expire hourly (auto-refresh)
- Google Sheets API has rate limits (handled automatically)
- Debug logging adds minimal overhead when off
- Verbose logging stores to database (auto-cleanup)

## 🐛 Known Issues

- Browser softphone requires HTTPS
- Safari may require user interaction for audio
- Google Sheets export limited by API quotas
- Multiple simultaneous browser users not yet supported

## 📚 Documentation

- [Browser Softphone Guide](BROWSER-SOFTPHONE-GUIDE.md)
- [Google Sheets Guide](GOOGLE-SHEETS-GUIDE.md)
- [IVR Voice Setup](IVR-VOICE-SETUP.md)
- [Complete Guide](README-COMPLETE-GUIDE.md)
