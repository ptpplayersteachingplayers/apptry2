<?php
/**
 * Calls admin page - Voice call management with recording playback
 * Enhanced with browser-based softphone (Twilio Client)
 * Version: 2.0.0
 */
class PTP_Comms_Hub_Admin_Page_Calls {
    
    public static function render() {
        global $wpdb;
        
        // Handle make call action
        if (isset($_POST['ptp_make_call']) && wp_verify_nonce($_POST['_wpnonce'], 'ptp_make_call')) {
            self::handle_make_call();
        }
        
        // Handle view single call details
        if (isset($_GET['view_call'])) {
            self::render_call_details(intval($_GET['view_call']));
            return;
        }
        
        // Get filter parameters
        $filter_status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        $filter_direction = isset($_GET['direction']) ? sanitize_text_field($_GET['direction']) : '';
        $filter_date_from = isset($_GET['date_from']) ? sanitize_text_field($_GET['date_from']) : '';
        $filter_date_to = isset($_GET['date_to']) ? sanitize_text_field($_GET['date_to']) : '';
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // Build query for calls
        $where_clauses = array("l.message_type IN ('voice', 'voicemail')");
        
        if ($filter_status) {
            $where_clauses[] = $wpdb->prepare("l.status = %s", $filter_status);
        }
        if ($filter_direction) {
            $where_clauses[] = $wpdb->prepare("l.direction = %s", $filter_direction);
        }
        if ($filter_date_from) {
            $where_clauses[] = $wpdb->prepare("DATE(l.created_at) >= %s", $filter_date_from);
        }
        if ($filter_date_to) {
            $where_clauses[] = $wpdb->prepare("DATE(l.created_at) <= %s", $filter_date_to);
        }
        if ($search) {
            $search_like = '%' . $wpdb->esc_like($search) . '%';
            $where_clauses[] = $wpdb->prepare(
                "(c.parent_first_name LIKE %s OR c.parent_last_name LIKE %s OR c.parent_phone LIKE %s)",
                $search_like, $search_like, $search_like
            );
        }
        
        $where_sql = implode(' AND ', $where_clauses);
        
        // Get call logs
        $calls = $wpdb->get_results("
            SELECT l.*, 
                   c.parent_first_name, 
                   c.parent_last_name, 
                   c.parent_phone,
                   c.parent_email,
                   c.id as contact_id
            FROM {$wpdb->prefix}ptp_communication_logs l
            LEFT JOIN {$wpdb->prefix}ptp_contacts c ON l.contact_id = c.id
            WHERE {$where_sql}
            ORDER BY l.created_at DESC
            LIMIT 100
        ");
        
        // Get statistics
        $total_calls = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_communication_logs WHERE message_type = 'voice'");
        $completed_calls = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_communication_logs WHERE message_type = 'voice' AND status = 'completed'");
        $voicemails = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_communication_logs WHERE message_type = 'voicemail'");
        $calls_today = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_communication_logs WHERE message_type IN ('voice', 'voicemail') AND DATE(created_at) = CURDATE()");
        $recordings_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ptp_communication_logs WHERE message_type IN ('voice', 'voicemail') AND meta_data LIKE '%recording_url%'");
        
        // Check if voice is configured
        $voice_service = new PTP_Comms_Hub_Voice_Service();
        $voice_configured = $voice_service->is_configured();
        
        // Check if Twilio Client (browser calling) is configured
        $browser_client_enabled = ptp_comms_get_setting('ivr_browser_client_enabled', 'no') === 'yes';
        $twilio_client_configured = false;
        
        if ($browser_client_enabled && class_exists('PTP_Comms_Hub_Twilio_Client')) {
            $twilio_client = new PTP_Comms_Hub_Twilio_Client();
            $twilio_client_configured = $twilio_client->is_configured();
        } elseif ($browser_client_enabled) {
            require_once PTP_COMMS_HUB_PATH . 'includes/class-twilio-client.php';
            $twilio_client = new PTP_Comms_Hub_Twilio_Client();
            $twilio_client_configured = $twilio_client->is_configured();
        }
        
        ?>
        <div class="wrap ptp-comms-admin">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
                <div>
                    <h1 style="display: flex; align-items: center; gap: 12px; margin: 0;">
                        <span style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); padding: 12px; border-radius: 12px;">
                            <span class="dashicons dashicons-phone" style="font-size: 28px; width: 28px; height: 28px; color: #FCD116;"></span>
                        </span>
                        <?php _e('Voice Calls & Recordings', 'ptp-comms-hub'); ?>
                    </h1>
                    <p style="color: #666; margin: 8px 0 0 0;"><?php _e('Manage inbound/outbound calls, voicemails, and recordings', 'ptp-comms-hub'); ?></p>
                </div>
                
                <?php if ($voice_configured): ?>
                <button type="button" id="ptp-make-call-btn" class="button button-primary" 
                        style="background: linear-gradient(135deg, #FCD116 0%, #e5bc00 100%); border: none; color: #1a1a1a; padding: 12px 24px; font-size: 14px; font-weight: 600; border-radius: 8px; height: auto; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-phone" style="font-size: 18px;"></span>
                    <?php _e('Make a Call', 'ptp-comms-hub'); ?>
                </button>
                <?php endif; ?>
            </div>
            
            <?php if (!$voice_configured): ?>
            <div class="ptp-card" style="background: linear-gradient(135deg, #fff5f5 0%, #fff 100%); border-left: 4px solid #dc3232;">
                <h3 style="margin-top: 0; color: #dc3232;">⚠️ Voice Not Configured</h3>
                <p>To enable voice calling and IVR, you need to configure your Twilio credentials.</p>
                <a href="<?php echo admin_url('admin.php?page=ptp-comms-settings'); ?>" class="button button-primary">
                    Configure Twilio Settings
                </a>
            </div>
            <?php endif; ?>
            
            <!-- Statistics Cards -->
            <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px;">
                <div class="ptp-card" style="text-align: center; background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); color: #fff;">
                    <div style="font-size: 36px; font-weight: 700; color: #FCD116; margin-bottom: 4px;">
                        <?php echo number_format($total_calls ?: 0); ?>
                    </div>
                    <div style="color: #aaa; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">
                        <?php _e('Total Calls', 'ptp-comms-hub'); ?>
                    </div>
                </div>
                
                <div class="ptp-card" style="text-align: center;">
                    <div style="font-size: 36px; font-weight: 700; color: #46b450; margin-bottom: 4px;">
                        <?php echo number_format($completed_calls ?: 0); ?>
                    </div>
                    <div style="color: #666; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">
                        <?php _e('Completed', 'ptp-comms-hub'); ?>
                    </div>
                </div>
                
                <div class="ptp-card" style="text-align: center;">
                    <div style="font-size: 36px; font-weight: 700; color: #0073aa; margin-bottom: 4px;">
                        <?php echo number_format($voicemails ?: 0); ?>
                    </div>
                    <div style="color: #666; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">
                        <?php _e('Voicemails', 'ptp-comms-hub'); ?>
                    </div>
                </div>
                
                <div class="ptp-card" style="text-align: center;">
                    <div style="font-size: 36px; font-weight: 700; color: #826eb4; margin-bottom: 4px;">
                        <?php echo number_format($recordings_count ?: 0); ?>
                    </div>
                    <div style="color: #666; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">
                        <?php _e('Recordings', 'ptp-comms-hub'); ?>
                    </div>
                </div>
                
                <div class="ptp-card" style="text-align: center;">
                    <div style="font-size: 36px; font-weight: 700; color: #f56e28; margin-bottom: 4px;">
                        <?php echo number_format($calls_today ?: 0); ?>
                    </div>
                    <div style="color: #666; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">
                        <?php _e('Today', 'ptp-comms-hub'); ?>
                    </div>
                </div>
            </div>
            
            <?php if ($browser_client_enabled && $twilio_client_configured): ?>
            <!-- Browser Softphone Panel -->
            <div class="ptp-card" id="ptp-softphone-panel" style="margin-bottom: 24px; background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); color: #fff;">
                <div style="display: flex; align-items: center; justify-content: space-between;">
                    <div style="display: flex; align-items: center; gap: 16px;">
                        <div id="ptp-softphone-status" style="display: flex; align-items: center; gap: 8px;">
                            <div id="ptp-status-indicator" style="width: 12px; height: 12px; border-radius: 50%; background: #666; transition: background 0.3s;"></div>
                            <span id="ptp-status-text" style="font-size: 14px; color: #aaa;">Connecting...</span>
                        </div>
                        <div id="ptp-call-duration" style="display: none; font-family: monospace; font-size: 18px; color: #FCD116;">
                            00:00
                        </div>
                    </div>
                    
                    <div id="ptp-softphone-controls" style="display: flex; align-items: center; gap: 12px;">
                        <!-- Dialer Toggle -->
                        <button type="button" id="ptp-toggle-dialer" class="button" style="background: #333; border-color: #444; color: #fff; padding: 8px 16px; border-radius: 8px;">
                            <span class="dashicons dashicons-phone" style="font-size: 16px; margin-top: 3px;"></span>
                            Dial Pad
                        </button>
                        
                        <!-- Call Controls (hidden until in call) -->
                        <div id="ptp-in-call-controls" style="display: none; gap: 8px;">
                            <button type="button" id="ptp-mute-btn" class="button" style="background: #333; border-color: #444; color: #fff; padding: 8px 12px; border-radius: 8px;" title="Mute">
                                <span class="dashicons dashicons-controls-volumeon" style="font-size: 18px;"></span>
                            </button>
                            <button type="button" id="ptp-hangup-btn" class="button" style="background: #dc3232; border-color: #dc3232; color: #fff; padding: 8px 20px; border-radius: 8px;">
                                <span class="dashicons dashicons-phone" style="font-size: 18px; transform: rotate(135deg); display: inline-block;"></span>
                                End Call
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Incoming Call UI (hidden until call comes in) -->
                <div id="ptp-incoming-call" style="display: none; margin-top: 20px; padding: 20px; background: rgba(70, 180, 80, 0.2); border-radius: 12px; text-align: center;">
                    <div style="font-size: 14px; color: #46b450; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px;">Incoming Call</div>
                    <div id="ptp-incoming-caller" style="font-size: 24px; font-weight: 700; margin-bottom: 4px;">Unknown Caller</div>
                    <div id="ptp-incoming-number" style="font-size: 16px; color: #aaa; margin-bottom: 20px;"></div>
                    <div style="display: flex; justify-content: center; gap: 16px;">
                        <button type="button" id="ptp-answer-btn" style="background: linear-gradient(135deg, #46b450 0%, #3a9142 100%); border: none; color: #fff; padding: 16px 32px; border-radius: 50px; cursor: pointer; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span class="dashicons dashicons-phone" style="font-size: 20px;"></span>
                            Answer
                        </button>
                        <button type="button" id="ptp-reject-btn" style="background: linear-gradient(135deg, #dc3232 0%, #b52727 100%); border: none; color: #fff; padding: 16px 32px; border-radius: 50px; cursor: pointer; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                            <span class="dashicons dashicons-phone" style="font-size: 20px; transform: rotate(135deg);"></span>
                            Decline
                        </button>
                    </div>
                </div>
                
                <!-- Active Call UI (hidden until call connected) -->
                <div id="ptp-active-call" style="display: none; margin-top: 20px; padding: 20px; background: rgba(252, 209, 22, 0.1); border-radius: 12px; text-align: center;">
                    <div style="font-size: 14px; color: #FCD116; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 8px;">
                        <span id="ptp-call-direction-label">On Call</span>
                    </div>
                    <div id="ptp-active-caller" style="font-size: 24px; font-weight: 700; margin-bottom: 4px;"></div>
                    <div id="ptp-active-number" style="font-size: 16px; color: #aaa;"></div>
                </div>
                
                <!-- Dialer Panel (hidden by default) -->
                <div id="ptp-dialer" style="display: none; margin-top: 20px; padding: 20px; background: rgba(255,255,255,0.05); border-radius: 12px;">
                    <input type="tel" id="ptp-dial-number" placeholder="Enter phone number" 
                           style="width: 100%; padding: 16px; font-size: 20px; text-align: center; background: #333; border: 2px solid #444; border-radius: 10px; color: #fff; margin-bottom: 16px; font-family: monospace;">
                    
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; max-width: 280px; margin: 0 auto 16px;">
                        <?php for ($i = 1; $i <= 9; $i++): ?>
                        <button type="button" class="ptp-dial-digit" data-digit="<?php echo $i; ?>" 
                                style="padding: 16px; font-size: 24px; background: #333; border: 1px solid #444; border-radius: 10px; color: #fff; cursor: pointer; transition: all 0.2s;">
                            <?php echo $i; ?>
                        </button>
                        <?php endfor; ?>
                        <button type="button" class="ptp-dial-digit" data-digit="*" 
                                style="padding: 16px; font-size: 24px; background: #333; border: 1px solid #444; border-radius: 10px; color: #fff; cursor: pointer;">*</button>
                        <button type="button" class="ptp-dial-digit" data-digit="0" 
                                style="padding: 16px; font-size: 24px; background: #333; border: 1px solid #444; border-radius: 10px; color: #fff; cursor: pointer;">0</button>
                        <button type="button" class="ptp-dial-digit" data-digit="#" 
                                style="padding: 16px; font-size: 24px; background: #333; border: 1px solid #444; border-radius: 10px; color: #fff; cursor: pointer;">#</button>
                    </div>
                    
                    <div style="display: flex; justify-content: center; gap: 12px;">
                        <button type="button" id="ptp-dial-backspace" style="padding: 12px 24px; background: #444; border: none; border-radius: 8px; color: #fff; cursor: pointer;">
                            <span class="dashicons dashicons-arrow-left-alt" style="font-size: 18px;"></span>
                        </button>
                        <button type="button" id="ptp-dial-call" style="padding: 12px 48px; background: linear-gradient(135deg, #46b450 0%, #3a9142 100%); border: none; border-radius: 50px; color: #fff; cursor: pointer; font-size: 16px; font-weight: 600;">
                            <span class="dashicons dashicons-phone" style="font-size: 18px; margin-right: 4px;"></span>
                            Call
                        </button>
                    </div>
                </div>
            </div>
            <?php elseif ($browser_client_enabled && !$twilio_client_configured): ?>
            <!-- Browser Client Not Configured Notice -->
            <div class="ptp-card" style="margin-bottom: 24px; background: linear-gradient(135deg, #fff5f5 0%, #fff 100%); border-left: 4px solid #f56e28;">
                <h3 style="margin-top: 0; color: #f56e28;">📞 Browser Calling Setup Required</h3>
                <p>Browser-based calling is enabled but not fully configured. You need to set up:</p>
                <ol>
                    <li><strong>API Key</strong> - For generating access tokens</li>
                    <li><strong>TwiML App</strong> - For routing browser calls</li>
                </ol>
                <a href="<?php echo admin_url('admin.php?page=ptp-comms-settings&tab=voice-ivr'); ?>" class="button button-primary">
                    Complete Setup
                </a>
            </div>
            <?php endif; ?>
            
            <!-- Filters -->
            <div class="ptp-card" style="margin-bottom: 24px;">
                <form method="get" action="" style="display: flex; gap: 12px; align-items: end; flex-wrap: wrap;">
                    <input type="hidden" name="page" value="ptp-comms-calls" />
                    
                    <div style="flex: 1; min-width: 200px;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px;">
                            <?php _e('Search', 'ptp-comms-hub'); ?>
                        </label>
                        <input type="text" name="s" value="<?php echo esc_attr($search); ?>" 
                               placeholder="Name or phone..." 
                               style="width: 100%; padding: 10px 14px; border: 1px solid #ddd; border-radius: 8px;" />
                    </div>
                    
                    <div style="min-width: 140px;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px;">
                            <?php _e('Direction', 'ptp-comms-hub'); ?>
                        </label>
                        <select name="direction" style="width: 100%; padding: 10px 14px; border: 1px solid #ddd; border-radius: 8px;">
                            <option value=""><?php _e('All', 'ptp-comms-hub'); ?></option>
                            <option value="inbound" <?php selected($filter_direction, 'inbound'); ?>>📥 Inbound</option>
                            <option value="outbound" <?php selected($filter_direction, 'outbound'); ?>>📤 Outbound</option>
                        </select>
                    </div>
                    
                    <div style="min-width: 140px;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px;">
                            <?php _e('Status', 'ptp-comms-hub'); ?>
                        </label>
                        <select name="status" style="width: 100%; padding: 10px 14px; border: 1px solid #ddd; border-radius: 8px;">
                            <option value=""><?php _e('All Statuses', 'ptp-comms-hub'); ?></option>
                            <option value="completed" <?php selected($filter_status, 'completed'); ?>>✓ Completed</option>
                            <option value="busy" <?php selected($filter_status, 'busy'); ?>>Busy</option>
                            <option value="no-answer" <?php selected($filter_status, 'no-answer'); ?>>No Answer</option>
                            <option value="failed" <?php selected($filter_status, 'failed'); ?>>Failed</option>
                            <option value="new" <?php selected($filter_status, 'new'); ?>>New</option>
                        </select>
                    </div>
                    
                    <div style="min-width: 140px;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px;">
                            <?php _e('From Date', 'ptp-comms-hub'); ?>
                        </label>
                        <input type="date" name="date_from" value="<?php echo esc_attr($filter_date_from); ?>" 
                               style="width: 100%; padding: 10px 14px; border: 1px solid #ddd; border-radius: 8px;" />
                    </div>
                    
                    <div style="min-width: 140px;">
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px;">
                            <?php _e('To Date', 'ptp-comms-hub'); ?>
                        </label>
                        <input type="date" name="date_to" value="<?php echo esc_attr($filter_date_to); ?>" 
                               style="width: 100%; padding: 10px 14px; border: 1px solid #ddd; border-radius: 8px;" />
                    </div>
                    
                    <div style="display: flex; gap: 8px;">
                        <button type="submit" class="button" style="padding: 10px 20px; height: auto; border-radius: 8px;">
                            <span class="dashicons dashicons-search" style="margin-top: 3px;"></span> Filter
                        </button>
                        <a href="?page=ptp-comms-calls" class="button" style="padding: 10px 16px; height: auto; border-radius: 8px;">
                            Reset
                        </a>
                    </div>
                </form>
            </div>
            
            <!-- Call List -->
            <div class="ptp-card" style="padding: 0; overflow: hidden;">
                <?php if (empty($calls)): ?>
                    <div style="text-align: center; padding: 80px 20px; color: #666;">
                        <div style="background: #f5f5f5; width: 80px; height: 80px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 20px;">
                            <span class="dashicons dashicons-phone" style="font-size: 40px; color: #ccc;"></span>
                        </div>
                        <h3 style="margin: 0 0 8px 0; color: #333;"><?php _e('No calls found', 'ptp-comms-hub'); ?></h3>
                        <p style="margin: 0; max-width: 400px; margin: 0 auto;"><?php _e('Calls will appear here once you make or receive voice calls through your Twilio number.', 'ptp-comms-hub'); ?></p>
                    </div>
                <?php else: ?>
                    <div class="ptp-calls-list">
                        <?php foreach ($calls as $call): 
                            $call_data = json_decode($call->meta_data, true) ?: array();
                            $duration = isset($call_data['duration']) ? intval($call_data['duration']) : 0;
                            $recording_url = isset($call_data['recording_url']) ? $call_data['recording_url'] : '';
                            $call_sid = isset($call_data['call_sid']) ? $call_data['call_sid'] : '';
                            $is_voicemail = $call->message_type === 'voicemail';
                            $contact_name = trim($call->parent_first_name . ' ' . $call->parent_last_name);
                            if (empty($contact_name)) $contact_name = 'Unknown';
                        ?>
                            <div class="ptp-call-row" style="display: flex; align-items: center; padding: 16px 20px; border-bottom: 1px solid #eee; gap: 16px; transition: background 0.2s;" 
                                 onmouseover="this.style.background='#fafafa'" onmouseout="this.style.background='transparent'">
                                
                                <!-- Icon -->
                                <div style="width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0;
                                    <?php if ($is_voicemail): ?>
                                        background: linear-gradient(135deg, #0073aa 0%, #005a87 100%);
                                    <?php elseif ($call->status === 'completed'): ?>
                                        background: linear-gradient(135deg, #46b450 0%, #3a9142 100%);
                                    <?php elseif ($call->status === 'failed' || $call->status === 'no-answer'): ?>
                                        background: linear-gradient(135deg, #dc3232 0%, #b52727 100%);
                                    <?php else: ?>
                                        background: linear-gradient(135deg, #666 0%, #444 100%);
                                    <?php endif; ?>
                                ">
                                    <?php if ($is_voicemail): ?>
                                        <span class="dashicons dashicons-format-audio" style="color: #fff; font-size: 20px;"></span>
                                    <?php elseif ($call->direction === 'inbound'): ?>
                                        <span class="dashicons dashicons-arrow-down-alt" style="color: #fff; font-size: 20px;"></span>
                                    <?php else: ?>
                                        <span class="dashicons dashicons-arrow-up-alt" style="color: #fff; font-size: 20px;"></span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Contact Info -->
                                <div style="flex: 1; min-width: 0;">
                                    <div style="font-weight: 600; font-size: 15px; color: #1a1a1a; margin-bottom: 2px;">
                                        <?php echo esc_html($contact_name); ?>
                                        <?php if ($is_voicemail): ?>
                                            <span style="background: #0073aa; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 10px; margin-left: 8px; font-weight: 500;">VOICEMAIL</span>
                                        <?php endif; ?>
                                    </div>
                                    <div style="font-size: 13px; color: #666;">
                                        <?php echo esc_html(function_exists('ptp_comms_format_phone') ? ptp_comms_format_phone($call->parent_phone) : $call->parent_phone); ?>
                                        <span style="margin: 0 6px; color: #ddd;">•</span>
                                        <?php if ($call->direction === 'inbound'): ?>
                                            <span style="color: #46b450;">Inbound</span>
                                        <?php else: ?>
                                            <span style="color: #f56e28;">Outbound</span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <!-- Duration & Status -->
                                <div style="text-align: center; min-width: 100px;">
                                    <?php if ($duration > 0): ?>
                                        <div style="font-size: 18px; font-weight: 600; color: #1a1a1a;">
                                            <?php echo gmdate('i:s', $duration); ?>
                                        </div>
                                        <div style="font-size: 11px; color: #999; text-transform: uppercase;">duration</div>
                                    <?php else: ?>
                                        <?php echo self::get_status_badge($call->status); ?>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Recording Player -->
                                <div style="min-width: 200px;">
                                    <?php if ($recording_url): ?>
                                        <div class="ptp-inline-player" style="display: flex; align-items: center; gap: 8px; background: #f5f5f5; padding: 8px 12px; border-radius: 24px;">
                                            <button type="button" class="ptp-play-btn" data-url="<?php echo esc_attr($recording_url); ?>"
                                                    style="width: 32px; height: 32px; border-radius: 50%; border: none; background: #FCD116; cursor: pointer; display: flex; align-items: center; justify-content: center;">
                                                <span class="dashicons dashicons-controls-play" style="font-size: 16px; color: #1a1a1a; margin-left: 2px;"></span>
                                            </button>
                                            <div class="ptp-audio-progress" style="flex: 1; height: 4px; background: #ddd; border-radius: 2px; overflow: hidden;">
                                                <div class="ptp-audio-progress-bar" style="width: 0%; height: 100%; background: #FCD116; transition: width 0.1s;"></div>
                                            </div>
                                            <a href="<?php echo esc_attr($recording_url); ?>" download style="color: #666; text-decoration: none;" title="Download">
                                                <span class="dashicons dashicons-download" style="font-size: 16px;"></span>
                                            </a>
                                        </div>
                                    <?php else: ?>
                                        <span style="color: #ccc; font-size: 12px;">No recording</span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Time -->
                                <div style="text-align: right; min-width: 100px; color: #666; font-size: 13px;">
                                    <?php 
                                    $call_time = strtotime($call->created_at);
                                    $today = strtotime('today');
                                    $yesterday = strtotime('yesterday');
                                    
                                    if ($call_time >= $today) {
                                        echo 'Today ' . date('g:i A', $call_time);
                                    } elseif ($call_time >= $yesterday) {
                                        echo 'Yesterday ' . date('g:i A', $call_time);
                                    } else {
                                        echo date('M j', $call_time) . '<br><small>' . date('g:i A', $call_time) . '</small>';
                                    }
                                    ?>
                                </div>
                                
                                <!-- Actions -->
                                <div style="display: flex; gap: 8px;">
                                    <?php if ($call->parent_phone): ?>
                                    <a href="tel:<?php echo esc_attr($call->parent_phone); ?>" 
                                       class="button button-small" title="Call back"
                                       style="border-radius: 6px; padding: 4px 10px;">
                                        <span class="dashicons dashicons-phone" style="font-size: 14px; margin-top: 3px;"></span>
                                    </a>
                                    <?php endif; ?>
                                    <a href="?page=ptp-comms-calls&view_call=<?php echo $call->id; ?>" 
                                       class="button button-small" title="View details"
                                       style="border-radius: 6px; padding: 4px 10px;">
                                        <span class="dashicons dashicons-visibility" style="font-size: 14px; margin-top: 3px;"></span>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Twilio Webhook Info -->
            <?php if ($voice_configured): ?>
            <div class="ptp-card" style="margin-top: 24px; background: linear-gradient(135deg, #f8f9fa 0%, #fff 100%);">
                <h3 style="margin-top: 0; display: flex; align-items: center; gap: 8px;">
                    <span class="dashicons dashicons-admin-settings" style="color: #666;"></span>
                    Twilio Webhook Configuration
                </h3>
                <p style="color: #666; margin-bottom: 16px;">Configure these URLs in your Twilio phone number settings to enable inbound calls and IVR:</p>
                
                <div style="display: grid; gap: 12px;">
                    <div>
                        <label style="font-weight: 500; font-size: 13px; display: block; margin-bottom: 4px;">Voice Webhook URL (for incoming calls):</label>
                        <code style="display: block; padding: 12px; background: #1a1a1a; color: #FCD116; border-radius: 6px; font-size: 12px; word-break: break-all;">
                            <?php echo esc_url(get_rest_url(null, 'ptp-comms/v1/incoming-call')); ?>
                        </code>
                    </div>
                    <div>
                        <label style="font-weight: 500; font-size: 13px; display: block; margin-bottom: 4px;">Status Callback URL:</label>
                        <code style="display: block; padding: 12px; background: #1a1a1a; color: #FCD116; border-radius: 6px; font-size: 12px; word-break: break-all;">
                            <?php echo esc_url(get_rest_url(null, 'ptp-comms/v1/call-status')); ?>
                        </code>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Make Call Modal -->
        <div id="ptp-make-call-modal" class="ptp-modal" style="display: none;">
            <div class="ptp-modal-content" style="max-width: 450px; padding: 0; border-radius: 16px; overflow: hidden;">
                <div style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); padding: 24px; color: #fff;">
                    <h2 style="margin: 0; display: flex; align-items: center; gap: 12px;">
                        <span class="dashicons dashicons-phone" style="color: #FCD116;"></span>
                        Make a Call
                    </h2>
                </div>
                
                <form method="post" action="" style="padding: 24px;">
                    <?php wp_nonce_field('ptp_make_call'); ?>
                    <input type="hidden" name="ptp_make_call" value="1" />
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 500;">Phone Number</label>
                        <input type="tel" name="call_to" required placeholder="+1 (555) 123-4567"
                               style="width: 100%; padding: 14px; border: 2px solid #ddd; border-radius: 10px; font-size: 16px;" />
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: block; margin-bottom: 8px; font-weight: 500;">Message (Text-to-Speech)</label>
                        <textarea name="call_message" rows="3" placeholder="Hello, this is PTP Soccer Camps calling..."
                                  style="width: 100%; padding: 14px; border: 2px solid #ddd; border-radius: 10px; font-size: 14px; resize: vertical;"></textarea>
                        <small style="color: #666;">Leave blank for IVR call (caller hears menu)</small>
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input type="checkbox" name="record_call" value="1" checked style="width: 18px; height: 18px;" />
                            <span>Record this call</span>
                        </label>
                    </div>
                    
                    <div style="display: flex; gap: 12px;">
                        <button type="button" class="button ptp-modal-close" style="flex: 1; padding: 14px; border-radius: 10px;">
                            Cancel
                        </button>
                        <button type="submit" class="button button-primary" style="flex: 1; padding: 14px; border-radius: 10px; background: #FCD116; border-color: #FCD116; color: #1a1a1a; font-weight: 600;">
                            <span class="dashicons dashicons-phone" style="margin-top: 3px;"></span> Call Now
                        </button>
                    </div>
                </form>
            </div>
        </div>
        
        <!-- Hidden Audio Element -->
        <audio id="ptp-global-audio" style="display: none;"></audio>
        
        <style>
        .ptp-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.6);
            z-index: 999999;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .ptp-modal-content {
            background: #fff;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .ptp-play-btn.playing .dashicons:before {
            content: "\f523"; /* pause icon */
        }
        .ptp-call-row:first-child {
            border-top: none;
        }
        .ptp-dial-digit:hover {
            background: #444 !important;
            transform: scale(1.05);
        }
        .ptp-dial-digit:active {
            background: #FCD116 !important;
            color: #1a1a1a !important;
        }
        @keyframes pulse-ring {
            0% { box-shadow: 0 0 0 0 rgba(70, 180, 80, 0.7); }
            70% { box-shadow: 0 0 0 20px rgba(70, 180, 80, 0); }
            100% { box-shadow: 0 0 0 0 rgba(70, 180, 80, 0); }
        }
        .ptp-ringing {
            animation: pulse-ring 1.5s infinite;
        }
        #ptp-status-indicator.connected {
            background: #46b450 !important;
        }
        #ptp-status-indicator.error {
            background: #dc3232 !important;
        }
        #ptp-status-indicator.ringing {
            background: #FCD116 !important;
            animation: pulse-ring 1s infinite;
        }
        </style>
        
        <?php if ($browser_client_enabled && $twilio_client_configured): ?>
        <!-- Twilio Client SDK -->
        <script src="https://sdk.twilio.com/js/client/v1.14/twilio.min.js"></script>
        <?php endif; ?>
        
        <script>
        jQuery(document).ready(function($) {
            var globalAudio = document.getElementById('ptp-global-audio');
            var currentPlayBtn = null;
            
            // Play button click
            $('.ptp-play-btn').on('click', function() {
                var $btn = $(this);
                var url = $btn.data('url');
                var $row = $btn.closest('.ptp-call-row');
                var $progressBar = $row.find('.ptp-audio-progress-bar');
                
                if ($btn.hasClass('playing')) {
                    globalAudio.pause();
                    $btn.removeClass('playing');
                } else {
                    if (currentPlayBtn) {
                        $(currentPlayBtn).removeClass('playing');
                    }
                    
                    globalAudio.src = url;
                    globalAudio.play();
                    $btn.addClass('playing');
                    currentPlayBtn = $btn[0];
                    
                    globalAudio.ontimeupdate = function() {
                        var progress = (globalAudio.currentTime / globalAudio.duration) * 100;
                        $progressBar.css('width', progress + '%');
                    };
                    
                    globalAudio.onended = function() {
                        $btn.removeClass('playing');
                        $progressBar.css('width', '0%');
                        currentPlayBtn = null;
                    };
                }
            });
            
            // Make call modal
            $('#ptp-make-call-btn').on('click', function() {
                $('#ptp-make-call-modal').fadeIn(200);
            });
            
            $('.ptp-modal-close').on('click', function() {
                $(this).closest('.ptp-modal').fadeOut(200);
            });
            
            $('.ptp-modal').on('click', function(e) {
                if (e.target === this) {
                    $(this).fadeOut(200);
                }
            });
            
            <?php if ($browser_client_enabled && $twilio_client_configured): ?>
            // ==========================================
            // TWILIO CLIENT (BROWSER SOFTPHONE)
            // ==========================================
            
            var twilioDevice = null;
            var currentCall = null;
            var callTimer = null;
            var callDuration = 0;
            var clientIdentity = null;
            
            // Initialize Twilio Device
            function initTwilioDevice() {
                updateStatus('Connecting...', '');
                
                $.get('<?php echo rest_url('ptp-comms/v1/client-token'); ?>', {
                    _wpnonce: '<?php echo wp_create_nonce('wp_rest'); ?>'
                })
                .done(function(response) {
                    if (response.success && response.token) {
                        clientIdentity = response.identity;
                        
                        twilioDevice = new Twilio.Device(response.token, {
                            codecPreferences: ['opus', 'pcmu'],
                            fakeLocalDTMF: true,
                            enableRingingState: true,
                            debug: true
                        });
                        
                        setupDeviceHandlers();
                    } else {
                        updateStatus('Setup Required', 'error');
                        console.error('Failed to get token:', response.error);
                    }
                })
                .fail(function(xhr, status, error) {
                    updateStatus('Connection Failed', 'error');
                    console.error('Token request failed:', error);
                });
            }
            
            // Setup Twilio Device event handlers
            function setupDeviceHandlers() {
                twilioDevice.on('ready', function(device) {
                    updateStatus('Ready', 'connected');
                    registerClient();
                    console.log('[PTP Softphone] Device ready');
                });
                
                twilioDevice.on('error', function(error) {
                    updateStatus('Error: ' + error.message, 'error');
                    console.error('[PTP Softphone] Device error:', error);
                });
                
                twilioDevice.on('connect', function(conn) {
                    currentCall = conn;
                    onCallConnected(conn);
                    console.log('[PTP Softphone] Call connected');
                });
                
                twilioDevice.on('disconnect', function(conn) {
                    currentCall = null;
                    onCallEnded();
                    console.log('[PTP Softphone] Call disconnected');
                });
                
                twilioDevice.on('incoming', function(conn) {
                    currentCall = conn;
                    onIncomingCall(conn);
                    console.log('[PTP Softphone] Incoming call from:', conn.parameters.From);
                });
                
                twilioDevice.on('cancel', function(conn) {
                    currentCall = null;
                    onCallEnded();
                    console.log('[PTP Softphone] Call cancelled');
                });
                
                twilioDevice.on('offline', function(device) {
                    updateStatus('Offline', '');
                    console.log('[PTP Softphone] Device offline');
                });
            }
            
            // Register client with server
            function registerClient() {
                if (clientIdentity) {
                    $.post('<?php echo rest_url('ptp-comms/v1/client-register'); ?>', {
                        identity: clientIdentity,
                        _wpnonce: '<?php echo wp_create_nonce('wp_rest'); ?>'
                    });
                }
            }
            
            // Unregister client on page unload
            $(window).on('beforeunload', function() {
                if (clientIdentity) {
                    navigator.sendBeacon(
                        '<?php echo rest_url('ptp-comms/v1/client-unregister'); ?>?identity=' + clientIdentity + '&_wpnonce=<?php echo wp_create_nonce('wp_rest'); ?>'
                    );
                }
            });
            
            // Update status indicator
            function updateStatus(text, className) {
                $('#ptp-status-text').text(text);
                $('#ptp-status-indicator').removeClass('connected error ringing').addClass(className);
            }
            
            // Handle incoming call
            function onIncomingCall(conn) {
                var callerNumber = conn.parameters.From || 'Unknown';
                var callerName = conn.customParameters ? conn.customParameters.get('callerName') : callerNumber;
                
                updateStatus('Incoming Call', 'ringing');
                $('#ptp-incoming-caller').text(callerName || 'Unknown Caller');
                $('#ptp-incoming-number').text(formatPhoneNumber(callerNumber));
                $('#ptp-incoming-call').slideDown();
                
                // Play ringtone (browser notification sound)
                playRingtone();
                
                // Browser notification
                if (Notification.permission === 'granted') {
                    new Notification('Incoming Call', {
                        body: callerName + '\n' + formatPhoneNumber(callerNumber),
                        icon: '<?php echo plugins_url('admin/images/phone-icon.png', dirname(__FILE__)); ?>',
                        requireInteraction: true
                    });
                }
            }
            
            // Handle call connected
            function onCallConnected(conn) {
                var otherParty = conn.parameters.To || conn.parameters.From || 'Unknown';
                var direction = conn.parameters.From ? 'Inbound Call' : 'Outbound Call';
                
                updateStatus('On Call', 'connected');
                $('#ptp-call-direction-label').text(direction);
                $('#ptp-active-caller').text(conn.customParameters ? conn.customParameters.get('callerName') : formatPhoneNumber(otherParty));
                $('#ptp-active-number').text(formatPhoneNumber(otherParty));
                
                $('#ptp-incoming-call').hide();
                $('#ptp-active-call').slideDown();
                $('#ptp-in-call-controls').css('display', 'flex');
                $('#ptp-call-duration').show();
                
                stopRingtone();
                startCallTimer();
            }
            
            // Handle call ended
            function onCallEnded() {
                updateStatus('Ready', 'connected');
                $('#ptp-incoming-call').slideUp();
                $('#ptp-active-call').slideUp();
                $('#ptp-in-call-controls').hide();
                $('#ptp-call-duration').hide().text('00:00');
                
                stopRingtone();
                stopCallTimer();
            }
            
            // Call timer
            function startCallTimer() {
                callDuration = 0;
                callTimer = setInterval(function() {
                    callDuration++;
                    var mins = Math.floor(callDuration / 60).toString().padStart(2, '0');
                    var secs = (callDuration % 60).toString().padStart(2, '0');
                    $('#ptp-call-duration').text(mins + ':' + secs);
                }, 1000);
            }
            
            function stopCallTimer() {
                if (callTimer) {
                    clearInterval(callTimer);
                    callTimer = null;
                }
                callDuration = 0;
            }
            
            // Ringtone (simple audio)
            var ringtoneAudio = null;
            function playRingtone() {
                // Use a simple ringtone
                if (!ringtoneAudio) {
                    ringtoneAudio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2MkZeYl4+Fc2ZjZGx1gIqPlpqYkYZ6bmNhZm92g46WmZaOgnVpYWFlbnqFkJeZl5CGemtjYGVud4OOlpmWjoJ2aWJhZW56hZCXmZeQhntrY2BlbneEjpaZlo6CdmliYWVueoWQl5mXkIZ7a2NgZW53hI6WmZaOgnZpYmFlbnqFkJeZl5CGe2tjYGVud4SOlpmWjoJ2aWJhZW56hZCXmZeQhntrY2BlbneEjpaZlo6CdmliYWVueoWQl5mXkIZ7a2NgZW53hI6WmZaOgnZpYmFlbnqF');
                }
                ringtoneAudio.loop = true;
                ringtoneAudio.play().catch(function(e) { console.log('Could not play ringtone'); });
            }
            
            function stopRingtone() {
                if (ringtoneAudio) {
                    ringtoneAudio.pause();
                    ringtoneAudio.currentTime = 0;
                }
            }
            
            // Format phone number
            function formatPhoneNumber(number) {
                if (!number) return 'Unknown';
                var cleaned = number.replace(/\D/g, '');
                if (cleaned.length === 11 && cleaned.startsWith('1')) {
                    return '+1 (' + cleaned.substr(1,3) + ') ' + cleaned.substr(4,3) + '-' + cleaned.substr(7,4);
                }
                if (cleaned.length === 10) {
                    return '(' + cleaned.substr(0,3) + ') ' + cleaned.substr(3,3) + '-' + cleaned.substr(6,4);
                }
                return number;
            }
            
            // Answer incoming call
            $('#ptp-answer-btn').on('click', function() {
                if (currentCall) {
                    currentCall.accept();
                }
            });
            
            // Reject incoming call
            $('#ptp-reject-btn').on('click', function() {
                if (currentCall) {
                    currentCall.reject();
                    currentCall = null;
                    onCallEnded();
                }
            });
            
            // Hang up call
            $('#ptp-hangup-btn').on('click', function() {
                if (currentCall) {
                    currentCall.disconnect();
                }
                if (twilioDevice) {
                    twilioDevice.disconnectAll();
                }
            });
            
            // Mute toggle
            $('#ptp-mute-btn').on('click', function() {
                if (currentCall) {
                    var isMuted = currentCall.isMuted();
                    currentCall.mute(!isMuted);
                    $(this).find('.dashicons')
                        .removeClass('dashicons-controls-volumeon dashicons-controls-volumeoff')
                        .addClass(isMuted ? 'dashicons-controls-volumeon' : 'dashicons-controls-volumeoff');
                    $(this).css('background', isMuted ? '#333' : '#dc3232');
                }
            });
            
            // Toggle dialer
            $('#ptp-toggle-dialer').on('click', function() {
                $('#ptp-dialer').slideToggle();
            });
            
            // Dial pad digits
            $('.ptp-dial-digit').on('click', function() {
                var digit = $(this).data('digit');
                var current = $('#ptp-dial-number').val();
                $('#ptp-dial-number').val(current + digit);
                
                // Send DTMF if on call
                if (currentCall) {
                    currentCall.sendDigits(digit.toString());
                }
            });
            
            // Backspace
            $('#ptp-dial-backspace').on('click', function() {
                var current = $('#ptp-dial-number').val();
                $('#ptp-dial-number').val(current.slice(0, -1));
            });
            
            // Make outbound call from dialer
            $('#ptp-dial-call').on('click', function() {
                var number = $('#ptp-dial-number').val().trim();
                if (number && twilioDevice) {
                    updateStatus('Calling...', '');
                    var params = { To: number };
                    twilioDevice.connect(params);
                }
            });
            
            // Request notification permission
            if (Notification.permission === 'default') {
                Notification.requestPermission();
            }
            
            // Initialize on page load
            initTwilioDevice();
            
            <?php endif; ?>
        });
        </script>
        <?php
    }
    
    /**
     * Handle make call form submission
     */
    private static function handle_make_call() {
        $to = sanitize_text_field($_POST['call_to']);
        $message = sanitize_textarea_field($_POST['call_message'] ?? '');
        $record = isset($_POST['record_call']);
        
        $voice_service = new PTP_Comms_Hub_Voice_Service();
        
        if (!empty($message)) {
            $result = $voice_service->make_call($to, $message, $record);
        } else {
            $result = $voice_service->make_ivr_call($to);
        }
        
        if ($result['success']) {
            add_settings_error('ptp_comms', 'call_initiated', 'Call initiated successfully! Call SID: ' . $result['sid'], 'success');
        } else {
            add_settings_error('ptp_comms', 'call_failed', 'Call failed: ' . $result['error'], 'error');
        }
    }
    
    /**
     * Render single call details
     */
    private static function render_call_details($call_id) {
        global $wpdb;
        
        $call = $wpdb->get_row($wpdb->prepare("
            SELECT l.*, 
                   c.parent_first_name, 
                   c.parent_last_name, 
                   c.parent_phone,
                   c.parent_email,
                   c.id as contact_id
            FROM {$wpdb->prefix}ptp_communication_logs l
            LEFT JOIN {$wpdb->prefix}ptp_contacts c ON l.contact_id = c.id
            WHERE l.id = %d
        ", $call_id));
        
        if (!$call) {
            echo '<div class="wrap"><div class="notice notice-error"><p>Call not found.</p></div></div>';
            return;
        }
        
        $call_data = json_decode($call->meta_data, true) ?: array();
        $duration = isset($call_data['duration']) ? intval($call_data['duration']) : 0;
        $recording_url = isset($call_data['recording_url']) ? $call_data['recording_url'] : '';
        $call_sid = isset($call_data['call_sid']) ? $call_data['call_sid'] : '';
        $contact_name = trim($call->parent_first_name . ' ' . $call->parent_last_name);
        if (empty($contact_name)) $contact_name = 'Unknown Caller';
        
        ?>
        <div class="wrap ptp-comms-admin">
            <div style="margin-bottom: 24px;">
                <a href="?page=ptp-comms-calls" class="button" style="margin-bottom: 16px;">
                    ← Back to Calls
                </a>
                <h1 style="display: flex; align-items: center; gap: 12px;">
                    <span class="dashicons dashicons-phone" style="font-size: 28px; color: #FCD116;"></span>
                    Call Details
                </h1>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 300px; gap: 24px;">
                <div>
                    <?php if ($recording_url): ?>
                    <div class="ptp-card" style="background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); color: #fff;">
                        <h3 style="margin-top: 0; color: #FCD116; display: flex; align-items: center; gap: 8px;">
                            <span class="dashicons dashicons-format-audio"></span>
                            Call Recording
                        </h3>
                        <audio controls style="width: 100%; margin-bottom: 16px;">
                            <source src="<?php echo esc_url($recording_url); ?>" type="audio/mpeg">
                        </audio>
                        <div style="display: flex; gap: 12px;">
                            <a href="<?php echo esc_url($recording_url); ?>" download class="button" style="background: #FCD116; border-color: #FCD116; color: #1a1a1a;">
                                <span class="dashicons dashicons-download" style="margin-top: 3px;"></span> Download Recording
                            </a>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="ptp-card">
                        <h3 style="margin-top: 0;">Call Information</h3>
                        <table class="form-table" style="margin: 0;">
                            <tr>
                                <th style="width: 150px;">Direction</th>
                                <td>
                                    <?php if ($call->direction === 'inbound'): ?>
                                        <span style="color: #46b450;">📥 Inbound</span>
                                    <?php else: ?>
                                        <span style="color: #f56e28;">📤 Outbound</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td><?php echo self::get_status_badge($call->status); ?></td>
                            </tr>
                            <tr>
                                <th>Duration</th>
                                <td><strong><?php echo $duration ? gmdate('i:s', $duration) . " ({$duration} seconds)" : 'N/A'; ?></strong></td>
                            </tr>
                            <tr>
                                <th>Date & Time</th>
                                <td><?php echo date('F j, Y \a\t g:i:s A', strtotime($call->created_at)); ?></td>
                            </tr>
                            <?php if ($call_sid): ?>
                            <tr>
                                <th>Call SID</th>
                                <td><code style="font-size: 11px;"><?php echo esc_html($call_sid); ?></code></td>
                            </tr>
                            <?php endif; ?>
                            <?php if ($call->message_type === 'voicemail' && !empty($call->message_content)): ?>
                            <tr>
                                <th>Transcription</th>
                                <td style="background: #f9f9f9; padding: 12px; border-radius: 6px;">
                                    <?php echo esc_html($call->message_content); ?>
                                </td>
                            </tr>
                            <?php endif; ?>
                        </table>
                    </div>
                </div>
                
                <div>
                    <div class="ptp-card">
                        <h3 style="margin-top: 0;">Contact</h3>
                        <div style="text-align: center; padding: 20px 0;">
                            <div style="width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%); margin: 0 auto 16px; display: flex; align-items: center; justify-content: center;">
                                <span style="font-size: 32px; color: #FCD116; font-weight: 700;">
                                    <?php echo strtoupper(substr($contact_name, 0, 1)); ?>
                                </span>
                            </div>
                            <h3 style="margin: 0 0 4px 0;"><?php echo esc_html($contact_name); ?></h3>
                            <p style="margin: 0; color: #666;">
                                <a href="tel:<?php echo esc_attr($call->parent_phone); ?>" style="color: #0073aa; text-decoration: none;">
                                    <?php echo esc_html(function_exists('ptp_comms_format_phone') ? ptp_comms_format_phone($call->parent_phone) : $call->parent_phone); ?>
                                </a>
                            </p>
                        </div>
                        
                        <div style="display: flex; gap: 8px; margin-top: 16px;">
                            <a href="tel:<?php echo esc_attr($call->parent_phone); ?>" class="button" style="flex: 1; text-align: center;">
                                <span class="dashicons dashicons-phone" style="margin-top: 3px;"></span> Call
                            </a>
                            <?php if ($call->contact_id): ?>
                            <a href="?page=ptp-comms-contacts&action=edit&id=<?php echo $call->contact_id; ?>" class="button" style="flex: 1; text-align: center;">
                                View Contact
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    private static function get_status_badge($status) {
        $badges = array(
            'completed' => '<span style="background: #d4edda; color: #155724; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">✓ Completed</span>',
            'initiated' => '<span style="background: #fff3cd; color: #856404; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">⏳ Initiated</span>',
            'ringing' => '<span style="background: #cce5ff; color: #004085; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">🔔 Ringing</span>',
            'in-progress' => '<span style="background: #cce5ff; color: #004085; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">📞 In Progress</span>',
            'busy' => '<span style="background: #fff3cd; color: #856404; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">Busy</span>',
            'no-answer' => '<span style="background: #f8d7da; color: #721c24; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">No Answer</span>',
            'failed' => '<span style="background: #f8d7da; color: #721c24; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">✗ Failed</span>',
            'canceled' => '<span style="background: #e2e3e5; color: #383d41; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">Canceled</span>',
            'new' => '<span style="background: #d1ecf1; color: #0c5460; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500;">New</span>',
        );
        
        return isset($badges[$status]) ? $badges[$status] : '<span style="background: #e2e3e5; color: #383d41; padding: 4px 12px; border-radius: 12px; font-size: 12px;">' . ucfirst($status) . '</span>';
    }
}
