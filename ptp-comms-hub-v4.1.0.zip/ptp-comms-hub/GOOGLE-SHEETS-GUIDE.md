# Google Sheets Integration Guide

## Overview

The Google Sheets integration allows you to:
- **Export** contacts, registrations, messages, and campaigns to a Google Spreadsheet
- **Import** contacts from a Google Spreadsheet
- **Auto-sync** data on a daily schedule
- View all your PTP Comms Hub data in a shareable spreadsheet

## Quick Setup

### Step 1: Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a new project or select an existing one
3. Name it something like "PTP Comms Hub"

### Step 2: Enable Google Sheets API

1. In Google Cloud Console, go to **APIs & Services → Library**
2. Search for "Google Sheets API"
3. Click **Enable**

### Step 3: Create OAuth Credentials

1. Go to **APIs & Services → Credentials**
2. Click **Create Credentials → OAuth client ID**
3. If prompted, configure the OAuth consent screen:
   - User Type: External
   - App name: PTP Comms Hub
   - User support email: Your email
   - Developer contact: Your email
   - Scopes: Add `https://www.googleapis.com/auth/spreadsheets`
4. For Application type, choose **Web application**
5. Add this Authorized redirect URI:
   ```
   https://your-site.com/wp-admin/admin.php?page=ptp-comms-settings&tab=google-sheets&google_callback=1
   ```
   (Replace `your-site.com` with your actual domain)
6. Click **Create**
7. Copy the **Client ID** and **Client Secret**

### Step 4: Configure in WordPress

1. Go to **PTP Comms Hub → Settings → Google Sheets**
2. Paste your Client ID and Client Secret
3. Click **Save All Settings**
4. Click **Connect to Google**
5. Authorize the app in Google's popup
6. You'll be redirected back with a success message

### Step 5: Export Your Data

1. Click **Export All Data** to sync everything
2. Or use individual export buttons for specific data
3. A new spreadsheet will be created automatically

## Features

### Export Options

| Button | What It Exports |
|--------|-----------------|
| Export All Data | Contacts, Registrations, Messages, Campaigns |
| Export Contacts Only | All contacts with phone, email, children, etc. |
| Export Registrations | Camp/event registrations with status |
| Export Messages | Recent SMS/WhatsApp messages (last 1000) |

### Import Contacts

You can add or update contacts by editing the Contacts sheet:

1. Open your Google Spreadsheet
2. Add rows to the Contacts sheet following the header format:
   - ID (leave blank for new)
   - First Name
   - Last Name
   - Phone (required, with country code)
   - Email
   - Child Name
   - Child Age
   - City
   - State
   - Zip
3. Click **Import Contacts** in WordPress
4. New contacts are created, existing ones updated (matched by phone)

### Auto-Sync

Enable automatic daily sync:
1. Check **Enable automatic daily sync** in settings
2. Save settings
3. Data exports automatically every 24 hours

## Spreadsheet Structure

The integration creates 4 sheets:

### Contacts Sheet
| Column | Description |
|--------|-------------|
| ID | Contact ID in database |
| First Name | Parent first name |
| Last Name | Parent last name |
| Phone | Phone number (E.164 format) |
| Email | Email address |
| Child Name | Child's name |
| Child Age | Child's age |
| City | City |
| State | State |
| Zip | ZIP code |
| Opted In | SMS opt-in status |
| Opted Out | SMS opt-out status |
| Source | How contact was acquired |
| Created | Date created |
| Updated | Last update date |

### Registrations Sheet
| Column | Description |
|--------|-------------|
| ID | Registration ID |
| Contact ID | Associated contact |
| Order ID | WooCommerce order ID |
| Product | Camp/event name |
| Event Date | Date of event |
| Event Location | Venue name |
| Child Name | Registered child |
| Status | Registration status |
| Created | Date created |

### Messages Sheet
| Column | Description |
|--------|-------------|
| ID | Message ID |
| Contact ID | Associated contact |
| Type | SMS, WhatsApp, Voice |
| Direction | Inbound/Outbound |
| Content | Message text (truncated) |
| Status | Delivery status |
| Twilio SID | Twilio message ID |
| Created | Timestamp |

### Campaigns Sheet
| Column | Description |
|--------|-------------|
| ID | Campaign ID |
| Name | Campaign name |
| Type | SMS, Voice, etc. |
| Status | Draft, Sending, Completed |
| Sent | Messages sent |
| Delivered | Messages delivered |
| Failed | Messages failed |
| Created | Date created |
| Completed | Date completed |

## Use Cases

### Reporting
- Create pivot tables for message analytics
- Track campaign performance over time
- Analyze contact growth trends

### Team Collaboration
- Share spreadsheet with staff
- Use Google Sheets comments for notes
- Set up automated alerts with Google Apps Script

### Data Backup
- Automatic off-site backup of all comms data
- Historical record of all interactions
- Easy data recovery if needed

### Analysis
- Use Google Sheets charts and graphs
- Connect to Google Data Studio
- Export to other tools

## Troubleshooting

### "Not authenticated" error
- Re-connect to Google from settings
- Check that credentials are correct
- Ensure redirect URI matches exactly

### Export fails
- Check Google Cloud API quota
- Verify spreadsheet ID is correct
- Look for errors in debug logs

### Import not working
- Phone number is required
- Use E.164 format (+12155551234)
- Check for duplicate phone numbers

### Token expired
- Tokens auto-refresh, but if issues persist
- Disconnect and reconnect to Google

## API Limits

Google Sheets API has usage limits:
- 100 requests per 100 seconds per user
- 500 requests per 100 seconds per project
- Large exports may take longer

The plugin handles rate limiting automatically.

## Security

- OAuth tokens stored securely in WordPress
- No Google password stored
- Tokens can be revoked anytime in Google Account
- Disconnect option removes all stored tokens
