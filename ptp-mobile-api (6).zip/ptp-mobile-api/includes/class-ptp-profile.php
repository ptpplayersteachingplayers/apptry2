<?php
if (!defined('ABSPATH')) exit;

class PTP_Profile_API {

    public function __construct() {
        register_rest_route(PTP_API_NAMESPACE, '/me', array(
            'methods' => array('GET', 'PUT'),
            'callback' => array($this, 'handle_profile'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/me', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_account'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/me/settings', array(
            'methods' => array('GET', 'PUT'),
            'callback' => array($this, 'handle_settings'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/me/password', array(
            'methods' => 'PUT',
            'callback' => array($this, 'change_password'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/me/events', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_events'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/parent/profile', array(
            'methods' => array('PUT', 'POST'),
            'callback' => array($this, 'update_parent_profile'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/profile', array(
            'methods' => 'POST',
            'callback' => array($this, 'save_onboarding'),
            'permission_callback' => array($this, 'is_auth'),
        ));
    }

    public function handle_profile($request) {
        $user = $this->get_user();

        if ($request->get_method() === 'GET') {
            return PTP_Auth_API::format_user($user);
        }

        // PUT - update
        $first = $request->get_param('firstName');
        $last = $request->get_param('lastName');
        $phone = $request->get_param('phone');

        if ($first || $last) {
            wp_update_user(array(
                'ID' => $user->ID,
                'first_name' => $first ?: get_user_meta($user->ID, 'first_name', true),
                'last_name' => $last ?: get_user_meta($user->ID, 'last_name', true),
                'display_name' => trim(($first ?: get_user_meta($user->ID, 'first_name', true)) . ' ' . ($last ?: get_user_meta($user->ID, 'last_name', true))),
            ));
        }

        if ($phone) {
            update_user_meta($user->ID, 'phone', sanitize_text_field($phone));
        }

        // Location
        $state = $request->get_param('preferredState');
        $city = $request->get_param('preferredCity');
        if ($state) update_user_meta($user->ID, 'preferred_state', sanitize_text_field($state));
        if ($city) update_user_meta($user->ID, 'preferred_city', sanitize_text_field($city));

        return PTP_Auth_API::format_user(get_user_by('ID', $user->ID));
    }

    public function handle_settings($request) {
        $user = $this->get_user();

        if ($request->get_method() === 'GET') {
            return array(
                'notificationsEnabled' => get_user_meta($user->ID, 'notifications_enabled', true) !== 'no',
                'emailNotifications' => get_user_meta($user->ID, 'email_notifications', true) !== 'no',
                'smsNotifications' => get_user_meta($user->ID, 'sms_notifications', true) === 'yes',
            );
        }

        // PUT
        $notif = $request->get_param('notificationsEnabled');
        $email = $request->get_param('emailNotifications');
        $sms = $request->get_param('smsNotifications');

        if ($notif !== null) update_user_meta($user->ID, 'notifications_enabled', $notif ? 'yes' : 'no');
        if ($email !== null) update_user_meta($user->ID, 'email_notifications', $email ? 'yes' : 'no');
        if ($sms !== null) update_user_meta($user->ID, 'sms_notifications', $sms ? 'yes' : 'no');

        return array('success' => true);
    }

    public function change_password($request) {
        $user = $this->get_user();
        $current = $request->get_param('currentPassword');
        $new = $request->get_param('newPassword');

        if (empty($current) || empty($new)) {
            return new WP_Error('missing', 'Current and new password required', array('status' => 400));
        }

        if (!wp_check_password($current, $user->user_pass, $user->ID)) {
            return new WP_Error('wrong_password', 'Current password is incorrect', array('status' => 400));
        }

        if (strlen($new) < 6) {
            return new WP_Error('weak', 'Password must be at least 6 characters', array('status' => 400));
        }

        wp_set_password($new, $user->ID);
        return array('success' => true);
    }

    public function get_events($request) {
        $user = $this->get_user();
        $start = sanitize_text_field($request->get_param('start')) ?: date('Y-m-d');
        $end = sanitize_text_field($request->get_param('end')) ?: date('Y-m-d', strtotime('+30 days'));

        $is_trainer = in_array('ptp_trainer', $user->roles) || in_array('trainer', $user->roles);
        $meta_key = $is_trainer ? '_trainer_id' : '_parent_id';

        $bookings = get_posts(array(
            'post_type' => 'ptp_booking',
            'posts_per_page' => 100,
            'meta_query' => array(
                array('key' => $meta_key, 'value' => $user->ID),
                array('key' => '_session_date', 'value' => array($start, $end), 'compare' => 'BETWEEN', 'type' => 'DATE'),
                array('key' => '_status', 'value' => array('pending', 'confirmed'), 'compare' => 'IN'),
            ),
        ));

        $events = array();
        foreach ($bookings as $b) {
            $events[] = array(
                'id' => $b->ID,
                'type' => 'training',
                'title' => 'Training Session',
                'date' => get_post_meta($b->ID, '_session_date', true),
                'time' => get_post_meta($b->ID, '_session_time', true),
                'status' => get_post_meta($b->ID, '_status', true),
            );
        }

        return array('events' => $events);
    }

    public function delete_account($request) {
        $user = $this->get_user();
        
        // Delete user's players
        $players = get_posts(array(
            'post_type' => 'ptp_player',
            'author' => $user->ID,
            'posts_per_page' => -1,
            'fields' => 'ids',
        ));
        foreach ($players as $pid) {
            wp_delete_post($pid, true);
        }

        // Delete user's bookings
        $bookings = get_posts(array(
            'post_type' => 'ptp_booking',
            'meta_query' => array(array('key' => '_parent_id', 'value' => $user->ID)),
            'posts_per_page' => -1,
            'fields' => 'ids',
        ));
        foreach ($bookings as $bid) {
            wp_delete_post($bid, true);
        }

        require_once(ABSPATH . 'wp-admin/includes/user.php');
        wp_delete_user($user->ID);

        return array('success' => true, 'message' => 'Account deleted');
    }

    public function update_parent_profile($request) {
        $user = $this->get_user();

        $first = $request->get_param('firstName');
        $last = $request->get_param('lastName');
        $phone = $request->get_param('phone');

        if ($first || $last) {
            wp_update_user(array(
                'ID' => $user->ID,
                'first_name' => $first ?: get_user_meta($user->ID, 'first_name', true),
                'last_name' => $last ?: get_user_meta($user->ID, 'last_name', true),
                'display_name' => trim(($first ?: get_user_meta($user->ID, 'first_name', true)) . ' ' . ($last ?: get_user_meta($user->ID, 'last_name', true))),
            ));
        }

        if ($phone) {
            update_user_meta($user->ID, 'phone', sanitize_text_field($phone));
            update_user_meta($user->ID, 'billing_phone', sanitize_text_field($phone));
        }

        $state = $request->get_param('preferredState');
        $city = $request->get_param('preferredCity');
        if ($state) update_user_meta($user->ID, 'preferred_state', sanitize_text_field($state));
        if ($city) update_user_meta($user->ID, 'preferred_city', sanitize_text_field($city));

        $interest = $request->get_param('mainInterest');
        if ($interest) update_user_meta($user->ID, 'main_interest', sanitize_text_field($interest));

        return array('success' => true, 'user' => PTP_Auth_API::format_user(get_user_by('ID', $user->ID)));
    }

    public function save_onboarding($request) {
        $user = $this->get_user();

        $first = $request->get_param('firstName');
        $last = $request->get_param('lastName');
        $phone = $request->get_param('phone');

        if ($first || $last) {
            wp_update_user(array(
                'ID' => $user->ID,
                'first_name' => $first ?: get_user_meta($user->ID, 'first_name', true),
                'last_name' => $last ?: get_user_meta($user->ID, 'last_name', true),
                'display_name' => trim(($first ?: '') . ' ' . ($last ?: '')),
            ));
        }

        if ($phone) {
            update_user_meta($user->ID, 'phone', sanitize_text_field($phone));
        }

        $state = $request->get_param('preferredState');
        $city = $request->get_param('preferredCity');
        if ($state) update_user_meta($user->ID, 'preferred_state', sanitize_text_field($state));
        if ($city) update_user_meta($user->ID, 'preferred_city', sanitize_text_field($city));

        $interest = $request->get_param('mainInterest');
        if ($interest) update_user_meta($user->ID, 'main_interest', sanitize_text_field($interest));

        // Mark onboarding complete
        update_user_meta($user->ID, 'onboarding_complete', 'yes');

        // Add children if provided
        $children = $request->get_param('children');
        if (is_array($children)) {
            foreach ($children as $child) {
                $player_id = wp_insert_post(array(
                    'post_type' => 'ptp_player',
                    'post_status' => 'publish',
                    'post_title' => sanitize_text_field($child['firstName'] ?? 'Player'),
                    'post_author' => $user->ID,
                ));

                if (!is_wp_error($player_id)) {
                    update_post_meta($player_id, '_first_name', sanitize_text_field($child['firstName'] ?? ''));
                    update_post_meta($player_id, '_last_name', sanitize_text_field($child['lastName'] ?? ''));
                    update_post_meta($player_id, '_age_band', sanitize_text_field($child['ageBand'] ?? ''));
                    update_post_meta($player_id, '_skill_level', sanitize_text_field($child['skillLevel'] ?? ''));
                    update_post_meta($player_id, '_position', sanitize_text_field($child['position'] ?? ''));
                }
            }
        }

        return array('success' => true, 'user' => PTP_Auth_API::format_user(get_user_by('ID', $user->ID)));
    }

    private function is_auth() { return $this->get_user() !== null; }

    private function get_user() {
        $auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (empty($auth)) $auth = isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '';
        if (empty($auth) || strpos($auth, 'Bearer ') !== 0) return null;

        $token = substr($auth, 7);
        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        $parts = explode('.', $token);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) return null;

        $data = json_decode(base64_decode($parts[0]), true);
        if (!$data || empty($data['uid']) || $data['exp'] < time()) return null;
        return get_user_by('ID', $data['uid']);
    }
}
