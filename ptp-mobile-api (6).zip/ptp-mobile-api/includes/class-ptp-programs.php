<?php
if (!defined('ABSPATH')) exit;

class PTP_Programs_API {

    public function __construct() {
        register_rest_route(PTP_API_NAMESPACE, '/programs', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_programs'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/programs/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_program'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/programs/featured', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_featured'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/programs/upcoming', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_upcoming'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/markets', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_markets'),
            'permission_callback' => '__return_true',
        ));
    }

    public function get_programs($request) {
        if (!function_exists('wc_get_product')) {
            return new WP_Error('woo_missing', 'WooCommerce not active', array('status' => 500));
        }

        $page = intval($request->get_param('page')) ?: 1;
        $per_page = intval($request->get_param('per_page')) ?: 20;
        $state = sanitize_text_field($request->get_param('state'));
        $market = sanitize_text_field($request->get_param('market'));
        $type = sanitize_text_field($request->get_param('type'));

        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            'paged' => $page,
            'meta_query' => array(),
            'orderby' => 'meta_value',
            'meta_key' => '_camp_date',
            'order' => 'ASC',
        );

        if ($state) {
            $args['meta_query'][] = array('key' => '_camp_state', 'value' => $state);
        }
        if ($market) {
            $args['meta_query'][] = array('key' => '_market_slug', 'value' => $market);
        }
        if ($type) {
            $terms = ($type === 'clinic') ? array('clinics', 'winter-clinics') : array('camps', 'summer-camps');
            $args['tax_query'] = array(array('taxonomy' => 'product_cat', 'field' => 'slug', 'terms' => $terms));
        }

        $query = new WP_Query($args);
        $programs = array();

        foreach ($query->posts as $post) {
            $product = wc_get_product($post->ID);
            if ($product) {
                $programs[] = $this->format_program($product);
            }
        }

        return array(
            'programs' => $programs,
            'total' => $query->found_posts,
            'page' => $page,
            'totalPages' => $query->max_num_pages,
        );
    }

    public function get_program($request) {
        if (!function_exists('wc_get_product')) {
            return new WP_Error('woo_missing', 'WooCommerce not active', array('status' => 500));
        }

        $product = wc_get_product(intval($request->get_param('id')));
        if (!$product) {
            return new WP_Error('not_found', 'Program not found', array('status' => 404));
        }

        return $this->format_program($product, true);
    }

    public function get_featured($request) {
        if (!function_exists('wc_get_product')) {
            return new WP_Error('woo_missing', 'WooCommerce not active', array('status' => 500));
        }

        $limit = intval($request->get_param('limit')) ?: 6;

        $query = new WP_Query(array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'meta_query' => array(
                array('key' => '_camp_date', 'value' => date('Y-m-d'), 'compare' => '>=', 'type' => 'DATE'),
            ),
            'orderby' => 'meta_value',
            'meta_key' => '_camp_date',
            'order' => 'ASC',
        ));

        $programs = array();
        foreach ($query->posts as $post) {
            $product = wc_get_product($post->ID);
            if ($product) {
                $programs[] = $this->format_program($product);
            }
        }

        return array('programs' => $programs);
    }

    public function get_upcoming($request) {
        return $this->get_featured($request);
    }

    public function get_markets() {
        global $wpdb;

        $results = $wpdb->get_results("
            SELECT DISTINCT meta_value as slug 
            FROM {$wpdb->postmeta} 
            WHERE meta_key = '_market_slug' 
            AND meta_value != ''
            ORDER BY meta_value ASC
        ");

        $markets = array();
        foreach ($results as $row) {
            $markets[] = array(
                'slug' => $row->slug,
                'name' => ucwords(str_replace('-', ' ', $row->slug)),
            );
        }

        return array('markets' => $markets);
    }

    private function format_program($product, $full = false) {
        $id = $product->get_id();

        $data = array(
            'id' => $id,
            'name' => $product->get_name(),
            'slug' => $product->get_slug(),
            'price' => floatval($product->get_price()),
            'regularPrice' => floatval($product->get_regular_price()),
            'salePrice' => $product->get_sale_price() ? floatval($product->get_sale_price()) : null,
            'onSale' => $product->is_on_sale(),
            'inStock' => $product->is_in_stock(),
            'imageUrl' => wp_get_attachment_url($product->get_image_id()),
            'date' => get_post_meta($id, '_camp_date', true),
            'endDate' => get_post_meta($id, '_camp_end_date', true),
            'time' => get_post_meta($id, '_camp_time', true),
            'location' => get_post_meta($id, '_camp_location', true),
            'venue' => get_post_meta($id, '_camp_venue', true),
            'city' => get_post_meta($id, '_camp_city', true),
            'state' => get_post_meta($id, '_camp_state', true),
            'market' => get_post_meta($id, '_market_slug', true),
        );

        if ($full) {
            $data['description'] = $product->get_description();
            $data['shortDescription'] = $product->get_short_description();
            $data['address'] = get_post_meta($id, '_camp_address', true);
            $data['ageBands'] = array_filter(array_map('trim', explode(',', get_post_meta($id, '_age_bands', true))));
            $data['whatToBring'] = array_filter(explode("\n", get_post_meta($id, '_what_to_bring', true)));
            $data['highlights'] = array_filter(explode("\n", get_post_meta($id, '_highlights', true)));
            $data['permalink'] = get_permalink($id);
        }

        return $data;
    }
}
