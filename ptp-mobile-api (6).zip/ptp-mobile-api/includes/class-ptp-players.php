<?php
if (!defined('ABSPATH')) exit;

class PTP_Players_API {

    public function __construct() {
        $this->register_routes();
    }

    public function register_routes() {
        register_rest_route(PTP_API_NAMESPACE, '/players', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_players'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/players', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'create_player'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_player'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods'             => 'PUT',
            'callback'            => array($this, 'update_player'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/players/(?P<id>\d+)', array(
            'methods'             => 'DELETE',
            'callback'            => array($this, 'delete_player'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));
    }

    public function get_players($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $query = new WP_Query(array(
            'post_type'      => 'ptp_player',
            'posts_per_page' => -1,
            'author'         => $user->ID,
            'post_status'    => 'publish',
        ));

        $players = array();
        foreach ($query->posts as $post) {
            $players[] = $this->format_player($post->ID);
        }
        return array('players' => $players);
    }

    public function create_player($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $first_name = sanitize_text_field($request->get_param('firstName'));
        $last_name  = sanitize_text_field($request->get_param('lastName'));

        if (empty($first_name)) {
            return new WP_Error('missing_name', 'First name required', array('status' => 400));
        }

        $player_id = wp_insert_post(array(
            'post_type'   => 'ptp_player',
            'post_status' => 'publish',
            'post_title'  => trim($first_name . ' ' . $last_name),
            'post_author' => $user->ID,
        ));

        if (is_wp_error($player_id)) {
            return new WP_Error('create_failed', 'Failed to create player', array('status' => 500));
        }

        update_post_meta($player_id, '_first_name', $first_name);
        update_post_meta($player_id, '_last_name', $last_name);
        update_post_meta($player_id, '_birth_date', sanitize_text_field($request->get_param('birthDate')));
        update_post_meta($player_id, '_skill_level', sanitize_text_field($request->get_param('skillLevel')));
        update_post_meta($player_id, '_position', sanitize_text_field($request->get_param('position')));
        update_post_meta($player_id, '_team', sanitize_text_field($request->get_param('team')));

        return array('success' => true, 'player' => $this->format_player($player_id));
    }

    public function get_player($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id   = absint($request->get_param('id'));
        $post = get_post($id);

        if (!$post || $post->post_type !== 'ptp_player' || $post->post_author != $user->ID) {
            return new WP_Error('not_found', 'Player not found', array('status' => 404));
        }

        return $this->format_player($id);
    }

    public function update_player($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id   = absint($request->get_param('id'));
        $post = get_post($id);

        if (!$post || $post->post_type !== 'ptp_player' || $post->post_author != $user->ID) {
            return new WP_Error('not_found', 'Player not found', array('status' => 404));
        }

        $fields = array('firstName' => '_first_name', 'lastName' => '_last_name', 'birthDate' => '_birth_date', 'skillLevel' => '_skill_level', 'position' => '_position', 'team' => '_team');

        foreach ($fields as $param => $meta_key) {
            $value = $request->get_param($param);
            if ($value !== null) {
                update_post_meta($id, $meta_key, sanitize_text_field($value));
            }
        }

        return array('success' => true, 'player' => $this->format_player($id));
    }

    public function delete_player($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id   = absint($request->get_param('id'));
        $post = get_post($id);

        if (!$post || $post->post_type !== 'ptp_player' || $post->post_author != $user->ID) {
            return new WP_Error('not_found', 'Player not found', array('status' => 404));
        }

        wp_delete_post($id, true);
        return array('success' => true);
    }

    private function is_authenticated() { return $this->get_user() !== null; }

    private function get_user() {
        $auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (empty($auth)) $auth = isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '';
        if (empty($auth) || strpos($auth, 'Bearer ') !== 0) return null;

        $token  = substr($auth, 7);
        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        $parts  = explode('.', $token);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) return null;

        $data = json_decode(base64_decode($parts[0]), true);
        if (!$data || empty($data['uid']) || $data['exp'] < time()) return null;
        return get_user_by('ID', $data['uid']);
    }

    private function format_player($id) {
        return array(
            'id'         => $id,
            'firstName'  => get_post_meta($id, '_first_name', true),
            'lastName'   => get_post_meta($id, '_last_name', true),
            'birthDate'  => get_post_meta($id, '_birth_date', true),
            'skillLevel' => get_post_meta($id, '_skill_level', true),
            'position'   => get_post_meta($id, '_position', true),
            'team'       => get_post_meta($id, '_team', true),
        );
    }
}
