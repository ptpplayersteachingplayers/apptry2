<?php
if (!defined('ABSPATH')) exit;

class PTP_Messages_API {

    public function __construct() {
        register_rest_route(PTP_API_NAMESPACE, '/conversations', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_conversations'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/conversations/start', array(
            'methods' => 'POST',
            'callback' => array($this, 'start_conversation'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/conversations/(?P<id>\d+)/messages', array(
            'methods' => array('GET', 'POST'),
            'callback' => array($this, 'handle_messages'),
            'permission_callback' => array($this, 'is_auth'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/conversations/(?P<id>\d+)/read', array(
            'methods' => 'POST',
            'callback' => array($this, 'mark_read'),
            'permission_callback' => array($this, 'is_auth'),
        ));
    }

    public function get_conversations() {
        $user = $this->get_user();
        
        $query = new WP_Query(array(
            'post_type' => 'ptp_conversation',
            'posts_per_page' => 50,
            'meta_query' => array(
                'relation' => 'OR',
                array('key' => '_participant_1', 'value' => $user->ID),
                array('key' => '_participant_2', 'value' => $user->ID),
            ),
        ));

        $convos = array();
        foreach ($query->posts as $post) {
            $p1 = get_post_meta($post->ID, '_participant_1', true);
            $p2 = get_post_meta($post->ID, '_participant_2', true);
            $other_id = ($p1 == $user->ID) ? $p2 : $p1;
            $other = get_user_by('ID', $other_id);

            $convos[] = array(
                'id' => $post->ID,
                'otherUser' => array(
                    'id' => $other_id,
                    'name' => $other ? $other->display_name : 'Unknown',
                    'avatar' => get_avatar_url($other_id),
                ),
                'lastMessage' => get_post_meta($post->ID, '_last_message', true),
                'lastMessageAt' => get_post_meta($post->ID, '_last_message_at', true),
                'unreadCount' => intval(get_post_meta($post->ID, '_unread_' . $user->ID, true)),
            );
        }

        return array('conversations' => $convos);
    }

    public function start_conversation($request) {
        $user = $this->get_user();
        $other_id = absint($request->get_param('userId'));

        if (!get_user_by('ID', $other_id)) {
            return new WP_Error('not_found', 'User not found', array('status' => 404));
        }

        // Check existing
        $existing = get_posts(array(
            'post_type' => 'ptp_conversation',
            'posts_per_page' => 1,
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'relation' => 'AND',
                    array('key' => '_participant_1', 'value' => $user->ID),
                    array('key' => '_participant_2', 'value' => $other_id),
                ),
                array(
                    'relation' => 'AND',
                    array('key' => '_participant_1', 'value' => $other_id),
                    array('key' => '_participant_2', 'value' => $user->ID),
                ),
            ),
        ));

        if (!empty($existing)) {
            return array('conversationId' => $existing[0]->ID);
        }

        $convo_id = wp_insert_post(array(
            'post_type' => 'ptp_conversation',
            'post_status' => 'publish',
            'post_title' => 'Conversation',
            'post_author' => $user->ID,
        ));

        update_post_meta($convo_id, '_participant_1', $user->ID);
        update_post_meta($convo_id, '_participant_2', $other_id);

        return array('conversationId' => $convo_id);
    }

    public function handle_messages($request) {
        $user = $this->get_user();
        $convo_id = absint($request->get_param('id'));

        $p1 = get_post_meta($convo_id, '_participant_1', true);
        $p2 = get_post_meta($convo_id, '_participant_2', true);

        if ($user->ID != $p1 && $user->ID != $p2) {
            return new WP_Error('forbidden', 'Not your conversation', array('status' => 403));
        }

        if ($request->get_method() === 'POST') {
            $content = sanitize_textarea_field($request->get_param('content'));
            if (empty($content)) {
                return new WP_Error('empty', 'Message cannot be empty', array('status' => 400));
            }

            $msg_id = wp_insert_post(array(
                'post_type' => 'ptp_message',
                'post_status' => 'publish',
                'post_content' => $content,
                'post_author' => $user->ID,
            ));

            update_post_meta($msg_id, '_conversation_id', $convo_id);
            update_post_meta($convo_id, '_last_message', wp_trim_words($content, 10));
            update_post_meta($convo_id, '_last_message_at', current_time('mysql'));

            $other_id = ($p1 == $user->ID) ? $p2 : $p1;
            $unread = intval(get_post_meta($convo_id, '_unread_' . $other_id, true));
            update_post_meta($convo_id, '_unread_' . $other_id, $unread + 1);

            return array('messageId' => $msg_id, 'success' => true);
        }

        // GET messages
        $messages = get_posts(array(
            'post_type' => 'ptp_message',
            'posts_per_page' => 100,
            'meta_query' => array(array('key' => '_conversation_id', 'value' => $convo_id)),
            'orderby' => 'date',
            'order' => 'ASC',
        ));

        $result = array();
        foreach ($messages as $msg) {
            $result[] = array(
                'id' => $msg->ID,
                'content' => $msg->post_content,
                'senderId' => $msg->post_author,
                'isMe' => $msg->post_author == $user->ID,
                'createdAt' => $msg->post_date,
            );
        }

        return array('messages' => $result);
    }

    public function mark_read($request) {
        $user = $this->get_user();
        $convo_id = absint($request->get_param('id'));
        update_post_meta($convo_id, '_unread_' . $user->ID, 0);
        return array('success' => true);
    }

    private function is_auth() { return $this->get_user() !== null; }

    private function get_user() {
        $auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (empty($auth)) $auth = isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '';
        if (empty($auth) || strpos($auth, 'Bearer ') !== 0) return null;

        $token = substr($auth, 7);
        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        $parts = explode('.', $token);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) return null;

        $data = json_decode(base64_decode($parts[0]), true);
        if (!$data || empty($data['uid']) || $data['exp'] < time()) return null;
        return get_user_by('ID', $data['uid']);
    }
}
