<?php
if (!defined('ABSPATH')) exit;

class PTP_Auth_API {

    public function __construct() {
        register_rest_route(PTP_API_NAMESPACE, '/auth/login', array(
            'methods' => 'POST',
            'callback' => array($this, 'login'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/auth/register', array(
            'methods' => 'POST',
            'callback' => array($this, 'register_user'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/auth/me', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_me'),
            'permission_callback' => array(__CLASS__, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/auth/forgot-password', array(
            'methods' => 'POST',
            'callback' => array($this, 'forgot_password'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/auth/fcm-token', array(
            'methods' => 'POST',
            'callback' => array($this, 'save_fcm'),
            'permission_callback' => array(__CLASS__, 'is_authenticated'),
        ));
    }

    public function login($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        $user = wp_authenticate($email, $password);

        if (is_wp_error($user)) {
            return new WP_Error('invalid_credentials', 'Invalid email or password', array('status' => 401));
        }

        return array(
            'token' => self::generate_token($user->ID),
            'user' => self::format_user($user),
        );
    }

    public function register_user($request) {
        $email = sanitize_email($request->get_param('email'));
        $password = $request->get_param('password');
        $first = sanitize_text_field($request->get_param('first_name'));
        $last = sanitize_text_field($request->get_param('last_name'));
        $phone = sanitize_text_field($request->get_param('phone'));
        $role = $request->get_param('role') ? sanitize_text_field($request->get_param('role')) : 'ptp_parent';

        if (email_exists($email)) {
            return new WP_Error('email_exists', 'Email already exists', array('status' => 400));
        }

        $user_id = wp_create_user($email, $password, $email);
        if (is_wp_error($user_id)) {
            return new WP_Error('failed', $user_id->get_error_message(), array('status' => 500));
        }

        wp_update_user(array('ID' => $user_id, 'first_name' => $first, 'last_name' => $last, 'display_name' => trim("$first $last")));
        update_user_meta($user_id, 'phone', $phone);

        $user = get_user_by('ID', $user_id);
        $user->set_role($role);

        return array(
            'token' => self::generate_token($user_id),
            'user' => self::format_user($user),
        );
    }

    public function get_me() {
        $user = self::get_user_from_token();
        return self::format_user($user);
    }

    public function forgot_password($request) {
        $email = sanitize_email($request->get_param('email'));
        if (get_user_by('email', $email)) {
            retrieve_password($email);
        }
        return array('success' => true, 'message' => 'If an account exists, a reset link was sent.');
    }

    public function save_fcm($request) {
        $user = self::get_user_from_token();
        update_user_meta($user->ID, 'fcm_token', sanitize_text_field($request->get_param('fcm_token')));
        update_user_meta($user->ID, 'fcm_device', sanitize_text_field($request->get_param('device_type')));
        return array('success' => true);
    }

    public static function generate_token($user_id) {
        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        $payload = base64_encode(json_encode(array(
            'iss' => get_site_url(),
            'iat' => time(),
            'exp' => time() + (30 * DAY_IN_SECONDS),
            'uid' => $user_id,
        )));
        return $payload . '.' . hash_hmac('sha256', $payload, $secret);
    }

    public static function validate_token($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 2) return false;

        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        if (!hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) return false;

        $data = json_decode(base64_decode($parts[0]), true);
        if (!$data || empty($data['uid']) || empty($data['exp']) || $data['exp'] < time()) return false;

        return $data['uid'];
    }

    public static function get_user_from_token() {
        $auth = '';
        if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['HTTP_AUTHORIZATION'];
        } elseif (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
            $auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
        }

        if (empty($auth) || strpos($auth, 'Bearer ') !== 0) return null;

        $user_id = self::validate_token(substr($auth, 7));
        return $user_id ? get_user_by('ID', $user_id) : null;
    }

    public static function is_authenticated() {
        return self::get_user_from_token() !== null;
    }

    public static function is_trainer() {
        $user = self::get_user_from_token();
        if (!$user) return false;
        return in_array('ptp_trainer', $user->roles) || in_array('trainer', $user->roles);
    }

    public static function format_user($user) {
        $id = $user->ID;
        $is_trainer = in_array('ptp_trainer', $user->roles) || in_array('trainer', $user->roles);

        $data = array(
            'id' => $id,
            'email' => $user->user_email,
            'firstName' => get_user_meta($id, 'first_name', true),
            'lastName' => get_user_meta($id, 'last_name', true),
            'phone' => get_user_meta($id, 'phone', true),
            'role' => $is_trainer ? 'trainer' : 'parent',
            'createdAt' => $user->user_registered,
        );

        if ($is_trainer) {
            $data['bio'] = get_user_meta($id, 'description', true);
            $data['hourlyRate'] = floatval(get_user_meta($id, 'trainer_hourly_rate', true));
            $data['rating'] = floatval(get_user_meta($id, 'trainer_rating', true));
            $data['reviewCount'] = intval(get_user_meta($id, 'trainer_review_count', true));
            $data['headshotUrl'] = get_user_meta($id, 'trainer_headshot', true);
            $data['collegePro'] = get_user_meta($id, 'trainer_education', true);
        }

        return $data;
    }
}
