<?php
if (!defined('ABSPATH')) exit;

class PTP_Bookings_API {

    public function __construct() {
        $this->register_routes();
    }

    public function register_routes() {
        register_rest_route(PTP_API_NAMESPACE, '/training/request', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'create_booking'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/training/my-sessions', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_my_sessions'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/training/sessions/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_session'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/training/sessions/(?P<id>\d+)/cancel', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'cancel_session'),
            'permission_callback' => array($this, 'is_authenticated'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/bookings/(?P<id>\d+)/confirm', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'confirm_booking'),
            'permission_callback' => array($this, 'is_trainer'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/bookings/(?P<id>\d+)/complete', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'complete_booking'),
            'permission_callback' => array($this, 'is_trainer'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/bookings/(?P<id>\d+)/cancel', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'trainer_cancel_booking'),
            'permission_callback' => array($this, 'is_trainer'),
        ));
    }

    public function create_booking($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $trainer_id = absint($request->get_param('trainerId'));
        $child_id   = absint($request->get_param('childId'));
        $date       = sanitize_text_field($request->get_param('date'));
        $time       = sanitize_text_field($request->get_param('time'));
        $location   = sanitize_text_field($request->get_param('location'));

        if (empty($trainer_id) || empty($child_id) || empty($date) || empty($time)) {
            return new WP_Error('missing_fields', 'Missing required fields', array('status' => 400));
        }

        $hourly_rate = get_user_meta($trainer_id, 'trainer_hourly_rate', true) ?: 80;

        $booking_id = wp_insert_post(array(
            'post_type'   => 'ptp_booking',
            'post_status' => 'publish',
            'post_title'  => sprintf('Session: %s', $date),
            'post_author' => $user->ID,
        ));

        if (is_wp_error($booking_id)) {
            return new WP_Error('create_failed', 'Failed to create booking', array('status' => 500));
        }

        update_post_meta($booking_id, '_trainer_id', $trainer_id);
        update_post_meta($booking_id, '_parent_id', $user->ID);
        update_post_meta($booking_id, '_child_id', $child_id);
        update_post_meta($booking_id, '_session_date', $date);
        update_post_meta($booking_id, '_session_time', $time);
        update_post_meta($booking_id, '_location', $location);
        update_post_meta($booking_id, '_price', $hourly_rate);
        update_post_meta($booking_id, '_status', 'pending');

        return array('success' => true, 'bookingId' => $booking_id);
    }

    public function get_my_sessions($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $is_trainer = in_array('ptp_trainer', $user->roles) || in_array('trainer', $user->roles);
        $meta_key   = $is_trainer ? '_trainer_id' : '_parent_id';

        $query = new WP_Query(array(
            'post_type'      => 'ptp_booking',
            'posts_per_page' => 50,
            'meta_query'     => array(array('key' => $meta_key, 'value' => $user->ID)),
        ));

        $sessions = array();
        foreach ($query->posts as $post) {
            $sessions[] = $this->format_booking($post->ID);
        }

        return array('sessions' => $sessions);
    }

    public function get_session($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id = absint($request->get_param('id'));
        $trainer_id = get_post_meta($id, '_trainer_id', true);
        $parent_id  = get_post_meta($id, '_parent_id', true);

        if ($user->ID != $trainer_id && $user->ID != $parent_id) {
            return new WP_Error('forbidden', 'Not your session', array('status' => 403));
        }

        return $this->format_booking($id);
    }

    public function cancel_session($request) {
        $user = $this->get_user();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id = absint($request->get_param('id'));
        if ($user->ID != get_post_meta($id, '_parent_id', true)) {
            return new WP_Error('forbidden', 'Not your session', array('status' => 403));
        }

        update_post_meta($id, '_status', 'cancelled');
        return array('success' => true);
    }

    public function confirm_booking($request) {
        $user = $this->get_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id = absint($request->get_param('id'));
        if ($user->ID != get_post_meta($id, '_trainer_id', true)) {
            return new WP_Error('forbidden', 'Not your booking', array('status' => 403));
        }

        update_post_meta($id, '_status', 'confirmed');
        return array('success' => true);
    }

    public function complete_booking($request) {
        $user = $this->get_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id = absint($request->get_param('id'));
        if ($user->ID != get_post_meta($id, '_trainer_id', true)) {
            return new WP_Error('forbidden', 'Not your booking', array('status' => 403));
        }

        update_post_meta($id, '_status', 'completed');
        return array('success' => true);
    }

    public function trainer_cancel_booking($request) {
        $user = $this->get_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $id = absint($request->get_param('id'));
        if ($user->ID != get_post_meta($id, '_trainer_id', true)) {
            return new WP_Error('forbidden', 'Not your booking', array('status' => 403));
        }

        $reason = sanitize_text_field($request->get_param('reason'));
        update_post_meta($id, '_status', 'cancelled');
        update_post_meta($id, '_cancel_reason', $reason);
        update_post_meta($id, '_cancelled_by', 'trainer');

        return array('success' => true);
    }

    private function is_authenticated() { return $this->get_user() !== null; }
    private function is_trainer() { return $this->get_trainer() !== null; }

    private function get_user() {
        $auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (empty($auth)) $auth = isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '';
        if (empty($auth) || strpos($auth, 'Bearer ') !== 0) return null;

        $token  = substr($auth, 7);
        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        $parts  = explode('.', $token);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) return null;

        $data = json_decode(base64_decode($parts[0]), true);
        if (!$data || empty($data['uid']) || $data['exp'] < time()) return null;
        return get_user_by('ID', $data['uid']);
    }

    private function get_trainer() {
        $user = $this->get_user();
        if (!$user || (!in_array('ptp_trainer', $user->roles) && !in_array('trainer', $user->roles))) return null;
        return $user;
    }

    private function format_booking($id) {
        return array(
            'id'       => $id,
            'status'   => get_post_meta($id, '_status', true),
            'date'     => get_post_meta($id, '_session_date', true),
            'time'     => get_post_meta($id, '_session_time', true),
            'location' => get_post_meta($id, '_location', true),
            'price'    => (float) get_post_meta($id, '_price', true),
            'trainerId'=> get_post_meta($id, '_trainer_id', true),
            'parentId' => get_post_meta($id, '_parent_id', true),
            'childId'  => get_post_meta($id, '_child_id', true),
        );
    }
}
