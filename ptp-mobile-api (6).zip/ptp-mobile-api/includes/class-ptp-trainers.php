<?php
if (!defined('ABSPATH')) exit;

class PTP_Trainers_API {

    public function __construct() {
        $this->register_routes();
    }

    public function register_routes() {
        register_rest_route(PTP_API_NAMESPACE, '/trainers', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_trainers'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainers/(?P<id>\d+)', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_trainer'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainers/(?P<id>\d+)/availability', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_availability'),
            'permission_callback' => '__return_true',
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainer/bookings', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_trainer_bookings'),
            'permission_callback' => array($this, 'is_trainer'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainer/stats', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_trainer_stats'),
            'permission_callback' => array($this, 'is_trainer'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainer/earnings', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_trainer_earnings'),
            'permission_callback' => array($this, 'is_trainer'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainer/players', array(
            'methods'             => 'GET',
            'callback'            => array($this, 'get_trainer_players'),
            'permission_callback' => array($this, 'is_trainer'),
        ));

        register_rest_route(PTP_API_NAMESPACE, '/trainer/profile', array(
            'methods'             => array('PUT', 'POST'),
            'callback'            => array($this, 'update_trainer_profile'),
            'permission_callback' => array($this, 'is_trainer'),
        ));
    }

    public function get_trainers($request) {
        $page     = max(1, absint($request->get_param('page')));
        $per_page = min(50, max(1, absint($request->get_param('per_page')) ?: 20));

        $query = new WP_User_Query(array(
            'role__in' => array('ptp_trainer', 'trainer'),
            'number'   => $per_page,
            'paged'    => $page,
        ));

        $trainers = array();
        foreach ($query->get_results() as $user) {
            $trainers[] = $this->format_trainer($user);
        }

        return array(
            'trainers'    => $trainers,
            'total'       => $query->get_total(),
            'page'        => $page,
            'total_pages' => ceil($query->get_total() / $per_page),
        );
    }

    public function get_trainer($request) {
        $user = get_user_by('ID', absint($request->get_param('id')));
        if (!$user || (!in_array('ptp_trainer', $user->roles) && !in_array('trainer', $user->roles))) {
            return new WP_Error('not_found', 'Trainer not found', array('status' => 404));
        }
        return $this->format_trainer($user, true);
    }

    public function get_availability($request) {
        $id = absint($request->get_param('id'));
        $availability = get_user_meta($id, 'trainer_availability', true);
        return array('trainerId' => $id, 'availability' => is_array($availability) ? $availability : array());
    }

    public function get_trainer_bookings($request) {
        $user = $this->get_current_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $query = new WP_Query(array(
            'post_type'      => 'ptp_booking',
            'posts_per_page' => 50,
            'meta_query'     => array(array('key' => '_trainer_id', 'value' => $user->ID)),
        ));

        $bookings = array();
        foreach ($query->posts as $post) {
            $bookings[] = array(
                'id'     => $post->ID,
                'status' => get_post_meta($post->ID, '_status', true),
                'date'   => get_post_meta($post->ID, '_session_date', true),
                'time'   => get_post_meta($post->ID, '_session_time', true),
            );
        }
        return array('bookings' => $bookings);
    }

    public function get_trainer_stats($request) {
        $user = $this->get_current_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $completed = get_posts(array(
            'post_type' => 'ptp_booking',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array(
                array('key' => '_trainer_id', 'value' => $user->ID),
                array('key' => '_status', 'value' => 'completed'),
            ),
        ));

        $pending = get_posts(array(
            'post_type' => 'ptp_booking',
            'posts_per_page' => -1,
            'fields' => 'ids',
            'meta_query' => array(
                array('key' => '_trainer_id', 'value' => $user->ID),
                array('key' => '_status', 'value' => 'pending'),
            ),
        ));

        return array(
            'rating' => (float) get_user_meta($user->ID, 'trainer_rating', true) ?: 5.0,
            'reviewCount' => (int) get_user_meta($user->ID, 'trainer_review_count', true),
            'completedSessions' => count($completed),
            'pendingBookings' => count($pending),
        );
    }

    public function get_trainer_earnings($request) {
        $user = $this->get_current_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $completed = get_posts(array(
            'post_type' => 'ptp_booking',
            'posts_per_page' => -1,
            'meta_query' => array(
                array('key' => '_trainer_id', 'value' => $user->ID),
                array('key' => '_status', 'value' => 'completed'),
            ),
        ));

        $total = 0;
        $this_month = 0;
        $current_month = date('Y-m');

        foreach ($completed as $booking) {
            $price = (float) get_post_meta($booking->ID, '_price', true);
            $total += $price;
            
            $date = get_post_meta($booking->ID, '_session_date', true);
            if (strpos($date, $current_month) === 0) {
                $this_month += $price;
            }
        }

        return array(
            'totalEarnings' => $total,
            'thisMonth' => $this_month,
            'completedSessions' => count($completed),
        );
    }

    public function get_trainer_players($request) {
        $user = $this->get_current_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $bookings = get_posts(array(
            'post_type' => 'ptp_booking',
            'posts_per_page' => -1,
            'meta_query' => array(
                array('key' => '_trainer_id', 'value' => $user->ID),
            ),
        ));

        $player_ids = array();
        foreach ($bookings as $booking) {
            $child_id = get_post_meta($booking->ID, '_child_id', true);
            if ($child_id && !in_array($child_id, $player_ids)) {
                $player_ids[] = $child_id;
            }
        }

        $players = array();
        foreach ($player_ids as $pid) {
            $post = get_post($pid);
            if ($post) {
                $players[] = array(
                    'id' => $pid,
                    'firstName' => get_post_meta($pid, '_first_name', true) ?: $post->post_title,
                    'lastName' => get_post_meta($pid, '_last_name', true),
                    'ageBand' => get_post_meta($pid, '_age_band', true),
                    'skillLevel' => get_post_meta($pid, '_skill_level', true),
                );
            }
        }

        return array('players' => $players);
    }

    public function update_trainer_profile($request) {
        $user = $this->get_current_trainer();
        if (!$user) return new WP_Error('unauthorized', 'Not authorized', array('status' => 401));

        $fields = array(
            'bio' => 'description',
            'hourlyRate' => 'trainer_hourly_rate',
            'location' => 'trainer_location',
            'teachingStyle' => 'trainer_teaching_style',
            'specializations' => 'trainer_specializations',
            'education' => 'trainer_education',
            'headshot' => 'trainer_headshot',
        );

        foreach ($fields as $param => $meta_key) {
            $value = $request->get_param($param);
            if ($value !== null) {
                update_user_meta($user->ID, $meta_key, sanitize_text_field($value));
            }
        }

        $first = $request->get_param('firstName');
        $last = $request->get_param('lastName');
        if ($first || $last) {
            wp_update_user(array(
                'ID' => $user->ID,
                'first_name' => $first ?: get_user_meta($user->ID, 'first_name', true),
                'last_name' => $last ?: get_user_meta($user->ID, 'last_name', true),
            ));
        }

        $availability = $request->get_param('availability');
        if ($availability && is_array($availability)) {
            update_user_meta($user->ID, 'trainer_availability', $availability);
        }

        return $this->format_trainer(get_user_by('ID', $user->ID), true);
    }

    private function is_trainer() {
        return $this->get_current_trainer() !== null;
    }

    private function get_current_trainer() {
        $auth = isset($_SERVER['HTTP_AUTHORIZATION']) ? $_SERVER['HTTP_AUTHORIZATION'] : '';
        if (empty($auth)) $auth = isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']) ? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] : '';
        if (empty($auth) || strpos($auth, 'Bearer ') !== 0) return null;

        $token  = substr($auth, 7);
        $secret = defined('JWT_AUTH_SECRET_KEY') ? JWT_AUTH_SECRET_KEY : wp_salt('auth');
        $parts  = explode('.', $token);
        if (count($parts) !== 2 || !hash_equals(hash_hmac('sha256', $parts[0], $secret), $parts[1])) return null;

        $data = json_decode(base64_decode($parts[0]), true);
        if (!$data || empty($data['uid']) || $data['exp'] < time()) return null;

        $user = get_user_by('ID', $data['uid']);
        if (!$user || (!in_array('ptp_trainer', $user->roles) && !in_array('trainer', $user->roles))) return null;
        return $user;
    }

    private function format_trainer($user, $full = false) {
        $id = $user->ID;
        $data = array(
            'id'          => $id,
            'firstName'   => get_user_meta($id, 'first_name', true),
            'lastName'    => get_user_meta($id, 'last_name', true),
            'collegePro'  => get_user_meta($id, 'trainer_education', true),
            'location'    => get_user_meta($id, 'trainer_location', true),
            'hourlyRate'  => (float) get_user_meta($id, 'trainer_hourly_rate', true),
            'rating'      => (float) get_user_meta($id, 'trainer_rating', true),
            'reviewCount' => (int) get_user_meta($id, 'trainer_review_count', true),
            'headshotUrl' => get_user_meta($id, 'trainer_headshot', true) ?: get_avatar_url($id, array('size' => 400)),
        );
        if ($full) {
            $data['bio']         = get_user_meta($id, 'description', true);
            $data['specialties'] = get_user_meta($id, 'trainer_specializations', true);
        }
        return $data;
    }
}
