<?php
/**
 * Plugin Name: PTP Mobile API
 * Description: REST API backend for the PTP Soccer mobile app.
 * Version: 1.0.0
 * Author: PTP Soccer
 */

if (!defined('ABSPATH')) exit;

define('PTP_API_VERSION', '1.0.0');
define('PTP_API_PATH', plugin_dir_path(__FILE__));
define('PTP_API_NAMESPACE', 'ptp/v1');

// Load class files
add_action('plugins_loaded', function() {
    $files = array(
        'class-ptp-auth.php',
        'class-ptp-programs.php',
        'class-ptp-trainers.php',
        'class-ptp-bookings.php',
        'class-ptp-players.php',
        'class-ptp-messages.php',
        'class-ptp-profile.php',
    );
    foreach ($files as $file) {
        $path = PTP_API_PATH . 'includes/' . $file;
        if (file_exists($path)) {
            require_once $path;
        }
    }
});

// Register REST routes
add_action('rest_api_init', function() {
    // Health check
    register_rest_route(PTP_API_NAMESPACE, '/health', array(
        'methods' => 'GET',
        'callback' => function() {
            return array('status' => 'ok', 'version' => PTP_API_VERSION);
        },
        'permission_callback' => '__return_true',
    ));

    // Debug endpoint
    register_rest_route(PTP_API_NAMESPACE, '/debug', array(
        'methods' => 'GET',
        'callback' => function() {
            global $wpdb;
            $wc_active = class_exists('WooCommerce');
            $product_count = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status = 'publish'");
            
            return array(
                'woocommerce_active' => $wc_active,
                'wc_get_product_exists' => function_exists('wc_get_product'),
                'published_products_count' => (int) $product_count,
                'php_version' => PHP_VERSION,
                'wp_version' => get_bloginfo('version'),
            );
        },
        'permission_callback' => '__return_true',
    ));

    // Init classes
    if (class_exists('PTP_Auth_API')) new PTP_Auth_API();
    if (class_exists('PTP_Programs_API')) new PTP_Programs_API();
    if (class_exists('PTP_Trainers_API')) new PTP_Trainers_API();
    if (class_exists('PTP_Bookings_API')) new PTP_Bookings_API();
    if (class_exists('PTP_Players_API')) new PTP_Players_API();
    if (class_exists('PTP_Messages_API')) new PTP_Messages_API();
    if (class_exists('PTP_Profile_API')) new PTP_Profile_API();
});

// Register post types
add_action('init', function() {
    register_post_type('ptp_player', array('public' => false, 'supports' => array('title', 'author')));
    register_post_type('ptp_booking', array('public' => false, 'supports' => array('title', 'author')));
    register_post_type('ptp_conversation', array('public' => false, 'supports' => array('title', 'author')));
    register_post_type('ptp_message', array('public' => false, 'supports' => array('content', 'author')));

    if (!get_role('ptp_trainer')) {
        add_role('ptp_trainer', 'PTP Trainer', array('read' => true));
    }
    if (!get_role('ptp_parent')) {
        add_role('ptp_parent', 'PTP Parent', array('read' => true));
    }
});

// CORS
add_action('rest_api_init', function() {
    remove_filter('rest_pre_serve_request', 'rest_send_cors_headers');
    add_filter('rest_pre_serve_request', function($value) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Authorization, Content-Type');
        return $value;
    });
}, 15);

// Admin page
add_action('admin_menu', function() {
    add_menu_page('PTP API', 'PTP API', 'manage_options', 'ptp-api', function() {
        echo '<div class="wrap"><h1>PTP Mobile API</h1>';
        echo '<p>Base URL: <code>' . esc_url(rest_url(PTP_API_NAMESPACE)) . '</code></p>';
        echo '<p><a href="' . esc_url(rest_url(PTP_API_NAMESPACE . '/health')) . '" class="button" target="_blank">Test API</a></p>';
        echo '</div>';
    }, 'dashicons-smartphone', 30);
});
